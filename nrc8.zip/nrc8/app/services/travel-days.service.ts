import { Injectable } from '@angular/core';

import { TravelDays } from '../models/TravelDays';
import { NrcService } from '../services/nrc.service';
import { ReportFilterContext } from "../models/ReportHeader";
import { ColumnSetting } from '../services/activ-travel.service';

@Injectable()
export class TravelDaysService {
  public TravelDays = new Array<TravelDays>()
  constructor(private nrcService: NrcService) { }

  getTravelDays(filterContext: ReportFilterContext): Promise<any> {
    let queryString = this.getQueryString(filterContext);
    return this.nrcService.getTravelDays(queryString);
  }

  mappingData(res) {
    //remove the old and add the new 
    this.TravelDays = [];

    let count = 0;
    var tempCountryArray = [];
    Object.keys(res.Result).forEach(function (keyRegion) {
      let countrysInRegions = res.Result[keyRegion];
      var tempCountryObject = countrysInRegions.countries;
      var tempRegion = countrysInRegions.region;

      Object.keys(tempCountryObject).forEach(function (key) {
        if (tempCountryObject[key]) {
          var country = tempCountryObject[key].country;
          var riskRating = tempCountryObject[key].riskRating;
          var travelDays = tempCountryObject[key].travelDays;
          var tempitem = { tempRegion, country, riskRating, travelDays };
          tempCountryArray.push(tempitem);
        }
      });
    });

    for (var j = 0; j < tempCountryArray.length; j++) {
      let temp = new TravelDays();
      temp.id = count;
      temp.index = count;
      count = count + 1;
      temp.isdrilldown = false;
      temp.isexpand = false;

      temp.countries = tempCountryArray[j].country;
      temp.riskRating = tempCountryArray[j].riskRating;
      temp.travelDays = tempCountryArray[j].travelDays;
      temp.region = tempCountryArray[j].tempRegion;
      this.TravelDays.push(temp);
    }
    return this.TravelDays;
  }

  getQueryString(filterContext: ReportFilterContext): string {
    let queryString: string = '';
    if (filterContext) {
      let tmp = [];
      if (filterContext.hasTimeRange && filterContext.dateFrom && filterContext.dateFrom.length) tmp.push(`startdate=${filterContext.dateFrom[0]}`);
      if (filterContext.hasTimeRange && filterContext.dateTo && filterContext.dateTo.length) tmp.push(`enddate=${filterContext.dateTo[0]}`);
      if (filterContext.hasRegion && filterContext.selectedRegions && filterContext.selectedRegions.length) tmp.push(`region=${filterContext.selectedRegions.join(',')}`);
      if (filterContext.hasCountry && filterContext.selectedCountries && filterContext.selectedCountries.length) tmp.push(`country=${filterContext.selectedCountries.join(',')}`);
      if (filterContext.hasRiskRating && filterContext.selectedRiskRatings && filterContext.selectedRiskRatings.length) tmp.push(`riskrating=${filterContext.selectedRiskRatings.join(',')}`);

      queryString = tmp.join('&');
      if (queryString) queryString = '?' + queryString;
    }
    return queryString;
  }

  public fullColumns: ColumnSetting[] = [
    {
      field: 'region',
      title: 'Region',
      index: 0,
      type: 'text'
    }, {
      field: 'countries',
      title: 'Country',
      index: 1,
      type: 'text'
    }, {
      field: 'riskRating',
      title: 'Risk Rating',
      index: 2,
      type: 'text'
    }, {
      field: 'travelDays',
      title: 'Days',
      index: 3,
      type: 'text'
    }
  ];

  public mobileColumns: ColumnSetting[] = [
    {
      field: 'region',
      title: 'Region',
      index: 0,
      type: 'text'
    }, {
      field: 'countries',
      title: 'Country',
      index: 1,
      type: 'text'
    }, {
      field: 'riskRating',
      title: 'Risk Rating',
      index: 2,
      type: 'text'
    }, {
      field: 'travelDays',
      title: 'Days',
      index: 3,
      type: 'date'
    }
  ];
}
