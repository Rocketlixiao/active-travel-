import { Injectable } from '@angular/core';
import { ArticleSort } from '../models/ArticleSort';
import { AssetSort } from '../models/AssetSort';
import { AssetIntelSort } from '../models/AssetIntelSort';

@Injectable()
export class SortService {

  private _articleListCurrentSort='';

  setArticleListCurrentSort(val) {
    this._articleListCurrentSort = val;
  }

  getArticleListCurrentSort() {
    return this._articleListCurrentSort;
  }

  private _assetsListCurrentSort = '';

  setAssetsListCurrentSort(val) {
    this._assetsListCurrentSort = val;
  }

  getAssetsListCurrentSort() {
    return this._assetsListCurrentSort;
  }

  constructor() { }

  getArticleSort(order: string) {
    let articleSort = new ArticleSort();
    switch (order) {
      case 'ImpactedAssets':
        articleSort.sortA = '-HasImpactedAssets';
        articleSort.sortB = '-severity';
        articleSort.sortC = '-ImpactedAssets';
        articleSort.sortD = '-timestamp';
        break;
      case 'severity':
        articleSort.sortA = 'invalid';
        articleSort.sortB = '-severity';
        articleSort.sortC = '-ImpactedAssets';
        articleSort.sortD = '-timestamp';
        break;
      case 'timestamp':
        articleSort.sortA = 'invalid';
        articleSort.sortB = '-timestamp';
        articleSort.sortC = '-ImpactedAssets';
        articleSort.sortD = '-severity';
        break;
      case '-timestamp':
        articleSort.sortA = 'invalid';
        articleSort.sortB = 'timestamp';
        articleSort.sortC = '-ImpactedAssets';
        articleSort.sortD = '-severity';
        break;
    }

    return articleSort;
  }

  getAssetSort(order: string) {
    let assetSort = new AssetSort();
    switch (order) {
      case '-sortProximityStatus':
        assetSort.sortA = '-sortProximityStatus';
        assetSort.sortB = 'type';
        assetSort.sortC = 'locationName';
        break;
      case 'ordertype':
        assetSort.sortA = 'type';
        assetSort.sortB = '-sortProximityStatus';
        assetSort.sortC = 'locationName';
        break;
      case 'name':
        assetSort.sortA = 'locationName';
        assetSort.sortB = '-sortProximityStatus';
        assetSort.sortC = 'type';
        break;
    }

    return assetSort;
  }

  getAssetIntelSort(order: string) {
    let assetIntelSort = new AssetIntelSort();
    switch (order) {
      case '-severity':
        assetIntelSort.sortA = '-severity';
        assetIntelSort.sortB = 'DistanceToAssetNumber';
        assetIntelSort.sortC = '-timestamp';
        break;
      case 'DistanceToAsset':
        assetIntelSort.sortA = 'DistanceToAssetNumber';
        assetIntelSort.sortB = '-severity';
        assetIntelSort.sortC = '-timestamp';
        break;
      case '-timestamp':
        assetIntelSort.sortA = '-timestamp';
        assetIntelSort.sortB = '-severity';
        assetIntelSort.sortC = 'DistanceToAssetNumber';
        break;
    }

    return assetIntelSort;
  }

}
