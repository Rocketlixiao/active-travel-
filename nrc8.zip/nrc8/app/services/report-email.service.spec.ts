import { TestBed, inject } from '@angular/core/testing';

import { ReportEmailService } from './report-email.service';

describe('ReportEmailService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReportEmailService]
    });
  });

  it('should be created', inject([ReportEmailService], (service: ReportEmailService) => {
    expect(service).toBeTruthy();
  }));
});
