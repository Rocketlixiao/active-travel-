import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { ReportFilterContext, ReportMySavedReportContext, SavedReport, ReportSaveReportContext, ReportRouteFactory } from "../models/ReportHeader";
import { NrcService } from "./nrc.service";
import { SharedService } from "./shared.service";

declare var globalConfig: any;

@Injectable()
export class ReportFilterService {
    constructor(private reportRouteFactory: ReportRouteFactory,
        private nrcService: NrcService,
        private sharedService: SharedService) { }

    upsetSavedReport(pagePath: string, saveReportContent: ReportSaveReportContext, fields: Array<{ isChecked: boolean, name: string }>, mySavedReport: ReportMySavedReportContext) {
        let reportType = this.reportRouteFactory.getLabel2ByKey(pagePath);
        if (reportType) {
            let filterContent = saveReportContent.filter;
            let report = this.findReportById(saveReportContent.reportId, mySavedReport);

            this.deleteDuplicateReportByName(mySavedReport, saveReportContent);
            if (!report) {
                report = {
                    ReportID: this.sharedService.generateGUID(),
                    UID: globalConfig.settingsData.UserId || '',
                    ReportName: saveReportContent.reportName,
                    ReportType: reportType,
                    Filters: [],
                    ViewFields: []
                } as SavedReport;
                mySavedReport.reports.push(report);
            }

            report.ReportName = saveReportContent.reportName;
            report.ViewFields = [];
            fields.forEach(c => { if (c.isChecked) report.ViewFields.push(c.name); });
            this.mapReportFilters(filterContent, report);
        }
    }

    mapFilterContent(savedReport: SavedReport, filterContent: ReportFilterContext, keepValue?: boolean): ReportFilterContext {
        if (!filterContent) filterContent = new ReportFilterContext();

        if (!keepValue) {
            filterContent.dateFrom = [];
            filterContent.dateTo = [];
            filterContent.selectedRegions = [];
            filterContent.selectedCities = [];
            filterContent.selectedCountries = [];
            filterContent.selectedRiskRatings = [];
            filterContent.selectedAirports = [];
            filterContent.selectedSegmentTypes = [];
            filterContent.selectedOrganizations = [];
            filterContent.selectedMinPassenger = [];
        }

        if (savedReport.Filters) {
            savedReport.Filters.forEach(f => {
                let k = Object.keys(f)[0];
                switch (k) {
                    case "startdate":
                        filterContent.hasTimeRange = true;
                        filterContent.dateFrom = f[k];
                        break;
                    case "enddate":
                        filterContent.hasTimeRange = true;
                        filterContent.dateTo = f[k];
                        break;
                    case "region":
                        filterContent.hasRegion = true;
                        filterContent.selectedRegions = f[k];
                        break;
                    case "city":
                        filterContent.hasCity = true;
                        filterContent.selectedCities = f[k];
                        break;
                    case "country":
                        filterContent.hasCountry = true;
                        filterContent.selectedCountries = f[k];
                        break;
                    case "riskrating":
                        filterContent.hasRiskRating = true;
                        filterContent.selectedRiskRatings = f[k];
                        break;
                    case "airport":
                        filterContent.hasAirport = true;
                        filterContent.selectedAirports = f[k];
                        break;
                    case "segmenttype":
                        filterContent.hasSegmentType = true;
                        filterContent.selectedSegmentTypes = [];
                        if (f[k]) {
                            f[k].forEach(s => {
                                let seg = globalConfig.filterDropdownItems.segmenttypes.find(s1 => s1.value == s);
                                filterContent.selectedSegmentTypes.push(seg);
                            });
                        }
                        break;
                    case "orgname":
                        filterContent.hasOrganization = true;
                        filterContent.selectedOrganizations = f[k];
                        break;
                    case "minpassengers":
                        filterContent.hasMinPassenger = true;
                        filterContent.selectedMinPassenger = f[k];
                        break;
                }
            });
        }

        if (savedReport.PropertyBags && savedReport.PropertyBags.CorrelationId) filterContent.PNRID = savedReport.PropertyBags.CorrelationId;

        return filterContent;
    }

    mapReportFilters(filterContent: ReportFilterContext, savedReport: SavedReport, keepValue?: boolean): SavedReport {
        if (!savedReport) savedReport = { Filters: [] } as SavedReport;
        if (!filterContent) return null;

        if (!keepValue) savedReport.Filters = [];

        if (filterContent.hasTimeRange && filterContent.dateFrom && filterContent.dateFrom.length) savedReport.Filters.push({ 'startdate': filterContent.dateFrom });
        if (filterContent.hasTimeRange && filterContent.dateTo && filterContent.dateTo.length) savedReport.Filters.push({ 'enddate': filterContent.dateTo });
        if (filterContent.hasRegion && filterContent.selectedRegions && filterContent.selectedRegions.length) savedReport.Filters.push({ 'region': filterContent.selectedRegions });
        if (filterContent.hasCity && filterContent.selectedCities && filterContent.selectedCities.length) savedReport.Filters.push({ 'city': filterContent.selectedCities });
        if (filterContent.hasCountry && filterContent.selectedCountries && filterContent.selectedCountries.length) savedReport.Filters.push({ 'country': filterContent.selectedCountries });
        if (filterContent.hasRiskRating && filterContent.selectedRiskRatings && filterContent.selectedRiskRatings.length) savedReport.Filters.push({ 'riskrating': filterContent.selectedRiskRatings });
        if (filterContent.hasAirport && filterContent.selectedAirports && filterContent.selectedAirports.length) savedReport.Filters.push({ 'airport': filterContent.selectedAirports });
        if (filterContent.hasSegmentType && filterContent.selectedSegmentTypes && filterContent.selectedSegmentTypes.length) savedReport.Filters.push({ 'segmenttype': filterContent.selectedSegmentTypes });
        if (filterContent.hasOrganization && filterContent.selectedOrganizations && filterContent.selectedOrganizations.length) savedReport.Filters.push({ 'orgname': filterContent.selectedOrganizations });
        if (filterContent.hasMinPassenger && filterContent.selectedMinPassenger && filterContent.selectedMinPassenger.length) savedReport.Filters.push({ 'minpassengers': filterContent.selectedMinPassenger });
        if (filterContent.hasPnrid && filterContent.PNRID) savedReport.PropertyBags = { CorrelationId: filterContent.PNRID };
        
        return savedReport;
    }

    findReportById(reportId: string, mySavedReportContent: ReportMySavedReportContext): SavedReport {
        let report: SavedReport;
        if (mySavedReportContent && mySavedReportContent.reports.length) {
            report = mySavedReportContent.reports.find(r => r.ReportID === reportId);
        }
        return report;
    }

    getFilterDropdownItems(): Observable<any> {
        if (globalConfig.filterDropdownItems && Object.keys(globalConfig.filterDropdownItems).length)
            return Observable.of(globalConfig.filterDropdownItems);

        globalConfig.filterDropdownItems = {
            segmenttypes: [
                { text: 'Air', value: 'air' },
                { text: 'Hotel', value: 'hotel' },
                { text: 'Rental Car', value: 'vehicle' },
                { text: 'Expatriate', value: 'expat' }
            ],
            riskratings: [1, 2, 3, 4],
            minpassengers: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        };
        return this.nrcService.getFilterDropdownItems().map((data: any) => {
            if (data.length) {
                data.forEach(d => {
                    if (d.Result.length) {
                        Object.keys(d.Result[0]).forEach(k => {
                            switch (k) {
                                case 'regions':
                                    globalConfig.filterDropdownItems[k] = d.Result[0][k].map(f => f.regionName);
                                    break;
                                case 'countries':
                                    globalConfig.filterDropdownItems[k] = d.Result[0][k].map(f => f.countryName);
                                    break;
                                case 'organizations':
                                    globalConfig.filterDropdownItems[k] = d.Result[0][k];
                                    break;
                            }
                            globalConfig.filterDropdownItems[k].sort();
                        });
                    }
                });
            }
        });
    }

    deleteDuplicateReportByName(mysavedReport: ReportMySavedReportContext, saveReportContent: ReportSaveReportContext) {
        let index = mysavedReport.reports.findIndex(r => r.ReportName == saveReportContent.reportName && r.ReportID != saveReportContent.reportId);
        if (index > -1) mysavedReport.reports.splice(index, 1);
    }

    containsFilters(filterContent: ReportFilterContext) {
        return filterContent.hasTimeRange && filterContent.dateFrom && filterContent.dateFrom.length && filterContent.dateTo && filterContent.dateTo.length
            || filterContent.hasAirport && filterContent.selectedAirports && filterContent.selectedAirports.length
            || filterContent.hasCity && filterContent.selectedCities && filterContent.selectedCities.length
            || filterContent.hasCountry && filterContent.selectedCountries && filterContent.selectedCountries.length
            || filterContent.hasMinPassenger && filterContent.selectedMinPassenger && filterContent.selectedMinPassenger.length
            || filterContent.hasOrganization && filterContent.selectedOrganizations && filterContent.selectedOrganizations.length
            || filterContent.hasRegion && filterContent.selectedRegions && filterContent.selectedRegions.length
            || filterContent.hasRiskRating && filterContent.selectedRiskRatings && filterContent.selectedRiskRatings.length
            || filterContent.hasSegmentType && filterContent.selectedSegmentTypes && filterContent.selectedSegmentTypes.length
            || filterContent.hasPnrid && filterContent.PNRID
            || filterContent.hasEmailAddress && filterContent.emailAddress
            || filterContent.hasTravelerName && filterContent.travelerName;
    }

    isMobileView() {
        return window.matchMedia("(max-width:768px)").matches;
    }

    resetSaveReport(savedReport: ReportSaveReportContext) {
        if (savedReport) {
            savedReport.reportId = null;
            savedReport.reportName = null;
        }
    }
}
