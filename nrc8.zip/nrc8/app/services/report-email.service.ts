import { Injectable } from '@angular/core';

import { NrcService } from "./nrc.service";
import { ReportFilterService } from "./report-filter.service";
import { ToastrService } from "./toastr.service";
import { SharedService } from "./shared.service";
import {
  SavedReport,
  ReportEmailContext,
  ReportRouteFactory,
  EmailTravellerContext,
  DownloadedReport,
  ReportFilterContext
} from "../models/ReportHeader";

declare var globalConfig: any;

@Injectable()
export class ReportEmailService {
  constructor(private nrcService: NrcService,
    private reportFilterService: ReportFilterService,
    private reportRouteFactory: ReportRouteFactory,
    private toastrService: ToastrService,
    private sharedService: SharedService) { }

  sendReportEmail(path: string, emailInfo: ReportEmailContext, filterContent: ReportFilterContext, columns: Array<{ isChecked: boolean, name: string }>): Promise<any> {
    if (emailInfo) {
      let reportType = this.reportRouteFactory.getLabel2ByKey(path);
      let id: string = this.sharedService.generateGUID();
      let report = {
        SendTo: [],
        SendCc: [],
        SendBcc: [],
        Subject: emailInfo.subject || '',
        Message: emailInfo.message || '',
        UID: globalConfig.settingsData.UserId,
        ReportType: reportType,
        ReportID: id,
        ReportFormat: emailInfo.selectedFileFormat,
        ReportName: `${reportType}_${id}`,
        Filters: [],
        ViewFields: []
      } as SavedReport;

      switch (emailInfo.selectedOutField) {
        case "TO":
          report.SendTo = emailInfo.recipients.map(r => r.email);
          break;
        case "CC":
          report.SendCc = emailInfo.recipients.map(r => r.email);
          break;
        case "BCC":
          report.SendBcc = emailInfo.recipients.map(r => r.email);
          break;
      }

      this.reportFilterService.mapReportFilters(filterContent, report);
      columns.forEach(c => {
        if (c.isChecked) report.ViewFields.push(c.name);
      });

      return this.sendEmailWithReport(report);
    }
  }

  sendTravelerEmail(path: string, emailTravelerContent: EmailTravellerContext) {
    if (emailTravelerContent) {
      let email = {
        To: '',
        Cc: '',
        Bcc: '',
        Subject: emailTravelerContent.subject || '',
        Body: emailTravelerContent.message || ''
      };

      let addresses = emailTravelerContent.recipients.filter(r => r.isChecked).map(r => r.email);
      switch (emailTravelerContent.selectedOutField) {
        case "TO":
          email.To = addresses.join(',');
          break;
        case "CC":
          email.Cc = addresses.join(',');
          break;
        case "BCC":
          email.Bcc = addresses.join(',');
          break;
      }

      return this.sendEmail(email);
    }
  }

  sendEmail(email: { To: string, Cc: string, Bcc: string, Subject: string, Body: string }): Promise<any> {
    return this.nrcService.sendReportEmail(email);
  }

  sendEmailWithReport(data: SavedReport): Promise<any> {
    return this.nrcService.sendReportEmailWithReport(data);
  }

  downloadReport(data: any, format: string, path: string, columns?: Array<string>) {
    let reportType = this.reportRouteFactory.getLabel2ByKey(path);
    let fileName = `${reportType}_${this.sharedService.generateGUID()}`;
    let report = {
      reportType: reportType,
      source: JSON.stringify(data),
      fieldColumns: columns || [],
      reportID: this.sharedService.generateGUID(),
      uID: globalConfig.settingsData.UserId || ''
    };

    switch (format) {
      case "PDF":
        fileName += '.pdf';
        this.nrcService.downloadPdfReport(report, fileName).subscribe({ error: err => this.nrcService.handleError(err) });
        break;
      case "EXCEL":
        fileName += '.xlsx';
        this.nrcService.downloadExcelReport(report, fileName).subscribe({ error: err => this.nrcService.handleError(err) });
        break;
      case "HTML":
        fileName += '.html';
        this.nrcService.downloadHtmlReport(report, fileName).subscribe({ error: err => this.nrcService.handleError(err) });
        break;
    }
  }
}
