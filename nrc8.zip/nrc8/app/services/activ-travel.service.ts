import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common'
import { retry } from 'rxjs/operator/retry';
import { NrcService } from '../services/nrc.service';
import { Airport } from '../models/Airport';

@Injectable()
export class ActivTravelService {
  public airport = new Array<Airport>()
  constructor(public datepipe: DatePipe, private nrcService: NrcService) { }

  getAirPort(filter: string): Promise<any> {
    return this.nrcService.getAirPort(filter);
  }

  public isMobile() {
    return window.matchMedia("(max-width:480px)").matches;
  }

  public getHeaderPagerDescription(skip: number, pageSize: number, total: number) {
    let description = "(Displaying " + (skip + 1) + "-" + ((skip + pageSize) > total ? total : (skip + pageSize)) + " of " + (total) + " total records)";
    return description;
  }

  public convertDateStringToKendoDate(orginDate: string) {
    //let latest_date = this.datepipe.transform(orginDate, 'yyyy-MM-dd');
    return orginDate;
  }

  public mappingData(res) {
    //remove the old and add the new 
    this.airport = [];
    //console.log(res)
    for (var i = 0; i < res.Result.length; i++) {
      let temp = new Airport();
      let templocation = res.Result[i];
      temp.airportCode = templocation.airportCode;
      temp.airportName = templocation.airportName;
      this.airport.push(temp);
    }
    return this.airport;

  }
}

export interface ColumnSetting {
  field: string;
  title: string;
  index: number;
  format?: string;
  type: 'text' | 'numeric' | 'boolean' | 'date' | 'hyperlink' | 'detail' ;
}
