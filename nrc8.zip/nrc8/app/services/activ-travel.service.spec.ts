import { TestBed, inject } from '@angular/core/testing';

import { ActivTravelService } from './activ-travel.service';

describe('ActivTravelService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ActivTravelService]
    });
  });

  it('should be created', inject([ActivTravelService], (service: ActivTravelService) => {
    expect(service).toBeTruthy();
  }));
});
