import { Injectable } from '@angular/core';

import { ActiveTravel } from '../models/activeTravel';
import { Travel } from '../models/Travel';
import { NrcService } from '../services/nrc.service';
import { ReportFilterContext } from "../models/ReportHeader";
import { ColumnSetting } from '../services/activ-travel.service';
//import '../libs/globalConfig.js';
declare var globalConfig: any;

@Injectable()
export class ExecutiveSummaryService {

  public executiveSummary = new Array<ActiveTravel>()
  constructor(private nrcService: NrcService) { }

  getExecutiveSummary(filterContext: ReportFilterContext): Promise<any> {
    let queryString = this.getQueryString(filterContext);
    return this.nrcService.getExecutiveSummarys(queryString);
  }

  mappingData(res) {
    //remove the old and add the new
    this.executiveSummary = [];
    //console.log(res.Result);
    for (var i = 0; i < res.Result.length; i++) {
      var tempActiveTravel = res.Result[i];

      var activeTravel = new ActiveTravel();

      activeTravel.id = i;
      activeTravel.index = i;
      activeTravel.isdrilldown = false;
      activeTravel.isexpand = false;
      activeTravel.atlocation = tempActiveTravel.atLocation;
      activeTravel.country = tempActiveTravel.country;
      activeTravel.enroute = tempActiveTravel.enRoute;
      activeTravel.region = tempActiveTravel.region;
      activeTravel.riskrating = tempActiveTravel.riskRating;
      activeTravel.travelerscount = tempActiveTravel.travelersCount;

      //console.log(activeTravel);

      let Travels = new Array<Travel>()
      for (var j = 0; j < tempActiveTravel.travelers.length; j++) {
        var tempTravel = new Travel();
        var temp = tempActiveTravel.travelers[j];

        tempTravel.index = j;
        tempTravel.isexpand = false;

        tempTravel.arrivalDate = temp.arrivalDate;
        tempTravel.city = temp.city;
        tempTravel.departureDate = temp.departureDate;

        if (temp.email.length > 0)
        {
          if (temp.email[0].isPrimary) {
            tempTravel.email = temp.email[0].email;
          }
        }
  

       
        tempTravel.endDate = temp.endDate;
        tempTravel.id = temp.id;
        tempTravel.locationName = temp.locationName;
        tempTravel.locationType = temp.locationType;
        tempTravel.name = temp.fullName;
        tempTravel.startDate = temp.startDate;
        tempTravel.suborg = temp.subOrg;
        tempTravel.type = temp.type;
        Travels.push(tempTravel);
      }

      activeTravel.travelers = Travels;

      this.executiveSummary.push(activeTravel);
    }

    return this.executiveSummary;

  }

  private getQueryString(filterContext?: ReportFilterContext): string {
    let queryString: string = '';
    if (filterContext) {
      let tmp = [];
      if (filterContext.hasRegion
        && filterContext.selectedRegions
        && filterContext.selectedRegions.length) tmp.push(`region=${filterContext.selectedRegions.join(',')}`);
      if (filterContext.hasCountry
        && filterContext.selectedCountries
        && filterContext.selectedCountries.length) tmp.push(`country=${filterContext.selectedCountries.join(',')}`);
      if (filterContext.hasRiskRating
        && filterContext.selectedRiskRatings
        && filterContext.selectedRiskRatings.length) tmp.push(`riskrating=${filterContext.selectedRiskRatings.join(',')}`);
      if (filterContext.hasOrganization
        && filterContext.selectedOrganizations
        && filterContext.selectedOrganizations.length) tmp.push(`orgname=${filterContext.selectedOrganizations.join(',')}`);

      queryString = tmp.join('&');
      if (queryString) queryString = '?' + queryString;
    }
    return queryString;
  }

  public fullColumns: ColumnSetting[] = [
    {
      field: 'region',
      title: 'Region',
      index: 0,
      type: 'text'
    }, {
      field: 'country',
      title: 'Country',
      index: 1,
      type: 'detail'
    }, {
      field: 'riskrating',
      title: 'Risk Rating',
      index: 2,
      type: 'text'
    }, {
      field: 'travelerscount',
      title: 'Travelers',
      index: 3,
      type: 'detail'
    }, {
      field: 'atlocation',
      title: 'At Location',
      index: 4,
      type: 'text'
    }, {
      field: 'enroute',
      title: 'En Route',
      index: 5,
      type: 'text'
    }
  ];

  public mobileColumns: ColumnSetting[] = [
    {
      field: 'region',
      title: 'Region',
      index: 0,
      type: 'text'
    }, {
      field: 'country',
      title: 'Country',
      index: 1,
      type: 'detail'
    }
  ];


}
