import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { Article } from '../models/Article';
import { Asset } from '../models/Asset';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { NrcService } from '../services/nrc.service';
import { SettingsService } from '../services/settings.service';
import { DOCUMENT } from '@angular/platform-browser';
//import '../libs/globalConfig.js';
declare var globalConfig: any;

@Injectable()
export class SharedService {

  /*Incidents variable*/
  tempIncidentsItems = [];
  incidentsItems = new BehaviorSubject<any>(this.tempIncidentsItems);
  castIncidentsItems = this.incidentsItems.asObservable();
  /*end Incidents variable*/

  /*Assets variable*/
  tempAssetsItems = [];
  assetsItems = new BehaviorSubject<any>(this.tempAssetsItems);
  castAssetsItems = this.assetsItems.asObservable();
  /*end Assets variable*/


  constructor(@Inject(DOCUMENT) private document: any, private nrcService: NrcService, private router: Router, private settingsService: SettingsService) {


  }

  /*show or hide map*/
  showOrHideMap() {
    if (this.router.url === '/' || this.router.url === '/map') {
      this.document.getElementById('map-view').style.visibility = "visible";
      this.document.body.style.overflow = 'hidden';
      if (this.document.getElementById('mapContainerNode') == null || this.document.getElementById('mapContainerNode').children.length == 0) {
        globalConfig.startLoadingMap();
      }
    }
    else {
      this.document.getElementById('map-view').style.visibility = "hidden";
      globalConfig.setBodyOverflow("auto");
    }
  }
  /*end show or hide map*/

  /*get Incidents/Assets/Proximities/LegacyProximities/Resources function*/
  changeIncidentsItems(incidentsItems: any) {
    this.incidentsItems.next(incidentsItems);
  }

  changeAssetsItems(assetsItems: any) {
    this.assetsItems.next(assetsItems);
  }
  //update impacted assets for incidents
  updateIncProximity(data) {
    //inc proximities
    globalConfig.allProximities.incidents = data.incidents;
    //update incidents
    globalConfig.updateImpactedAssetsForIncidents();
    //broadcast incidents/assets items
    this.tempIncidentsItems = globalConfig.allFilteredIncidentItems;
    this.changeIncidentsItems(this.tempIncidentsItems);
  }

  updateDataFromPLPR(data) {
    //assets proximities
    globalConfig.allProximities.assets = data[0].assets;

    //remove invalid incidents from asset proximities and recalculate the severity of asset
    globalConfig.filterIncidentsFromAssetProximities(globalConfig.allIncidentItems);
    //legacy proximities
    globalConfig.allLegacyProximities = data[1];

    //update assets
    globalConfig.updateProximitiesForAssets();
    //resources
    globalConfig.allResources = globalConfig.convertResourcesObjectToArray(data[2]);
    //update resources count for incidents                
    globalConfig.updateResourcesForIncidents();
    //broadcast incidents/assets items
    this.tempIncidentsItems = globalConfig.allFilteredIncidentItems;
    this.changeIncidentsItems(this.tempIncidentsItems);
    this.tempAssetsItems = globalConfig.allFilteredAssetItems;
    this.changeAssetsItems(this.tempAssetsItems);
    //update map
    globalConfig.refreshLocationsOnMap();
  }

  getProximitiesParameters() {
    var promise = new Promise<any>((resolve, reject) => {

      if (typeof (this.settingsService.getSettingsData()) == 'undefined') {
        this.nrcService.getSettings()
          .then(res => {
            this.settingsService.changeSettingsData(res);
            let parameters = '';
            if (globalConfig.settingsData.ProximityWarningEnabled) {

              parameters = '{minor:';
              parameters += this.settingsService.getSettingsData().MinorEnabled ? this.settingsService.getSettingsData().MinorRadius : '-1';
              parameters += ',moderate:';
              parameters += this.settingsService.getSettingsData().ModerateEnabled ? this.settingsService.getSettingsData().ModerateRadius : '-1';
              parameters += ',severe:';
              parameters += this.settingsService.getSettingsData().SevereEnabled ? this.settingsService.getSettingsData().SevereRadius : '-1';
              parameters += ',extreme:';
              parameters += this.settingsService.getSettingsData().ExtremeEnabled ? this.settingsService.getSettingsData().ExtremeRadius : '-1';
              parameters += ',u:' + this.settingsService.getSettingsData().DistanceUnit;
              parameters += '}';

            } else {

              parameters = '{minor:-1,moderate:-1,severe:-1,extreme:-1,u:' + this.settingsService.getSettingsData().DistanceUnit + '}';
            }

            resolve(parameters);

          });
      }
      else {
        let parameters = '';
        if (this.settingsService.getSettingsData().ProximityWarningEnabled) {

          parameters = '{minor:';
          parameters += this.settingsService.getSettingsData().MinorEnabled ? this.settingsService.getSettingsData().MinorRadius : '-1';
          parameters += ',moderate:';
          parameters += this.settingsService.getSettingsData().ModerateEnabled ? this.settingsService.getSettingsData().ModerateRadius : '-1';
          parameters += ',severe:';
          parameters += this.settingsService.getSettingsData().SevereEnabled ? this.settingsService.getSettingsData().SevereRadius : '-1';
          parameters += ',extreme:';
          parameters += this.settingsService.getSettingsData().ExtremeEnabled ? this.settingsService.getSettingsData().ExtremeRadius : '-1';
          parameters += ',u:' + this.settingsService.getSettingsData().DistanceUnit;
          parameters += '}';

        } else {

          parameters = '{minor:-1,moderate:-1,severe:-1,extreme:-1,u:' + this.settingsService.getSettingsData().DistanceUnit + '}';

        }

        resolve(parameters);
      }

    });
    return promise;
  };

  getIncidents(callback: any) {
    if (globalConfig.allIncidentItems.length > 0) {
      if (callback) {
        callback();
      }
    }
    else {
      this.nrcService.getIncidents().then(res => {
        for (let item of res.incidents) {
          globalConfig.allIncidentItems.push(globalConfig.convertIncident(item));
        }

        if (callback) {
          callback();
        }
      });
    }
  };

  getIncidentsAssets(callback: any) {
    if (!globalConfig.isIncidentsLoadComplete || !globalConfig.isAssetsLoadComplete) {
      //get new incidents
      this.nrcService.getIncidents().then(res => {
        globalConfig.AutoRef_timestamp = res.timestamp;

        if (!globalConfig.allIncidentItems.length) {
          for (let item of res.incidents) {
            globalConfig.allIncidentItems.push(globalConfig.convertIncident(item));
          }
        }

        globalConfig.allFilteredIncidentItems = globalConfig.allIncidentItems;

        this.tempIncidentsItems = globalConfig.allFilteredIncidentItems;
        this.changeIncidentsItems(this.tempIncidentsItems);

        //notice the loader timer interval that incidents are loaded completely
        globalConfig.isIncidentsLoadComplete = true;

        //update impacted assets for incidents
        this.getProximitiesParameters().then(parasProximities => {
          this.nrcService.getIncProximities(parasProximities).then(data => {
            this.updateIncProximity(data);
          })
        });

        //get new assets
        if (!globalConfig.allAssetItems.length) {
          this.nrcService.getAssets('').then(res => {

            globalConfig.AutoRef_locationRequestTimestamp = res.ts.toString();
            for (let item of res.features) {
              globalConfig.allAssetItems.push(globalConfig.convertAssets(item.attributes));
            }

            globalConfig.allFilteredAssetItems = globalConfig.allAssetItems;

            this.tempAssetsItems = globalConfig.allFilteredAssetItems;
            this.changeAssetsItems(this.tempAssetsItems);

            //remove invalid incidents from asset proximities and recalculate the severity of asset
            globalConfig.filterIncidentsFromAssetProximities(globalConfig.allIncidentItems);
            //indicate assets has been loaded
            globalConfig.isAssetsLoadComplete = true;

          });
        }
        //get proximities/legacy proximities
        this.getProximitiesParameters().then(parasProximities => {
          this.nrcService.getFacProximitiesLegacyProximitiesResources(parasProximities).subscribe(data => {
            this.updateDataFromPLPR(data);
          },
            err => { this.nrcService.handleError(err); })
        });

        if (callback) {
          callback();
        }

      });
    }
    else {
      if (callback) {
        callback();
      }
    }
  }
  /*end get Incidents/Assets/Proximities/LegacyProximities/Resources function*/

  //get proximities and legacy proximities for incidents/assets detail page
  getProximitiesForDetailPage(callback: any) {
    if (Object.keys(globalConfig.allProximities).length && typeof callback === 'function') {
      callback();
    }
    else {
      this.getProximitiesParameters().then(parasProximities => {
        this.nrcService.getProximitiesLegacyProximities(parasProximities).subscribe(data => {
          globalConfig.allProximities.assets = data[0].assets;
          globalConfig.allProximities.incidents = data[0].incidents;
          globalConfig.allLegacyProximities = data[1];
          if (typeof callback === 'function') callback();
        },
          err => { this.nrcService.handleError(err); })
      });
    }
  }

  getCustomProximitiesForDetailPage(distance, callback) {
    var parasProximities = '{minor:' + distance + ',moderate:' + distance + ',severe:' + distance + ',extreme:' + distance + ',u:' + globalConfig.settingsData.DistanceUnit + '}'
    this.nrcService.getProximities(parasProximities).then(function (data) {

      var incidentProximities = data.incidents;
      if (typeof callback === 'function') callback(incidentProximities);
    });

  }

  generateGUID(): string {
    return this.random4() + this.random4() + "-" + this.random4() + "-" + this.random4() + "-" +
      this.random4() + "-" + this.random4() + this.random4() + this.random4();
  }

  private random4(): string {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
}
