import { Injectable } from '@angular/core';

import { NrcService } from "./nrc.service";
import { Passenger, PassengerOnFlight } from "../models/PassengerOnFlight";
import { ReportFilterContext } from "../models/ReportHeader";
import { ColumnSetting } from '../services/activ-travel.service';

@Injectable()
export class PassengersOnFlightService {
  constructor(private nrcService: NrcService) { }

  getpassengersOnFlight(filterContext?: ReportFilterContext): Promise<any> {
    let queryString = this.getQueryString(filterContext);
    return this.nrcService.getPassengersOnFlight(queryString);
  }
  mappingData(res) {
    let result: PassengerOnFlight[] = [];
    for (var i = 0; i < res.Result.length; i++) {
      var tmp = res.Result[i], psgOnFlight = new PassengerOnFlight();

      psgOnFlight.id = i;
      psgOnFlight.index = i;
      psgOnFlight.isdrilldown = false;
      psgOnFlight.isexpand = false;
      if (tmp.airlineName != null)
      {
        psgOnFlight.airline = tmp.airlineName;
      }
    
      psgOnFlight.arrivalAirport = tmp.arrivalAirport;
      psgOnFlight.arrivalTime = tmp.arrivalTime;
      psgOnFlight.arrivalCity = tmp.arrivalCity;
      psgOnFlight.arrivalCountry = tmp.arrivalCountry;
      psgOnFlight.arrivalRisk = tmp.arrivalRisk;
      psgOnFlight.departureAirport = tmp.departureAirport;
      psgOnFlight.departureTime = tmp.departureTime;
      psgOnFlight.departureCity = tmp.departureCity;
      psgOnFlight.departureCountry = tmp.departureCountry;
      psgOnFlight.departureRisk = tmp.departureRisk;
      let tempAirLineCode = "";
      let tempFlightNumber = "";
      if (tmp.airlineCode != null) {
        tempAirLineCode = tmp.airlineCode;
      }
      if (tmp.flightNumber != null) {
        tempFlightNumber = tmp.flightNumber;
      }

      psgOnFlight.flightNumber = tempAirLineCode + " " + tempFlightNumber;
    
      psgOnFlight.passengers = [];
      psgOnFlight.passengersCount = 0;

      var tempCount = 0;

      if (tmp.passengers && tmp.passengers.length) {
        tmp.passengers.forEach(trlr => {
          let psg = {
            pnrid: trlr.id,
            index: tempCount++,
            isexpand: false,
            name: trlr.fullName,
            email: trlr.email && trlr.email.length > 0 ? trlr.email[0].email : '',
            region: tmp.departureRegion,
            country: tmp.departureCountry,
            city: tmp.departureCity,
            airportOrlocation: tmp.departureAirport,
            segmentTime: tmp.departureTime,
            segmentDesignator: tempAirLineCode + " " + tempFlightNumber,
            segmentType: 'air'
          } as Passenger;
          psgOnFlight.passengers.push(psg);
          psgOnFlight.passengersCount++;
        });
      }
      result.push(psgOnFlight);
    }
    return result;
  }

  private getQueryString(filterContext?: ReportFilterContext): string {
    let queryString: string = '';
    if (filterContext) {
      let tmp = [];
      if (filterContext.hasTimeRange
        && filterContext.dateFrom
        && filterContext.dateFrom.length) tmp.push(`startdate=${filterContext.dateFrom[0]}`);

      if (filterContext.hasTimeRange
        && filterContext.dateTo
        && filterContext.dateTo.length) tmp.push(`enddate=${filterContext.dateTo[0]}`);

      if (filterContext.hasOrganization
        && filterContext.selectedOrganizations
        && filterContext.selectedOrganizations.length) tmp.push(`orgname=${filterContext.selectedOrganizations.join(',')}`);

      if (filterContext.hasMinPassenger
        && filterContext.selectedMinPassenger
        && filterContext.selectedMinPassenger.length) tmp.push(`minpassengers=${filterContext.selectedMinPassenger[0]}`);

      queryString = tmp.join('&');
      if (queryString) queryString = '?' + queryString;
    }
    return queryString;
  }

  public fullColumns: ColumnSetting[] = [
    //{
    //  field: 'id',
    //  title: 'Id',
    //  index: 0,
    //  type: 'text'
    //},
    {
      field: 'airline',
      title: 'Air Line',
      index: 1,
      type: 'text'
    }, {
      field: 'flightNumber',
      title: 'Flight Number',
      index: 2,
      type: 'text'
    }, {
      field: 'departureAirport',
      title: 'Departure Airport',
      index: 3,
      type: 'text'
    }, {
      field: 'departureTime',
      title: 'Departure Time',
      index: 4,
      type: 'date'
    }, {
      field: 'departureCity',
      title: 'Departure City',
      index: 5,
      type: 'text'
    }, {
      field: 'departureCountry',
      title: 'Departure Country',
      index: 6,
      type: 'text'
    }, {
      field: 'departureRisk',
      title: 'Departure Risk',
      index: 7,
      type: 'text'
    }, {
      field: 'arrivalAirport',
      title: 'Arrival Airport',
      index: 8,
      type: 'text'
    }, {
      field: 'arrivalTime',
      title: 'Arrival Time',
      index: 9,
      type: 'date'
    }, {
      field: 'arrivalCity',
      title: 'Arrival City',
      index: 10,
      type: 'text'
    }, {
      field: 'arrivalCountry',
      title: 'Arrival Country',
      index: 11,
      type: 'text'
    }, {
      field: 'arrivalRisk',
      title: 'Arrival Risk',
      index: 12,
      type: 'text'
    }, {
      field: 'passengersCount',
      title: 'Passengers',
      index: 13,
      type: 'detail'
    }
  ];
}
