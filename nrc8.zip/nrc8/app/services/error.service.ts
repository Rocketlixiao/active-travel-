import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class ErrorService {

  errorMessage = new BehaviorSubject<string>('');
  castErrorMessage = this.errorMessage.asObservable();

  openDialog = new BehaviorSubject<boolean>(false);
  castOpenDialog = this.openDialog.asObservable();

  private isPopup = false;
  setIsPopup(val) {
    this.isPopup = val;
  }

  getIsPopup() {
    return this.isPopup;
  }

  constructor(private router: Router) {
    router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.isPopup = false;
        //console.log(router.url);
      }
    });
  }

  changeErrorMessage(message: string) {
    this.errorMessage.next(message);
  }

  changeOpenDialog(flag: boolean) {
    this.openDialog.next(flag);
  }


  popupMessage(message: any) {
    
    if (!this.isPopup) {
      this.changeErrorMessage(message);
      this.changeOpenDialog(true);
    }   
  }

  closePopupMessage() {
    this.isPopup = false;
    this.changeOpenDialog(false);
  }
}
