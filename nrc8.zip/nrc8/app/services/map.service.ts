import { Injectable, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router } from '@angular/router';

//import '../libs/globalConfig.js';
declare var globalConfig: any;
declare var app: any;

@Injectable()
export class MapService {

  url = 'https://www.bing.com/api/maps/mapcontrol?callback=__onBingLoaded&branch=release';
  credentials = 'AhbeoOinKb6Xem0M7a6Fug0-60OggkzXRXVl-9nnwFK7rBAVrV1HiJXYoFO6oRXO';
  basemaps = [
    { label: 'Aerial', image: 'images/bing_aerial_map.jpg', mapTypeId: 'a' },
    { label: 'Road', image: 'images/bing_road_map.jpg', mapTypeId: 'r' },
    //{ label: 'Bird\'s eye', image: 'images/bing_bird_map.png', mapTypeId: 'be' },
    { label: 'Streetside', image: 'images/bing_streetside_map.png', mapTypeId: 'ss' }
  ];
  private promise;

  constructor(@Inject(DOCUMENT) private document: any, private router: Router) { }

  load() {

    // First time 'load' is called?
    if (!this.promise) {
      // Make promise to load
      this.promise = new Promise(resolve => {

        // Set callback for when bing maps is loaded.
        window['__onBingLoaded'] = (ev) => {
          resolve('Bing Maps API loaded');
        };

        const node = this.document.createElement('script');
        node.src = this.url;
        node.type = 'text/javascript';
        node.async = true;
        node.defer = true;
        this.document.getElementsByTagName('head')[0].appendChild(node);
      });
    }

    // Always return promise. When 'load' is called many times, the promise is already resolved.
    return this.promise;
  }

  ResetMapAndScrollBar() {
    var scrollableDiv = this.document.getElementById("divscrollable");
    if (scrollableDiv) {
      scrollableDiv.scrollTop = 0;
    }

    //When run filter, reload cluster.        
    if (this.router.url === '/map' || this.router.url === '/') {
      try {
        if (globalConfig.refreshClusters && typeof (globalConfig.refreshClusters) == "function" && app != null && app.map != null && app.map.map != undefined && app.map.map.extent != undefined) {

          globalConfig.refreshClusters();
        }
      }
      catch (e) { }
    }
  }
}
