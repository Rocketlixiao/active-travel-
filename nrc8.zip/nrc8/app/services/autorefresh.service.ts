import { Injectable } from '@angular/core';
import { SharedService } from '../services/shared.service';
import { NrcService } from '../services/nrc.service';
import { FilterService } from '../services/filter.service';
import { MapService } from '../services/map.service';


//import '../libs/globalConfig.js';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
declare var globalConfig: any;
@Injectable()
export class AutorefreshService {
  AutoRef_updatedCount = new BehaviorSubject<string>("0");
  castAutoRef_updatedCount = this.AutoRef_updatedCount.asObservable();

  _autoRefreshStatus = 'auto-refresh-finished';
  autoRefreshStatus = new BehaviorSubject<string>(this._autoRefreshStatus);
  castAutoRefreshStatus = this.autoRefreshStatus.asObservable();

  constructor(private sharedService: SharedService, private nrcService: NrcService, private filterService: FilterService, private mapService: MapService) {

  }

  changeAutoRef_updatedCount(count: string) {
    this.AutoRef_updatedCount.next(count);
  }

  changeAutoRefreshStatus(clsStatus: string) {
    this.autoRefreshStatus.next(clsStatus);
  }

  //get all incidents ids that the current incident is impacting the specific location
  getIncidentIdsByUpdatedAssetId(locationId) {
    for (var k = 0; k < globalConfig.allProximities.assets.length; k++) {
      var impactedAsset = globalConfig.allProximities.assets[k];
      if (impactedAsset.id == locationId) {
        for (var j = 0; j < impactedAsset.n.length; j++) {
          var existed = false;
          for (var m = 0; m < globalConfig.AutoRef_impactAssetIncidentsIds.length; m++) {
            if (globalConfig.AutoRef_impactAssetIncidentsIds[m] == impactedAsset.n[j].id) {
              existed = true;
              break;
            }
          }

          if (!existed) {
            globalConfig.AutoRef_impactAssetIncidentsIds.push(impactedAsset.n[j].id);
          }
        }
        break;
      }

    }
  }

  funAutoRef() {
    if (globalConfig.AutoRef_timestamp != '') {
      //get all of incident/asset updates
      this.nrcService.getIncidentsAssetsUpdates(globalConfig.AutoRef_timestamp).subscribe(data => {

        var tempIncidentUpdates = data[0].incidents;
        var tempAssets = data[1].features;
        var tempAssetUpdates = [];

        //get deleted assets
        var oldItemAsset;
        var newItemAsset;
        for (var i = 0; i < globalConfig.allAssetItems.length; i++) {
          oldItemAsset = globalConfig.allAssetItems[i];
          var isDeleted = true;
          for (var j = 0; j < tempAssets.length; j++) {
            newItemAsset = tempAssets[j];
            if (oldItemAsset.id == newItemAsset.attributes.facilityid) {
              isDeleted = false;
              break;
            }
          }

          if (isDeleted) {
            oldItemAsset.isDeleted = true;
            tempAssetUpdates.push(oldItemAsset);
            this.getIncidentIdsByUpdatedAssetId(oldItemAsset.id);//collect the incident id which impacted the deleted asset
          }
        }

        //get all of asset updates by timestamp
        var lastLocationRequestTimestamp = new Date(globalConfig.AutoRef_locationRequestTimestamp * 1);
        var itemAsset;
        var lastupdateddate;
        for (var i = 0; i < tempAssets.length; i++) {
          itemAsset = tempAssets[i];
          lastupdateddate = new Date(itemAsset.attributes.lastupdateddate * 1);
          if (lastupdateddate > lastLocationRequestTimestamp) {
            tempAssetUpdates.push(itemAsset);
            this.getIncidentIdsByUpdatedAssetId(itemAsset.id);//collect the incident id which impacted the current asset
          }
        }

        //if the incident update impact asset in old proximites, the asset needs to be updated.
        if (tempIncidentUpdates.length > 0) {
          for (var i = 0; i < tempIncidentUpdates.length; i++) {
            var updatedItemIncident = tempIncidentUpdates[i];
            for (var k = 0; k < globalConfig.allProximities.assets.length; k++) {
              var impacted = false;
              var impactedAsset = globalConfig.allProximities.assets[k];
              for (var m = 0; m < impactedAsset.n.length; m++) {
                if (updatedItemIncident.incidents == impactedAsset.n[m].id) {
                  impacted = true;
                  break;
                }
              }
              //if find the asset impacted by updated incident, put it into tempAssetUpdates list
              if (impacted) {
                var tempItemAsset;
                for (var j = 0; j < tempAssets.length; j++) {
                  tempItemAsset = tempAssets[j];
                  if (tempItemAsset.attributes.facilityid == impactedAsset.id) {
                    tempAssetUpdates.push(tempItemAsset);
                    break;
                  }
                }
              }
            }
          }
        }

        //init incident/asset timestamp
        globalConfig.AutoRef_timestamp = data[0].timestamp;
        globalConfig.AutoRef_locationRequestTimestamp = data[1].ts.toString();
        //if there is any update about incident or asset, reloading proximities and merge the updates into old incident/asset list
        if (tempIncidentUpdates.length > 0 || tempAssetUpdates.length > 0) {
          this.sharedService.getProximitiesParameters().then(paraProximities => {
            this.nrcService.getProximitiesLegacyProximitiesResources(paraProximities).subscribe(ret => {
              //update proximities with the latest newProximities
              globalConfig.allProximities.assets = ret[0].assets;
              globalConfig.allProximities.incidents = ret[0].incidents;
              //remove invalid incidents from asset proximities and recalculate the severity of asset
              globalConfig.filterIncidentsFromAssetProximities(globalConfig.allIncidentItems, globalConfig.AutoRef_updatedIncidents, tempIncidentUpdates);
              globalConfig.allLegacyProximities = ret[1];
              //get new resources
              globalConfig.allResources = globalConfig.convertResourcesObjectToArray(ret[2]);

              //merge the latest incident updates into AutoRef_updatedIncidents list and convert them into correct format.
              for (var i = 0; i < tempIncidentUpdates.length; i++) {
                var updatedItem = tempIncidentUpdates[i];
                for (var j = 0; j < globalConfig.AutoRef_updatedIncidents.length; j++) {
                  //delete incident if it existed in old updated incident list.
                  if (updatedItem.incidents == globalConfig.AutoRef_updatedIncidents[j].incidents) {
                    globalConfig.AutoRef_updatedIncidents.splice(j, 1);
                    break;
                  }
                }

                globalConfig.AutoRef_updatedIncidents.push(globalConfig.convertIncident(updatedItem));
              }

              //update the updates count
              if (globalConfig.AutoRef_updatedIncidents.length > 10) {
                this.changeAutoRef_updatedCount('10+');
              }
              else {
                this.changeAutoRef_updatedCount(globalConfig.AutoRef_updatedIncidents.length + '');
              }


              //merge the latest asset updates into AutoRef_updatedAssets list and convert them into correct format. 
              //the incident update impact asset in new proximites, the asset needs to be updated.
              if (tempIncidentUpdates.length > 0) {
                for (var i = 0; i < tempIncidentUpdates.length; i++) {
                  var updatedItemIncident = tempIncidentUpdates[i];
                  for (var k = 0; k < globalConfig.allProximities.assets.length; k++) {
                    var impacted = false;
                    var impactedAsset = globalConfig.allProximities.assets[k];
                    for (var m = 0; m < impactedAsset.n.length; m++) {
                      if (updatedItemIncident.incidents == impactedAsset.n[m].id) {
                        impacted = true;
                        break;
                      }
                    }
                    //if find the asset impacted by updated incident, put it into tempAssetUpdates list
                    if (impacted) {
                      var tempItemAsset;
                      for (var j = 0; j < tempAssets.length; j++) {
                        tempItemAsset = tempAssets[j];
                        if (tempItemAsset.attributes.facilityid == impactedAsset.id) {
                          tempAssetUpdates.push(tempItemAsset);
                          break;
                        }
                      }
                    }
                  }
                }
              }
              for (var i = 0; i < tempAssetUpdates.length; i++) {
                var updatedItem = tempAssetUpdates[i];
                for (var j = 0; j < globalConfig.AutoRef_updatedAssets.length; j++) {
                  //delete asset if it existed in old updated asset list.
                  var facilityid = updatedItem.isDeleted ? updatedItem.id : updatedItem.attributes.facilityid;
                  if (facilityid == globalConfig.AutoRef_updatedAssets[j].id) {
                    globalConfig.AutoRef_updatedAssets.splice(j, 1);
                    break;
                  }
                }

                if (updatedItem.isDeleted) {
                  globalConfig.AutoRef_updatedAssets.push(updatedItem);
                }
                else {
                  globalConfig.AutoRef_updatedAssets.push(globalConfig.convertAssets(updatedItem.attributes));
                }

                this.getIncidentIdsByUpdatedAssetId(updatedItem.id);//collect the incident id which is impacting the current asset

              }
            },
              err => { this.nrcService.handleError(err); })
          });
        }
      },
        err => { this.nrcService.handleError(err); });
    }
  };

  autoRef() {
    setInterval(() => {
      this.funAutoRef();
    }, 60000);
  }

  CallMergeUpdates() {
    if (this._autoRefreshStatus === "auto-refresh-finished") {
      this.MergeUpdates(true);
    }
  }

  /*auto refresh incidents*/
  MergeUpdates(isRefreshIcon) {

    this._autoRefreshStatus = "auto-refresh-processing";
    this.changeAutoRefreshStatus(this._autoRefreshStatus);
    //merge updated Assets into old assets list
    if (globalConfig.AutoRef_updatedAssets.length > 0) {

      for (var i = 0; i < globalConfig.AutoRef_updatedAssets.length; i++) {

        var updatedItem = globalConfig.AutoRef_updatedAssets[i];
        for (var j = 0; j < globalConfig.allAssetItems.length; j++) {
          //delete existed assets
          if (updatedItem.id == globalConfig.allAssetItems[j].id) {
            globalConfig.allAssetItems.splice(j, 1);
            break;
          }
        }
        //Add existed or new assets 
        if (!updatedItem.isDeleted) {
          globalConfig.allAssetItems.push(updatedItem);
        }
      }
      //notify that globalConfig.allAssetItems is updated
      //$rootScope.$broadcast('globalConfig.allAssetItems.valueChanged');
      this.sharedService.changeAssetsItems(globalConfig.allAssetItems);
    }
    //update legacy proximities
    if (globalConfig.allAssetItems.length > 0) {
      for (let item of globalConfig.allAssetItems) {
        item.objtype = globalConfig.getLegacyProximitiesById(item.id);

      };
    }

    //merge updated incidents into old incidents list
    if (globalConfig.AutoRef_updatedIncidents.length > 0) {
      for (var i = 0; i < globalConfig.AutoRef_updatedIncidents.length; i++) {
        for (var j = 0; j < globalConfig.allIncidentItems.length; j++) {
          //delete existed and closed incidents
          if (globalConfig.AutoRef_updatedIncidents[i].incidents == globalConfig.allIncidentItems[j].incidents) {
            globalConfig.allIncidentItems.splice(j, 1);
            break;
          }
        }
        //Add existed or new incidents
        if (globalConfig.AutoRef_updatedIncidents[i].IsOpened) {
          var updatedItem = globalConfig.AutoRef_updatedIncidents[i];
          globalConfig.allIncidentItems.push(updatedItem);
        }
      }
    }
    //update time ago
    //if (globalConfig.allIncidentItems.length > 0) {
    //  for (let item of globalConfig.allIncidentItems) {
    //    item.date = globalConfig.formatTimeago(new Date(item.realDate));

    //  };
    //}

    //update resources count for incidents
    if (globalConfig.allIncidentItems.length > 0) {
      for (let item of globalConfig.allIncidentItems) {
        item.resourceCount = globalConfig.getResourcesCountById(item.id, item.source);

      };
    }
    //update impacted asset for incidents
    if (globalConfig.AutoRef_impactAssetIncidentsIds.length > 0) {
      for (var i = 0; i < globalConfig.AutoRef_impactAssetIncidentsIds.length; i++) {
        for (var j = 0; j < globalConfig.allIncidentItems.length; j++) {
          if (globalConfig.AutoRef_impactAssetIncidentsIds[i] == globalConfig.allIncidentItems[j].id) {
            globalConfig.setupImpactedAssetsForIncidentItem(globalConfig.allIncidentItems[j]);
            break;
          }
        }
      }
    }

    //Run filter

    if (globalConfig.filterObject != null) {
      this.filterService.RunFilter(globalConfig.filterObject);
    }
    else {
      //bind incidents and assets again
      globalConfig.allFilteredIncidentItems = globalConfig.allIncidentItems;
      globalConfig.allFilteredAssetItems = globalConfig.allAssetItems;

      this.sharedService.changeIncidentsItems(globalConfig.allFilteredIncidentItems);
      this.sharedService.changeAssetsItems(globalConfig.allFilteredAssetItems);
    }

    //If click the refresh icon   
    if (isRefreshIcon) {

      var url = window.location.href.toLowerCase();

      //if the current page is map, cluster again
      if (globalConfig.isMapPage(url)) {
        this.mapService.ResetMapAndScrollBar();
      }

      //if it's in article detail page and current incident is in updates, refresh the current incident.
      if (globalConfig.isArticleDetailPage(url)) {

        if (globalConfig.AutoRef_updatedIncidents.length > 0) {

          for (var i = 0; i < globalConfig.AutoRef_updatedIncidents.length; i++) {
            //if article is in updates, refresh the detail page.
            if (url.indexOf(globalConfig.AutoRef_updatedIncidents[i].incidents.toLowerCase()) >= 0) {
              window.location.reload();
              break;
            }
          }
        }
      }

      //if it's in asset detail page and current asset is in updates, refresh the current asset.
      if (globalConfig.isAssetDetailPage(url)) {
        if (globalConfig.AutoRef_updatedAssets.length > 0) {
          for (var i = 0; i < globalConfig.AutoRef_updatedAssets.length; i++) {
            if (url.indexOf(globalConfig.AutoRef_updatedAssets[i].id.toLowerCase()) >= 0) {
              window.location.reload();
              break;
            }
          }
        }
      }

      //refresh filter if it's turned on
      if (globalConfig.isFilterApplied && url.indexOf("/content/list") !== -1) {
        this.filterService.RunMutipleFilter(this.filterService.getMultipleFilters()[globalConfig.filtedItemIndex]);
        this.filterService.saveFilterForArticleAndAssets();
      }
    }



    globalConfig.AutoRef_updatedIncidents = [];
    globalConfig.AutoRef_updatedAssets = [];
    this.changeAutoRef_updatedCount("0");

    var switchIcon = window.setTimeout(() => {
      this._autoRefreshStatus = "auto-refresh-finished";
      this.changeAutoRefreshStatus(this._autoRefreshStatus);
    }, 500);
  }

}
