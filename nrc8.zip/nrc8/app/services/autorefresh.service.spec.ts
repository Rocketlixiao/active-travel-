import { TestBed, inject } from '@angular/core/testing';

import { AutorefreshService } from './autorefresh.service';

describe('AutorefreshService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AutorefreshService]
    });
  });

  it('should be created', inject([AutorefreshService], (service: AutorefreshService) => {
    expect(service).toBeTruthy();
  }));
});
