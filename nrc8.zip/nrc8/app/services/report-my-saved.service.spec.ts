import { TestBed, inject } from '@angular/core/testing';

import { ReportMySavedService } from './report-my-saved.service';

describe('ReportMySavedService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReportMySavedService]
    });
  });

  it('should be created', inject([ReportMySavedService], (service: ReportMySavedService) => {
    expect(service).toBeTruthy();
  }));
});
