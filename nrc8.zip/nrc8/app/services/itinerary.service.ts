import { Injectable } from '@angular/core';
import { DatePipe, DeprecatedI18NPipesModule } from "@angular/common";

import { NrcService } from "./nrc.service";
import { ReportFilterContext } from "../models/ReportHeader";
import { ItineraryDetail, Segment, TravelDay, City } from "../models/ItineraryDetail";

declare var moment: any;

@Injectable()
export class ItineraryService {

  constructor(private nrcService: NrcService, private datePipe: DatePipe) { }

  getItineraryDetail(filterContext?: ReportFilterContext): Promise<any> {
    let queryString = this.getQueryString(filterContext);
    return this.nrcService.getItineraryDetail(queryString);
  }

  mapItineraryDetail(data): ItineraryDetail {
    let detail: ItineraryDetail = new ItineraryDetail();
    if (data && data.Result.length) {
      let tmpData = data.Result[0],
        tmpPeople = tmpData.people[0],
        tmpTravel = tmpData.docTypeAttributes.Travel;

      detail = {
        id: tmpData.correlationId,
        title: tmpData.title,
        fullName: tmpPeople.fullName,
        email: tmpPeople.emailAddresses.length ? tmpPeople.emailAddresses[0].email : '',
        primaryPhone: tmpPeople.phoneNumbers.length ? (tmpPeople.phoneNumbers[0].label + tmpPeople.phoneNumbers[0].number) : '',
        bookingAgency: tmpTravel.sourceAgencyName,
        lastBookingAgencyUpdated: tmpTravel.lastProcessed,
        travelDays: []
      } as ItineraryDetail;


      let tmp: any = {};
      if (tmpData.locations && tmpData.locations.length) {
        tmpData.locations.sort((l1, l2) => moment(l1.locTypeAttributes.utcDate) - moment(l2.locTypeAttributes.utcDate));
        tmpData.locations.forEach(l => {
          let t = this.datePipe.transform(l.locTypeAttributes.utcDate, "MM/dd/yy");
          if (t) {
            ((tmp[t] = tmp[t] || {})[l.locationCode] = (tmp[t] = tmp[t] || {})[l.locationCode] || []).push(l);
          }
        });
      }

      Object.keys(tmp).forEach(kd => {
        let tmpDay = {
          localDate: kd,
          travelCities: []
        } as TravelDay;

        Object.keys(tmp[kd]).forEach(kl => {
          let tmpCity = {
            code: kl,
            travelSegments: []
          } as City;

          tmp[kd][kl].forEach(l => {
            let tmpSgt = {
              type: `${l.locTypeAttributes.segmentType}-${l.locTypeAttributes.segmentStartEnd}`,
              typeName: this.getSegmentLabel(l.locTypeAttributes.segmentType, l.locTypeAttributes.segmentStartEnd),
              infoTitle: "",
              infoDescription: this.getSegmentDescription(l),
              riskLabel: l.locTypeAttributes.riskRatingLabel,
              riskNumber: l.locTypeAttributes.riskRating || l.locTypeAttributes.riskRatingNumber
            } as Segment;
            tmpCity.travelSegments.push(tmpSgt);
          });
          tmpDay.travelCities.push(tmpCity);
        });
        tmpDay.risk = this.getHighestRiskRating(tmpDay.travelCities);
        detail.travelDays.push(tmpDay);
      });
    }

    return detail;
  }

  private getQueryString(filterContext?: ReportFilterContext): string {
    let queryString: string = '';
    if (filterContext) {
      let tmp = [];
      if (filterContext.hasPnrid
        && filterContext.PNRID) tmp.push(`locator=${filterContext.PNRID}`);
      if (filterContext.hasTravelerName
        && filterContext.travelerName) tmp.push(`people.fullName=${filterContext.travelerName}`);
      if (filterContext.hasEmailAddress
        && filterContext.emailAddress) tmp.push(`people.emailAddresses.email=${filterContext.emailAddress}`);

      queryString = tmp.join('&');
      if (queryString) queryString = '?' + queryString;
    }
    return queryString;
  }

  private getSegmentLabel(type: string, startEnd: string) {
    switch (type + startEnd) {
      case "airstart":
        return "FLIGHT DEPARTURE";
      case "airend":
        return "FLIGHT ARRIVAL";
      case "hotelstart":
        return "HOTEL CHECKIN";
      case "hotelend":
        return "HOTEL CHECKOUT";
      case "vehiclestart":
        return "CAR RENTAL PICKUP";
      case "vehicleend":
        return "CAR RENTAL DROPOFF";
    }
  }

  private getSegmentDescription(location: any): string {
    switch (location.locationType) {
      case "airport":
        return `${location.locTypeAttributes.airlineCode} ${location.locTypeAttributes.flightNumber} ${location.locTypeAttributes.segmentStartEnd == 'start' ? 'Depature' : 'Arrival'} ${this.datePipe.transform(location.locTypeAttributes.utcDate, "shortTime")}`;
      case "hotel":
        return "";
      case "rental":
        return "";
      default:
        return "";
    }
  }

  private getHighestRiskRating(cities: City[]) {
    let risk = 0, label = '';
    if (cities && cities.length) {
      cities.forEach(c => {
        if (c.travelSegments.length) {
          c.travelSegments.forEach(s => {
            if (risk < s.riskNumber) {
              risk = s.riskNumber;
              label = s.riskLabel;
            }
          });
        }
      });
    }
    return label;
  }
}
