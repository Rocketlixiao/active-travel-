import { Injectable } from '@angular/core';

declare var toastr: any;

@Injectable()
export class ToastrService {
  private toastOption: any = {
    toastClass: 'report-toast',
    positionClass: 'report-toast-position',
    messageClass: 'report-toast-message'
  };
  private iconSuccess: string = '<i class="toast-icon report-toast-ok"></i>';
  private iconError: string = '<i class="toast-icon report-toast-error"></i>';

  success(message: string, title?: string) {
    toastr.success(this.iconSuccess + message, title, this.toastOption);
  }

  error(message: string, title?: string) {
    toastr.error(this.iconError + message, title, this.toastOption);
  }
}
