import { TestBed, inject } from '@angular/core/testing';

import { NrcService } from './nrc.service';

describe('NrcService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NrcService]
    });
  });

  it('should be created', inject([NrcService], (service: NrcService) => {
    expect(service).toBeTruthy();
  }));
});
