import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { SettingsData } from '../models/SettingsData';
import { NrcService } from '../services/nrc.service';
import { ThemeService } from '../services/theme.service';
import { ErrorService } from '../services/error.service';


//import '../libs/globalConfig.js';
declare var globalConfig: any;

@Injectable()
export class SettingsService {

  tempSettingsData = new SettingsData();
  settingsData = new BehaviorSubject<SettingsData>(this.tempSettingsData);
  castSettingsData = this.settingsData.asObservable();

  private _settingsData: SettingsData;
  getSettingsData() {
    return this._settingsData;
  }
  setSettingsData(val) {
    this._settingsData = val;
  }

  constructor(private nrcService: NrcService, private themeService: ThemeService, private errorService: ErrorService) { }

  getSettings() {
    this.nrcService.getSettings()
      .then(res => {
        this.changeSettingsData(res);
      })
  }

  getOrgSetting() {
    this.nrcService.getCurrentUser().then(data => {
      if (data && data.Result && data.Result.userInfo) {
        let features = data.Result.userInfo.features as string;
        globalConfig.isNc4AdminOrOrgAdmin = data.Result.userInfo.isSysadmin == 'true' || (features && features.indexOf('ORGADMIN') > -1);
      }
    });
  }

  getPromiseSettings() {
    var promise = new Promise<any>((resolve, reject) => {
      if (this.getSettingsData()) {

        resolve(this.getSettingsData());
      }
      else {

        this.nrcService.getSettings().then(res => {

          this.changeSettingsData(res);

          resolve(res);
        });
      }
    });
    return promise;
  }

  changeSettingsData(settingsData: SettingsData) {
    try {
      this.tempSettingsData = settingsData;
      this.tempSettingsData.ColorPaletteObject = this.themeService.getSelectedOption(settingsData.ColorPalette, this.themeService.listColorPalette);
      this.tempSettingsData.LogoPath = globalConfig.CDN.root + '/nc4mapMainStyle/images/';
      this.tempSettingsData.LogoTitleObject = this.themeService.getSelectedOption(settingsData.LogoTitle, this.themeService.listLogoImage);
      //update settings
      globalConfig.settingsData = this.tempSettingsData;
      this.setSettingsData(this.tempSettingsData);
      this.settingsData.next(this.tempSettingsData);

      //update theme
      this.themeService.updateTheme(this.tempSettingsData);
    } catch (e) {
      this.errorService.popupMessage(e);      
    }
  }
}
