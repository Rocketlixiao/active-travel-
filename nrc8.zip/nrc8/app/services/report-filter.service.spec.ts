import { TestBed, inject } from '@angular/core/testing';

import { ReportFilterService } from './report-filter.service';

describe('ReportFilterService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReportFilterService]
    });
  });

  it('should be created', inject([ReportFilterService], (service: ReportFilterService) => {
    expect(service).toBeTruthy();
  }));
});
