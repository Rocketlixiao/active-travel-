import { TestBed, inject } from '@angular/core/testing';

import { TravelDaysService } from './travel-days.service';

describe('TravelDaysService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TravelDaysService]
    });
  });

  it('should be created', inject([TravelDaysService], (service: TravelDaysService) => {
    expect(service).toBeTruthy();
  }));
});
