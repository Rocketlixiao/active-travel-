import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';

import { BuildInfo } from '../models/BuildInfo';
import { SettingsData } from '../models/SettingsData';
import { ErrorService } from '../services/error.service';
import { Observer } from "rxjs";
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/map';
import { error } from 'protractor';

declare var globalConfig: any;
declare var reportConfig: any;

@Injectable()
export class NrcService {

  private headers = new Headers({ 'Content-type': 'application/json;charset=utf-8' });
  private _errorService: any;

  constructor(private http: Http, private errorService: ErrorService) {
    this._errorService = this.errorService;
  }

  getUserInfo() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/userinfo.json' : '/esa/jsonoutput/userinfo';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getBuildInfo() {

    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/api/BuildInfo' : 'api/BuildInfo';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getSettings() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/api/RiskCenterFeedProfile' : 'api/RiskCenterFeedProfile';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  createSettings(settingsData: SettingsData) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/api/RiskCenterFeedProfile' : 'api/RiskCenterFeedProfile';
    return this.http.post(url, JSON.stringify(settingsData), { headers: this.headers })
      .toPromise()
      .then(response => response.json())
      .catch(error => this.handleError(error));
  }

  getIncidents() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/api/RiskCenterFeed' : 'api/RiskCenterFeed';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getIncidentsByIds(ids: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/api/RiskCenterFeed?ids=' + ids : 'api/RiskCenterFeed?ids=' + ids;
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getIncident(identity: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/api/RiskCenterFeed/' + identity : 'api/RiskCenterFeed/' + identity;
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }


  getAssets(lids: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/locations.json?&lids=' + lids : '/nc4maps/rest/services/location/FeatureServer/locationaz/query?f=json&where=1=1&outSR=102100&outFields=city,street,postal,country,description,lastupdateddate,contactemail,region,showonmap&cluster=false&lids=' + lids;

    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getAsset(locationId: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/location.json' : '/nc4maps/rest/services/location/FeatureServer/location/' + locationId + '?f=json&outSR=102100';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getProximities(parameters: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/proximity.json?us=' + parameters : '/vnext/proximity?us=' + parameters;
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getIncProximities(parameters: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/proximityinc.json?us=' + parameters : '/vnext/proximity?type=inc&us=' + parameters;
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getFacProximities(parameters: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/proximityfac.json?us=' + parameters : '/vnext/proximity?type=fac&us=' + parameters;
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getLegacyProximities() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/legacyproximity.json' : '/nc4maps/rest/services/location/FeatureServer/locationpw/query?f=json&where=1=1&outSR=102100';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getResources() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/resources.json' : '/vnext/incInfo';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getIncidentsAssetsUpdates(timestamp: string) {

    const urlIncidents = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/api/RiskCenterFeed?timestamp=' + encodeURIComponent(timestamp) : 'api/RiskCenterFeed?timestamp=' + encodeURIComponent(timestamp);
    const urlAssets = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/locations.json' : '/nc4maps/rest/services/location/FeatureServer/locationaz/query?f=json&where=1=1&outSR=102100&outFields=city,street,postal,country,description,lastupdateddate,contactemail,region,showonmap&cluster=false';

    return Observable.forkJoin(
      this.http.get(urlIncidents).map((res: Response) => res.json()),
      this.http.get(urlAssets).map((res: Response) => res.json())
    )
  }

  getFacProximitiesLegacyProximitiesResources(parameters: string) {
    const urlProximity = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/proximityfac.json?us=' + parameters : '/vnext/proximity?type=fac&us=' + parameters;
    const urlLegacyProximities = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/legacyproximity.json' : '/nc4maps/rest/services/location/FeatureServer/locationpw/query?f=json&where=1=1&outSR=102100';
    const urlResources = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/resources.json' : '/vnext/incInfo';

    return Observable.forkJoin(
      this.http.get(urlProximity).map((res: Response) => res.json()),
      this.http.get(urlLegacyProximities).map((res: Response) => res.json()),
      this.http.get(urlResources).map((res: Response) => res.json())
    )
  }

  getProximitiesLegacyProximitiesResources(parameters: string) {
    const urlProximity = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/proximityfac.json?us=' + parameters : '/vnext/proximity?us=' + parameters;
    const urlLegacyProximities = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/legacyproximity.json' : '/nc4maps/rest/services/location/FeatureServer/locationpw/query?f=json&where=1=1&outSR=102100';
    const urlResources = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/resources.json' : '/vnext/incInfo';

    return Observable.forkJoin(
      this.http.get(urlProximity).map((res: Response) => res.json()),
      this.http.get(urlLegacyProximities).map((res: Response) => res.json()),
      this.http.get(urlResources).map((res: Response) => res.json())
    )
  }

  getProximitiesLegacyProximities(parameters: string) {
    const urlProximity = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/proximity.json?us=' + parameters : '/vnext/proximity?us=' + parameters;
    const urlLegacyProximities = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/legacyproximity.json' : '/nc4maps/rest/services/location/FeatureServer/locationpw/query?f=json&where=1=1&outSR=102100';

    return Observable.forkJoin(
      this.http.get(urlProximity + '?us=' + parameters).map((res: Response) => res.json()),
      this.http.get(urlLegacyProximities).map((res: Response) => res.json())
    )
  }

  getCategories() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/categories.json' : globalConfig.CDN.root + '/endpoint/categories.json';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getDataTypes() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/data-types.json' : globalConfig.CDN.root + '/endpoint/data-types.json';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getMultipleFilters() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/multipleFilters.json' : globalConfig.CDN.root + '/endpoint/multipleFilters.json';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  sendNotificationIncident(data: any) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/api/ForwardNotificationIncident' : 'api/ForwardNotificationIncident';

    return this.http
      .post(url, data)
      .map(res => res.json())

  }

  sendNotificationAsset(data: any) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/api/ForwardNotificationAsset' : 'api/ForwardNotificationAsset';

    return this.http
      .post(url, data)
      .map(res => res.json())

  }

  getCurrentUser() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/user.json' : '/nrcapi/echo';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getEsaUserInfo() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/esa-userinfo.json' : '/esa/jsonoutput/userinfo';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  //activ travel report get Executive Summary
  getExecutiveSummarys(queryString?: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/executive-summary.json' : '/nrcapi/executivesummary' + (queryString || '');
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getItineraryDetail(queryString: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/itineraryDetail.json' : `/nrcapi/assets` + (queryString || '');
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getActivTravels(queryString: string) {
    let q = "maxitems=" + (reportConfig.TravelLocationMaxRows || -1);
    if (queryString) queryString = `${queryString}&${q}`;
    else queryString = "?" + q;

    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/travel-location.json' : '/nrcapi/travellocationsnow' + (queryString || '');
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getPassengersOnFlight(queryString?: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/passengers-on-flight.json' : '/nrcapi/passengersonflight' + (queryString || '');
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getTravelDays(queryString?: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/travel-days.json' : '/nrcapi/traveldays' + (queryString || '');
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getTravelSearch(queryString?: string) {
    let q = "maxitems=" + (reportConfig.TravelSearchMaxRows || -1);
    if (queryString) queryString = `${queryString}&${q}`;
    else queryString = "?" + q;

    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/travel-search.json' : '/nrcapi/travelsearch' + (queryString || '');
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  getMySavedReports() {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/my-saved-reports.json' : '/nrcapi/usersettings';
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }


  getAirPort(queryString?: string) {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/airport.json' : '/nrcapi/airports' + (queryString || '');
    return this.http.get(url)
      .toPromise()
      .then(res => res.json())
      .catch(error => this.handleError(error));
  }

  searchAirPorts(queryString?: string): Observable<any> {
    const url = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/airport.json' : '/nrcapi/airports' + (queryString || '');
    return this.http.get(url).map(x => x.json().Result);
  };

  getFilterDropdownItems() {
    const urlRegions = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/filter-regions.json' : '/nrcapi/regions';
    const urlCountries = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/filter-countries.json' : '/nrcapi/countries';
    const urlOrganizations = globalConfig.isDebugMode ? 'http://localhost:3643/nrc8/endpoint/filter-organizations.json' : '/nrcapi/myorgs';

    return Observable.forkJoin(
      this.http.get(urlRegions).map((res: Response) => res.json()),
      this.http.get(urlCountries).map((res: Response) => res.json()),
      this.http.get(urlOrganizations).map((res: Response) => {
        let r = res.json(), tmp = r.Result;
        r.Result = [];
        r.Result.push({
          'organizations': tmp
        });
        return r;
      })
    )
  }

  sendReportEmail(data: any) {
    const url = 'api/AzureFunctionProxy/SendMail';

    return this.http.post(url, data)
      .toPromise()
      .catch(error => this.handleError(error));
  }

  sendReportEmailWithReport(data: any) {
    const url = 'api/AzureFunctionProxy/SendMailwithReport';

    return this.http.post(url, data)
      .toPromise()
      .catch(error => this.handleError(error));
  }

  updateMySavedReports(data: any) {
    const url = '/nrcapi/usersettings';

    return this.http.post(url, JSON.stringify(data))
      .toPromise()
      .then(response => response.json())
      .catch(error => this.handleError(error));
  }

  downloadPdfReport(data: any, fileName: string): Observable<any> {
    const url = 'api/AzureFunctionProxy/DownloadPDF';
    return this.makeXMLRequest(url, fileName, data);
  }

  downloadExcelReport(data: any, fileName: string): Observable<any> {
    const url = 'api/AzureFunctionProxy/DownloadExcel';
    return this.makeXMLRequest(url, fileName, data);
  }

  downloadHtmlReport(data: any, fileName: string): Observable<any> {
    const url = 'api/AzureFunctionProxy/DownloadHtml';
    return this.makeXMLRequest(url, fileName, data);
  }

  handleError(error: any) {
    var message = 'Sorry! Something went wrong and we weren’t able to load the data for this report. Please try your query again, and if this problem persists, please report it to support@NC4.com';
    this.errorService.popupMessage(message);
  }

  private makeXMLRequest(url: string, fileName: string, data: any): Observable<any> {
    return Observable.create((obs: Observer<any>) => {
      let xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = () => {
        var a;
        if (xhttp.readyState === 4 && xhttp.status === 200) {
          a = document.createElement('a');
          a.href = window.URL.createObjectURL(xhttp.response);
          a.download = fileName;
          a.style.display = 'none';
          document.body.appendChild(a);
          a.click();
          obs.next(null);
        }
        else {
          obs.error('Download file failed');
        }
      };
      xhttp.onerror = err => obs.error('Download file failed');
      xhttp.open("POST", url);
      xhttp.setRequestHeader("Content-Type", "application/json");
      xhttp.responseType = 'blob';
      xhttp.send(JSON.stringify(data));
    });
  }
}
