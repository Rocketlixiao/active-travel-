import { Injectable, Inject } from '@angular/core';
import { NrcService } from '../services/nrc.service'
import { MapService } from '../services/map.service'
import { SharedService } from '../services/shared.service';
import { SettingsService } from '../services/settings.service';
import { SettingsData } from '../models/SettingsData';
import { DOCUMENT } from '@angular/platform-browser';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Router } from '@angular/router';

//import '../libs/globalConfig.js';
declare var globalConfig: any;

@Injectable()
export class FilterService {

  ButtonText = new BehaviorSubject<string>("APPLY FILTERS");
  castButtonText = this.ButtonText.asObservable();

  settingsData: SettingsData;
  //tempMultipleFilters =[];
  mutipleFilters = new BehaviorSubject<any[]>(null);
  castMutipleFilters = this.mutipleFilters.asObservable();

  private _multipleFilters: any[];

  setMultipleFilters(val) {
    this._multipleFilters = val;
  }

  getMultipleFilters() {
    return this._multipleFilters;
  }

  constructor(@Inject(DOCUMENT) private document: any, private nrcService: NrcService, private sharedService: SharedService, private router: Router, private mapService: MapService) { }

  changeButtonText(buttonText: string) {
    this.ButtonText.next(buttonText);
  }

  chageMutipleFilters(mutipleFilters: any[]) {
    globalConfig.multipleFilters = mutipleFilters;
    this.setMultipleFilters(mutipleFilters);
    this.mutipleFilters.next(mutipleFilters);
  }

  updateMultipleFilters(settingsData: any) {
    this.getPromiseMultipleFilters().then(res => {

      for (let r of res) {
        if (r.name === "CyberTech India Only") {
          r.isOpen = settingsData.IsCybertechIndia;
          break;
        }
      }

      this.chageMutipleFilters(res);
    });
  }

  getMultipleFiltersData() {
    this.nrcService.getMultipleFilters().then(res => {
      this.chageMutipleFilters(res);
    });
  }

  getPromiseMultipleFilters() {
    var promise = new Promise<any[]>((resolve, reject) => {
      if (this.getMultipleFilters()) {

        resolve(this.getMultipleFilters());
      }
      else {

        this.nrcService.getMultipleFilters().then(res => {
          resolve(res);
        });
      }
    });
    return promise;
  }

  isInclude(a, b) {
    var arr = a.split(",");
    for (var i = 0; i < arr.length; i++) {
      if (b.toLowerCase() == arr[i].toLowerCase()) {
        return true;
      }
    }
    return false;
  }

  compare(a, b) {
    if (a.severity < b.severity)
      return 1;
    if (a.severity > b.severity)
      return -1;
    return 0;
  }

  isMatched(dateStart, dateEnd, item, isMap) {
    var dayEnd = new Date(parseFloat(dateEnd));
    dayEnd.setHours(0);
    dayEnd.setMinutes(0);
    dayEnd.setSeconds(0);
    dayEnd.setMilliseconds(0);
    dayEnd.setDate(dayEnd.getDate() + 1);
    var dayEndTime = dayEnd.getTime();

    var timespan = isMap ? item.sent : item.timestamp;
    var itemTimestamp = new Date(timespan).getTime();
    if (dateStart == dateEnd) {
      if (itemTimestamp < dateStart)
        return;
    }
    else {
      if (itemTimestamp < dateStart || itemTimestamp > dayEndTime)
        return false;
    }

    if (!this.isInclude(globalConfig.filterObject.isOpen + '', item.IsOpened + ''))
      return false;

    var a = globalConfig.filterObject.severities == "" || (globalConfig.filterObject.severities != "" && this.isInclude(globalConfig.filterObject.severities, isMap ? item.info_severity : item.risk));
    var b = globalConfig.filterObject.incidents == "" || (globalConfig.filterObject.incidents != "" && this.isInclude(globalConfig.filterObject.incidents, item.source));
    var c = globalConfig.filterObject.region == "" || (globalConfig.filterObject.region != "" && this.isInclude(globalConfig.filterObject.region, item.region));
    var d = false;
    if (globalConfig.filterObject.filterSubCategory == "") {
      d = globalConfig.filterObject.filterCategory == "" || (globalConfig.filterObject.filterCategory != "" && this.isInclude(globalConfig.filterObject.filterCategory, isMap ? globalConfig.getIncidentCategory(item) : item.category));
    } else {
      d = this.isInclude(globalConfig.filterObject.filterSubCategory, item.info_event);
    }
    var f = globalConfig.filterObject.ImpactedAssets == "" || (globalConfig.filterObject.ImpactedAssets != "" && item.ImpactedAssets != globalConfig.filterObject.ImpactedAssets);
    var g = globalConfig.filterObject.country == "" || (globalConfig.filterObject.country != "" && item.country.toLowerCase() == globalConfig.filterObject.country);

    if (!a || !b || !c || !d || !f || !g)
      return false;

    return true;//true means this item matched the filter condition
  };

  RunFilter(filter) {
    globalConfig.filterObject = filter;
    if (filter.name != "") {

      var multipleFilters = this.getMultipleFilters();
      for (var i = 0; i < multipleFilters.length; i++) {
        multipleFilters[i].IsCurrent = false;
        if (multipleFilters[i].name == filter.name) {
          multipleFilters[i].IsCurrent = true;
          globalConfig.filtedItemIndex = i;
        }
      }
      this.setMultipleFilters(multipleFilters);

      globalConfig.isFilterApplied = false;
      this.changeButtonText(globalConfig.isFilterApplied ? "CLEAR FILTERS" : "APPLY FILTERS");
    }

    globalConfig.allFilteredIncidentItems = [];

    var dateStart = globalConfig.filterObject.dateStart;
    var dateEnd = globalConfig.filterObject.dateEnd;
    for (let item of globalConfig.allIncidentItems) {

      if (this.isMatched(dateStart, dateEnd, item, false)) {
        globalConfig.allFilteredIncidentItems.push(item);
      }
    };

    globalConfig.allFilteredIncidentItems = globalConfig.allFilteredIncidentItems.sort(this.compare);
    globalConfig.allFilteredAssetItems = globalConfig.allAssetItems;

    if (globalConfig.filterObject.locations.length > 0) {
      globalConfig.allFilteredAssetItems = [];
      for (let item of globalConfig.allAssetItems) {
        if (globalConfig.filterObject.locations.indexOf(item.type.toLowerCase()) * 1 >= 0) {
          globalConfig.allFilteredAssetItems.push(item);
        }
      };
    }

    //update incidents/assets when filter is completed
    this.sharedService.changeIncidentsItems(globalConfig.allFilteredIncidentItems);
    this.sharedService.changeAssetsItems(globalConfig.allFilteredAssetItems);

    //hide preset
    if (this.document.getElementById('filterPreset')) {
      globalConfig.removeClass(this.document.getElementById('filterPreset'), 'active');
    }
  };

  RunMutipleFilter(filter) {
    this.RunFilter(filter);
    this.mapService.ResetMapAndScrollBar();
  }

  getCheckedValuesByParentDivId(parentDivId) {
    var parentDiv = this.document.getElementById(parentDivId);
    var checkBoxs = parentDiv.getElementsByTagName('input');
    var result = "";
    for (var i = 0; i < checkBoxs.length; i++) {
      if (checkBoxs[i].checked)
        result += checkBoxs[i].value + ",";
    }
    result = result.substring(0, result.length - 1);
    return result;
  }

  saveFilterForArticleAndAssets() {

    var severities = "", locations = "", analysis = "", incidents = "", openOrClosed = "";
    severities = this.getCheckedValuesByParentDivId("severityFilter");
    openOrClosed = this.getCheckedValuesByParentDivId("openOrCloseFilter");
    if (openOrClosed == "") {
      openOrClosed = "open";
    }
    if (this.document.getElementsByName('layer[3]')[0].checked) {
      locations = this.getCheckedValuesByParentDivId("locationFilterDiv");
    }
    if (this.document.getElementsByName('layer[0]')[0].checked) {
      incidents = this.getCheckedValuesByParentDivId("interIncidentsFilterDiv");
    }
    if (this.document.getElementsByName('layer[2]')[0].checked) {
      analysis = this.getCheckedValuesByParentDivId("analysisFilterDiv");
    }
    if (incidents == "") {
      incidents = analysis;
    }
    else {
      incidents = incidents + "," + analysis;
    }

    var regionSelect = this.document.getElementById("region");
    var region = regionSelect.value;
    if (region == "Select Region") {
      region = "";
    }
    var dateStart = this.document.getElementById("date-range-from").value;
    var dateEnd = this.document.getElementById("date-range-to").value;

    var filterCategory = "";

    var tagSpans = this.document.getElementById("categorySelector").getElementsByTagName("a")[0].getElementsByTagName("span");
    for (var i = 0; i < tagSpans.length; i++) {
      if (tagSpans[i].className == "select2-chosen") {
        filterCategory = tagSpans[i].innerHTML.toLowerCase();
      }
    }

    if (filterCategory == "select category") {
      filterCategory = "";
    }
    var filterSubCategory = this.getCheckedValuesByParentDivId("subCategoryDiv");

    var newItem = { "name": "", "severities": severities, "locations": locations, "incidents": incidents, "isOpen": openOrClosed, "region": region, "dateStart": dateStart, "dateEnd": dateEnd, "filterCategory": filterCategory, "filterSubCategory": filterSubCategory, "ImpactedAssets": "", "country": "" };

    if (!globalConfig.isFilterApplied) {
      globalConfig.isFilterApplied = true;
    }
    else {
      globalConfig.isFilterApplied = false;
    }

    if (globalConfig.isFilterApplied) {
      this.changeButtonText("CLEAR FILTERS");
      //Run filer here.
      this.RunMutipleFilter(newItem);
      //update multiple filter object
      var multipleFilters = this.getMultipleFilters();
      for (var i = 0; i < multipleFilters.length; i++) {
        multipleFilters[i].IsCurrent = false;
      }
      this.setMultipleFilters(multipleFilters);
    }
    else {

      this.changeButtonText("APPLY FILTERS");
      //Reset filter.
      var multipleFilters = this.getMultipleFilters();
      globalConfig.filtedItemIndex = 0;
      this.RunMutipleFilter(multipleFilters[globalConfig.filtedItemIndex]);
    }

    this.document.getElementById("filterClickIcon").setAttribute("class", "wrap nav-item");
  }
}
