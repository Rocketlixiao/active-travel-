import { Injectable } from '@angular/core';
import { CapitalizePipe } from '../pipes/capitalize.pipe';
import { SharedService } from '../services/shared.service';
//import '../libs/globalConfig.js';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
declare var globalConfig: any;

@Injectable()
export class DashboardService {

  TRAVELER = 'traveler';
  ACTIVPOINT = 'activpoint';
  FACILITY = 'facility';
  LABEL_CENTRALAMERICA = 'central-america';
  LABEL_NORTHAMERICA = 'north-america';
  LABEL_OCEANIA = 'oceania';
  LABEL_ANTARCTICA = 'antarctica';
  LABEL_MIDDLEEAST = 'middle-east';
  LABEL_SOUTHAMERICA = 'south-america';
  LABEL_AFRICA = 'africa';
  LABEL_EUROPE = 'europe';
  LABEL_ASIA = 'asia';
  CENTRALAMERICA = 'Central America';
  NORTHAMERICA = 'North America';
  OCEANIA = 'Oceania';
  ANTARCTICA = 'Antarctica';
  MIDDLEEAST = 'Middle East';
  SOUTHAMERICA = 'South America';
  AFRICA = 'Africa';
  EUROPE = 'Europe';
  ASIA = 'Asia';
  types = [
    {
      CDN: globalConfig.CDN.root,
      type: 'traveler', title: 'Travelers', id: this.TRAVELER, total: 0,
      alerts: {
        extreme: 0, severe: 0, moderate: 0, minor: 0
      },
      charts: {
        pie: { title: "Chart Headline", description: "Legend", data: [{ label: '', lineLabel: '', value: '100', color: globalConfig.SEVERITY_COLOR_NORMAL }] },
        regionmap: { title: "Map Headline", description: "Legend", data: [] }
      }
    },
    {
      CDN: globalConfig.CDN.root,
      type: 'activpoint', title: 'ActivPoint', id: this.ACTIVPOINT, total: 0,
      alerts: {
        extreme: 0, severe: 0, moderate: 0, minor: 0
      },
      charts: {
        pie: { title: "Chart Headline", description: "Legend", data: [{ label: '', lineLabel: '', value: '100', color: globalConfig.SEVERITY_COLOR_NORMAL }] },
        regionmap: { title: "Map Headline", description: "Legend", data: [] }
      }
    },
    {
      CDN: globalConfig.CDN.root,
      type: 'location', title: 'Facilities', id: this.FACILITY, link: '/assets/list', total: 0,
      alerts: {
        extreme: 0, severe: 0, moderate: 0, minor: 0
      },
      charts: {
        pie: { title: "Chart Headline", description: "Legend", data: [{ label: '', lineLabel: '', value: '100', color: globalConfig.SEVERITY_COLOR_NORMAL }] },
        regionmap: { title: "Map Headline", description: "Legend", data: [] }
      }
    }
  ];

  tempFacilityDashboard = this.findType('facility');
  dashboardFacility = new BehaviorSubject<any>(this.tempFacilityDashboard);
  castDashboardFacility = this.dashboardFacility.asObservable();

  constructor(private sharedService: SharedService) {

  }

  changeDashboardFacility(dashboard: any) {
    this.dashboardFacility.next(dashboard);
  }

  findType(id: string) {
    return this.types.find(type => type.id === id);
  }

  initDashboardFacility(id: string) {

    if (id === this.FACILITY) {
      this.sharedService.castAssetsItems.subscribe(ass => {

        this.handleFacilities(ass, id);
        this.changeDashboardFacility(this.tempFacilityDashboard);
      });


    }
  }

  handleFacilities(assets, id) {

    if (!assets.length || id != this.FACILITY) {

      return;
    }

    //severity
    var extreme = 0, severe = 0, moderate = 0, minor = 0, total = assets.length,
      round = Math.round,
      //region
      ca = 0, na = 0, oc = 0, an = 0, me = 0, sa = 0, af = 0, eu = 0, ai = 0;
    let capitalize = new CapitalizePipe();
    for (let asset of assets) {
      switch (asset.risk) {
        case globalConfig.SEVERITY_VALUE_EXTREME:
          extreme++;
          break;
        case globalConfig.SEVERITY_VALUE_SEVERE:
          severe++;
          break;
        case globalConfig.SEVERITY_VALUE_MODERATE:
          moderate++;
          break;
        case globalConfig.SEVERITY_VALUE_MINOR:
          minor++;
          break;
      }
      
      switch (asset.region) {
        case this.CENTRALAMERICA:
          ca++;
          break;
        case this.NORTHAMERICA:
          na++;
          break;
        case this.OCEANIA:
          oc++;
          break;
        case this.ANTARCTICA:
          an++;
          break;
        case this.MIDDLEEAST:
          me++;
          break;
        case this.SOUTHAMERICA:
          sa++;
          break;
        case this.AFRICA:
          af++;
          break;
        case this.EUROPE:
          eu++;
          break;
        case this.ASIA:
          ai++;
          break;
      }
    };

    this.tempFacilityDashboard.total = total;
    //alerts
    this.tempFacilityDashboard.alerts = {
      extreme: extreme,
      severe: severe,
      moderate: moderate,
      minor: minor
    };
    //charts.pie
    var pctgExtreme = (extreme / total * 100).toFixed(5) || '0',
      pctgSevere = (severe / total * 100).toFixed(5) || '0',
      pctgModerate = (moderate / total * 100).toFixed(5) || '0',
      pctgMinor = (minor / total * 100).toFixed(5) || '0',
      pctgNormal = ((this.tempFacilityDashboard.total - extreme - severe - moderate - minor) / total * 100).toFixed(5) || '0';
    function mark(value) {
      value *= 100;
      return value < 1 ? '<1%' : (round(value) + '%') || '';
    }
    this.tempFacilityDashboard.charts.pie.title = 'Facilities by Severity';
    this.tempFacilityDashboard.charts.pie.data = [
      { label: capitalize.transform(globalConfig.SEVERITY_VALUE_EXTREME), lineLabel: mark(extreme / total), value: pctgExtreme, color: globalConfig.SEVERITY_COLOR_EXTREME },
      { label: capitalize.transform(globalConfig.SEVERITY_VALUE_SEVERE), lineLabel: mark(severe / total), value: pctgSevere, color: globalConfig.SEVERITY_COLOR_SEVERE },
      { label: capitalize.transform(globalConfig.SEVERITY_VALUE_MODERATE), lineLabel: mark(moderate / total), value: pctgModerate, color: globalConfig.SEVERITY_COLOR_MODERATE },
      { label: capitalize.transform(globalConfig.SEVERITY_VALUE_MINOR), lineLabel: mark(minor / total), value: pctgMinor, color: globalConfig.SEVERITY_COLOR_MINOR },
      { label: 'None/Normal', lineLabel: mark((total - extreme - severe - moderate - minor) / total), value: pctgNormal, color: globalConfig.SEVERITY_COLOR_NORMAL }
    ];
    //charts.regionmap
    this.tempFacilityDashboard.charts.regionmap.title = 'Facilities by Region';
    this.tempFacilityDashboard.charts.regionmap.data = [
      { label: this.LABEL_CENTRALAMERICA, coordinate: [425.5, 403.2], value: ca },
      { label: this.LABEL_NORTHAMERICA, coordinate: [425.6, 215.7], value: na },
      { label: this.LABEL_OCEANIA, coordinate: [1698.9, 675.9], value: oc },
      { label: this.LABEL_ANTARCTICA, coordinate: [1211.1, 895.1], value: an },
      { label: this.LABEL_MIDDLEEAST, coordinate: [1204.5, 302.1], value: me },
      { label: this.LABEL_SOUTHAMERICA, coordinate: [600.9, 568.7], value: sa },
      { label: this.LABEL_AFRICA, coordinate: [1032.4, 416], value: af },
      { label: this.LABEL_EUROPE, coordinate: [1121.9, 159], value: eu },
      { label: this.LABEL_ASIA, coordinate: [1480.6, 299.2], value: ai }
    ];
  }
}
