import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { NrcService } from "./nrc.service";
import { SavedReport } from "../models/ReportHeader";

@Injectable()
export class ReportMySavedService {
  constructor(private nrcService: NrcService) { }

  getMySavedReports(): Promise<any> {
    return this.nrcService.getMySavedReports();
  }

  updateMySavedReports(data: SavedReport[]): Promise<any> {
    return this.nrcService.updateMySavedReports(data);
  }
}
