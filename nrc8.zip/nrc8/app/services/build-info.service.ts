import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { BuildInfo } from '../models/BuildInfo';
import { NrcService } from '../services/nrc.service';

@Injectable()
export class BuildInfoService {

  /*BuildInfo variable*/
  tempBuildInfo = new BuildInfo();
  buildInfo = new BehaviorSubject<BuildInfo>(this.tempBuildInfo);
  castBuildInfo = this.buildInfo.asObservable();
  /*end BuildInfo variable*/

  constructor(private nrcService: NrcService) { }

  /*BuildInfo function*/
  getBuildInfo() {
    this.nrcService.getBuildInfo()
      .then(res => {
        this.tempBuildInfo.version = res.version;
        this.tempBuildInfo.datetime = res.datetime;
        this.changeBuildInfo(this.tempBuildInfo);
      });
  }

  changeBuildInfo(buildInfo: BuildInfo) {
    this.buildInfo.next(buildInfo);
  }
  /*end BuildInfo function*/
}
