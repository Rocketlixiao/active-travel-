import { TestBed, inject } from '@angular/core/testing';

import { BuildInfoService } from './build-info.service';

describe('BuildInfoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BuildInfoService]
    });
  });

  it('should be created', inject([BuildInfoService], (service: BuildInfoService) => {
    expect(service).toBeTruthy();
  }));
});
