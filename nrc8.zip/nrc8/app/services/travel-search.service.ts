import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { NrcService } from '../services/nrc.service';
import { TravelSearch, Select, Where } from '../models/TravelSearch';
import { ColumnSetting } from '../services/activ-travel.service';
declare var globalConfig: any;

@Injectable()
export class TravelSearchService {
  public TravelSearch = new Array<TravelSearch>()
  constructor(private nrcService: NrcService) { }

  getTravelSearch(queryString: string): Promise<any> {
    return this.nrcService.getTravelSearch(queryString);
  }

  mappingData(res: any, searchCriti: any) {

    console.log(searchCriti);
    //remove the old and add the new 
    this.TravelSearch = [];
    for (var i = 0; i < res.Result.length; i++) {

      let temp = new TravelSearch();
      let tempSearch = res.Result[i];

      temp.id = tempSearch.id;

      temp.index = i;
      temp.isdrilldown = false;
      temp.isexpand = false;

      temp.name = tempSearch.fullName;
      temp.tripStart = tempSearch.tripStart;
      temp.tripEnd = tempSearch.tripEnd;
      temp.countries = tempSearch.countries;
      if (tempSearch.email[0] != undefined) {
        if (tempSearch.email[0].isPrimary) {
          temp.email = tempSearch.email[0].email;
        }
        else {
          temp.email = "";
        }

        if (tempSearch.phone[0] != undefined) {
          if (tempSearch.phone[0]["isPrimary"]) {
            temp.phone = tempSearch.phone[0].number;
          }
        } else { temp.phone = ""; }

      }
      //find in key word 
      let keywordString = "";
      for (var j = 0; j < searchCriti.length; j++) {
        let tempSelectInput = searchCriti[j].selectInput;
        let tempWhereValue = searchCriti[j].selectWhereValue + "";
        //for calendar use 
        let tempSelectWhereDataRangeStartValue = searchCriti[j].selectWhereDataRangeStartValue;
        let tempSelectWherDataRangeEndValue = searchCriti[j].selectWherDataRangeEndValue;

        switch (tempSelectInput) {
          case "country":
            var whereArray = tempWhereValue.toString().split(",");
            for (var w = 0; w < whereArray.length; w++) {
              for (var t = 0; t < tempSearch.countries.length; t++) {
                if (whereArray[w] == tempSearch.countries[t]) {
                  keywordString = keywordString + tempSearch.countries[t] + ","
                }
              }
            }
            break;
          case "locator":
            keywordString = keywordString + tempWhereValue + ","
            break;
          case "travelername":
            keywordString = keywordString + tempWhereValue + ","
            break;
          case "starttoenddate":
            keywordString = keywordString + tempSelectWhereDataRangeStartValue + "," + tempSelectWherDataRangeEndValue + ","
            break;

          default:
        }
      }

      //remove comma ,

      keywordString = keywordString.replace(/,\s*$/, "");

      temp.keywordsfoundinsearch = keywordString;

      this.TravelSearch.push(temp);
    }
    return this.TravelSearch;
  }

  getSelect(isAdmin:any) {

    console.log(isAdmin);
    let select= [
      new Select('region', 'Region'),
      new Select('country', 'Country'),
      new Select('city', 'City'),
      new Select('starttoenddate', 'Date Range'),
      new Select('segmenttype', 'Segment Type'),
      new Select('riskrating', 'Risk Rating'),
      new Select('locator', 'Record Locator'),
      new Select('travelername', 'Traveler name'),
      new Select('email', 'Email address'),
      new Select('flightnumber', 'Flight number'),
      new Select('airline', 'Airline'),
      new Select('locationname', 'Rental Car Agency'),
      new Select('airport', 'Airport')
    ];

    if (isAdmin)
    {
      select.push(new Select('orgname', 'Org Selector'));
    }
 
    return select;
  }

  getWhere() {

    return [
      new Where('In', 'region', 'In'),
      new Where('Not In', 'region', 'Not In'),

      new Where('In', 'country', 'In'),
      new Where('Not In', 'country', 'Not In'),

      new Where('In', 'city', 'In'),
      new Where('Not In', 'city', 'Not In'),

      new Where('=', 'starttoenddate', '='),
      new Where('<>', 'starttoenddate', '<>'),

      new Where('In', 'segmenttype', 'In'),
      new Where('Not In', 'segmenttype', 'Not In'),


      new Where('In', 'riskrating', 'In'),
      new Where('Not In', 'riskrating', 'Not In'),

      new Where('In', 'orgname', 'In'),
      new Where('Not In', 'orgname', 'Not In'),

      new Where('In', 'locator', 'In'),
      new Where('Not In', 'locator', 'Not In'),

      new Where('=', 'travelername', '='),
      new Where('<>', 'travelername', '<>'),

      new Where('=', 'airport', '='),
      new Where('<>', 'airport', '<>'),

      new Where('=', 'email', '='),
      new Where('<>', 'email', '<>'),

      new Where('In', 'flightnumber', 'In'),
      new Where('Not In', 'flightnumber', 'Not In'),

      new Where('In', 'airline', 'In'),
      new Where('Not In', 'airline', 'Not In'),

      new Where('In', 'locationname', 'In'),
      new Where('Not In', 'locationname', 'Not In'),

    ];
  }
  public fullColumns: ColumnSetting[] = [
    {
      field: 'id',
      title: 'Id',
      index: 0,
      type: 'hyperlink'
    }, {
      field: 'name',
      title: 'Name',
      index: 1,
      type: 'text'
    }, {
      field: 'phone',
      title: 'Phone',
      index: 2,
      type: 'text'
    }, {
      field: 'tripStart',
      title: 'Trip Start',
      index: 3,
      type: 'date'
    }, {
      field: 'tripEnd',
      title: 'Trip End',
      index: 4,
      type: 'date'
    }, {
      field: 'countries',
      title: 'Countries',
      index: 5,
      type: 'text'
    }, {
      field: 'keywordsfoundinsearch',
      title: 'Keywords Found in Search',
      index: 5,
      type: 'text'
    }
  ];

  public mobileColumns: ColumnSetting[] = [
    {
      field: 'id',
      title: 'Id',
      index: 0,
      type: 'hyperlink'
    }, {
      field: 'name',
      title: 'name',
      index: 0,
      type: 'text'
    }
  ];


}



