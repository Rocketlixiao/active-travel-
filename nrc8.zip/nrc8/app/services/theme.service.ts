import { Injectable, Inject } from '@angular/core';
import { Theme } from '../models/Theme';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { SettingsData } from '../models/SettingsData';
import { DOCUMENT } from '@angular/platform-browser';
//import '../libs/globalConfig.js';
declare var globalConfig: any;

@Injectable()
export class ThemeService {

  /*Theme variable*/
  listColorPalette = [
    { key: 'NC4 Blue', value: 'NC4Blue' },
    { key: 'Apple Black', value: 'AppleBlack' },
    { key: 'AIG Blue', value: 'AigBlue' },
    { key: 'Honeywell Red', value: 'HoneywellRed' },
    { key: 'MetLife Blue', value: 'MetLifeBlue' }
  ];

  listLogoImage = [
    { key: 'NC4.png', value: 'NC4-logo-white.svg' },
    { key: 'Apple.png', value: 'logos/Apple.png' },
    { key: 'AIG.png', value: 'logos/AIG.png' },
    { key: 'Honeywell.png', value: 'logos/Honeywell.png' },
    { key: 'MetLife.png', value: 'logos/Metlife.png' }
  ];

  defaultClassName: string = '';
  tempTheme = new Theme();
  theme = new BehaviorSubject<Theme>(this.tempTheme);
  castTheme = this.theme.asObservable();
  /*end Theme variable*/

  tempSettingsData = new SettingsData();

  constructor(@Inject(DOCUMENT) private document: any) {
    this.defaultClassName = this.document.body.className;
  }

  /*Theme function*/
  getSelectedOption(value: string, items: any) {
    let selected = items[0];
    for (let item of items) {
      if (item.value === value) {
        selected = item;
      }
    }

    return selected;
  };

  updateTheme(settingsData: SettingsData) {



    this.tempTheme.colorPalette = this.getSelectedOption(settingsData.ColorPalette, this.listColorPalette).value;
    this.tempTheme.logoPath = globalConfig.CDN.root + '/nc4mapMainStyle/images/';
    this.tempTheme.logoTitle = this.getSelectedOption(settingsData.LogoTitle, this.listLogoImage).value;
    this.tempTheme.showPoweredBy = settingsData.ShowPoweredBy;
    this.tempTheme.UserName = settingsData.UserName;
    this.tempTheme.HomeUrl = settingsData.HomeUrl;
    this.tempTheme.LogoutUrl = settingsData.LogoutUrl;

    this.changeTheme(this.tempTheme);

    //set theme in whole body
    this.document.body.className = this.defaultClassName + ' ' + this.tempTheme.colorPalette;


  }

  changeTheme(theme: Theme) {
    this.theme.next(theme);
  }

  /*end Theme function*/
}
