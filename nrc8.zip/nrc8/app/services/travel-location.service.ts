import { Injectable } from '@angular/core';
import { TravelLocation } from '../models/TravelLocation';
import { NrcService } from '../services/nrc.service';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { ReportFilterContext } from "../models/ReportHeader";
import { ColumnSetting } from '../services/activ-travel.service';
declare var globalConfig: any;

@Injectable()
export class TravelLocationService {
  public travelLocation = new Array<TravelLocation>()
  constructor(private nrcService: NrcService) { }

  getTravelLocation(filterContext: ReportFilterContext): Promise<any> {
    let queryString = this.getQueryString(filterContext);
    return this.nrcService.getActivTravels(queryString);
  }
  //, sort: SortDescriptor[]
  mappingData(res) {
    //remove the old and add the new 
    this.travelLocation = [];
    for (var i = 0; i < res.Result.length; i++) {
      let temp = new TravelLocation();
      let templocation = res.Result[i];;

      temp.id = templocation.id;
      temp.index = i;
      temp.isdrilldown = false;
      temp.isexpand = false;


      temp.region = templocation.region;
      temp.country = templocation.country;
      temp.city = templocation.city;

      temp.name = templocation.fullName;
      temp.segmentType = templocation.segmentType;
      temp.segmentTime = templocation.segmentTime;

      temp.travelStatus = templocation.travelStatus;

      temp.locationName = templocation.locationName;

      if (templocation.email.length > 0) {
        if (templocation.email[0].isPrimary) {
          temp.email = templocation.email[0].email;
        }
      }

      if (templocation.phone.length && templocation.phone[0]["isPrimary"]) {
        temp.phone = templocation.phone[0].number;
      }
      else { temp.phone = ""; }

      if (templocation.segmentType == "air") {

        temp.segmentDesignator = templocation.airlineCode + " " + templocation.flightNumber;
     
      } else if (templocation.segmentType == "hotel" || templocation.segmentType == "vehicle" || templocation.segmentType == "expat") {

        temp.segmentDesignator = templocation.locationName;
      }

      this.travelLocation.push(temp);

    }

    //this.travelLocation = orderBy(this.travelLocation, sort);
    return this.travelLocation;
  }

  private getQueryString(filterContext?: ReportFilterContext): string {
    let queryString: string = '';
    if (filterContext) {
      let tmp = [];
      if (filterContext.hasRegion
        && filterContext.selectedRegions
        && filterContext.selectedRegions.length) tmp.push(`region=${filterContext.selectedRegions.join(',')}`);
      if (filterContext.hasCountry
        && filterContext.selectedCountries
        && filterContext.selectedCountries.length) tmp.push(`country=${filterContext.selectedCountries.join(',')}`);
      if (filterContext.hasCity
        && filterContext.selectedCities
        && filterContext.selectedCities.length) tmp.push(`city=${filterContext.selectedCities.join(',')}`);
      if (filterContext.hasAirport
        && filterContext.selectedAirports
        && filterContext.selectedAirports.length) tmp.push(`locationname=${filterContext.selectedAirports.join(',')}`);
      if (filterContext.hasTimeRange
        && filterContext.dateFrom
        && filterContext.dateFrom.length) tmp.push(`startdate=${filterContext.dateFrom[0]}`);
      if (filterContext.hasTimeRange
        && filterContext.dateTo
        && filterContext.dateTo.length) tmp.push(`enddate=${filterContext.dateTo[0]}`);
      if (filterContext.hasSegmentType
        && filterContext.selectedSegmentTypes
        && filterContext.selectedSegmentTypes.length) tmp.push(`segmenttype=${filterContext.selectedSegmentTypes.map(s => s.value).join(',')}`);
      if (filterContext.hasRiskRating
        && filterContext.selectedRiskRatings
        && filterContext.selectedRiskRatings.length) tmp.push(`riskrating=${filterContext.selectedRiskRatings.join(',')}`);
      if (filterContext.hasOrganization
        && filterContext.selectedOrganizations
        && filterContext.selectedOrganizations.length) tmp.push(`orgname=${filterContext.selectedOrganizations.join(',')}`);

      queryString = tmp.join('&');
      if (queryString) queryString = '?' + queryString;
    }
    return queryString;
  }

  public fullColumns: ColumnSetting[] = [
    {
      field: 'id',
      title: 'PNRID',
      index: 0,
      type: 'hyperlink'
    }, {
      field: 'region',
      title: 'Region',
      index: 4,
      type: 'text'
    }, {
      field: 'country',
      title: 'Country',
      index: 5,
      type: 'text'
    }, {
      field: 'city',
      title: 'City',
      index: 6,
      type: 'text'
    }, {
      field: 'name',
      title: 'Name',
      index: 7,
      type: 'text'
    }, {
      field: 'email',
      title: 'Email',
      index: 8,
      type: 'text'
    }, {
      field: 'phone',
      title: 'Phone',
      index: 9,
      type: 'text'
    }, {
      field: 'locationName',
      title: 'Airport/Location Name',
      index: 10,
      type: 'text'
    }, {
      field: 'segmentTime',
      title: 'Seg. Time',
      index: 11,
      type: 'date'
    }, {
      field: 'segmentType',
      title: 'Seg. Type',
      index: 12,
      type: 'text'
    }, {
      field: 'segmentDesignator',
      title: 'Seg. Desgntr',
      index: 13,
      type: 'text'
    }
  ];
}
