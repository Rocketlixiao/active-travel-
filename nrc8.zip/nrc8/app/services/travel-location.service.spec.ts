import { TestBed, inject } from '@angular/core/testing';

import { TravelLocationService } from './travel-location.service';

describe('TravelLocationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TravelLocationService]
    });
  });

  it('should be created', inject([TravelLocationService], (service: TravelLocationService) => {
    expect(service).toBeTruthy();
  }));
});
