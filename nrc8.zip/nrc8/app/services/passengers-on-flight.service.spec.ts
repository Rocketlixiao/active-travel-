import { TestBed, inject } from '@angular/core/testing';

import { PassengersOnFlightService } from './passengers-on-flight.service';

describe('PassengersOnFlightService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PassengersOnFlightService]
    });
  });

  it('should be created', inject([PassengersOnFlightService], (service: PassengersOnFlightService) => {
    expect(service).toBeTruthy();
  }));
});
