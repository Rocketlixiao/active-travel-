export class Airport   {
  longitude: number;
  latitude: number;
  airportCode: string;
  airportName: string;
  cityName: string;
  stateProvince: string;
  countryName: string;
  countryIso: string;
  lowercaseAirportName: string;
    constructor() {
    }
} 
