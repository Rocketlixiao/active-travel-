export class TravelSearch   {
    id: string;
    index: number;         //the number of the row
    isdrilldown: boolean;  //is dill down for this row
    isexpand: boolean;     //is expand for this row
    name: string;
    email: string;
    phone: string;
    tripStart: string;
    tripEnd: string;
    countries: string;
    keywordsfoundinsearch: string;
    constructor() {
    }
}

export class SearchCritial {
  id = 0;

  //ANDORNOT = ['AND', 'OR', 'NOT'];

  //FIELD = [
  //  'Region',
  //  'Country',
  //  'City',
  //  'Airport',
  //  'Start Date of Travel',
  //  'End Date',
  //  'Segment Type',
  //  'Risk Rating',
  //  'Org Selector',
  //  'Record Locator',
  //  'Traveler name',
  //  'Email address',
  //  'Flight number',
  //  'Airline',
  //  'Rental Car Agency'
  //];
  //OPERATOR = ['=', '<>', '>=', '=<', 'IN'];

  //value = [];
}



export class Hero {
  id = 0;
  name = '';
  addresses: Address[];
}

export class Address {
  ANDORNOT = '';
  FIELD = '';
  OPERATOR = '';
  value = '';
  state = '';
}

export const heroes: Hero[] = [
  {
    id: 1,
    name: 'Whirlwind',
    addresses: [
     
    ]
  },
  {
    id: 2,
    name: 'Bombastic',
    addresses: [
    ]
  },
  {
    id: 3,
    name: 'Magneta',
    addresses: []
  },
];

export const ANDORNOT = ['And'];
export const FIELD = [
  'Region',
  'Country',
  'City',
  'Airport',
  'Start Date of Travel',
  'End Date',
  'Segment Type',
  'Risk Rating',
  'Org Selector',
  'Record Locator',
  'Traveler name',
  'Email address',
  'Flight number',
  'Airline',
  'Rental Car Agency'
];
export const OPERATOR = ['=', '<>', 'Not In', 'In'];

export const states = ['CA', 'MD', 'OH', 'VA'];


export class Select {
  constructor(public id: string, public name: string) { }
}

export class Where {
  constructor(public id: string, public selectid: string, public name: string) { }
}

export class Product {
  constructor(
    public ProductID?: number,
    public ProductName?: string,
    public UnitPrice?: number,
    public UnitsInStock?: number,
    public Discontinued?: boolean
  ) { }
}



