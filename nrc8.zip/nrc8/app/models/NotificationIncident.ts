
export class NotificationIncident {
  outField: string;
  availableOutFields: string[];
  additionalRecipients: string;
  emailsRegex: string;
  personalMessage: string;
  attachPDF: any;
  isInSubmitting: boolean;
  requestError: any;
}
