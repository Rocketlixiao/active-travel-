export class FilterData {
    status?: string;
    timeFrom?: string;
    timeTo?: string;
    regions: Array<string> = [];
    cities: Array<string> = [];
    countries: Array<string> = [];
    riskRating?: number;
    airports: Array<string> = [];
    segmentTypes: Array<string> = [];
    organizations: Array<string> = [];
}