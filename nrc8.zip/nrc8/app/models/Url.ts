export class Url {
  url_label: string;
  url: string; 
}
