export class ArticleDetail {
  Severity: string;
  Location: string;
  City: string;
  Country: string;
  Occurred: string;
  Last_Update: string;  
}
