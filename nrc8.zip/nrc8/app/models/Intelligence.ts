export class Intelligence {
  risk: string;
  date: any;
  clientDate: string;
  text: string;
  identifier: string;
  severity: string;
  headline: string;
  description: string;
  event: string;
  category: string;
  name: string;
  address: string;
  detail: {};  
}
