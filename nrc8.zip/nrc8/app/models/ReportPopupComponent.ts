import { EventEmitter } from "@angular/core";

export class ReportPopupComponent {
    data: any;
    submitData: EventEmitter<any>;
    submitSendEmail?: EventEmitter<any>;
}