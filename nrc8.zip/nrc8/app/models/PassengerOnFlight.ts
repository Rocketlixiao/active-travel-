export class PassengerOnFlight {
    id: number;
    index: number;         //the number of the row
    isdrilldown: boolean;  //is dill down for this row
    isexpand: boolean;     //is expand for this row

    airline: string;
    flightNumber: string;
    departureAirport: string;
    departureTime: string;
    departureCity: string;
    departureCountry: string;
    departureRisk: number;
    arrivalAirport: string;
    arrivalTime: string;
    arrivalCity: string;
    arrivalCountry: string;
    arrivalRisk: number;
    passengers: Passenger[];
    passengersCount: number;
}

export class Passenger {
    region: string;
    index: number;         //the number of the row
    isexpand: boolean;     //is expand for this row
    country: string;
    city: string;
    airportOrlocation: string;
    pnrid: string;
    name: string;
    email: string;
    segmentType: string;
    segmentTime: string;
    segmentDesignator: string;
}
