export class AssetSort {
  sortA: string = '-sortProximityStatus';
  sortB: string = 'type';
  sortC: string = 'locationName';  
}
