export class BuildInfo {
  version: string;
  datetime: string; 
}
