import { Url } from '../models/Url';
export class Asset {
  id: string;
  sourceURI: string;
  locationName: string;
  streetAddress: string;
  city: string;
  state: string;
  country: string;
  zip: string;
  latitude: string;
  longitude: string;
  type: string;
  contactManager: string;
  cotactOfficePhone: string;
  contactFax: string;
  contactCell: string;
  contactEmail: string;
  description: string;
  last_update: string;
  clientDate: string;
  ProximityStatusToDisplay: string;
  ProximityStatus: string;
  IncidentsAround: any[];
  address: string;
  Urls: Url[];
  objtype: string;
}
