export class TravelLocation   {
    id: string;
    index: number;         //the number of the row
    isdrilldown: boolean;  //is dill down for this row
    isexpand: boolean;     //is expand for this row

    region: string;
    country: string;
    city: string;
    name: string;
    email: string;
    phone: string;
    locationName: string;
    segmentTime: string;
    segmentType: string;
    travelStatus: string;
    segmentDesignator: string;
    constructor() {
    }
} 
