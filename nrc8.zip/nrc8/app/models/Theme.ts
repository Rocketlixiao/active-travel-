declare var globalConfig: any;
export class Theme {
  colorPalette: string;
  logoPath: string = globalConfig.CDN.root + '/nc4mapMainStyle/images/';
  logoTitle: string = 'NC4-logo-white.svg';
  showPoweredBy: boolean;
  UserName: string;
  HomeUrl: string;
  LogoutUrl: string;
}
