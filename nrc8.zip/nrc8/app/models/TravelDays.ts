export class TravelDays   {
    id: number;
    index: number;         //the number of the row
    isdrilldown: boolean;  //is dill down for this row
    isexpand: boolean;     //is expand for this row
    region: string;
    countries: string;
    riskRating: number;
    travelDays: number;
    constructor() {
    }
} 
