import { Injectable } from "@angular/core";

export class ReportHeader {
    description: string;
    itineraryDate?: string;
    filterContent?: ReportFilterContext;
    emailContent?: ReportEmailContext;
    editColumnsContent?: ReportEditColumnsContext;
    saveReportContent?: ReportSaveReportContext;
    mySavedReportsContent?: ReportMySavedReportContext;
    emailTravellerContent?: EmailTravellerContext;
}

export class ReportEditColumnsContext {
    columns: Array<{ title: string, name: string, isChecked: boolean }>;
}

export class ReportMySavedReportContext {
    recurrenceTypes: Array<string>;
    reportFormats: Array<string>;
    daysOfWeek: Array<string>;
    daysOfMonth: Array<number>;
    reports: Array<SavedReport>;
}

export class ReportSaveReportContext {
    allExistingReports?: Array<string>;
    currentReportName?: string;
    reportName?: string;
    reportId?: string;
    filter?: ReportFilterContext;
}

export class ReportEmailContext {
    outFields: string[];
    selectedOutField?: string;
    recipients?: Array<{ email: string, isChecked: boolean }>;
    subject?: string;
    message?: string;
    fileFormats: string[];
    selectedFileFormat?: string;
}

export class DownloadedReport {
    ReportType: string;
    Source: string; //report data json string
    FieldColumns?: Array<string>;
}

export class ReportFilterContext {
    hasTimeRange?: boolean;
    dateTitle?: string;
    dateFrom?: Array<string>;
    dateTo?: Array<string>;
    dateRange?: number;

    hasRegion?: boolean;
    selectedRegions?: Array<string>;

    hasCity?: boolean;
    selectedCities?: Array<string>;

    hasCountry?: boolean;
    selectedCountries?: Array<string>;

    hasRiskRating?: boolean;
    selectedRiskRatings?: Array<number>;

    hasAirport?: boolean;
    selectedAirports?: Array<string>;

    hasSegmentType?: boolean;
    selectedSegmentTypes?: Array<{ text: string, value: string }>;

    hasOrganization?: boolean;
    selectedOrganizations?: Array<string>;

    hasMinPassenger?: boolean;
    selectedMinPassenger?: Array<number>;

    hasPnrid?: boolean;
    PNRID?: string;

    hasTravelerName?: boolean;
    travelerName?: string;

    hasEmailAddress?: boolean;
    emailAddress?: string;
}

export class SavedReport {
    UID: string;
    ReportID: string;
    Scheduled: string;
    ReportFormat: string;
    SendTo: Array<string>;
    ViewFields: Array<string>;
    Filters: Array<any>;
    ReportName: string;
    ReportType: string;
    IsSubscribed?: boolean;
    DeliveryDayOfWeek?: string;
    DeliveryDayOfMonth?: string;
    DeliveryTimeOfDay?: string;
    SendCc?: Array<string>;
    SendBcc?: Array<string>;
    Subject?: string;
    Message?: string;
    PropertyBags?: { CorrelationId?: string; };
}

export class EmailTravellerContext {
    outFields: Array<string>;
    selectedOutField?: string;
    recipients?: Array<{ email: string, isChecked: boolean }>;
    subject?: string;
    message?: string;
}

@Injectable()
export class ReportRouteFactory {
    routes = [
        { key: "executive-summary", label1: "Executive Summary", label2: "ExecutiveSummary" },
        { key: "travel-location", label1: "Travel Locations", label2: "TravelLocations" },
        { key: "passengers-on-flight", label1: "Passengers On Flight", label2: "PassengersOnFlight" },
        { key: "travel-days", label1: "Travel Days", label2: "TravelDays" },
        { key: "travel-search", label1: "Search", label2: "Search" },
        { key: "itinerary", label1: "Itinerary Detail", label2: "ItineraryDetail" }
    ];

    getRouteByKey(key: string) {
        return this.routes.find(function (s) {
            return s.key === key;
        });
    };

    getRouteByLabel1(label1: string) {
        return this.routes.find(function (s) {
            return s.label1 === label1;
        });
    };

    getRouteByLabel2(label2: string) {
        return this.routes.find(function (s) {
            return s.label2 === label2;
        });
    };

    getKeyByLabel1(label1: string) {
        var route = this.getRouteByLabel1(label1);
        if (route) return route.key;
    };

    getKeyByLabel2(label2: string) {
        var route = this.getRouteByLabel1(label2);
        if (route) return route.key;
    };

    getLabel1ByKey(key: string) {
        var route = this.getRouteByKey(key);
        if (route) return route.label1;
    };

    getLabel2ByKey(key: string) {
        var route = this.getRouteByKey(key);
        if (route) return route.label2;
    };

    getReportRouteData(): Array<{ link: string, text: string }> {
        return this.routes.map(r => {
            return { link: `/reports/${r.key}`, text: r.label1 };
        });
    }
}