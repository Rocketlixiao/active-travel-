export class ArticleSort {
  sortA: string = '-HasImpactedAssets';
  sortB: string = '-severity';
  sortC: string = '-ImpactedAssets';
  sortD: string = '-timestamp';
}
