import { Travel } from './Travel';

export class ActiveTravel   {
    id: number;
    //name: string;
    index: number;         //the number of the row
    isdrilldown: boolean;  //is dill down for this row
    isexpand: boolean;     //is expand for this row
    region: string;
    country: string;
    riskrating: number;
    travelerscount: number;
    atlocation: number;
    enroute: number;
    travelers: Travel[] ;
    constructor() {
    }
} 
