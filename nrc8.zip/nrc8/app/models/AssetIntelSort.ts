export class AssetIntelSort {
  sortA: string = '-severity';
  sortB: string = 'DistanceToAssetNumber';
  sortC: string = '-timestamp';  
}
