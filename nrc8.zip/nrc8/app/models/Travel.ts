export class Travel {
    id: number;
    index: number;         //the number of the row
    isexpand: boolean;     //is expand for this row
    city: string;
    email: string;
    type: string;
    startDate: string;
    endDate: string;
    locationType: string;
    locationName: string;
    arrivalDate: string;
    departureDate: string;
    name: string;
    suborg: string;
    constructor() {
    }
} 
