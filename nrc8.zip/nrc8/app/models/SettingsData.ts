export class SettingsData {
  UserId: string;
  ProximityWarningEnabled: boolean;
  DistanceUnit: string;
  ExtremeEnabled: boolean;
  SevereEnabled: boolean;
  ModerateEnabled: boolean;
  MinorEnabled: boolean;
  ExtremeRadius: number;
  SevereRadius: number;
  ModerateRadius: number;
  MinorRadius: number;
  ColorPalette: string;
  ColorPaletteObject= { key: 'NC4 Blue', value: 'NC4Blue'};
  LogoTitle: string;
  LogoTitleObject = { key: 'NC4.png', value: 'NC4-logo-white.svg'};
  LogoPath: string;
  ShowPoweredBy: boolean;
  UserName: string;
  HomeUrl: string;
  LogoutUrl: string;
  IsThemeEditor: boolean;
  IsORGAdmin: boolean;
  IsCybertechIndia: boolean;
}
