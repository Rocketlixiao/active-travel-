export class ItineraryDetail {
    id: string;
    title: string;
    fullName: string;
    email: string;
    primaryPhone: string;
    bookingAgency: string;
    lastBookingAgencyUpdated: string;
    travelDays: TravelDay[];
}

export class TravelDay {
    localDate: string;
    risk: string;
    travelCities: City[];
}

export class City {
    code: string;
    travelSegments: Segment[];
}

export class Segment {
    type: string;
    typeName: string;
    infoTitle: string;
    infoDescription: string;
    riskNumber: number;
    riskLabel: string;
}