import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { DatePipe } from "@angular/common";
import { RouterModule, Routes } from '@angular/router';
import { HttpModule, JsonpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OrderModule } from 'ngx-order-pipe';
import { GridModule } from '@progress/kendo-angular-grid';
import { DropDownsModule, MultiSelectModule } from '@progress/kendo-angular-dropdowns';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { PopupModule } from "@progress/kendo-angular-popup";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { DragulaModule } from 'ng2-dragula';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';

import {
  PerfectScrollbarModule, PerfectScrollbarConfigInterface,
  PERFECT_SCROLLBAR_CONFIG
} from 'ngx-perfect-scrollbar';


//models
import { Theme } from './models/Theme';
import { BuildInfo } from './models/BuildInfo';
import { SettingsData } from './models/SettingsData';
import { ReportRouteFactory } from "./models/ReportHeader";


//service
import { SharedService } from './services/shared.service';
import { NrcService } from './services/nrc.service';
import { StorageService } from './services/storage.service';
import { FilterService } from './services/filter.service';
import { SortService } from './services/sort.service';
import { DashboardService } from './services/dashboard.service';
import { BuildInfoService } from './services/build-info.service';
import { SettingsService } from './services/settings.service';
import { ThemeService } from './services/theme.service';
import { MapService } from './services/map.service';
import { AutorefreshService } from './services/autorefresh.service';
import { PagerService } from './services/pager.service';
import { ItineraryService } from "./services/itinerary.service";
import { TravelLocationService } from './services/travel-location.service';
import { ActivTravelService } from './services/activ-travel.service';
import { ExecutiveSummaryService } from './services/executive-summary.service';
import { PassengersOnFlightService } from "./services/passengers-on-flight.service";
import { ReportEmailService } from "./services/report-email.service";
import { TravelDaysService } from './services/travel-days.service';
import { ToastrService } from "./services/toastr.service";
import { TravelSearchService } from './services/travel-search.service';
import { ReportFilterService } from "./services/report-filter.service";
import { ErrorService } from "./services/error.service";

//pipes
import { CapitalizePipe } from './pipes/capitalize.pipe';
import { LinkyModule } from 'angular-linky';
import { KeysPipe } from './pipes/keys.pipe';
import { SimpleOrderByPipe } from './pipes/simple-order-by.pipe';
import { NC4TimeAgoPipe } from './pipes/NC4-time-ago.pipe';

//directives
import { FiltersDirective } from './directives/filters.directive';
import { PiechartDirective } from './directives/piechart.directive';
import { RichtextDirective } from './directives/richtext.directive';
import { ChartDirective } from './directives/chart.directive';
import { OverlayDashboardDirective } from './directives/overlay-dashboard.directive';
import { FilterTagsDirective } from "./directives/filter-tags.directive";

//components
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { MapComponent } from './components/map/map.component';

import { ContentComponent } from './components/content/content/content.component';
import { ContentGridComponent } from './components/content/content-grid/content-grid.component';
import { ContentToolBarComponent } from './components/content/content-tool-bar/content-tool-bar.component';

import { AssetsComponent } from './components/assets/assets/assets.component';
import { AssetsGridComponent } from './components/assets/assets-grid/assets-grid.component';
import { AssetsToolBarComponent } from './components/assets/assets-tool-bar/assets-tool-bar.component';

import { DashboardComponent } from './components/dashboard/dashboard/dashboard.component';
import { DashboardPiechartComponent } from './components/dashboard/dashboard-piechart/dashboard-piechart.component';
import { DashboardRegionmapComponent } from './components/dashboard/dashboard-regionmap/dashboard-regionmap.component';

import { ArticleComponent } from './components/article/article/article.component';
import { ArticleForwardComponent } from './components/article/article-forward/article-forward.component';
import { ArticleItineraryComponent } from './components/article/article-itinerary/article-itinerary.component';
import { ArticleDetailComponent } from './components/article/article-detail/article-detail.component';
import { ArticleRelatedComponent } from './components/article/article-related/article-related.component';
import { ArticleImpactedAssetsComponent } from './components/article/article-impacted-assets/article-impacted-assets.component';
import { ArticleAttachmentsComponent } from './components/article/article-attachments/article-attachments.component';
import { ArticleIntelComponent } from './components/article/article-intel/article-intel.component';
import { ArticleMapComponent } from './components/article/article-map/article-map.component';

import { AssetComponent } from './components/asset/asset/asset.component';
import { AssetIntelComponent } from './components/asset/asset-intel/asset-intel.component';
import { AssetDetailComponent } from './components/asset/asset-detail/asset-detail.component';
import { AssetMapComponent } from './components/asset/asset-map/asset-map.component';
import { AssetForwardComponent } from './components/asset/asset-forward/asset-forward.component';

import { HelperNavComponent } from './components/filter/helper-nav/helper-nav.component';
import { FiltersComponent } from './components/filter/filters/filters.component';
import { PresetsComponent } from './components/filter/presets/presets.component';

import { SettingsComponent } from './components/settings/settings.component';


import { ExecutiveSummaryComponent } from './components/executive-summary/MasterGrid/executive-summary.component';
import { DetailGridComponent } from './components/executive-summary/detail-grid/detail-grid.component';
import { ItineraryDetailComponent } from './components/itinerary-detail/itinerary-detail.component';
import { BasicInfoComponent } from './components/report-header/basic-info/basic-info.component';
import { FeaturesComponent } from './components/report-header/features/features.component';
import { TravelLocationComponent } from './components/travel-location/travel-location.component';
import { PassengersOnFlight } from './components/passengers-on-flight/MasterGrid/passengers-on-flight.component';
import { FlightDetailGridComponent } from './components/passengers-on-flight/detail-grid/detail-grid.component';
import { ReportFilterComponent } from './components/report-common/report-filter/report-filter.component';
import { TravelDaysComponent } from './components/travel-days/travel-days.component';
import { ReportEmailComponent } from './components/report-common/report-email/report-email.component';
import { ReportEditColumnsComponent } from './components/report-common/report-edit-columns/report-edit-columns.component';
import { ReportSaveReportComponent } from './components/report-common/report-save-report/report-save-report.component';
import { ReportMySavedComponent } from './components/report-common/report-my-saved/report-my-saved.component';
import { TravelSearchComponent } from './components/travel-search/travel-search.component';
import { ReportEmailTravellerComponent } from './components/report-common/report-email-traveller/report-email-traveller.component';
import { ReportGridHeaderComponent } from './components/report-common/report-grid-header/report-grid-header.component';
import { ReportInputParametersComponent } from './components/report-common/report-input-parameters/report-input-parameters.component';
import { ReportItinerayComponent } from './components/report-common/report-itineray/report-itineray.component';
import { ErrorDialogComponent } from './components/error-dialog/error-dialog.component';
import { ReportFeatureHostDirective } from './directives/report-feature-host.directive';
import { LoadingComponent } from './components/loading/loading.component';

const appRoutes: Routes = [
  { path: 'map', component: MapComponent },
  { path: 'content/list', component: ContentComponent },
  { path: 'content/grid', component: ContentGridComponent },
  { path: 'assets/list', component: AssetsComponent },
  { path: 'assets/grid', component: AssetsGridComponent },
  { path: 'settings/profile', component: SettingsComponent },
  { path: 'content/:identity', component: ArticleComponent },
  { path: 'content/:identity/:drawer', component: ArticleComponent },
  { path: 'assets/:locationId', component: AssetComponent },
  { path: 'assets/:locationId/:drawer', component: AssetComponent },
  { path: 'reports/executive-summary', component: ExecutiveSummaryComponent },
  { path: 'reports/executive-summary/:reportId', component: ExecutiveSummaryComponent },
  { path: 'reports/itinerary', component: ItineraryDetailComponent },
  { path: 'reports/itinerary/:travelerId', component: ItineraryDetailComponent },
  { path: 'reports/itinerary/:travelerId/:reportId', component: ItineraryDetailComponent },
  { path: 'reports/travel-location', component: TravelLocationComponent },
  { path: 'reports/travel-location/:reportId', component: TravelLocationComponent },
  { path: 'reports/travel-days', component: TravelDaysComponent },
  { path: 'reports/travel-days/:reportId', component: TravelDaysComponent },
  { path: 'reports/passengers-on-flight', component: PassengersOnFlight },
  { path: 'reports/passengers-on-flight/:reportId', component: PassengersOnFlight },
  { path: 'reports/travel-search', component: TravelSearchComponent },
  { path: '**', component: MapComponent }
];

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  wheelPropagation: true
};

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MapComponent,
    ContentComponent,
    AssetsComponent,
    SettingsComponent,
    DashboardComponent,
    AssetsToolBarComponent,
    ContentToolBarComponent,
    ContentGridComponent,
    AssetsGridComponent,
    DashboardPiechartComponent,
    DashboardRegionmapComponent,
    CapitalizePipe,
    ArticleComponent,
    ArticleItineraryComponent,
    ArticleDetailComponent,
    KeysPipe,
    NC4TimeAgoPipe,
    ArticleRelatedComponent,
    ArticleImpactedAssetsComponent,
    ArticleAttachmentsComponent,
    ArticleIntelComponent,
    ArticleMapComponent,
    AssetComponent,
    AssetIntelComponent,
    AssetDetailComponent,
    AssetMapComponent,
    SimpleOrderByPipe,
    HelperNavComponent,
    FiltersComponent,
    PresetsComponent,
    FiltersDirective,
    PiechartDirective,
    RichtextDirective,
    ChartDirective,
    OverlayDashboardDirective,
    FilterTagsDirective,
    ArticleForwardComponent,
    AssetForwardComponent,
    ExecutiveSummaryComponent,
    DetailGridComponent,
    ItineraryDetailComponent,
    BasicInfoComponent,
    FeaturesComponent,
    TravelLocationComponent,
    PassengersOnFlight,
    FlightDetailGridComponent,
    ReportFilterComponent,
    TravelDaysComponent,
    ReportEmailComponent,
    ReportEditColumnsComponent,
    ReportMySavedComponent,
    ReportSaveReportComponent,
    TravelSearchComponent,
    ReportEmailTravellerComponent,
    ReportGridHeaderComponent,
    ReportInputParametersComponent,
    ReportItinerayComponent,
    ErrorDialogComponent,
    ReportFeatureHostDirective,
    LoadingComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,    
    FormsModule,
    HttpModule,
    InputsModule,
    GridModule,
    DropDownsModule,
    ButtonsModule,
    HttpClientModule,
    JsonpModule,
    LinkyModule,
    MultiSelectModule,
    OrderModule,
    PopupModule,
    ReactiveFormsModule,
    DragulaModule,
    DialogsModule,
    TimepickerModule.forRoot(),
    //RouterModule.forRoot(appRoutes)
    RouterModule.forRoot(appRoutes, { useHash: true }),
    PerfectScrollbarModule
  ],
  entryComponents: [
    ReportEditColumnsComponent,
    ReportEmailComponent,
    ReportFilterComponent,
    ReportSaveReportComponent,
    ReportMySavedComponent,
    ReportEmailTravellerComponent,
    ReportItinerayComponent
  ],
  providers: [
    Theme,
    BuildInfo,
    ReportRouteFactory,
    SettingsData,
    SharedService,
    NrcService,
    StorageService,
    FilterService,
    SortService,
    DashboardService,
    BuildInfoService,
    SettingsService,
    ThemeService,
    MapService,
    AutorefreshService,
    PagerService,
    ItineraryService,
    TravelLocationService,
    ActivTravelService,
    ExecutiveSummaryService,
    PassengersOnFlightService,
    DatePipe,
    ReportEmailService,
    TravelDaysService,
    ToastrService,
    TravelSearchService,
    ErrorService,
    ReportFilterService,
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ],
  schemas: [NO_ERRORS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
