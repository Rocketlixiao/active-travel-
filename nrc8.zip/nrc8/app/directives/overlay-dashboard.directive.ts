import { Directive, OnInit, HostListener } from '@angular/core';
//import '../libs/globalConfig.js';
declare var globalConfig: any;

@Directive({
  selector: '[appOverlayDashboard]'
})
export class OverlayDashboardDirective implements OnInit{

  @HostListener('click', ['$event']) onClick($event) {
   
    globalConfig.removeClass($event.target.parentElement.parentElement.parentElement,'active');
  }

  constructor() { }

  ngOnInit(){
    //angular.element(elem).on('click', function () {
    //  angular.element(this).parents('.nav-item.active').removeClass('active');
    //});
  }
}
