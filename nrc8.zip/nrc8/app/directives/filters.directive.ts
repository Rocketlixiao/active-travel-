import { Directive } from '@angular/core';

//import '../libs/globalConfig.js';
declare var globalConfig: any;

@Directive({
  selector: '[filters]'
})
export class FiltersDirective {

  constructor() { }
  OnInit() {
    //globalConfig.callFormsUI();
  }
}
