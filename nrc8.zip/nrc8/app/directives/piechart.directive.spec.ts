import { PiechartDirective } from './piechart.directive';

describe('PiechartDirective', () => {
  it('should create an instance', () => {
    const directive = new PiechartDirective();
    expect(directive).toBeTruthy();
  });
});
