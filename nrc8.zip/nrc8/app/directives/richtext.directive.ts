import { Directive } from '@angular/core';

@Directive({
  selector: '[appRichtext]'
})
export class RichtextDirective {

  constructor() { }

}
