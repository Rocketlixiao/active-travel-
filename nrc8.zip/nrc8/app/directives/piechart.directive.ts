import { Directive, Input, OnInit, HostListener } from '@angular/core';

//import '../libs/globalConfig.js';
declare var globalConfig: any;

@Directive({
  selector: '[appPiechart]'
})
export class PiechartDirective implements OnInit{
  @Input() dashboard: any;

  constructor() {

  }

  ngOnInit() {    
   
    if (this.dashboard) {      
     
      globalConfig.callPiechart(this.dashboard.id, this.dashboard.charts.pie.data);
     
    }
  }
}
