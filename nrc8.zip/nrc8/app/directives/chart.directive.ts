import { Directive, OnInit } from '@angular/core';

@Directive({
  selector: '[chart]'
})
export class ChartDirective implements OnInit{

  constructor() { }
  ngOnInit() {
    console.log('ruan in chart');
  }
}
