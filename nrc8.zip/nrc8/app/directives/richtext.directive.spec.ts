import { RichtextDirective } from './richtext.directive';

describe('RichtextDirective', () => {
  it('should create an instance', () => {
    const directive = new RichtextDirective();
    expect(directive).toBeTruthy();
  });
});
