import { Directive, ElementRef, OnChanges, SimpleChanges, Input } from '@angular/core';

declare var $ui: any;

@Directive({
  selector: '[appFilterTags]'
})
export class FilterTagsDirective implements OnChanges {
  @Input('appFilterTags') number: number;
  constructor(private el: ElementRef) {
  }

  ngOnChanges(changes: SimpleChanges) {
    setTimeout(() => {
      $ui(this.el.nativeElement).find('kendo-taglist .k-reset li').removeClass('hidden');

      let wrap = $ui(this.el.nativeElement).find('ul.k-reset');
      if (this.isOverflow(wrap)) {
        let tags = $ui(this.el.nativeElement).find('kendo-taglist .k-reset li'), length = tags.length;
        while (this.isOverflow(wrap)) {
          tags.eq(length).addClass('hidden');
          length--;
        }
      }

      this.setHiddenTagsCount();
    });
  }

  private isOverflow(el) {
    return el[0].scrollHeight > el[0].clientHeight;
  }
  private setHiddenTagsCount() {
    let txt = $ui(this.el.nativeElement).find('.k-reset .k-button.hidden').length || '';
    let tag = $ui(this.el.nativeElement).find('.tags-count');

    if (tag.length) tag.text(txt);
    else tag = $ui(this.el.nativeElement).append(`<span class='tags-count'>${txt}</span>`);
  }
}
