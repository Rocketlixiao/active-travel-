import { FilterTagsDirective } from './filter-tags.directive';

describe('FilterTagsDirective', () => {
  it('should create an instance', () => {
    // const directive = new FilterTagsDirective();
    // expect(directive).toBeTruthy();
  });
});
