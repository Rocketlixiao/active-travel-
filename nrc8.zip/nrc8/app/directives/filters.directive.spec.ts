import { FiltersDirective } from './filters.directive';

describe('FiltersDirective', () => {
  it('should create an instance', () => {
    const directive = new FiltersDirective();
    expect(directive).toBeTruthy();
  });
});
