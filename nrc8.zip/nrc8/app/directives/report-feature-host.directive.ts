import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appReportFeatureHost]'
})
export class ReportFeatureHostDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}
