import { ReportFeatureHostDirective } from './report-feature-host.directive';

describe('ReportFeatureHostDirective', () => {
  it('should create an instance', () => {
    const directive = new ReportFeatureHostDirective();
    expect(directive).toBeTruthy();
  });
});
