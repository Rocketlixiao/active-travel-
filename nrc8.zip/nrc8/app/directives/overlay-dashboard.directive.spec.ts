import { OverlayDashboardDirective } from './overlay-dashboard.directive';

describe('OverlayDashboardDirective', () => {
  it('should create an instance', () => {
    const directive = new OverlayDashboardDirective();
    expect(directive).toBeTruthy();
  });
});
