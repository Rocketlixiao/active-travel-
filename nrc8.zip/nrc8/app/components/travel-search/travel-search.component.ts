import { Component, ElementRef, ViewChild, AfterViewInit, OnInit, Input, OnChanges } from '@angular/core';
import { FormControl, FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { GridComponent, GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { SortDescriptor, orderBy, composeSortDescriptors } from '@progress/kendo-data-query';
import { AutoCompleteComponent, MultiSelectComponent } from '@progress/kendo-angular-dropdowns';

import { ActivatedRoute, Params } from "@angular/router";
import { ActivTravelService, ColumnSetting } from '../../services/activ-travel.service';
import { TravelSearchService } from '../../services/travel-search.service';
import { TravelSearch, Address, Hero, FIELD, OPERATOR, SearchCritial, Select } from '../../models/TravelSearch';
import { SharedService } from '../../services/shared.service';
import { NrcService } from '../../services/nrc.service';
import { ToastrService } from "../../services/toastr.service";
import { ReportEmailService } from "../../services/report-email.service";
import { FilterData } from '../../models/FilterData';
import { ReportHeader, ReportFilterContext, ReportEmailContext } from "../../models/ReportHeader";
import { Airport } from "../../models/Airport";
import { retry } from 'rxjs/operator/retry';
import { LowerCasePipe } from '@angular/common';
import { ReportFilterService } from "../../services/report-filter.service";
import { Text } from '@progress/kendo-drawing';
import { filter } from 'rxjs/operator/filter';

declare var $ui: any;
declare var moment: any;
declare var reportConfig: any;
declare var globalConfig: any;
@Component({
  selector: 'app-travel-search',
  templateUrl: './travel-search.component.html',
  styleUrls: ['./travel-search.component.css']
})
export class TravelSearchComponent implements OnInit, ReportHeader {
  showLoading: boolean = false;
  private rawData: any;
  CDN = globalConfig.CDN.root;
  warning: any = {
    showed: false,
    title: 'Warning',
    message: (reportConfig.TravelSearchMaxRows || 500) + ' rows of data delivered, the remaining rows were truncated. Please refine your search to reduce the result set, or Download Report to receive the complete result set.'
  };
  PiiInfo: { showPii: boolean } = { showPii: false };
  //date picker
  private dateFormat: string = 'YYYY-MM-DD';
  private dateRangePicker: any;
  @ViewChild('calendar') public calendar: any;

  filterContent: ReportFilterContext;
  //header init 
  description: string;
  filterData: FilterData = new FilterData();

  //grid init
  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  public total = 0;
  private data: Object[];
  //grid loading process
  public isLoading = false;
  //device is in mobile or desktop
  public isMobile = false;

  //kendo grid and dropdown
  @ViewChild(GridComponent) grid: GridComponent;
  public source: Array<{ text: string, value: number }> = [];
  public selectedValue: { text: string, value: number } = { text: "", value: null };
  public defaultItem: { text: string, value: number } = { text: "1", value: 1 };
  //grid data 
  travelSearch: TravelSearch[];

  //button and page config 
  public buttonCount = 5;
  public info = true;
  public type: 'numeric' | 'input' = 'numeric';
  public pageSizes = true;
  public previousNext = true;

  //Search  criteria;
  public profileForm: FormGroup;

  regions: Array<string>;
  countries: Array<string>;
  organizations: any;
  riskRating: any;
  segmenttype: any;

  heroForm: FormGroup;
  fIELDs = FIELD;
  oPERATORs = OPERATOR;

  //Search  clause;
  selects;  //for select field Select[];
  wheres;     //for operator  <> = in not in 
  listItems; //for region,country and other mutiselect
  AutoItems;  //for auto complete array

  @ViewChild(MultiSelectComponent) public multiselect: MultiSelectComponent[];


  public productlistItems: Array<TravelSearch> = [];

  //declare calender
  datesFrom;
  datesTo;
  private dateFromPicker: any;

  //sort
  public sort: SortDescriptor[] = [];

  //diaolog windows open 
  public pnrid;// link to itenary detial page 
  public windowOpened = false;

  @ViewChild('dateFrom') public dateFrom: any;

  constructor(private fb: FormBuilder,
    public activatedRoute: ActivatedRoute,
    private sharedService: SharedService,
    public travelSearchService: TravelSearchService,
    private toastrService: ToastrService,
    private activTravelService: ActivTravelService,
    private reportFilterService: ReportFilterService,
    private reportEmailService: ReportEmailService,
    private nrcService: NrcService) {

    this.profileForm = this.fb.group({
      optionGroups: this.fb.array([
        this.fb.group({
          selectInput: [""],
          whereInput: [""],
          selectWhereValue: [""],
          selectWhereDataRangeStartValue: [""],
          selectWherDataRangeEndValue: [""],

        }),
      ]),
    });
    this.selects = [];
    this.selects[0] = this.travelSearchService.getSelect(globalConfig.isNc4AdminOrOrgAdmin);
    this.wheres = [];
    this.listItems = [];
    this.AutoItems = [];

    this.datesFrom;// = [];
    this.datesTo;// = [];

  }

  ngOnInit(): void {

    //region country organizations riskRating segmenttype  dropdownlist
    this.reportFilterService.getFilterDropdownItems().subscribe(() => {

      this.regions = globalConfig.filterDropdownItems.regions;
      this.countries = globalConfig.filterDropdownItems.countries;
      this.organizations = globalConfig.filterDropdownItems.organizations;
      this.riskRating = globalConfig.filterDropdownItems.riskratings;
      this.segmenttype = globalConfig.filterDropdownItems.segmenttypes;

    },
      err => { this.nrcService.handleError(err); });

    this.sharedService.showOrHideMap();

    this.isMobile = this.activTravelService.isMobile();
    $ui.datepicker.setDefaults({
      dateFormat: 'yy-mm-dd'
    });
  }

  onDownLoadReportSubmited(format: string) {
    if(this.rawData) {
      this.PiiInfo.showPii = true;
      this.activatedRoute.url.subscribe(segements => {
        if (segements && segements.length > 1) {
          let path = segements[1].path;
          this.reportEmailService.downloadReport(this.rawData, format, path, []);
        }
      });
    }
  }

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.skip = skip;
    this.pageSize = take;
    this.applyFilter();
  }


  public applyFilter() {

    let allData = this.travelSearch;
    this.total = allData.length;

    this.gridView = {
      data: allData.slice(this.skip, this.skip + this.pageSize),
      total: this.total
    };
    this.binddropdown();
    this.description = "(Displaying " + (this.skip + 1) + "-" + ((this.skip + this.pageSize) > this.total ? this.total : (this.skip + this.pageSize)) + " of " + (this.total) + " total records)";

    this.showLoading = false;
  }

  public binddropdown() {
    this.source = this.source.filter(item => item == { text: "", value: null });
    let totalPages = Math.floor(((this.total - 1) / this.pageSize) + 1);
    for (var i = 1; i <= totalPages; i++) {
      let drp = { text: String(i), value: i };
      this.source.push(drp);
    }

    if (totalPages > 0) {

      this.selectedValue = { text: "1", value: 1 };
    } else {
      this.selectedValue = { text: "", value: null };
    }

  }


  public valueChange(pageIndex: any): void {
    console.log(pageIndex);
    this.skip = (pageIndex.value - 1) * this.pageSize;
    this.applyFilter();
    this.selectedValue = { text: pageIndex.value, value: pageIndex.value };

  }

  private showExpandIcon(dataitem: any) {
    let icon = "+"
    let rowIndex = dataitem.index;
    let expandCollpase = this.travelSearch.filter(
      x => x.index == rowIndex)[0];
    if (expandCollpase.isexpand) {
      icon = "-"
    } else {
      icon = "+"
    }
    return icon;

  }

  public ShowHideSubContent(dataitem: any) {
    let rowIndex = dataitem.index;
    let expandCollpaseFilterFlagIndexs = this.travelSearch.filter(
      x => x.index == dataitem.index)[0];

    if (!this.travelSearch[rowIndex].isexpand) {

      this.grid.expandRow(rowIndex);

      this.travelSearch[rowIndex].isexpand = true;

    } else {

      this.grid.collapseRow(rowIndex);
      this.travelSearch[rowIndex].isexpand = false;
    }
  }


  public addOptionGroup() {

    let searchCriti = this.profileForm.controls["optionGroups"].value;
    if (searchCriti.length > 7) {
      this.toastrService.error('The maximum of 8 Search Clauses has been reached, and no additional Search Clauses can be added');
      return false;
    }
    const fa = this.profileForm.controls["optionGroups"] as FormArray;
    fa.push(this.newOptionGroup());

    var that = this;
    setTimeout(function () { that.initDateRangePicker(searchCriti.length - 1) }, 500);

    this.addRemoveDropDown();

  }


  public addRemoveDropDown() {
    let searchCriti = this.profileForm.controls["optionGroups"].value;
    let index = searchCriti.length - 1;

    this.selects[index] = this.travelSearchService.getSelect(globalConfig.isNc4AdminOrOrgAdmin);

    for (var i = 0; i < searchCriti.length; i++) {
      let tempSelectInput = searchCriti[i].selectInput;

      this.selects[index] = this.selects[index].filter((item) => item.id !== tempSelectInput);
     
    }

  }

  public applyAdvanceSearch() {
    
    let searchCriti = this.profileForm.controls["optionGroups"].value;
    let searchWhereClause = "";
    let isValideFlag = false;
    let queryFlat = "";
    for (var i = 0; i < searchCriti.length; i++) {

      let tempSelectInput = searchCriti[i].selectInput;
      let tempWhereValue = this.trimText(tempSelectInput,searchCriti[i].selectWhereValue);
      //for calendar use
      let tempSelectWhereDataRangeStartValue: any;
      let tempSelectWherDataRangeEndValue: any

      let tempWhereInput = searchCriti[i].whereInput;

      if (tempSelectInput == "starttoenddate") {
        tempSelectWhereDataRangeStartValue = searchCriti[i].selectWhereDataRangeStartValue;
        tempSelectWherDataRangeEndValue = searchCriti[i].selectWherDataRangeEndValue;

        if (tempSelectInput != "" && tempSelectWhereDataRangeStartValue != ""
          && tempSelectWherDataRangeEndValue != "" && tempWhereInput != "" ) {
          isValideFlag = true;
        }

      } else
      {
        if (tempSelectInput != "" && tempWhereValue != "" && tempWhereInput != "") {
          isValideFlag = true;
        }
      }

      if (i == 0) {
        queryFlat = "?";
      }
      else
      {
        queryFlat = "&";
      }

      switch (tempWhereInput) {
        case "In":
          searchWhereClause = searchWhereClause + queryFlat + tempSelectInput.toLocaleLowerCase() + "=" +  tempWhereValue;
          break;
        case "Not In":
          searchWhereClause = searchWhereClause + queryFlat + tempSelectInput.toLocaleLowerCase() + "<>" + tempWhereValue;
          break;
        case "=":
          //calendar logic 
          if (tempSelectInput == "starttoenddate") {
            searchWhereClause = searchWhereClause + queryFlat + "startdate" + "=" + tempSelectWhereDataRangeStartValue;
            searchWhereClause = searchWhereClause + "&enddate" + "=" + tempSelectWherDataRangeEndValue;
          } else {
            searchWhereClause = searchWhereClause + queryFlat + tempSelectInput.toLocaleLowerCase() + "=" + tempWhereValue;
          }

          break;
        case "<>":
          searchWhereClause = searchWhereClause + queryFlat + tempSelectInput.toLocaleLowerCase() + "<>" + tempWhereValue;
          break;
        default: //unknown

      }
    }

    if (!isValideFlag) {
      this.toastrService.error('Invalid Search Clause: Please enter a valid Search Clause and try again.');      
      return false;
    }

    this.showLoading = true;
    this.travelSearchService.getTravelSearch(searchWhereClause)
      .then(data => {
        if(data) {
          this.rawData = data;
          if (data.Result && data.Result.length >= reportConfig.TravelSearchMaxRows) this.warning.showed = true;
          this.travelSearch = this.travelSearchService.mappingData(data, searchCriti);
          this.applyFilter();
        }
      });
    console.log(searchWhereClause);
  }

  public trimText(SelectInput: string, WhereValue:any)
  {
    let mutifilter = ['city', 'travelername', 'email', 'locator', 'locationname', 'flightnumber'];

    if (mutifilter.filter((item) => item == SelectInput).length > 0) {
      WhereValue = WhereValue.trim();
      return WhereValue;
    }
    return WhereValue
   
  }

  public removeOptionGroup(index: number) {

    const fa = this.profileForm.controls["optionGroups"] as FormArray;

    //add the remove select value to the other dropdow select list 
    let tempId = fa.value[index].selectInput;

    //add the remove select value to the other dropdow select list
    let fullSelectValue = this.travelSearchService.getSelect(globalConfig.isNc4AdminOrOrgAdmin).filter((item) => item.id == tempId)[0];

    console.log(fullSelectValue);
    if (fullSelectValue) {
      for (var i = 0; i < this.selects.length; i++) {
        let tempSelect = new Select(fullSelectValue.id, fullSelectValue.name);

        console.log(this.selects[i]);
        if (!this.selects[i].find((item) => item.id == tempId)) {
          this.selects[i].push(tempSelect);
        }
      }
    }

    fa.removeAt(index);
  }

  onSelectSelect(selectInput: string, formIndex: number): void {

    this.wheres[formIndex] = this.travelSearchService.getWhere().filter((item) => item.selectid == selectInput);
    console.log(this.wheres[formIndex]);
    //every time the select changed, set the selectWhereValue =''  
    const tempFormArray = this.profileForm.controls["optionGroups"] as FormArray;
    const tempFormGroup = tempFormArray.controls[formIndex] as FormGroup;
    tempFormGroup.patchValue({
      whereInput: "=",
      selectWhereValue: "",
      selectWhereDataRangeStartValue: "",
      selectWherDataRangeEndValue: ""
    })

    if (selectInput == "starttoenddate") {
      this.datesFrom = "";
      this.datesTo = "";
      var that = this;
      setTimeout(function () { that.initDateRangePicker(formIndex); }, 500);

    }

    this.bindMutiSelect(selectInput, formIndex);

  }




  private bindMutiSelect(selectInput: string, formIndex: number) {

    this.listItems[formIndex] = [];
    let arraylisttemp = [];

    let tempItem = []; // temp array to load muti select drop 
    switch (selectInput) {
      case "region":
        let tempRegions = globalConfig.filterDropdownItems.regions;
        for (var i = 0; i < tempRegions.length; i++) {
          tempItem.push(tempRegions[i]);
        }
        console.log(globalConfig.filterDropdownItems.regions);
        this.listItems[formIndex] = tempItem;

        break;
      case "country":
        let tempCountries = globalConfig.filterDropdownItems.countries;
        for (var c = 0; c < tempCountries.length; c++) {
          tempItem.push(tempCountries[c]);
        }
        this.listItems[formIndex] = tempItem;
        break;
      case "segmenttype":
        for (var s = 0; s < this.segmenttype.length; s++) {
          tempItem.push(this.segmenttype[s].text);
        }
        this.listItems[formIndex] = tempItem;
        break;
      case "orgname":
        console.log("orgname");
        let tempOrganizations = globalConfig.filterDropdownItems.organizations;
        for (var o = 0; o < tempOrganizations.length; o++) {
          tempItem.push(tempOrganizations[o].orgName);
        }
        this.listItems[formIndex] = tempItem;
        break;
      case "riskrating":
        
        let tempRiskratings = globalConfig.filterDropdownItems.riskratings;
        for (var r = 0; r < tempRiskratings.length; r++) {
          tempItem.push(tempRiskratings[r]);
        }
        this.listItems[formIndex] = tempItem;
        break;
      default: //unknown

    }

  }

  private newOptionGroup() {
    return new FormGroup({
      selectInput: new FormControl(""),
      whereInput: new FormControl(""),
      selectWhereValue: new FormControl(""),
      selectWhereDataRangeStartValue: new FormControl(""),
      selectWherDataRangeEndValue: new FormControl("")

    });
  }

  private showMutiDrop(value, index) {
    let display = false;
    let mutifilter = ['region', 'country', 'orgname', 'segmenttype', 'riskrating'];

    if (mutifilter.filter((item) => item == value).length > 0) {
      display = true;
    }

    return display;
  }

  private showAuto(value, index) {
    let display = false;
    let mutifilter = ['airport'];

    if (mutifilter.filter((item) => item == value).length > 0) {
      display = true;
    }

    return display;
  }

  private showCalender(value, index) {
    let display = false;
    let mutifilter = ['starttoenddate', 'starttoenddate'];

    if (mutifilter.filter((item) => item == value).length > 0) {
      display = true;
    }

    return display;
  }

  private showTextbox(value, index) {
    let display = false;
    let mutifilter = ['city', 'travelername', 'email', 'locator', 'locationname', 'flightnumber'];

    if (mutifilter.filter((item) => item == value).length > 0) {
      display = true;
    }

    return display;
  }

  public initDateRangePicker(formIndex: any) {

    this.dateRangePicker = $ui(this.calendar.nativeElement).find('.nc4-icon-calendar');
    let picker = this.dateRangePicker.daterangepicker({
      opens: 'left'
    }, (start, end) => {
      this.datesFrom = moment(start).format(this.dateFormat);
      this.datesTo = moment(end).format(this.dateFormat);

    });

  }

  private onSort(event: any) {
    console.log(event.columns);
    console.log(event.order);
    let dataItem = event.columns;
    let order = event.order;
    this.sort = [];
    this.sort.push({ field: dataItem.field, dir: order });

    this.travelSearch = orderBy(this.travelSearch, this.sort);
    //rearrange index order  
    for (var i = 0; i < this.travelSearch.length; i++) {
      this.travelSearch[i].index = i;
    }
    this.applyFilter();
  }

  handleFilter(value: any, index: any) {
    if (value.length >= 3) {
      console.log(value);
      console.log(index);
      let filter = "?search=" + value + "";
      this.activTravelService.getAirPort(filter)
        .then(data => {
          this.bindAutoCompelete(this.activTravelService.mappingData(data), index);
        });

    }
  }

  bindAutoCompelete(airport: Array<Airport>, index: any) {
    let tempItem = [];
    for (var i = 0; i < airport.length; i++) {
      tempItem.push(airport[i].airportName);
    }

    console.log(tempItem);
    this.AutoItems[index] = tempItem;
  }

  onFilterChange(value: string, $index: any, fieldName: string) {

    let tempListItems: Array<string>;
    switch (fieldName) {
      case "region":
        this.listItems[$index] = globalConfig.filterDropdownItems["regions"].filter(r => r.toLowerCase().indexOf(value.toLowerCase()) > -1);
        break;
      case "country":
        this.listItems[$index] = globalConfig.filterDropdownItems["countries"].filter(r => r.toLowerCase().indexOf(value.toLowerCase()) > -1);
        break;
      case "segmenttype":
        var tempSegmenttypes = globalConfig.filterDropdownItems["segmenttypes"].filter(r => r.text.toLowerCase().indexOf(value.toLowerCase()) > -1);
        tempListItems = [];
        for (var i = 0; i < tempSegmenttypes.length; i++) {
          tempListItems.push(tempSegmenttypes[i].text);
        }
        this.listItems[$index] = tempListItems;
        break;
      case "orgname":
        var tempOrganizations = globalConfig.filterDropdownItems["organizations"].filter(r => r.orgName.toLowerCase().indexOf(value.toLowerCase()) > -1);
        tempListItems = [];
        for (var t = 0; t < tempOrganizations.length; t++) {
          tempListItems.push(tempOrganizations[t].orgName);
        }
        this.listItems[$index] = tempListItems;
        break;
      case "riskrating":
        this.listItems[$index] = globalConfig.filterDropdownItems["riskratings"].filter(r => r.toString().toLowerCase().indexOf(value.toLowerCase()) > -1);
        break;
      default:

    }

  }

  //dialog windows open and close
  public GridDetialClickHanlder(dataItem: any) {
    this.pnrid = dataItem.id;
    this.windowOpened = true;
    console.log(this.pnrid);

  }

  public close(component) {
    this.windowOpened = false;

  }
}
