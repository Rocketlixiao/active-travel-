import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetsToolBarComponent } from './assets-tool-bar.component';

describe('AssetsToolBarComponent', () => {
  let component: AssetsToolBarComponent;
  let fixture: ComponentFixture<AssetsToolBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetsToolBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetsToolBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
