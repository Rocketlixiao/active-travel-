import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { SortService } from '../../../services/sort.service';

@Component({
  selector: 'app-assets-tool-bar',
  templateUrl: './assets-tool-bar.component.html',
  styleUrls: ['./assets-tool-bar.component.css']
})
export class AssetsToolBarComponent implements OnInit {
  path: string;
  orderValue: string = '-sortProximityStatus';
  @Output() sortEvent = new EventEmitter<string>();

  constructor(private router: Router, private sortService: SortService) { }

  changeSort(event) {   
    this.sortService.setAssetsListCurrentSort(this.orderValue)
    this.sortEvent.emit(this.orderValue);
  }

  ngOnInit() {
    this.path = this.router.url;
    
    if (this.sortService.getAssetsListCurrentSort()) {
      this.orderValue = this.sortService.getAssetsListCurrentSort();
      this.changeSort(this.orderValue);
    }
  }

}
