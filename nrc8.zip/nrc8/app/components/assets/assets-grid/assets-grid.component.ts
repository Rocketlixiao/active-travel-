import { Component, OnInit, Inject } from '@angular/core';
import { SharedService } from '../../../services/shared.service';
import { SortService } from '../../../services/sort.service';
import { AssetSort } from '../../../models/AssetSort';
import { AutorefreshService } from '../../../services/autorefresh.service';

//import '../../../libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-assets-grid',
  templateUrl: './assets-grid.component.html',
  styleUrls: ['./assets-grid.component.css']
})
export class AssetsGridComponent implements OnInit {
  CDN = globalConfig.CDN.root;

  assetsItems: any;
  assetSort = new AssetSort();
  sortA = this.assetSort.sortA;
  sortB = this.assetSort.sortB;
  sortC = this.assetSort.sortC;

  constructor(private sharedService: SharedService, private sortService: SortService, private autorefreshService: AutorefreshService) { }

  receiveSort($event) {
    this.assetSort = this.sortService.getAssetSort($event);
    this.sortA = this.assetSort.sortA;
    this.sortB = this.assetSort.sortB;
    this.sortC = this.assetSort.sortC;
  }

  ngOnInit() {
    this.sharedService.showOrHideMap();

    this.sharedService.castAssetsItems.subscribe(ass => this.assetsItems = ass);

    //Merge the updates when page is loaded.
    this.autorefreshService.MergeUpdates(false);

    if (globalConfig.allAssetItems.length === 0) {
      this.sharedService.getIncidentsAssets(null);
    }
  }

}
