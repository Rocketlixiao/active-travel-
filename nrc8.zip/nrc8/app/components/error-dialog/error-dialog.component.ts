import { Component, OnInit } from '@angular/core';
import { ErrorService } from '../../services/error.service';

@Component({
  selector: 'app-error-dialog',
  templateUrl: './error-dialog.component.html',
  styleUrls: []
})
export class ErrorDialogComponent implements OnInit {

  errorMessage: string = '';
  openDialog: boolean = false;

  constructor(private errorService: ErrorService) { }

  ngOnInit() {

    this.errorService.castErrorMessage.subscribe(err => this.errorMessage = err);
    this.errorService.castOpenDialog.subscribe(op => this.openDialog = op);
  }

  closeOpenDialog() {
    this.errorService.closePopupMessage();
  }

}
