import { Component, OnInit } from '@angular/core';
import { Theme } from '../../models/Theme';
import { environment } from '../../../environments/environment';
import { Router, NavigationEnd, Params, ActivatedRoute } from '@angular/router';
import { BuildInfo } from '../../models/BuildInfo';
import { SharedService } from '../../services/shared.service'
import { BuildInfoService } from '../../services/build-info.service';
import { ThemeService } from '../../services/theme.service';
import { AutorefreshService } from '../../services/autorefresh.service';
//import '../../libs/globalConfig.js';
declare var globalConfig: any;

import { Location } from '@angular/common';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  buildInfo: BuildInfo;
  theme: Theme;
  noAsset: boolean;
  isMap: boolean;
  isContent: boolean;
  isAssets: boolean;
  isReports:boolean;
  isSettings: boolean;
  noAssets: boolean;
  autoRefreshStatus = 'auto-refresh-finished';
  AutoRef_updatedCount = '0';


  constructor(private buildInfoService: BuildInfoService, private sharedService: SharedService, private location: Location, private router: Router, private themeService: ThemeService, private autorefreshService: AutorefreshService, private actRoute: ActivatedRoute) {

    router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        let path = location.path();
        if (path.indexOf('/content') >= 0) {
          this.isMap = false;
          this.isContent = true;
          this.isAssets = false;
          this.isReports = false;
          this.isSettings = false;
        }
        else if (path.indexOf('/assets') >= 0) {
          this.isMap = false;
          this.isContent = false;
          this.isAssets = true;
          this.isReports = false;
          this.isSettings = false;
        }        
        else if (path.indexOf('/reports') >= 0) {
          this.isMap = false;
          this.isContent = false;
          this.isAssets = false;
          this.isReports = true;
          this.isSettings = false;
        }
        else if (path.indexOf('/settings') >= 0) {
          this.isMap = false;
          this.isContent = false;
          this.isAssets = false;
          this.isReports = false;
          this.isSettings = true;
        }
        else {
          this.isMap = true;
          this.isContent = false;
          this.isAssets = false;
          this.isReports = false;
          this.isSettings = false;
        }
      }
    });
  }

  CallMergeUpdates() {
    this.autorefreshService.CallMergeUpdates();
  };



  ngOnInit() {
    this.noAssets = globalConfig.allAssetItems.length > 0 ? false : true;
    this.themeService.castTheme.subscribe(the => this.theme = the);
    this.buildInfoService.castBuildInfo.subscribe(bui => this.buildInfo = bui);
    this.autorefreshService.castAutoRefreshStatus.subscribe(sta => this.autoRefreshStatus = sta);
    this.autorefreshService.castAutoRef_updatedCount.subscribe(cou => this.AutoRef_updatedCount = cou);

    if (!environment.production) {
      globalConfig.callPanelNav();
    }

  }
}
