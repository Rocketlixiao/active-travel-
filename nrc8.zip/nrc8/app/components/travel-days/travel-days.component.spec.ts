import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelDaysComponent } from './travel-days.component';

describe('TravelDaysComponent', () => {
  let component: TravelDaysComponent;
  let fixture: ComponentFixture<TravelDaysComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TravelDaysComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelDaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
