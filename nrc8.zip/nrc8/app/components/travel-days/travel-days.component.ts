import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { GridComponent, GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { process, GroupDescriptor, State, aggregateBy } from '@progress/kendo-data-query';
import { ActivatedRoute, ParamMap } from "@angular/router";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/observable/of';

import { ActivTravelService } from '../../services/activ-travel.service';
import { TravelDaysService } from '../../services/travel-days.service';
import { ReportEmailService } from "../../services/report-email.service";
import { NrcService } from "../../services/nrc.service";
import { ToastrService } from "../../services/toastr.service";
import { TravelDays } from '../../models/TravelDays';
import { SharedService } from '../../services/shared.service';
import { ReportFilterService } from "../../services/report-filter.service";
import { ReportInputParametersComponent } from "../report-common/report-input-parameters/report-input-parameters.component";
import {
  ReportHeader,
  SavedReport,
  ReportFilterContext,
  ReportEmailContext,
  ReportSaveReportContext,
  ReportMySavedReportContext
} from "../../models/ReportHeader";

declare var globalConfig: any;

@Component({
  selector: 'app-travel-days',
  templateUrl: './travel-days.component.html',
  styleUrls: ['./travel-days.component.css']
})
export class TravelDaysComponent implements OnInit, OnDestroy, ReportHeader {
  showLoading: boolean = false;
  private rawData: any;
  private lastReportsCount: number = 0;

  testlistitems: Array<string> = ['Baseball', 'Basketball', 'Cricket', 'Field Hockey', 'Football', 'Table Tennis', 'Tennis', 'Volleyball'];
  //header init 
  PiiInfo: { showPii: boolean } = { showPii: false };
  description: string;
  filterContent: ReportFilterContext = {
    hasTimeRange: true,
    dateTitle: 'Travel Dates',

    hasRegion: true,
    selectedRegions: [],
    hasCountry: true,
    selectedCountries: [],
    hasRiskRating: true,
    selectedRiskRatings: []
  };
  emailContent: ReportEmailContext = {
    outFields: ['TO', 'BCC', 'CC'],
    selectedOutField: 'TO',
    fileFormats: ['EXCEL', 'HTML', 'PDF']
  };
  saveReportContent: ReportSaveReportContext = new ReportSaveReportContext();
  mySavedReportsContent: ReportMySavedReportContext = {
    daysOfWeek: ['Moday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    daysOfMonth: [],
    reportFormats: ['EXCEL', 'HTML', 'PDF'],
    recurrenceTypes: ['daily', 'weekly', 'monthly'],
    reports: []
  };

  //grid init
  public take = 0;

  public gridData: any;
  public total: any;
  public totalRecord: number = 0;

  //device is in mobile or desktop
  public isMobile = false;

  travelDays: TravelDays[];

  public aggregates: any[] = [{ field: 'travelDays', aggregate: 'sum' }];

  public state: State = {
    skip: 0,
    take: 10000,
    group: [{ field: 'region', aggregates: this.aggregates }]
  };

  @ViewChild('appFeatures') appFeatures: any;
  @ViewChild('inputParametersPopup') inputParametersPopup: ReportInputParametersComponent;
  constructor(private sharedService: SharedService,
    private travelDaysService: TravelDaysService,
    private activTravelService: ActivTravelService,
    private nrcService: NrcService,
    private toastrService: ToastrService,
    private reportFilterService: ReportFilterService,
    private activatedRoute: ActivatedRoute,
    private reportEmailService: ReportEmailService) {
    for (let i = 1; i < 32; i++) {
      this.mySavedReportsContent.daysOfMonth.push(i);
    }
    this.activatedRoute.paramMap.switchMap((params: ParamMap) => {
      return Observable.of(params.get('reportId'));
    }).subscribe(id => {
      if (this.travelDays && id) {
        this.initFilterContent(this.mySavedReportsContent.reports.find(r => r.ReportID == id));
        this.loadData();
      }
    });
  }
  ngOnInit(): void {
    this.sharedService.showOrHideMap();
    this.isMobile = this.activTravelService.isMobile();
    this.loadMySavedReports(() => {
      let reportId = this.activatedRoute.snapshot.paramMap.get('reportId');
      if (reportId || this.reportFilterService.containsFilters(this.filterContent)) this.loadData();
      else this.appFeatures.toggleFilter();
    });
  }

  ngOnDestroy(): void {
    this.appFeatures.closePoup();
    globalConfig.travelDaysFilterContent = this.filterContent;
  }

  public loadItems(): void {

    this.applyFilter();
  }

  public applyFilter() {
    this.total = aggregateBy(this.travelDays, this.aggregates);
    //set total record 
    this.totalRecord = this.total["travelDays"].sum;
    this.gridData = process(this.travelDays, this.state);

    this.showLoading = false;
  }

  onFilterSubmited() {
    this.appFeatures.closePoup(true);
    this.loadData(true);
  }

  onEmailSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.sendReportEmail(path, this.emailContent, this.filterContent, [])
          .then(data => {
            this.toastrService.success("Email sent successfully");
          });
      }
    });
  }

  onDownLoadReportSubmited(format: string) {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.downloadReport(this.rawData, format, path);
      }
    });
  }

  onSendEmailSubmited(data: SavedReport) {
    this.PiiInfo.showPii = true;
    this.reportEmailService.sendEmailWithReport(data)
      .then(data => {
        this.toastrService.success("Report successfully emailed");
      });
  }

  onSaveReportSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportFilterService.upsetSavedReport(path, this.saveReportContent, [], this.mySavedReportsContent);
        this.onMySavedReportsSubmited(() => {
          if (!this.activatedRoute.snapshot.paramMap.get('reportId'))
            this.reportFilterService.resetSaveReport(this.saveReportContent);
        });
      }
    });
  }

  onMySavedReportsSubmited(success?: () => void) {
    this.PiiInfo.showPii = true;
    this.nrcService.updateMySavedReports(this.mySavedReportsContent.reports)
      .then(data => {
        let isDeleting = this.lastReportsCount > this.mySavedReportsContent.reports.length;
        this.lastReportsCount = this.mySavedReportsContent.reports.length;
        this.toastrService.success(isDeleting ? "Deleted report successfully" : "Reports saved successfully");
        if (typeof success === 'function') success();
      });
  }

  private loadData(isFilter?: boolean) {
    this.showLoading = true;
    this.travelDaysService.getTravelDays(this.filterContent)
      .then(data => {
        if (data) {
          this.rawData = data;
          if (isFilter) this.toastrService.success('Filters successfully applied');
          this.state.skip = 0;
          this.travelDays = this.travelDaysService.mappingData(data);
          this.loadItems();
          this.mapEditColumnsContext(this.travelDays);
          this.mapSaveReportContext(this.travelDays);
        }
      });
  }

  private mapEditColumnsContext(data: TravelDays[]) {

  }

  private mapSaveReportContext(data: TravelDays[]) {
    if (data && data.length) {
      this.saveReportContent.filter = this.filterContent;
    }
  }

  private loadMySavedReports(loadData: () => any) {
    this.nrcService.getMySavedReports()
      .then(data => {
        if (data) {
          this.mySavedReportsContent.reports = data.Result.docTypeAttributes.UserProfile.userTravelSettings.savedReports;
          this.lastReportsCount = this.mySavedReportsContent.reports.length;
        }

        let reportId = this.activatedRoute.snapshot.paramMap.get('reportId');
        this.initFilterContent(this.mySavedReportsContent.reports.find(r => r.ReportID == reportId));
        loadData();
      })
      .catch(err => { this.initFilterContent(null); });
  }

  private initFilterContent(report: SavedReport) {
    if (report) {
      this.reportFilterService.mapFilterContent(report, this.filterContent);
      this.saveReportContent = {
        reportId: report.ReportID,
        reportName: report.ReportName,
        currentReportName: report.ReportName,
        filter: this.filterContent
      };
    }
    else if (globalConfig.travelDaysFilterContent) {
      this.filterContent = globalConfig.travelDaysFilterContent;
    }

    let reports = this.mySavedReportsContent.reports || [];
    this.saveReportContent.allExistingReports = reports.map(r => r.ReportName);
  }
}
