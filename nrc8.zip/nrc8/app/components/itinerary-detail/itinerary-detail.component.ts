
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params } from "@angular/router";

import { SharedService } from "../../services/shared.service";
import { ItineraryService } from "../../services/itinerary.service";
import { ReportFilterService } from "../../services/report-filter.service";
import { ReportEmailService } from "../../services/report-email.service";
import { NrcService } from "../../services/nrc.service";
import { ToastrService } from '../../services/toastr.service';
import { FeaturesComponent } from "../report-header/features/features.component";
import {
  ReportHeader,
  SavedReport,
  ReportEmailContext,
  ReportSaveReportContext,
  ReportFilterContext,
  ReportMySavedReportContext
} from "../../models/ReportHeader";

declare var moment: any;
declare var globalConfig: any;

@Component({
  selector: 'app-itinerary-detail',
  templateUrl: './itinerary-detail.component.html',
  styleUrls: ['./itinerary-detail.component.css']
})
export class ItineraryDetailComponent implements OnInit, ReportHeader {
  showLoading: boolean = false;
  private rawData: any;
  private lastReportsCount: number = 0;

  PiiInfo: { showPii: boolean } = { showPii: false };
  data: any = {};
  description: string;
  itineraryDate: string;

  emailContent: ReportEmailContext = {
    outFields: ['TO', 'BCC', 'CC'],
    selectedOutField: 'TO',
    fileFormats: ['EXCEL', 'HTML', 'PDF']
  };
  saveReportContent: ReportSaveReportContext = { filter: [] } as ReportSaveReportContext;
  mySavedReportsContent: ReportMySavedReportContext = {
    daysOfWeek: ['Moday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    daysOfMonth: [],
    reportFormats: ['EXCEL', 'HTML', 'PDF'],
    recurrenceTypes: ['daily', 'weekly', 'monthly'],
    reports: []
  };
  filterContent: ReportFilterContext = {
    hasPnrid: true
  };

  @ViewChild('appFeatures') appFeatures: FeaturesComponent;
  constructor(
    private activatedRoute: ActivatedRoute,
    private sharedService: SharedService,
    private nrcService: NrcService,
    private toastrService: ToastrService,
    private itineraryService: ItineraryService,
    private reportFilterService: ReportFilterService,
    private reportEmailService: ReportEmailService) {
    for (let i = 1; i < 32; i++) {
      this.mySavedReportsContent.daysOfMonth.push(i);
    }
  }

  ngOnInit() {
    this.sharedService.showOrHideMap();
    this.loadMySavedReports(() => this.loadData());
  }

  ngOnDestroy(): void {
    this.appFeatures.closePoup();
    globalConfig.itineraryDetailFilterContent = this.filterContent;
  }

  loadData() {    
    let travelerId = this.activatedRoute.snapshot.paramMap.get('travelerId');
    if (this.reportFilterService.containsFilters(this.filterContent)) {
      this.getDetail();
    }
    else if (travelerId) {
      this.filterContent.PNRID = travelerId;
      this.getDetail();
    }
    else this.appFeatures.toggleFilter();
  }

  onFilterSubmited() {
    this.appFeatures.closePoup(true);
    this.loadData();
  }

  onEmailSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.sendReportEmail(path, this.emailContent, null, [])
          .then(data => {
            this.toastrService.success("Email sent successfully");
          });
      }
    });
  }

  onDownLoadReportSubmited(format: string) {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.downloadReport(this.rawData, format, path);
      }
    });
  }

  onSaveReportSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportFilterService.upsetSavedReport(path, this.saveReportContent, [], this.mySavedReportsContent);
        this.onMySavedReportsSubmited(() => {
          if (!this.activatedRoute.snapshot.paramMap.get('reportId'))
            this.reportFilterService.resetSaveReport(this.saveReportContent);
        });
      }
    });
  }

  onMySavedReportsSubmited(success?: () => void) {
    this.PiiInfo.showPii = true;
    this.nrcService.updateMySavedReports(this.mySavedReportsContent.reports)
      .then(data => {
        let isDeleting = this.lastReportsCount > this.mySavedReportsContent.reports.length;
        this.lastReportsCount = this.mySavedReportsContent.reports.length;
        this.toastrService.success(isDeleting ? "Deleted report successfully" : "Reports saved successfully");
        if (typeof success === 'function') success();
      });
  }

  onSendEmailSubmited(data: SavedReport) {
    this.PiiInfo.showPii = true;
    this.reportEmailService.sendEmailWithReport(data)
      .then(data => {
        this.toastrService.success("Report successfully emailed");
      });
  }

  private loadMySavedReports(loadData: () => any) {
    this.nrcService.getMySavedReports().then(data => {
      if (data) {
        this.mySavedReportsContent.reports = data.Result.docTypeAttributes.UserProfile.userTravelSettings.savedReports;
        this.lastReportsCount = this.mySavedReportsContent.reports.length;
      }

      let reportId = this.activatedRoute.snapshot.paramMap.get('reportId');
      let report = this.mySavedReportsContent.reports.find(r => r.ReportID == reportId);
      this.initFilterContent(report);
      loadData();
    })
      .catch(err => { this.initFilterContent(null); });
  }

  private initFilterContent(report: SavedReport) {
    if (report) {
      this.reportFilterService.mapFilterContent(report, this.filterContent);
      this.saveReportContent = {
        reportId: report.ReportID,
        reportName: report.ReportName,
        currentReportName: report.ReportName,
        filter: this.filterContent
      };
    }
    else if (globalConfig.itineraryDetailFilterContent) {
      this.filterContent = globalConfig.itineraryDetailFilterContent;
    }

    let reports = this.mySavedReportsContent.reports || [];
    this.saveReportContent.allExistingReports = reports.map(r => r.ReportName);
  }

  private getDetail() {
    this.showLoading = true;
    this.itineraryService.getItineraryDetail(this.filterContent).then(data => {
      if (data && data.Result && data.Result.length) {
        this.rawData = data;
        this.data = this.itineraryService.mapItineraryDetail(data);

        let start = moment(this.data.travelDays[0].localDate, 'MM/DD/YY').format('MMM DD, YYYY');
        let end = moment(this.data.travelDays[this.data.travelDays.length - 1].localDate, 'MM/DD/YY').format('MMM DD, YYYY');
        this.description = `${this.data.title} Itinerary | `;
        this.itineraryDate = `${start} - ${end}`;
      }
      else this.toastrService.error("Invalid PNRID entered. Please enter a valid PNRID.");

      this.showLoading = false;
    });
  }
}
