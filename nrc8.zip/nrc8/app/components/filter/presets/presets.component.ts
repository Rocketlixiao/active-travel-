import { Component, OnInit } from '@angular/core';
import { FilterService } from '../../../services/filter.service';
import { SettingsService } from '../../../services/settings.service'


@Component({
  selector: 'app-presets',
  templateUrl: './presets.component.html',
  styleUrls: ['./presets.component.css']
})
export class PresetsComponent implements OnInit {
  multipleFilters: any[];

  constructor(private filterService: FilterService, private settingsService: SettingsService) { }

  runMutipleFilter(filter) {
    this.filterService.RunMutipleFilter(filter);
  }

  ngOnInit() {
    this.filterService.castMutipleFilters.subscribe(res => {
      this.multipleFilters = res;
      
    });

    this.settingsService.castSettingsData.subscribe(set => {
      this.filterService.updateMultipleFilters(set);
    })

  }
}
