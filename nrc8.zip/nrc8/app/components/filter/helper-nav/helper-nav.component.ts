import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-helper-nav',
  templateUrl: './helper-nav.component.html',
  styleUrls: ['./helper-nav.component.css']
})
export class HelperNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
