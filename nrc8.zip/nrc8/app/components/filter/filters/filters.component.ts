import { Component, OnInit, Inject } from '@angular/core';
import { NrcService } from '../../../services/nrc.service';
import { FilterService } from '../../../services/filter.service';

import { DOCUMENT } from '@angular/platform-browser';
//import '../../../libs/globalConfig.js';
declare var globalConfig: any;
import * as $ from 'jquery';


@Component({
  selector: 'app-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.css']
})
export class FiltersComponent implements OnInit {

  ButtonText: string = "APPLY FILTERS";
  filterStatus: string = "filter-finished";

  categories: any[];
  category: any = {};
  selected = 'Select Category';

  data_type_list: any[];
  constructor(@Inject(DOCUMENT) private document: any, private nrcService: NrcService, private filterService: FilterService) { }

  ngOnInit() {
    globalConfig.callFormsUI();
    this.filterService.castButtonText.subscribe(text => this.ButtonText = text);

    this.nrcService.getCategories().then(res => this.categories = res);
    this.nrcService.getDataTypes().then(res => this.data_type_list = res);
    //Todo... not find an approach to trigger select change
    this.detectCategory();
  }

  detectCategory() {

    var timeIntervalSelect2 = setInterval(() => {
      var divCategorySelector = this.document.getElementById("categorySelector");
      if (divCategorySelector) {
        var tagSpans = divCategorySelector.getElementsByTagName("a")[0].getElementsByTagName("span");

        let tempCategory = '';
        for (var i = 0; i < tagSpans.length; i++) {
          if (tagSpans[i].className == "select2-chosen") {
            tempCategory = tagSpans[i].innerHTML;
          }
        }

        if (tempCategory !== this.selected) {
          this.selected = tempCategory;
          this.selectCategory(this.selected);
        }
      }
      else {

        clearInterval(timeIntervalSelect2);
      }
    }, 500);
  }

  selectCategory($event) {


    if ($event == "" || $event == "Select Category") {
      this.document.getElementById("subCategoryDiv").style.display = "none";
    }
    else {
      this.document.getElementById("subCategoryDiv").style.display = "block";
    }

    for (let ca of this.categories) {
      if (ca.name == $event)
        this.category = ca;
    }
  };

  showOrHideLocation(id) {
    var locationFilter = this.document.getElementById(id);
    var visibility = locationFilter.style.display;
    var checkBoxs = locationFilter.getElementsByTagName('input');

    for (var i = 0; i < checkBoxs.length; i++) {
      if (checkBoxs[i].checked) {
        checkBoxs[i].checked = false;
        checkBoxs[i].parentNode.setAttribute("class", "checkbox");
      }
    }

    if (visibility == "block") {
      locationFilter.style.display = "none";
    }
    else {
      locationFilter.style.display = "block";
    }
  }

  showLocationFilter(id) {
    if (id == 3) {
      this.showOrHideLocation("locationFilterDiv");
    }
    if (id == 0) {
      this.showOrHideLocation("interIncidentsFilterDiv");
    }
    if (id == 2) {
      this.showOrHideLocation("analysisFilterDiv");
    }
  }

  saveFilter() {

    if (this.filterStatus !== "filter-processing") {
      this.filterStatus = "filter-processing";

      this.filterService.saveFilterForArticleAndAssets();
      var scrollableDiv = this.document.getElementById("divscrollable");

      if (scrollableDiv) {
        scrollableDiv.scrollTop = 0;
      }

      this.filterStatus = "filter-finished";
    }
  }


}
