import { Component, OnInit, Input } from '@angular/core';

import { ItineraryService } from "../../../services/itinerary.service";
import { ReportFilterContext } from "../../../models/ReportHeader";

@Component({
  selector: 'app-report-itineray',
  templateUrl: './report-itineray.component.html',
  styleUrls: ['./report-itineray.component.css']
})
export class ReportItinerayComponent implements OnInit {
  data: any = {};
  @Input() pnrid: string;
  constructor(private itineraryService: ItineraryService) { }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    if (this.pnrid) {
      let filter = { hasPnrid: true, PNRID: this.pnrid } as ReportFilterContext;
      this.itineraryService.getItineraryDetail(filter).then(data => {
        this.data = this.itineraryService.mapItineraryDetail(data);
      });
    }
  }
}
