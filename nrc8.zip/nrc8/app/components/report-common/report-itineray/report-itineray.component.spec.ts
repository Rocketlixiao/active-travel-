import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportItinerayComponent } from './report-itineray.component';

describe('ReportItinerayComponent', () => {
  let component: ReportItinerayComponent;
  let fixture: ComponentFixture<ReportItinerayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportItinerayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportItinerayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
