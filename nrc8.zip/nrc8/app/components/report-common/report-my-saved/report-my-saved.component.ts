import { Component, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { Router } from "@angular/router";

import { ReportPopupComponent } from "../../../models/ReportPopupComponent";
import { ReportMySavedReportContext, SavedReport, ReportRouteFactory } from "../../../models/ReportHeader";

declare var globalConfig: any;
declare var moment: any;

@Component({
  selector: 'app-report-my-saved',
  templateUrl: './report-my-saved.component.html',
  styleUrls: ['./report-my-saved.component.css'],
  host: {
    'class': 'report-popup'
  }
})
export class ReportMySavedComponent implements ReportPopupComponent {
  selectedReport: SavedReport = new SavedReport();
  showSelectedReport: boolean = false;
  mytime: Date = new Date();
  dialogOpened: boolean = false;
  deleteIndex: number = -1;
  timeofday: Date;

  @Input() data: ReportMySavedReportContext;
  @Output() submitData: EventEmitter<any> = new EventEmitter();
  @Output() submitSendEmail: EventEmitter<any> = new EventEmitter();
  @ViewChild('dropdownlist') dropdownlist: any;
  constructor(
    private router: Router,
    private reportRouteFactory: ReportRouteFactory) { }

  set sendTo(value: string) {
    if (value) this.selectedReport.SendTo = value.split(';');
    else this.selectedReport.SendTo = [];
  }
  get sendTo(): string { return this.selectedReport.SendTo && this.selectedReport.SendTo.join(';'); }

  returnResult(close?: boolean) {
    let rtn = null;
    if (!close) rtn = this.data;
    this.submitData.emit(rtn);
  }

  sendEmail() {
    this.submitSendEmail.emit(this.selectedReport);
  }

  getFilterName(filter: any): string {
    if (Object.keys(filter).length) return Object.keys(filter)[0];
    return null;
  }

  getFilterValue(filter: any): string {
    let key = Object.keys(filter).length ? Object.keys(filter)[0] : null;

    if (key && filter[key]) {
      if (filter[key] instanceof Array) {
        if (key == 'segmenttype') {
          let tmp = [];
          filter[key].forEach(f => {
            let seg = globalConfig.filterDropdownItems.segmenttypes.find(s => s.value == f);
            if (seg) tmp.push(seg.text);
          });
          return tmp.join(',');
        }
        return filter[key].join(',');
      }
      return filter[key];
    }
    return null;
  }

  viewReport(report: SavedReport) {
    if (report.ReportType) {
      let route = this.reportRouteFactory.getRouteByLabel2(report.ReportType);
      if (route) {
        let secondaryPath = report.PropertyBags && report.PropertyBags.CorrelationId;
        this.router.navigate([`/reports/${route.key}/${secondaryPath ? (secondaryPath + '/') : ''}${report.ReportID}`]);
      }
    }
  }

  onTimeOfDayChanged(date: Date) {
    if (date) this.selectedReport.DeliveryTimeOfDay = moment(date).format('hh:mm A');
  }

  onSelectReport(item: SavedReport, showSelectedReport?: boolean) {
    this.selectedReport = item;
    this.showSelectedReport = !!showSelectedReport;

    if (this.selectedReport.DeliveryTimeOfDay) {
      this.timeofday = moment(this.selectedReport.DeliveryTimeOfDay, 'hh:mm A').toDate();
    }
    else {
      let d = new Date();
      d.setMinutes(0);
      this.timeofday = d;
    }
  }

  promptForDelete() {
    this.dialogOpened = true;
  }

  deleteReport() {
    if (this.deleteIndex > -1) {
      this.data.reports.splice(this.deleteIndex, 1);
      this.deleteIndex = -1;
      this.returnResult(false);
    }
  }
}
