import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportMySavedComponent } from './report-my-saved.component';

describe('ReportMySavedComponent', () => {
  let component: ReportMySavedComponent;
  let fixture: ComponentFixture<ReportMySavedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportMySavedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportMySavedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
