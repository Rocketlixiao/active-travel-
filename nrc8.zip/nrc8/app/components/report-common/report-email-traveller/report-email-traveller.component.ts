import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, Validators } from "@angular/forms";

import { ReportPopupComponent } from "../../../models/ReportPopupComponent";
import { ReportEmailContext } from "../../../models/ReportHeader";

@Component({
  selector: 'app-report-email-traveller',
  templateUrl: './report-email-traveller.component.html',
  styleUrls: ['./report-email-traveller.component.css'],
  host: {
    'class': 'report-popup'
  }
})
export class ReportEmailTravellerComponent implements ReportPopupComponent {
  emailForm: FormGroup;

  @Input() data: ReportEmailContext;
  @Output() submitData: EventEmitter<any> = new EventEmitter();
  constructor() {
  }

  returnResult(close?: boolean) {
    let rtn = null;
    if (!close) rtn = this.data;
    this.submitData.emit(rtn);
  }

  hasNoRecipients(): boolean {
    return !(this.data && this.data.recipients && this.data.recipients.some(r => r.isChecked));
  }
}
