import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportEmailTravellerComponent } from './report-email-traveller.component';

describe('ReportEmailTravellerComponent', () => {
  let component: ReportEmailTravellerComponent;
  let fixture: ComponentFixture<ReportEmailTravellerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportEmailTravellerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportEmailTravellerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
