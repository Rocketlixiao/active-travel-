import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportInputParametersComponent } from './report-input-parameters.component';

describe('ReportInputParametersComponent', () => {
  let component: ReportInputParametersComponent;
  let fixture: ComponentFixture<ReportInputParametersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportInputParametersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportInputParametersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
