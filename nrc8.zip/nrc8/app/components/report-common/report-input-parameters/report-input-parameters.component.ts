import { Component, Input, Output, EventEmitter, ViewChild, OnInit } from '@angular/core';
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { Observable, Subject } from "rxjs";
import { debounceTime, distinctUntilChanged, switchMap, map } from "rxjs/operators";

import { ReportPopupComponent } from "../../../models/ReportPopupComponent";
import { ReportFilterContext } from "../../../models/ReportHeader";
import { Airport } from "../../../models/Airport";
import { NrcService } from "../../../services/nrc.service";

declare var $ui: any;
declare var moment: any;
declare var globalConfig: any;

@Component({
  selector: 'app-report-input-parameters',
  templateUrl: './report-input-parameters.component.html',
  styleUrls: ['./report-input-parameters.component.css']
})
export class ReportInputParametersComponent implements OnInit, ReportPopupComponent {
  private dateRangePicker: any;
  private dateFormat: string = 'YYYY-MM-DD';

  isPopupOpened: boolean = true;
  regions: Array<string>;
  countries: Array<string>;
  segmenttypes: Array<{ text: string, value: string }>;
  riskratings: Array<number>;
  airports$: Observable<Airport[]>;
  searchText$ = new Subject<string>();
  @Input() data: ReportFilterContext;
  @Output() submitData: EventEmitter<any> = new EventEmitter();
  @ViewChild('dateRangeWrap') dateRangeWrap: any;
  constructor(private nrcService: NrcService) { }

  set city(city: string) {
    this.data.selectedCities = city ? city.split(',').map(c => c.trim()).filter(c => c) : [];
  }
  get city(): string { return this.data.selectedCities && this.data.selectedCities.length && this.data.selectedCities.join(',') || ''; }

  set airport(airport: string) {
    this.data.selectedAirports = airport ? [airport] : [];
  }
  get airport(): string { return this.data.selectedAirports && this.data.selectedAirports.length && this.data.selectedAirports[0]; }

  set minpassenger(min: number) {
    this.data.selectedMinPassenger = min ? [min] : [];
  }
  get minpassenger(): number { return this.data.selectedMinPassenger && this.data.selectedMinPassenger.length && this.data.selectedMinPassenger[0]; }

  ngOnInit() {
    setTimeout(() => {
      this.initDateRangePicker();
      this.regions = globalConfig.filterDropdownItems.regions;
      this.countries = globalConfig.filterDropdownItems.countries;
      this.riskratings = globalConfig.filterDropdownItems.riskratings;
      this.segmenttypes = globalConfig.filterDropdownItems.segmenttypes;
    });

    this.airports$ = this.searchText$.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      switchMap(txt =>
        this.nrcService.searchAirPorts(`?search=${txt}`))
    );
  }

  returnResult(close?: boolean) {
    this.isPopupOpened = false;
    let rtn = null;
    if (!close) rtn = this.data;
    this.submitData.emit(rtn);
  }

  onFilterChange(value: string, fieldName: string, cpt: MultiSelectComponent) {
    cpt.loading = true;
    if (value) {
      this[fieldName] = globalConfig.filterDropdownItems[fieldName].filter(r => r.toLowerCase().indexOf(value.toLowerCase()) > -1);
    }
    else {
      this[fieldName] = globalConfig.filterDropdownItems[fieldName];
    }
    cpt.loading = false;
  }

  onComplexFilterChange(value: string, fieldName: string, cpt: MultiSelectComponent) {
    cpt.loading = true;
    if (value) {
      this[fieldName] = globalConfig.filterDropdownItems[fieldName].filter((r: { text: string, value: string }) => r.value.toLowerCase().indexOf(value.toLowerCase()) > -1);
    }
    else {
      this[fieldName] = globalConfig.filterDropdownItems[fieldName];
    }
    cpt.loading = false;
  }

  onAutoCompleteFilterChanged(value: string) {
    if (value && value.length > 2)
      this.searchText$.next(value);
  }

  isFiltersInValid() {
    let count = 0;
    if (this.data.hasRegion && this.data.selectedRegions && this.data.selectedRegions.length > 0) count++;
    if (count < 2 && this.data.hasCity && this.data.selectedCities && this.data.selectedCities.length > 0) count++;
    if (count < 2 && this.data.hasCountry && this.data.selectedCountries && this.data.selectedCountries.length > 0) count++;
    if (count < 2 && this.data.hasAirport && this.data.selectedAirports && this.data.selectedAirports.length > 0) count++;
    return count > 1;
  }

  private initDateRangePicker() {
    if (!this.dateRangePicker && this.dateRangeWrap) {
      this.dateRangePicker = $ui(this.dateRangeWrap.nativeElement).find('.nc4-icon-calendar');
      let option: any = { opens: 'left' };
      if (this.data.dateRange) {
        option.minDate = new Date();
        option.maxDate = moment(new Date()).add(this.data.dateRange, 'days').toDate();
      }
      this.dateRangePicker.daterangepicker(
        option,
        (start, end) => {
          this.data.dateFrom = [moment(start).format(this.dateFormat)];
          this.data.dateTo = [moment(end).format(this.dateFormat)];
        });
    }
  }
}
