import { Component, EventEmitter, Input, Output } from '@angular/core';

import { ReportPopupComponent } from "../../../models/ReportPopupComponent";
import { ReportSaveReportContext } from "../../../models/ReportHeader";

@Component({
  selector: 'app-report-save-report',
  templateUrl: './report-save-report.component.html',
  styleUrls: ['./report-save-report.component.css'],
  host: {
    'class': 'report-popup'
  }
})
export class ReportSaveReportComponent implements ReportPopupComponent {
  confirmDialog: any = {
    dialogOpened: false,
    title: 'Warning',
    message: ''
  };
  @Input() data: ReportSaveReportContext;
  @Output() submitData: EventEmitter<any> = new EventEmitter();
  constructor() { }

  set reportname(value: string) {
    if (value && value.trim()) this.data.reportName = value.trim();
    else this.data.reportName = null;
  }
  get reportname(): string { return this.data.reportName; }

  segmentTypes(): string {
    return this.data && this.data.filter.selectedSegmentTypes.map(s => s.text).join(',');
  }

  returnResult(close?: boolean) {
    let rtn = null;
    if (!close) rtn = this.data;
    this.submitData.emit(rtn);
  }

  prompt() {
    let duplicateReportMessage = `A saved report "${this.data.reportName}" already exists. Are you sure you want to overwrite "${this.data.reportName}"?`;
    let existingReportMessage = `Are you sure you want to save "${this.data.reportName}" and overwrite the existing file?`;

    if (this.data.reportId) {
      if (this.data.currentReportName !== this.data.reportName
        && this.data.allExistingReports && this.data.allExistingReports.indexOf(this.data.reportName) > -1) {
        this.confirmDialog.message = duplicateReportMessage;
      }
      else {
        this.confirmDialog.message = existingReportMessage;
      }
      this.confirmDialog.dialogOpened = true;
    }
    else if (this.data.allExistingReports && this.data.allExistingReports.indexOf(this.data.reportName) > -1) {
      this.confirmDialog.message = duplicateReportMessage;
      this.confirmDialog.dialogOpened = true;
    }
    else this.returnResult();
  }
}
