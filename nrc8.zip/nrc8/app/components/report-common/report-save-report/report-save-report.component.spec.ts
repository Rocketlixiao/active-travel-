import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportSaveReportComponent } from './report-save-report.component';

describe('ReportSaveReportComponent', () => {
  let component: ReportSaveReportComponent;
  let fixture: ComponentFixture<ReportSaveReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportSaveReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportSaveReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
