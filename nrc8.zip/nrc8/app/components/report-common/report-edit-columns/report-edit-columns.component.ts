import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DragulaService } from 'ng2-dragula';

import { ReportPopupComponent } from "../../../models/ReportPopupComponent";
import { ReportEditColumnsContext } from "../../../models/ReportHeader";

@Component({
  selector: 'app-report-edit-columns',
  templateUrl: './report-edit-columns.component.html',
  styleUrls: ['./report-edit-columns.component.css'],
  host: {
    'class': 'report-popup'
  }
})
export class ReportEditColumnsComponent implements OnInit, ReportPopupComponent {
  @Input() data: ReportEditColumnsContext;
  @Output() submitData: EventEmitter<any> = new EventEmitter();

  constructor(private dragulaService: DragulaService)
  {
      this.dragulaService.dropModel.subscribe((value) => {
        this.onDropModel(value.slice(1));
      });
      this.dragulaService.removeModel.subscribe((value) => {
        this.onRemoveModel(value.slice(1));
      });
  }

  ngOnInit() {
  }

  returnResult(close?: boolean) {
    let rtn = null;
    if (!close) rtn = this.data;
    this.submitData.emit(rtn);
  }

  //drag an drop 
  private onDropModel(args) {
    let [el, target, source] = args;

  }

  //drag an drop
  private onRemoveModel(args) {
    let [el, source] = args;
  }



}
