import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportEditColumnsComponent } from './report-edit-columns.component';

describe('ReportEditColumnsComponent', () => {
  let component: ReportEditColumnsComponent;
  let fixture: ComponentFixture<ReportEditColumnsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportEditColumnsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportEditColumnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
