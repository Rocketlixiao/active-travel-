import { Component, EventEmitter, Input, Output, ViewChild, OnInit } from '@angular/core';
import { MultiSelectComponent } from "@progress/kendo-angular-dropdowns";
import { Observable, Subject } from "rxjs";
import { debounceTime, distinctUntilChanged, switchMap } from "rxjs/operators";

import { ReportPopupComponent } from "../../../models/ReportPopupComponent";
import { Airport } from "../../../models/Airport";
import { ReportFilterContext } from "../../../models/ReportHeader";
import { NrcService } from "../../../services/nrc.service";

declare var $ui: any;
declare var moment: any;
declare var globalConfig: any;

@Component({
  selector: 'app-report-filter',
  templateUrl: './report-filter.component.html',
  styleUrls: ['./report-filter.component.css'],
  host: {
    'class': 'report-popup'
  }
})
export class ReportFilterComponent implements OnInit, ReportPopupComponent {
  private dateFormat: string = 'YYYY-MM-DD';
  private dateRangePicker: any;

  regions: Array<string> = [];
  countries: Array<string> = [];
  organizations: Array<string> = [];
  segmenttypes: Array<{ text: string, value: string }> = [];
  riskratings: Array<number> = [];
  airports$: Observable<Airport[]>;
  searchText$ = new Subject<string>();
  @Input() data: ReportFilterContext;
  @Output() submitData: EventEmitter<any> = new EventEmitter();
  @ViewChild('dateRangeWrap') dateRangeWrap: any;
  constructor(private nrcService: NrcService) { }

  set pnrid(value: string) {
    if (value && value.trim()) this.data.PNRID = value.trim();
    else this.data.PNRID = null;
  }
  get pnrid(): string { return this.data.PNRID; }

  ngOnInit() {
    setTimeout(() => {
      this.regions = globalConfig.filterDropdownItems.regions;
      this.countries = globalConfig.filterDropdownItems.countries;
      this.organizations = globalConfig.filterDropdownItems.organizations && globalConfig.filterDropdownItems.organizations.length && globalConfig.filterDropdownItems.organizations.map(o => o.orgName);
      this.riskratings = globalConfig.filterDropdownItems.riskratings;
      this.segmenttypes = globalConfig.filterDropdownItems.segmenttypes;
      this.initDateRangePicker();
    });

    this.airports$ = this.searchText$.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      switchMap(txt =>
        this.nrcService.searchAirPorts(`?search=${txt}`))
    );
  }

  //#region setter/getter
  set city(city: string) {
    this.data.selectedCities = city ? city.split(',').map(c => c.trim()).filter(c => c) : [];
  }
  get city(): string { return this.data.selectedCities && this.data.selectedCities.length && this.data.selectedCities.join(',') || ''; }

  set airport(airport: string) {
    this.data.selectedAirports = airport ? [airport] : [];
  }
  get airport(): string { return this.data.selectedAirports && this.data.selectedAirports.length && this.data.selectedAirports[0] || ''; }

  set minpassenger(min: number) {
    this.data.selectedMinPassenger = min ? [min] : [];
  }
  get minpassenger(): number { return this.data.selectedMinPassenger && this.data.selectedMinPassenger.length && this.data.selectedMinPassenger[0]; }
  //#endregion setter/getter

  returnResult(close?: boolean) {
    let rtn = null;
    if (!close) rtn = this.data;
    this.submitData.emit(rtn);
  }

  clearFilter() {
    this.data.dateFrom = [];
    this.data.dateTo = [];
    this.data.selectedRegions = [];
    this.data.selectedCities = [];
    this.data.selectedCountries = [];
    this.data.selectedRiskRatings = [];
    this.data.selectedAirports = [];
    this.data.selectedSegmentTypes = [];
    this.data.selectedOrganizations = [];
    this.data.selectedMinPassenger = [];

    this.returnResult();
  }

  onFilterChange(value: string, fieldName: string, cpt: MultiSelectComponent) {
    cpt.loading = true;
    if (value) {
      if (fieldName == 'organizations') {
        this[fieldName] = globalConfig.filterDropdownItems[fieldName].map(o => o.orgName).filter(r => (r + '').toLowerCase().indexOf(value.toLowerCase()) > -1);
      }
      else {
        this[fieldName] = globalConfig.filterDropdownItems[fieldName].filter(r => (r + '').toLowerCase().indexOf(value.toLowerCase()) > -1);
      }
    }
    else {
      this[fieldName] = globalConfig.filterDropdownItems[fieldName];
    }
    cpt.loading = false;
  }

  onComplexFilterChange(value: string, fieldName: string, cpt: MultiSelectComponent) {
    cpt.loading = true;
    if (value) {
      this[fieldName] = globalConfig.filterDropdownItems[fieldName].filter((r: { text: string, value: string }) => r.value.toLowerCase().indexOf(value.toLowerCase()) > -1);
    }
    else {
      this[fieldName] = globalConfig.filterDropdownItems[fieldName];
    }
    cpt.loading = false;
  }

  onAutoCompleteFilterChanged(value: string) {
    if (value && value.length > 2)
      this.searchText$.next(value.toLowerCase());
  }

  isFiltersInValid() {
    let count = 0;
    if (this.data.hasRegion && this.data.selectedRegions && this.data.selectedRegions.length > 0) count++;
    if (count < 2 && this.data.hasCity && this.data.selectedCities && this.data.selectedCities.length > 0) count++;
    if (count < 2 && this.data.hasCountry && this.data.selectedCountries && this.data.selectedCountries.length > 0) count++;
    if (count < 2 && this.data.hasAirport && this.data.selectedAirports && this.data.selectedAirports.length > 0) count++;

    return count > 1;
  }

  geoFields(): string {
    let ret = [];
    if (this.data) {
      if (this.data.hasRegion) ret.push('Region');
      if (this.data.hasCountry) ret.push('Country');
      if (this.data.hasCity) ret.push('City');
      if (this.data.hasAirport) ret.push('Airport');
    }
    return ret.join(', ');
  }

  private initDateRangePicker(force?: boolean) {
    if (force || (!this.dateRangePicker && this.dateRangeWrap)) {
      this.dateRangePicker = $ui(this.dateRangeWrap.nativeElement).find('.nc4-icon-calendar');

      let option: any = { opens: 'left' };
      if (this.data.dateFrom && this.data.dateFrom.length) option.startDate = moment(this.data.dateFrom[0]);
      if (this.data.dateTo && this.data.dateTo.length) option.endDate = moment(this.data.dateTo[0]);
      if (this.data.dateRange) {
        option.minDate = new Date();
        option.maxDate = moment(new Date()).add(this.data.dateRange, 'days').toDate();
      }

      this.dateRangePicker.daterangepicker(
        option, (start, end) => {
          this.data.dateFrom = [moment(start).format(this.dateFormat)];
          this.data.dateTo = [moment(end).format(this.dateFormat)];
        });
    }
  }
}
