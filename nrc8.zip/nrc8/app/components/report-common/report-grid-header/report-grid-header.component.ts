import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ActivTravelService, ColumnSetting } from '../../../services/activ-travel.service';
declare var globalConfig: any;
@Component({
  selector: 'app-report-grid-header',
  templateUrl: './report-grid-header.component.html',
  styleUrls: ['./report-grid-header.component.css']
})
export class ReportGridHeaderComponent implements OnInit {
  @Input() public column: ColumnSetting;
  @Output() sortColumnsSubmited: EventEmitter<any> = new EventEmitter();
  CDN = globalConfig.CDN.root;
  constructor()
  {

  }

  ngOnInit() {
    //console.log(this.column);
  }

 public SortItem(columns:any,order:string)
 {
   let output = { columns, order };
   this.sortColumnsSubmited.emit(output);
   //console.log(columns);
   //console.log(order);
  }
}

