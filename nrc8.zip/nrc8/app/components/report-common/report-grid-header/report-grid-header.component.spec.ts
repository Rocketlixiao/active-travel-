import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportGridHeaderComponent } from './report-grid-header.component';

describe('ReportGridHeaderComponent', () => {
  let component: ReportGridHeaderComponent;
  let fixture: ComponentFixture<ReportGridHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ReportGridHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportGridHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
