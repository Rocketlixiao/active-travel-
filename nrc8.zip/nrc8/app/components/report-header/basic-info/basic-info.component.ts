import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

import { ReportFilterContext, ReportRouteFactory } from "../../../models/ReportHeader";

@Component({
  selector: 'app-basic-info',
  templateUrl: './basic-info.component.html',
  styleUrls: ['./basic-info.component.css']
})
export class BasicInfoComponent implements OnInit {
  @Input() PiiInfo: { showPii: boolean };
  @Input() description: string;
  @Input() itineraryDate: string;
  @Input() filterData: ReportFilterContext;
  @Output() changeFilter: EventEmitter<ReportFilterContext> = new EventEmitter();
  navItems: string[] = [];
  pageTitle: string;
  constructor(private activatedRoute: ActivatedRoute, private reportRouteFactory: ReportRouteFactory) { }

  ngOnInit() {
    this.activatedRoute.url.subscribe(segements => {
      this.navItems.length = 0;
      if (segements && segements.length > 1) {
        let title = this.reportRouteFactory.getLabel1ByKey(segements[1].path);
        this.pageTitle = title == this.reportRouteFactory.routes[5].label1 ? '' : title;
        segements.forEach((s, i) => {
          if (i > 0) this.navItems.push(this.reportRouteFactory.getLabel1ByKey(s.path));
        });
      }
    });
  }

  deleteFilter(arr: any[], index) {
    arr.splice(index, 1);
    this.changeFilter.emit(this.filterData);
  }

  deleteFilterDateRange() {
    this.filterData.dateFrom = [];
    this.filterData.dateTo = [];
    this.changeFilter.emit(this.filterData);
  }
}
