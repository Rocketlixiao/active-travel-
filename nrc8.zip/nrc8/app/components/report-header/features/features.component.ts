import { Component, OnInit, ElementRef, Input, Output, EventEmitter, ViewChild, ComponentFactoryResolver, Type } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";

import { ReportFilterComponent } from "../../report-common/report-filter/report-filter.component";
import { ReportEmailComponent } from "../../report-common/report-email/report-email.component";
import { ReportEditColumnsComponent } from "../../report-common/report-edit-columns/report-edit-columns.component";
import { SharedService } from "../../../services/shared.service";
import { ReportFilterService } from "../../../services/report-filter.service";
import { ReportFeatureHostDirective } from "../../../directives/report-feature-host.directive";
import { ReportPopupComponent } from "../../../models/ReportPopupComponent";
import { ReportFilterContext, ReportEmailContext, ReportSaveReportContext, EmailTravellerContext, ReportRouteFactory } from "../../../models/ReportHeader";
import { ReportSaveReportComponent } from '../../report-common/report-save-report/report-save-report.component';
import { ReportMySavedComponent } from '../../report-common/report-my-saved/report-my-saved.component';
import { ReportEmailTravellerComponent } from "../../report-common/report-email-traveller/report-email-traveller.component";

@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.css']
})
export class FeaturesComponent implements OnInit {
  private activePopups: ReportPopupComponent[] = [];

  formatDialogOpened: boolean = false;
  lastPopupId: string;
  reportsItems: Array<{ link: string, text: string }> = this.reportRouteFactory.getReportRouteData();
  selectedReport: any;
  isOpen: boolean = false;
  mobilePopupShowed: boolean = false;
  @Input() editColumnsContent: ReportEmailContext;
  @Input() saveReportContent: ReportSaveReportContext;
  @Input() mySavedReportsContent: ReportSaveReportContext;
  @Input() emailContent: ReportEmailContext;
  @Input() filterContent: ReportFilterContext;
  @Input() emailTravellerContent: EmailTravellerContext;
  @Output() editColumnsSubmited: EventEmitter<any> = new EventEmitter();
  @Output() saveReportSubmited: EventEmitter<any> = new EventEmitter();
  @Output() mySavedReportsSubmited: EventEmitter<any> = new EventEmitter();
  @Output() emailSubmited: EventEmitter<any> = new EventEmitter();
  @Output() downLoadReportSubmited: EventEmitter<any> = new EventEmitter();
  @Output() sendEmailSubmited: EventEmitter<any> = new EventEmitter();
  @Output() filterSubmited: EventEmitter<any> = new EventEmitter();
  @Output() emailTravellerSubmited: EventEmitter<any> = new EventEmitter();
  @ViewChild(ReportFeatureHostDirective) featureHost: ReportFeatureHostDirective;
  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private reportFilterService: ReportFilterService,
    private reportRouteFactory: ReportRouteFactory,
    private componentFactoryResolver: ComponentFactoryResolver,
    private sharedService: SharedService) { }

  ngOnInit() {
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let r = this.reportsItems.find(r => r.link.indexOf(`/${segements[1].path}`) == 8);
        if (r) this.selectedReport = r;
      }
    });
  }

  toggleEditColumns() {
    this.togglePopup('editcolumns', ReportEditColumnsComponent, this.editColumnsContent, data => {
      if (data) {
        this.hideMobileCommonControl();
        this.editColumnsSubmited.emit(data);
      }
      this.closePoup(true);
    });
  }

  toggleMySavedReports() {
    this.togglePopup('mysavedreport', ReportMySavedComponent, this.mySavedReportsContent,
      data => {
        if (data) {
          this.hideMobileCommonControl();
          this.mySavedReportsSubmited.emit(data);
        }
        this.closePoup(true);
      },
      data => {
        if (data) {
          this.hideMobileCommonControl();
          this.sendEmailSubmited.emit(data);
        }
        this.closePoup(true);
      });
  }

  toggleSaveReport() {
    this.togglePopup('savereport', ReportSaveReportComponent, this.saveReportContent, data => {
      if (data) {
        this.hideMobileCommonControl();
        this.saveReportSubmited.emit(data);
      }
      this.closePoup(true);
    });
  }

  toggleEmail() {
    this.togglePopup('email', ReportEmailComponent, this.emailContent, data => {
      if (data) {
        this.hideMobileCommonControl();
        this.emailSubmited.emit(data);
      }
      this.closePoup(true);
    });
  }

  toggleFilter() {
    this.togglePopup('filter', ReportFilterComponent, this.filterContent, data => {
      if (data) {
        this.hideMobileCommonControl();
        this.filterSubmited.emit(data);
      }
      this.closePoup(true);
    });
  }

  toggleEmailTraveller(anchor?: ElementRef, data?: EmailTravellerContext) {
    this.togglePopup(this.sharedService.generateGUID(), ReportEmailTravellerComponent, data || this.emailTravellerContent, data => {
      if (data) this.emailTravellerSubmited.emit(data);
      this.closePoup(true);
    });
  }

  togglePopup(popupName: string, cType: Type<ReportPopupComponent>, popupContent: any, onSubmit: (data: any) => void, onSubmitSendEmail?: (data: any) => void) {
    if (this.lastPopupId === popupName) {
      this.closePoup(true);
      return;
    }

    this.closePoup(false);
    this.lastPopupId = popupName;

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(cType);
    let component = this.featureHost.viewContainerRef.createComponent(componentFactory);
    let popupInst = component.instance;
    popupInst.data = popupContent;
    popupInst.submitData.subscribe(onSubmit);
    if (onSubmitSendEmail) popupInst.submitSendEmail.subscribe(onSubmitSendEmail);
  }

  downLoadReport(format: string) {
    this.formatDialogOpened = false;
    this.downLoadReportSubmited.emit(format);
  }

  closePoup(resetLast?: boolean) {
    if (resetLast) this.lastPopupId = null;

    this.activePopups.forEach((popup: ReportPopupComponent) => {
      popup.submitData.unsubscribe();
      if (popup.submitSendEmail) popup.submitSendEmail.unsubscribe();
    });
    this.featureHost.viewContainerRef.clear();
  }

  hideMobileCommonControl() {
    if (this.reportFilterService.isMobileView())
      this.isOpen = false;
  }

  goToReport(report: { link: string }) {
    this.router.navigate([report.link]);
  }
}
