import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { SortService } from '../../../services/sort.service';

@Component({
  selector: 'app-content-tool-bar',
  templateUrl: './content-tool-bar.component.html',
  styleUrls: ['./content-tool-bar.component.css']
})
export class ContentToolBarComponent implements OnInit {
  path: string;
  orderValue: string = 'ImpactedAssets';
  @Output() sortEvent = new EventEmitter<string>();

  constructor(private router: Router, private sortService: SortService) { }

  changeSort(event) {   
    
    this.sortService.setArticleListCurrentSort(this.orderValue);
    this.sortEvent.emit(this.orderValue);    
  } 

  ngOnInit() {
    this.path = this.router.url;

    if (this.sortService.getArticleListCurrentSort()) {
      this.orderValue = this.sortService.getArticleListCurrentSort();
      this.changeSort(this.orderValue);
    }
  }
}
