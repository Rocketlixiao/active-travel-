import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentToolBarComponent } from './content-tool-bar.component';

describe('ContentToolBarComponent', () => {
  let component: ContentToolBarComponent;
  let fixture: ComponentFixture<ContentToolBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentToolBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentToolBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
