import { Component, OnInit, Inject } from '@angular/core';
import { SharedService } from '../../../services/shared.service';
import { SortService } from '../../../services/sort.service';
import { ArticleSort } from '../../../models/ArticleSort';
import { AutorefreshService } from '../../../services/autorefresh.service';

//import '../../../libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-content-grid',
  templateUrl: './content-grid.component.html',
  styleUrls: ['./content-grid.component.css']
})
export class ContentGridComponent implements OnInit {

  incidentsItems: any;
  articleSort = new ArticleSort();
  sortA = this.articleSort.sortA;
  sortB = this.articleSort.sortB;
  sortC = this.articleSort.sortC;
  sortD = this.articleSort.sortD;

  constructor(private sharedService: SharedService, private sortService: SortService, private autorefreshService: AutorefreshService) { }

  receiveSort($event) {
    this.articleSort = this.sortService.getArticleSort($event);
    this.sortA = this.articleSort.sortA;
    this.sortB = this.articleSort.sortB;
    this.sortC = this.articleSort.sortC;
    this.sortD = this.articleSort.sortD;
  }

  ngOnInit() {

    this.sharedService.showOrHideMap();

    this.sharedService.castIncidentsItems.subscribe(ins => this.incidentsItems = ins);

    //Merge the updates when page is loaded.
    this.autorefreshService.MergeUpdates(false);

    if (globalConfig.allIncidentItems.length === 0) {
      this.sharedService.getIncidentsAssets(null);
    }
  }

}
