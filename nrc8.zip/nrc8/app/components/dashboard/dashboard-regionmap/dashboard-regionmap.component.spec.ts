import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardRegionmapComponent } from './dashboard-regionmap.component';

describe('DashboardRegionmapComponent', () => {
  let component: DashboardRegionmapComponent;
  let fixture: ComponentFixture<DashboardRegionmapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardRegionmapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardRegionmapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
