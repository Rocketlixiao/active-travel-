import { Component, OnInit, Input } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';

//import '../../../libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-dashboard-piechart',
  templateUrl: './dashboard-piechart.component.html',
  styleUrls: ['./dashboard-piechart.component.css']
})
export class DashboardPiechartComponent implements OnInit {
  dashboard: any;

  constructor(private dashboardService: DashboardService) { }

  ngOnInit() {

    this.dashboardService.castDashboardFacility.subscribe(res => {
      this.dashboard = res;
      globalConfig.callPiechart(this.dashboard.id, this.dashboard.charts.pie.data);
    });
    
  }
}
