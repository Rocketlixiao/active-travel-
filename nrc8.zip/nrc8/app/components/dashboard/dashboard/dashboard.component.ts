import { Component, OnInit, Input, Inject } from '@angular/core';
import { DashboardService } from '../../../services/dashboard.service';


//import '../../../libs/globalConfig.js';
declare var globalConfig: any;
//import * as $ from 'jquery';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @Input() id: string;
  dashboard: any = {};

  constructor(private dashboardService: DashboardService) { }

  ngOnInit() {

    this.init(this.id);
  }


  init($id) {    

    //traveler
    if ($id === this.dashboardService.TRAVELER) {
      this.dashboard = this.dashboardService.findType($id) || {};
    }

    //activpoint
    if ($id === this.dashboardService.ACTIVPOINT) {
      this.dashboard = this.dashboardService.findType($id) || {};
    }

    //facility
    if ($id === this.dashboardService.FACILITY) {

      this.dashboardService.castDashboardFacility.subscribe(res => this.dashboard = res);
      this.dashboardService.initDashboardFacility($id);  
    }

  }

  carousel(selector, option) {
    globalConfig.carousel(selector, option);
  };



}
