import { Component, OnInit, Inject, AfterViewInit} from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { NrcService } from '../../services/nrc.service';
import { BuildInfoService } from '../../services/build-info.service';
import { SettingsData } from '../../models/SettingsData';
import { Theme } from '../../models/Theme';
import { SettingsService } from '../../services/settings.service';
import { ThemeService } from '../../services/theme.service';
import { BuildInfo } from '../../models/BuildInfo';
import { AutorefreshService } from '../../services/autorefresh.service';
import { DOCUMENT } from '@angular/platform-browser';
//import '../../libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {
  testlistitems: Array<string> = ["X-Small", "Small", "Medium", "Large", "X-Large", "2X-Large"];
  setting = new SettingsData();
  settingsUpdate: SettingsData;
  buildInfo = new BuildInfo();
  theme: Theme;

  MAX_MILES = 50;
  MAX_KM = 80;
  MI = "mi";
  KM = "km";
  isInSaving = false;
  measure = { maxLength: this.MAX_MILES };
  listColorPalette = this.themeService.listColorPalette;
  listLogoImage = this.themeService.listLogoImage;

  constructor(@Inject(DOCUMENT) private document: any, private sharedService: SharedService, private nrcService: NrcService, private buildInfoService: BuildInfoService, private themeService: ThemeService, private settingsService: SettingsService, private autorefreshService: AutorefreshService) { }

  selectColorPalette(value: string) {

    var div = this.document.getElementById("divColorPalette");
    if (globalConfig.hasClass(div, 'open')) {
      globalConfig.removeClass(div, 'open');
    }
    this.setting.ColorPaletteObject = this.themeService.getSelectedOption(value, this.themeService.listColorPalette);
  }

  selectLogoTitle(value: string) {
    var div = this.document.getElementById("divLogoTitle");
    if (globalConfig.hasClass(div, 'open')) {
      globalConfig.removeClass(div, 'open');

    }

    this.setting.LogoTitleObject = this.themeService.getSelectedOption(value, this.themeService.listLogoImage);
  }

  swithRadiu(status: string) {
    var div1 = this.document.getElementById(status + "-div1");
    var div2 = this.document.getElementById(status + "-div2");

    div1.className = globalConfig.hasClass(this.document.getElementById(status + "-div1"), "close1") ? "radius-div1 open1" : "radius-div1 close1";
    div2.className = globalConfig.hasClass(this.document.getElementById(status + "-div2"), "close2") ? "radius-div2 open2" : "radius-div2 close2";

  }

  saveSettings() {
    this.isInSaving = true;
    this.settingsUpdate = this.setting;
    this.settingsUpdate.ProximityWarningEnabled = this.document.getElementById('ckbenableAssetStatus').checked ? true : false;
    this.settingsUpdate.DistanceUnit = this.setting.DistanceUnit;
    this.settingsUpdate.ExtremeRadius = this.setting.ExtremeRadius;
    this.settingsUpdate.ExtremeEnabled = this.document.getElementById('extreme-div1').className == "radius-div1 open1" ? true : false;
    this.settingsUpdate.SevereRadius = this.setting.SevereRadius;
    this.settingsUpdate.SevereEnabled = this.document.getElementById('severe-div1').className == "radius-div1 open1" ? true : false;
    this.settingsUpdate.ModerateRadius = this.setting.ModerateRadius;
    this.settingsUpdate.ModerateEnabled = this.document.getElementById('moderate-div1').className == "radius-div1 open1" ? true : false;
    this.settingsUpdate.MinorRadius = this.setting.MinorRadius;
    this.settingsUpdate.MinorEnabled = this.document.getElementById('minor-div1').className == "radius-div1 open1" ? true : false;
    this.settingsUpdate.ColorPalette = this.setting.ColorPaletteObject.value;
    this.settingsUpdate.LogoPath = globalConfig.CDN.root + '/nc4mapMainStyle/images/';
    this.settingsUpdate.LogoTitle = this.setting.LogoTitleObject.value;
    this.settingsUpdate.ShowPoweredBy = this.document.getElementById('ckbenableShowPoweredBy').checked ? true : false;

    //this.nrcService.postSettings(this.settingsUpdate);
    this.nrcService.createSettings(this.settingsUpdate).then(res => {
      if (res.success) {
        alert('Save successful.');

        //rest all global cache that related to settings.
        globalConfig.allIncidentItems = [];
        globalConfig.allFilteredIncidentItems = [];
        globalConfig.allAssetItems = [];
        globalConfig.allFilteredAssetItems = [];
        globalConfig.AutoRef_updatedIncidents = [];
        globalConfig.AutoRef_updatedAssets = [];
        globalConfig.allProximities = {};
        globalConfig.allLegacyProximities = {};
        globalConfig.allResources = {};
        globalConfig.settingsData = {};
        globalConfig.isIncidentsLoadComplete = false;
        globalConfig.isAssetsLoadComplete = false;
        globalConfig.isClusterComplete = false;

        this.settingsService.changeSettingsData(this.settingsUpdate);

        //update theme
        this.theme.colorPalette = this.settingsUpdate.ColorPalette;
        this.theme.logoPath = this.settingsUpdate.LogoPath;
        this.theme.logoTitle = this.settingsUpdate.LogoTitle;
        this.theme.showPoweredBy = this.settingsUpdate.ShowPoweredBy;
        this.themeService.changeTheme(this.theme);
      }
      else {
        alert('Save failed!');
      }

      this.isInSaving = false;

    })
  }

  ngAfterViewInit() {
    hideSlideListInPhone();
  }

  ngOnInit() {
    this.document.getElementById('map-view').style.visibility = "hidden";
    globalConfig.setBodyOverflow("auto");

    //Merge the updates when page is loaded.
    this.autorefreshService.MergeUpdates(false);

    this.buildInfoService.castBuildInfo.subscribe(bui => this.buildInfo = bui);

    this.settingsService.castSettingsData.subscribe(set => {

      this.setting = set;
      this.measure.maxLength = set.DistanceUnit === this.MI ? this.MAX_MILES : this.MAX_KM;
      this.setting.IsThemeEditor = set.IsThemeEditor;

    });

    this.themeService.castTheme.subscribe(the => this.theme = the);

  }

}
