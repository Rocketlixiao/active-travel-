import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
declare var globalConfig: any;
@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.css']
})
export class LoadingComponent implements OnInit {
  @Input() flag: boolean
  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed
    if (changes['flag']) {
      if (this.flag) {
        globalConfig.showLoader();
      }
      else {
        globalConfig.hideLoader();
      }
    }
  }

}
