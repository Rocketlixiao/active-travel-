import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticleMapComponent } from './article-map.component';

describe('ArticleMapComponent', () => {
  let component: ArticleMapComponent;
  let fixture: ComponentFixture<ArticleMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticleMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticleMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
