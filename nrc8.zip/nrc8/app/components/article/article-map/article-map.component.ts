import { Component, OnInit, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { MapService } from '../../../services/map.service';

//import '../../../libs/globalConfig.js';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Router } from '@angular/router';
declare var globalConfig: any;
declare var Microsoft: any;
declare var HtmlPushpin: any;
declare var HtmlPushpinLayer: any;

@Component({
  selector: 'app-article-map',
  templateUrl: './article-map.component.html',
  styleUrls: ['./article-map.component.css']
})
export class ArticleMapComponent implements OnInit {

  CDN = globalConfig.CDN.root;

  map:any;
  mapPrint: any;

  lastMapTypeId = 'a';
  actualZoom = 11;
  actualCenter: any;
  pinsLayer:any;
  pinsLayerPrint: any;

  incidentid: string;
  source: string;
  category: string;
  risk: string;  

  //resize the pin position when window width is changed
  previewWidth = window.innerWidth;

  mapReadyObservable = new BehaviorSubject<boolean>(false);
  castMapReadyObservable = this.mapReadyObservable.asObservable();

  constructor(@Inject(DOCUMENT) private document: any, private mapService: MapService, private router: Router) {

  }

  ngOnInit() {
    this.detectMapReady();

    if (typeof Microsoft !== 'undefined') {
      this.loadMapScenario();
    }

    this.windowResizeInterval();
  }

  detectMapReady() {
    let mapReadyInterval = null;
    mapReadyInterval = setInterval(() => {

      if (this.map && typeof (HtmlPushpinLayer) != 'undefined') {

        this.emitMapReady(true);
        window.clearInterval(mapReadyInterval);
        mapReadyInterval = null;
      }
    }, 200)
  }

  emitMapReady(val) {
    this.mapReadyObservable.next(val);
  }

  windowResizeInterval() {
    window.setInterval(() => {
      var curWidth = window.innerWidth;

      if ((this.previewWidth != curWidth) && this.pinsLayer != null) {
        this.pinsLayer.onLoad();
        this.previewWidth = curWidth;
      }

    }, 200);
  }

  loadMapScenario() {
    this.map = new Microsoft.Maps.Map(this.document.getElementById('mapDivAsset'), {
      credentials: this.mapService.credentials,
      mapTypeId: Microsoft.Maps.MapTypeId.aerial,
      zoom: 18,
      showDashboard: false,
      disablePanning: true,
      disableScrollWheelZoom: true

    });

    this.mapPrint = new Microsoft.Maps.Map(this.document.getElementById('mapDivAssetPrint'), {
      credentials: this.mapService.credentials,
      mapTypeId: Microsoft.Maps.MapTypeId.aerial,
      zoom: 18,
      showDashboard: false,
      disablePanning: true,
      disableScrollWheelZoom: true

    });

    //fix the issue that can't scroll page when moving map
    var scrollTopStart = 0;
    var pagey1 = 0;
    var pagey2 = 0;
    Microsoft.Maps.Events.addHandler(this.map, 'mousedown', function (mouseEvent) {
      this.document.getElementById('mapPaperAirplaneMessage').style.display = 'none';
      scrollTopStart = window.pageYOffset;
      pagey1 = mouseEvent.pageY;
    });

    Microsoft.Maps.Events.addHandler(this.map, 'mouseup', function (mouseEvent) {
      pagey2 = mouseEvent.pageY;
      var distance = pagey1 - pagey2;

      window.setTimeout(function () {
        window.scrollTo(0, scrollTopStart + distance);
      }, 200);
    });

    //Register the custom module.
    Microsoft.Maps.registerModule('HtmlPushpinLayerModule', 'assets/js/HtmlPushpinLayerModule.js');
  }

  SetZoomOut() {

    var currentZoomLevel = this.map.getZoom();
    currentZoomLevel = currentZoomLevel + 1;
    this.map.setView({ zoom: currentZoomLevel });
    if (this.pinsLayer != undefined) {
      this.pinsLayer.updatePositions();
    }

  }

  SetZoomIn() {

    var currentZoomLevel = this.map.getZoom();
    currentZoomLevel = currentZoomLevel - 1;
    this.map.setView({ zoom: currentZoomLevel });
    if (this.pinsLayer != undefined) {
      this.pinsLayer.updatePositions();
    }
  }

  ShowZoomInOut(flag) {
    var zoomOut = this.document.getElementById('mapZoomOut');
    var zoomIn = this.document.getElementById('mapZoomIn');
    var mapPaperAirplane = this.document.getElementById('mapPaperAirplane');
    if (flag) {

      zoomOut.style.display = 'block';
      zoomIn.style.display = 'block';
      mapPaperAirplane.style.display = 'block';


    }
    else {
      zoomOut.style.display = 'none';
      zoomIn.style.display = 'none';
      mapPaperAirplane.style.display = 'none';
    }
  }

  closeStreetSide() {
    var ss = this.document.getElementsByClassName("streetsideExit")[0];
    if (ss != null && typeof (ss) != 'undefined') {
      ss.click();
    }
  }

  switchBaseMap(mapTypeId) {

    if (mapTypeId == 'a') {
      this.ShowZoomInOut(true);
      if (this.lastMapTypeId == 'ss') {
        this.closeStreetSide();
        this.map.setView({ center: this.actualCenter });
        this.document.getElementById("basemap-select-text").innerHTML = "Aerial";
        if (this.pinsLayer != undefined) {
          this.pinsLayer.updatePositions();
        }
      }
      this.map.setView({ mapTypeId: Microsoft.Maps.MapTypeId.aerial });
    }
    else if (mapTypeId == 'r') {
      this.ShowZoomInOut(true);
      if (this.lastMapTypeId == 'ss') {
        this.closeStreetSide();
        this.map.setView({ center: this.actualCenter });
        this.document.getElementById("basemap-select-text").innerHTML = "Road";
        if (this.pinsLayer != undefined) {
          this.pinsLayer.updatePositions();
        }
      }
      this.map.setView({ mapTypeId: Microsoft.Maps.MapTypeId.road });


    }
    else if (mapTypeId == 'ss') {
      this.ShowZoomInOut(false);
      this.actualCenter = this.map.getCenter();

      var that = this;
      this.map.setView({
        mapTypeId: Microsoft.Maps.MapTypeId.streetside,
        streetsideOptions: {
          showCurrentAddress: false,
          overviewMapMode: Microsoft.Maps.OverviewMapMode.hidden,
          showProblemReporting: true,
          disablePanoramaNavigation: false,
          showHeadingCompass: true,
          showZoomButtons: true,
          panoramaLookupRadius: 500,
          onSuccessLoading: function () { return true },
          onErrorLoading: function () { that.switchBaseMap('a'); return alert("Streetside view isn't supported in this area."); }
        }

      });
    }

    this.lastMapTypeId = mapTypeId;

  }

  //***************incident data*************************


  ShowBaseMapItems() {
    var baseMapyLayer = this.document.getElementById('baseMapItems');

    if (baseMapyLayer.style.display != 'block') {
      baseMapyLayer.style.display = 'block';
    }
    else {
      baseMapyLayer.style.display = 'none';
    }
  };
  SwitchMapTypeId(mapTypeId, label) {

    var baseMapText = this.document.getElementById('basemap-select-text');
    baseMapText.innerText = label;
    this.ShowBaseMapItems();
    this.switchBaseMap(mapTypeId);
  };

  BuildArticleMap(articleObject) {
    this.incidentid = articleObject.id;
    //hide paper airplane when source is not in "NIMC,CyberTech India,GFP,AB"
    if (!globalConfig.enablePaperAirplaneBySource(articleObject.source)) {
      this.document.getElementById('mapPaperAirplane').style.display = "none";
    }
    
    this.source = articleObject.source;
    this.category = articleObject.category.toLowerCase();
    this.risk = articleObject.risk;

    this.castMapReadyObservable.subscribe(isReady => {
      if (isReady) {

        var that = this;

        var centerX = 0;
        var centerY = 0;
        var distanceMaxX = 0;
        var distanceMaxY = 0;
        //distance for aireplane
        var distanceMaxXForAirplane = 0;
        var distanceMaxYForAirplane = 0;
        // the original purpose is to use incident icon height in pixel divide by map height in pixel (which is 50 / 320),
        // however, it appears the map might rendr it in a smaller or larger extend, so use this hardcoded value for now.
        var offsetRatio = 1 / 6;
        var mapLocations = [];
        //create pin with layer to fix gif not flashing issue
        var pins = [];
        var pinsPrint = [];
        var htmlTemplate = '<img src="{url}" width={width} height={height}/>';

        if (globalConfig.isValidCoordinate(articleObject.longitude) && globalConfig.isValidCoordinate(articleObject.latitude)) {

          centerX = articleObject.longitude * 1;
          centerY = articleObject.latitude * 1;

          var iconPath = globalConfig.getIncidentIconsBySeverityCategory(articleObject.risk, articleObject.category);
          var pinWidth = globalConfig.getPinWidthHeight(iconPath).width;
          var pinHeight = globalConfig.getPinWidthHeight(iconPath).height;
          var pin = new HtmlPushpin(new Microsoft.Maps.Location(centerY, centerX), htmlTemplate.replace('{url}', iconPath).replace('{width}', pinWidth).replace('{height}', pinHeight), new Microsoft.Maps.Point(pinWidth / 2, pinHeight), '999');
          pins.push(pin);
          this.map.setView({ center: new Microsoft.Maps.Location(centerY, centerX) });

          var pinPrint = new HtmlPushpin(new Microsoft.Maps.Location(centerY, centerX), htmlTemplate.replace('{url}', iconPath).replace('{width}', pinWidth).replace('{height}', pinHeight), new Microsoft.Maps.Point(pinWidth / 2, pinHeight), '999');
          pinsPrint.push(pinPrint);
          this.mapPrint.setView({ center: new Microsoft.Maps.Location(centerY, centerX) });

        }

        var arrAssets = articleObject.ImpactedAssetsItems;
        if (arrAssets.length > 0) {
          var inciX, inciY;

          for (var i = 0; i < arrAssets.length; i++) {
            if (globalConfig.isValidCoordinate(arrAssets[i].longitude) && globalConfig.isValidCoordinate(arrAssets[i].latitude)) {
              inciX = arrAssets[i].longitude * 1;
              inciY = arrAssets[i].latitude * 1

              var temp = Math.abs(inciX - centerX)
              if (temp > distanceMaxX) {
                distanceMaxX = temp;
              }

              temp = Math.abs(inciY - centerY)
              if (temp > distanceMaxY) {
                distanceMaxY = temp;
              }
              //if location layer is on, calculate distanceMaxX/distanceMaxY
              if (globalConfig.checkIfExistOnMap('location', '')) {
                var temp1 = Math.abs(inciX - centerX)
                if (temp1 > distanceMaxXForAirplane) {
                  distanceMaxXForAirplane = temp1;
                }

                temp1 = Math.abs(inciY - centerY)
                if (temp1 > distanceMaxYForAirplane) {
                  distanceMaxYForAirplane = temp1;
                }

              }

              var iconPath = globalConfig.getAssetIconPathBySeverity(arrAssets[i].ProximityStatus, arrAssets[i].objtype);
              var pinWidth = globalConfig.getPinWidthHeight(iconPath).width;
              var pinHeight = globalConfig.getPinWidthHeight(iconPath).height;
              var pin = new HtmlPushpin(new Microsoft.Maps.Location(inciY, inciX), htmlTemplate.replace('{url}', iconPath).replace('{width}', pinWidth).replace('{height}', pinHeight), new Microsoft.Maps.Point(pinWidth / 2, pinHeight), '10');
              pins.push(pin);
              //for printing
              var pinPrint = new HtmlPushpin(new Microsoft.Maps.Location(inciY, inciX), htmlTemplate.replace('{url}', iconPath).replace('{width}', pinWidth).replace('{height}', pinHeight), new Microsoft.Maps.Point(pinWidth / 2, pinHeight), '10');
              pinsPrint.push(pinPrint);

            }
          }
        }

        var refinedDistanceMaxX = Math.max(distanceMaxX, distanceMaxY) * 2 * offsetRatio + distanceMaxX;
        var refinedDistanceMaxY = Math.max(distanceMaxX, distanceMaxY) * 2 * offsetRatio + distanceMaxY;
        if (distanceMaxX > 0 || distanceMaxY > 0) {
          var viewRect = Microsoft.Maps.LocationRect.fromCorners(new Microsoft.Maps.Location(centerY - refinedDistanceMaxY, centerX - refinedDistanceMaxX), new Microsoft.Maps.Location(centerY + refinedDistanceMaxY, centerX + refinedDistanceMaxX));
          this.map.setView({ bounds: viewRect });
          this.mapPrint.setView({ bounds: viewRect });
        }

        //prepare for air plane
        //Init PaperAireplane parameters
        globalConfig.initPaperAirplane();
        var refinedDistanceMaxXForAirplane = Math.max(distanceMaxXForAirplane, distanceMaxYForAirplane) * 2 * offsetRatio + distanceMaxXForAirplane;
        var refinedDistanceMaxYForAirplane = Math.max(distanceMaxXForAirplane, distanceMaxYForAirplane) * 2 * offsetRatio + distanceMaxYForAirplane;
        if (distanceMaxXForAirplane > 0 || distanceMaxYForAirplane > 0) {

          let extent: any = {};
          extent.cX1 = centerX - refinedDistanceMaxXForAirplane;
          extent.cY1 = centerY - refinedDistanceMaxYForAirplane;
          extent.cX2 = centerX + refinedDistanceMaxXForAirplane;
          extent.cY2 = centerY + refinedDistanceMaxYForAirplane;
          globalConfig.paperAirplane.extent = extent;
        }
        else {
          let point: any = {};
          point.cX = centerX;
          point.cY = centerY;
          globalConfig.paperAirplane.centerPoint = point;
        }

        //Load the module.
        Microsoft.Maps.loadModule('HtmlPushpinLayerModule', function () {

          that.pinsLayer = new HtmlPushpinLayer();
          that.pinsLayer.setPushpins(pins);

          //Add the HTML pushpin to the map.
          that.map.layers.insert(that.pinsLayer);
        });
        //load print map
        //Microsoft.Maps.loadModule('HtmlPushpinLayerModule', function () {

        //  that.pinsLayerPrint = new HtmlPushpinLayer();
        //  that.pinsLayerPrint.setPushpins(pinsPrint);

        //  //Add the HTML pushpin to the map.
        //  that.mapPrint.layers.insert(that.pinsLayerPrint);

        //});

      }
    });
  }



  DirectToMap() {
    var divMapPaperAirplaneMessage = this.document.getElementById('mapPaperAirplaneMessage');
    globalConfig.createHTMLNotOnMapMessage('mapPaperAirplaneMessage', this.incidentid, this.risk, this.source, this.category);

    if (divMapPaperAirplaneMessage.innerHTML == '') {
      globalConfig.paperAirplane.launch = true;
      //open the popup window when navigate to map
      globalConfig.paperAirplane.initInforWindowData('incident', this.incidentid);
      //window.location.href = '/map';
      
      this.router.navigateByUrl('/map');

    }
    else {
      if (divMapPaperAirplaneMessage.style.display != 'block') {
        divMapPaperAirplaneMessage.style.display = 'block';
      }

    }
  }

}
