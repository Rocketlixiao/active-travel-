import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticleIntelComponent } from './article-intel.component';

describe('ArticleIntelComponent', () => {
  let component: ArticleIntelComponent;
  let fixture: ComponentFixture<ArticleIntelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticleIntelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticleIntelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
