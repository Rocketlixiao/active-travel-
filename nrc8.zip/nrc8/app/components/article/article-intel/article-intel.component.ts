import { Component, OnInit, SimpleChanges, Input } from '@angular/core';
import { Intelligence } from '../../../models/Intelligence';
//import '../../../libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-article-intel',
  templateUrl: './article-intel.component.html',
  styleUrls: ['./article-intel.component.css']
})
export class ArticleIntelComponent implements OnInit {

  @Input() data: Intelligence[];
  intelligence: Intelligence[];

  constructor() { }

  expandCollapseHistoryDetail(event) {
    globalConfig.expandCollapseHistoryDetail(event);
  }

  ngOnInit() {

  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed
    if (changes['data']) {
      if (this.data) {
        this.intelligence = this.data;
      }
    }
  }


}
