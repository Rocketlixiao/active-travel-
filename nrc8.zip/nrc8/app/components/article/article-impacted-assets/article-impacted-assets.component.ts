import { Component, OnInit, Inject, SimpleChanges, Input } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Article } from '../../../models/Article';
import { SharedService } from '../../../services/shared.service';
import { NrcService } from '../../../services/nrc.service';
import { SettingsService } from '../../../services/settings.service';

//import '../../../libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-article-impacted-assets',
  templateUrl: './article-impacted-assets.component.html',
  styleUrls: ['./article-impacted-assets.component.css']
})
export class ArticleImpactedAssetsComponent implements OnInit {

  @Input() data: Article;
  article = new Article();
  CDN = globalConfig.CDN.root;
  distanceUnit: string;
  maxLength: number;
  customDistence: number;

  constructor( @Inject(DOCUMENT) private document: any, private sharedService: SharedService, private nrcService: NrcService, private settingsService: SettingsService) { }

  //set custom proximities
  showCustomProximities() {
    var proximitySettings = this.document.getElementById('proximitySettings');
    if (proximitySettings.style.display != 'block') {
      proximitySettings.style.display = 'block';
    }
    else {
      proximitySettings.style.display = 'none';
    }
  };

  refreshImpactedAssets(type) {

    if (type == "default") {
      this.article.ImpactedAssetsItems = this.article.initImpactedAssetsItems;
    }
    else {
      var customProximities = this.document.getElementById("customProximities");
      var customProximitiesValue = customProximities.value;

      var reg = /^[1-9]\d*$/;
      if (customProximitiesValue == '' || !reg.test(customProximitiesValue) || customProximitiesValue * 1 < 1 || customProximitiesValue * 1 > this.maxLength) {
        this.document.getElementById('proximitySettingsError').innerText = 'Please input correct distance [1-' + this.maxLength + '].';
        this.document.getElementById('proximitySettingsError').style.display = 'block';
        this.document.getElementById('rdoDefault').checked = 'checked';
        return;
      }

      this.document.getElementById('proximitySettingsError').style.display = 'none';

      var that = this;
      this.sharedService.getCustomProximitiesForDetailPage(customProximitiesValue, function (incidentsProximities) {
        var thisIncident = (incidentsProximities || []).find(function (i) { return i.id === that.article.id });
        var impactedAssetsItems = [];
        if (thisIncident && thisIncident.n.length>0) {
          for(let item of thisIncident.n) {
            impactedAssetsItems.push({
              facilityid: item.id,
              distance: item.d.toFixed(2) + ' ' + that.settingsService.getSettingsData().DistanceUnit,
              ProximityStatus: globalConfig.filter_toLowerCase(item.s)
            });
          };
        }

        that.article.ImpactedAssetsItems = impactedAssetsItems;
        
        var lids = impactedAssetsItems.map(ass => ass.facilityid).join(',');
        
        if (lids) {
          that.nrcService.getAssets(lids).then(aData=>{
              if (aData) {
                for(let item of impactedAssetsItems) {
                  var foundItem = (aData.features || []).find(function (i) { return i.id === item.facilityid; });
                  if (foundItem) {
                    item.facilitytype = foundItem.attributes.facilitytype;
                    item.facilityname = foundItem.attributes.facilityname;
                    item.description = foundItem.attributes.description;
                    //Todo
                    //item.description = globalConfig.filter_linky(foundItem.attributes.description, '_blank');
                    item.description = foundItem.attributes.description;
                    if (item.description) {
                      item.description = item.description.replace(/&#10;/g, '<br/>').replace(/\r\n/g, "<br/>").replace(/\n/g, "<br/>");
                    }
                    item.street = foundItem.attributes.street;
                    item.city = foundItem.attributes.city;
                    item.stateprovince = foundItem.attributes.stateprovince;
                    item.postal = foundItem.attributes.zip;
                    item.country = foundItem.attributes.country;
                    item.latitude = foundItem.attributes.latitude;
                    item.longitude = foundItem.attributes.longitude;
                    item.contactemail = foundItem.attributes.contactemail;
                  }
                };

                that.article.ImpactedAssetsItems = impactedAssetsItems;
              }
            },
            function (error) {
              console.log('failed to get impacted assets by custom proximities.');
            }
          );
        }
      });
    }
  };

  ngOnInit() {
    var MAX_MILES = 50, MAX_KM = 80, MI = "mi", KM = "km";

    this.distanceUnit = this.settingsService.getSettingsData().DistanceUnit;
    this.maxLength = this.distanceUnit === MI ? MAX_MILES : MAX_KM;
    this.customDistence = 5;
  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed
    if (changes['data']) {
      if (this.data.detail) {
        this.article = this.data;
      }
    }
  }

}
