import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticleImpactedAssetsComponent } from './article-impacted-assets.component';

describe('ArticleImpactedAssetsComponent', () => {
  let component: ArticleImpactedAssetsComponent;
  let fixture: ComponentFixture<ArticleImpactedAssetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticleImpactedAssetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticleImpactedAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
