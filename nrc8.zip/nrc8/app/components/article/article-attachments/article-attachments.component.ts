import { Component, OnInit, Input, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-article-attachments',
  templateUrl: './article-attachments.component.html',
  styleUrls: ['./article-attachments.component.css']
})
export class ArticleAttachmentsComponent implements OnInit {
  @Input() data: any[];
  resources: any[];
  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed
    if (changes['data']) {
      if (this.data) {
        this.resources = this.data;       
      }
    }
  }


}
