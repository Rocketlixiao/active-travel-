import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-article-related',
  templateUrl: './article-related.component.html',
  styleUrls: ['./article-related.component.css']
})
export class ArticleRelatedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  showRelated() {
    console.log('show related');
  }

}
