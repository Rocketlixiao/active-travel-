import { Component, OnInit, Input, SimpleChanges, ViewChild } from '@angular/core';
import { Article } from '../../../models/Article';
import { MapService } from '../../../services/map.service';
import { ArticleMapComponent } from '../article-map/article-map.component';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Component({
  selector: 'app-article-detail',
  templateUrl: './article-detail.component.html',
  styleUrls: ['./article-detail.component.css']
})
export class ArticleDetailComponent implements OnInit {
  @ViewChild(ArticleMapComponent) articleMapComponent: ArticleMapComponent
  @Input() data: Article;
  article = new Article();
  mapReady = false;
  mapComponentReadyObservable = new BehaviorSubject<boolean>(false);
  castMapComponentReadyObservable = this.mapComponentReadyObservable.asObservable();

  constructor(private mapService: MapService) {
    this.mapService.load()
      .then(res => {
        this.mapReady = true;
      });
  }

  ngOnInit() {
    if (this.article.showMap) {
      this.detectArticleMapReady();
    }
  }

  detectArticleMapReady() {
    let mapInterval = null;
    mapInterval = setInterval(() => {
      if (this.mapReady && typeof (this.articleMapComponent.BuildArticleMap) != 'undefined') {
        this.emitMapComponentReady(true);
        window.clearInterval(mapInterval);
        mapInterval = null;
      }
    }, 200)
  }

  emitMapComponentReady(val) {
    this.mapComponentReadyObservable.next(val);
  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed
    if (changes['data']) {
      if (this.data.detail) {
        this.article = this.data;
      }
    }
  }

  callArticleBuildMap(article) {

    this.castMapComponentReadyObservable.subscribe(res => {
      if (res) {

        this.articleMapComponent.BuildArticleMap(article);

      }
    })
  }

}
