import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticleForwardComponent } from './article-forward.component';

describe('ArticleForwardComponent', () => {
  let component: ArticleForwardComponent;
  let fixture: ComponentFixture<ArticleForwardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticleForwardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticleForwardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
