import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticleItineraryComponent } from './article-itinerary.component';

describe('ArticleItineraryComponent', () => {
  let component: ArticleItineraryComponent;
  let fixture: ComponentFixture<ArticleItineraryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticleItineraryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticleItineraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
