import { Component, OnInit, Input, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-article-itinerary',
  templateUrl: './article-itinerary.component.html',
  styleUrls: ['./article-itinerary.component.css']
})
export class ArticleItineraryComponent implements OnInit {
  @Input() data: any[];
  itinerary: any[];
  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed
    if (changes['data']) {
      if (this.data) {
        this.itinerary = this.data;
      }
    }
  }

}
