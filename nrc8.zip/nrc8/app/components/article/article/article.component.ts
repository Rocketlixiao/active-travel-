import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, ParamMap, Params } from '@angular/router';
import { SharedService } from '../../../services/shared.service';
import { NrcService } from '../../../services/nrc.service';

import { AutorefreshService } from '../../../services/autorefresh.service';
import { Article } from '../../../models/Article';
import { Intelligence } from '../../../models/Intelligence';

import { ArticleDetailComponent } from '../article-detail/article-detail.component';


//import '../../../libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {
  @ViewChild(ArticleDetailComponent) articleDetailComponent: ArticleDetailComponent;

  tempArticle = new Article();
  article = new Article();
  forward: any = {};


  paramsIdentity: string;
  paramsDrawer: string;

  constructor(private sharedService: SharedService, private actRoute: ActivatedRoute, private nrcService: NrcService, private autorefreshService: AutorefreshService) { }

  ngOnInit() {

    this.sharedService.showOrHideMap();

    this.actRoute.params.subscribe((params: Params) => {
      if (params["identity"]) {
        this.paramsIdentity = params["identity"];

        this.nrcService.getIncident(this.paramsIdentity).then(data => {

          this.dataMapping(data);
          this.initArticle(this.tempArticle);

        });
      }

      if (params["drawer"]) {
        this.paramsDrawer = params["drawer"];
      }
    });
  }

  initArticle(art: Article) {
    if (!art.id) {
      return;
    }

    this.article = art;

    //Merge the updates when page is loaded.
    this.autorefreshService.MergeUpdates(false);

    this.article.initImpactedAssetsItems = [];

    this.article.template = "templates/" + globalConfig.filter_toLowerCase(this.article.type) + ".html";

    //forward, call get article data since it's ready
    this.mapForwardModel(this.article);

    var that = this;
    //ensure proximities are pre-filled
    setTimeout(() => {
      that.sharedService.getProximitiesForDetailPage(function () {

        var thisIncident = (globalConfig.allProximities.incidents || []).find(function (i) { return i.id === that.paramsIdentity });
        if (thisIncident) {
          for (let item of thisIncident.n) {
            that.article.ImpactedAssetsItems.push({
              facilityid: item.id,
              distance: item.d.toFixed(2) + ' ' + globalConfig.settingsData.DistanceUnit
            });
          }
          that.article.ImpactedAssets = that.article.ImpactedAssetsItems.length;
          that.article.ImpactedAssetsId = "";

          if (that.article.ImpactedAssets == 1) {
            that.article.ImpactedAssetsId = that.article.ImpactedAssetsItems[0].facilityid;
          }

          var lids = that.article.ImpactedAssetsItems.map(ass => ass.facilityid).join(',');

          if (lids) {
            that.nrcService.getAssets(lids).then(aData => {
              if (aData) {

                for (let item of that.article.ImpactedAssetsItems) {
                  var foundItem = (aData.features || []).find(function (i) { return i.id === item.facilityid; });
                  if (foundItem) {
                    item.facilitytype = foundItem.attributes.facilitytype;
                    item.facilityname = foundItem.attributes.facilityname;
                    item.description = foundItem.attributes.description;
                    //Todo
                    //item.description = globalConfig.filter_linky(foundItem.attributes.description, '_blank');
                    item.description = foundItem.attributes.description;
                    if (item.description) {
                      item.description = item.description.replace(/&#10;/g, '<br/>').replace(/\r\n/g, "<br/>").replace(/\n/g, "<br/>");
                    }
                    item.street = foundItem.attributes.street;
                    item.city = foundItem.attributes.city;
                    item.stateprovince = foundItem.attributes.stateprovince;
                    item.postal = foundItem.attributes.zip;
                    item.country = foundItem.attributes.country;
                    item.latitude = foundItem.attributes.latitude;
                    item.longitude = foundItem.attributes.longitude;
                    item.contactemail = foundItem.attributes.contactemail;
                    item.objtype = globalConfig.getLegacyProximitiesById(foundItem.attributes.facilityid);
                  }
                };

                that.article.initImpactedAssetsItems = that.article.ImpactedAssetsItems;

                //get all incidents and recalculate proximities statuses first
                //TODO, adjust this snippet to improve performance.
                that.sharedService.getIncidents(function () {
                  globalConfig.filterIncidentsFromAssetProximities(globalConfig.allIncidentItems);
                  for (let item of that.article.ImpactedAssetsItems) {
                    var assetProximity = globalConfig.allProximities.assets.find(function (i) { return i.id == item.facilityid; });
                    if (assetProximity) {

                      item.ProximityStatus = globalConfig.filter_toLowerCase(assetProximity.s);
                    }
                  };

                  //build asset thumbnail map
                  that.setupIncidentMapTimeInterval(that.article);

                  //add impacted assets to forwarded article
                  that.updateForwardModel(that.article);
                });
              }
            },
              function (error) {
                console.log('failed to get impacted assets');
              }
            );
          }
          else {
            //build asset thumbnail map
            that.setupIncidentMapTimeInterval(that.article);
          }
        }
        else {
          //build asset thumbnail map
          that.setupIncidentMapTimeInterval(that.article);
        }



        //scroll page down to content drawer
        var scrollDrawableTimeout = window.setTimeout(function () {

          if (globalConfig.filter_toLowerCase(that.paramsDrawer) === 'assets') {
            that.article.showImpactedAssets = true;
            globalConfig.scrollPage();
          }
          else if (globalConfig.filter_toLowerCase(that.paramsDrawer) === 'attachments') {
            that.article.showAttachments = true;
            globalConfig.scrollPage();
          }
          else if (globalConfig.filter_toLowerCase(that.paramsDrawer) === 'updates') {
            that.article.showIncidentsHistory = true;
            globalConfig.scrollPage();
          }

        }, 500);
      });

    }, 0);
  }

  dataMapping(data) {
    var data = data.incident;
    this.tempArticle.id = data.Current.incidents;
    this.tempArticle.sourceURI = 'javascript:void(0)';
    this.tempArticle.type = "Analysis";
    this.tempArticle.risk = globalConfig.filter_toLowerCase(data.Current.info_severity);
    this.tempArticle.source = data.Current.source;
    this.tempArticle.event = data.Current.info_event;

    if (data.Current.source === "NIMC") {      
      this.tempArticle.type = "Intelligence";
      this.tempArticle.name = data.Current.info_eventCode_NC4_NIMC + ' > ' + data.Current.info_event;
      this.tempArticle.subcategory = data.Current.info_event;
    }
    else if (data.Current.source === "Cybertech India") {      
      this.tempArticle.type = "Intelligence";
      this.tempArticle.name = data.Current.info_eventCode_NC4_CyberTechIndia + ' > ' + data.Current.info_event;
      this.tempArticle.subcategory = data.Current.info_event;
    }
    else {      
      
      if (data.Current.parameter_TSCategory != null && typeof (data.Current.parameter_TSCategory) != 'undefined' && data.Current.parameter_TSCategory.length > 0) {
        this.tempArticle.subcategory = data.Current.parameter_TSCategory.split('>')[0].replace('/', ' /');
      }

      if (data.Current.source === 'SEB' ||
        data.Current.source === 'SR' ||
        data.Current.source === 'AB' ||
        data.Current.source === 'GFP') {
        this.tempArticle.name = (data.Current.parameter_TSCategory ? data.Current.parameter_TSCategory.replace(new RegExp(">", "gm"), ", ") : "");

        if (data.Current.resources.length > 0) {
          for (var i = 0; i < data.Current.resources.length; i++) {
            var p = data.Current.resources[i];
            {
              if (p.uri != null && typeof (p.uri) != 'undefined' && p.uri != '' && p.mimeType != null && typeof (p.mimeType) != 'undefined' && p.mimeType == 'application/pdf') {
                this.tempArticle.sourceURI = p.uri;
                break;
              }
            }
          }
        }
      }

      if (data.Current.source === 'CR' || data.Current.source === 'CRR') {

        this.tempArticle.subcategory = data.Current.info_event;
        this.tempArticle.name = data.Current.info_event;
      }
    }

    this.tempArticle.category = globalConfig.getIncidentCategory(data.Current);
    //this.tempArticle.date = globalConfig.formatTimeago(new Date(data.Current.sent));
    this.tempArticle.date = new Date(data.Current.sent);
    this.tempArticle.clientDate = globalConfig.getClientDate(data.Current.sent);
    this.tempArticle.headline = data.Current.info_headline;
    //Todd
    //this.tempArticle.description = globalConfig.filter_linky(data.Current.info_description, '_blank');
    this.tempArticle.description = data.Current.info_description;
    if (this.tempArticle.description) {
      this.tempArticle.description = this.tempArticle.description.replace(/&#10;/g, '<br/>').replace(/\r\n/g, "<br/>").replace(/\n/g, "<br/>");
    }
    this.tempArticle.isRealTime = (data.Current.source === "NIMC") || (data.Current.source === "Cybertech India");

    if ((data.Current.source === 'CR')
      || (data.Current.source === 'CRR')) {
      this.tempArticle.showMap = false;
    }
    else {
      this.tempArticle.showMap = true;
    }

    var location = null;
    if (data.Current.locations && data.Current.locations.length > 0) {
      location = data.Current.locations[data.Current.locations.length - 1];
      this.tempArticle.longitude = location.longitude;
      this.tempArticle.latitude = location.latitude;
    }

    var resources = [];
    if (data.Current.resources.length > 0) {
      for (var i = 0; i < data.Current.resources.length; i++) {
        resources.push(data.Current.resources[i]);
      }
    }

    if (data.Previdous.length > 0) {
      let intelligence = [];
      for (let item of data.Previdous) {

        var newItem = new Intelligence();
        newItem.risk = globalConfig.filter_toLowerCase(item.info_severity);
        //newItem.date = globalConfig.formatTimeago(item.sent);
        newItem.date = new Date(item.sent);
        newItem.clientDate = globalConfig.getClientDate(item.sent);
        newItem.text = item.info_headline;
        newItem.identifier = item.identifier;
        newItem.severity = item.info_severity;
        newItem.headline = item.info_headline;
        //Todd
        //newItem.description = globalConfig.filter_linky(item.info_description, '_blank');
        newItem.description = item.info_description;
        newItem.event = item.info_event;
        
        if (item.source === "NIMC") {
          newItem.name = item.info_eventCode_NC4_NIMC + ' > ' + item.info_event;          
        }
        else if (item.source === "Cybertech India") {
          newItem.name = item.info_eventCode_NC4_CyberTechIndia + ' > ' + item.info_event;        
        }
        else if ((item.source === 'SEB') ||
          (item.source === 'SR') ||
          (item.source === 'AB') ||
          (item.source === 'GFP')) {
          newItem.name = (item.parameter_TSCategory ? item.parameter_TSCategory.replace(new RegExp(">", "gm"), ", ") : "");          
        }
        else {
          newItem.name = item.info_event;         
        }

        newItem.category = globalConfig.getIncidentCategory(item);

        let temLocation = null;
        if (item.locations && item.locations.length > 0) {
          temLocation = item.locations[item.locations.length - 1];
        }

        if ((item.source === 'CR') || (item.source === 'CRR')) {
          newItem.address = temLocation ? temLocation.country : "";
        }
        else {
          if (temLocation && temLocation.country === 'United States') {
            newItem.address = (temLocation ? temLocation.city : "") + ', ' + (temLocation ? temLocation.state : "");
          }
          else {
            newItem.address = (temLocation ? temLocation.city : "") + ', ' + (temLocation ? temLocation.country : "");
          }
        }
        newItem.address = globalConfig.trimRight(newItem.address);
        var reg = /,$/gi;
        newItem.address = globalConfig.trimRight(newItem.address.replace(reg, ""));
        newItem.address = newItem.address.replace(reg, "");

        var location = item.locations.length > 0 ? item.locations[0] : null;
        var city = location ? (location.city ? location.city + ", " : "") + location.state + ", " + location.postal : "";
        city = globalConfig.trimRight(city);
        city = globalConfig.trimRight(city.replace(reg, ""));
        city = city.replace(reg, "");

        newItem.detail = {
          "Severity": item.info_severity,
          "Location": location ? location.street : "",
          "City": city,
          "Country": location ? location.country : "",
          "Occurred": globalConfig.getClientDate(item.sent),
          "Last_Update": newItem.clientDate
        };

        if (item.resources.length > 0) {
          for (var j = 0; j < item.resources.length; j++) {
            resources.push(item.resources[j]);
          }
        }

        intelligence.push(newItem);
      };
      this.tempArticle.intelligence = intelligence;
    }
    //if source is CR/CRR, make resources is null because the link of attachment is invalid.   
    this.tempArticle.resources = ((data.Current.source === "CR") || (data.Current.source === "CRR")) ? [] : resources.filter(function (r) { return !!r.uri; });
    var city = location ? (location.city ? location.city + ", " : "") + location.state + ", " + location.postal : "";
    city = globalConfig.trimRight(city);
    var reg = /,$/gi;
    city = globalConfig.trimRight(city.replace(reg, ""));
    city = city.replace(reg, "");
    this.tempArticle.detail = {
      "Severity": data.Current.info_severity,
      "Location": location ? location.street : "",
      "City": city,
      "Country": location ? location.country : "",
      "Occurred": data.Previdous.length > 0 ? globalConfig.getClientDate(data.Previdous[data.Previdous.length - 1].sent) : globalConfig.getClientDate(data.Current.sent),
      "Last_Update": this.tempArticle.clientDate
    };

    if ((data.Current.source === 'CR') || (data.Current.source === 'CRR')) {
      this.tempArticle.address = this.tempArticle.detail.Country;
    }
    else {
      if ((this.tempArticle.detail.Country === 'United States')) {
        this.tempArticle.address = (location ? (location.city ? location.city + ", " : "") : "") + (location ? location.state : "");
      }
      else {
        this.tempArticle.address = (location ? (location.city ? location.city + ", " : "") : "") + (location ? location.country : "");
      }
    }

    this.tempArticle.address = globalConfig.trimRight(this.tempArticle.address);
    this.tempArticle.address = globalConfig.trimRight(this.tempArticle.address.replace(reg, ""));
    this.tempArticle.address = this.tempArticle.address.replace(reg, "");

    //#region waiting for another call
    this.tempArticle.ImpactedAssetsItems = [];
    this.tempArticle.ImpactedAssets = this.tempArticle.ImpactedAssetsItems.length;
    this.tempArticle.ImpactedAssetsId = "";
    //#endregion

    //show/hide bottom tabs
    this.tempArticle.showIncidentsHistory = false;
    this.tempArticle.showImpactedAssets = false;
    this.tempArticle.showAttachments = false;

    //itinerary
    this.tempArticle.itinerary = [];
  }

  openForwardNotification(selector) {
    globalConfig.showModal(selector);
  };

  collapseHistoryDetail() {
    globalConfig.collapseHistory('.intel-wrap .intel-item', 'expanded');
  }

  showBottomTabs(tabName) {
    if (tabName == 'updates') {
      this.article.showImpactedAssets = false;
      this.article.showAttachments = false;
      this.article.showIncidentsHistory = !this.article.showIncidentsHistory;
      this.collapseHistoryDetail();
    }
    else if (tabName == 'assets') {
      this.article.showIncidentsHistory = false;
      this.article.showAttachments = false;
      this.article.showImpactedAssets = !this.article.showImpactedAssets;
    }
    else if (tabName == 'attachments') {
      this.article.showIncidentsHistory = false;
      this.article.showImpactedAssets = false;
      this.article.showAttachments = !this.article.showAttachments;
    }

    globalConfig.scrollPage();
  };

  //forward, get article data
  mapForwardModel(article) {
    this.forward = {
      Category: article.category,
      Type: article.event,
      Severity: article.detail.Severity,
      City: article.detail.City,
      Country: article.detail.Country,
      AreaDescription: article.detail.Location,
      Headline: article.headline,
      Description: article.description,
      Source: article.source,
      Occurred: article.detail.Occurred,
      LastUpdated: article.detail.Last_Update,
      Assets: [],
      Links: [],
      ImpactedAssets: []
    };

    //$scope.forward.Links
    for (let item of article.resources) {
      this.forward.Links.push({
        Address: item.uri,
        Text: item.resourceDesc
      });
    };

    //$scope.forward.Me, get current user email address
    this.nrcService.getUserInfo().then(data => {

      this.forward.Me = data && data[0] && data[0].emailaddress && data[0].emailaddress.split(/[,;]/)[0] || null;
    });
  }

  setupIncidentMapTimeInterval(article) {
    if (article.showMap) {
      this.articleDetailComponent.callArticleBuildMap(article);

    }
  }

  //forward, get impacted assets when ready
  updateForwardModel(article) {
    var thisLocation = /(?:http|https):\/\/[^/]+/.exec(window.location.href),
      path = (thisLocation ? thisLocation[0] : '') + '/nrc8/#/assets/';

    for (let item of article.ImpactedAssetsItems) {
      //get contacts list
      if (item.contactemail) {
        this.forward.Assets.push({
          isChecked: false,
          facilityname: item.facilityname,
          contacts: item.contactemail.split(/[,;]/).filter(function (c) { return !!c; })
        });
      }

      //get impacted assets detail
      this.forward.ImpactedAssets.push({
        ProximityStatus: globalConfig.filter_toLowerCase(item.ProximityStatus),
        StatusKey: globalConfig.severityFactory.getKeyByValue(item.ProximityStatus),
        Url: path + item.facilityid,
        Title: item.facilitytype + ' | ' + item.facilityname,
        Address: item.street + '; ' + item.city + ' ' + item.stateprovince + ' ' + item.postal + '; ' + item.country,
        Description: item.description,
        Distance: item.distance
      });
      this.forward.ImpactedAssets.sort(function (a, b) { return b.StatusKey - a.StatusKey; });
    };
  };



}
