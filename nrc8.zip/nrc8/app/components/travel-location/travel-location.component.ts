import { Component, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { GridComponent, GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { ActivatedRoute, ParamMap } from "@angular/router";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/observable/of';
import { DialogModule, WindowState } from '@progress/kendo-angular-dialog';

import { ActivTravelService, ColumnSetting } from '../../services/activ-travel.service';
import { TravelLocationService } from '../../services/travel-location.service';
import { ReportEmailService } from "../../services/report-email.service";
import { NrcService } from "../../services/nrc.service";
import { ToastrService } from "../../services/toastr.service";
import { TravelLocation } from '../../models/TravelLocation';
import { SharedService } from '../../services/shared.service';
import { ReportFilterService } from "../../services/report-filter.service";
import { ReportInputParametersComponent } from "../report-common/report-input-parameters/report-input-parameters.component";
import {
  ReportHeader,
  SavedReport,
  ReportFilterContext,
  ReportEmailContext,
  ReportEditColumnsContext,
  ReportSaveReportContext,
  ReportMySavedReportContext
} from "../../models/ReportHeader";
import { setTimeout } from 'timers';
declare var globalConfig: any;
declare var reportConfig: any;
@Component({
  selector: 'app-travel-location',
  templateUrl: './travel-location.component.html',
  styleUrls: ['./travel-location.component.css']
})
export class TravelLocationComponent implements OnInit, OnDestroy, ReportHeader {
  showLoading: boolean = false;
  private rawData: any;
  private lastReportsCount: number = 0;

  CDN = globalConfig.CDN.root;
  warning: any = {
    showed: false,
    title: 'Warning',
    message: (reportConfig.TravelLocationMaxRows || 500) + ' rows of data delivered, the remaining rows were truncated. Please refine your search to reduce the result set, or Download Report to receive the complete result set.'
  };
  //header init 
  PiiInfo: { showPii: boolean } = { showPii: false };
  description: string;
  filterContent: ReportFilterContext = {
    hasTimeRange: true,
    dateTitle: 'Travel Dates',

    hasRegion: true,
    selectedRegions: [],
    hasCity: true,
    selectedCities: [],
    hasCountry: true,
    selectedCountries: [],
    hasRiskRating: true,
    selectedRiskRatings: [],
    hasAirport: true,
    selectedAirports: [],
    hasSegmentType: true,
    selectedSegmentTypes: [],
    selectedOrganizations: []
  };
  emailContent: ReportEmailContext = {
    outFields: ['TO', 'BCC', 'CC'],
    selectedOutField: 'TO',
    fileFormats: ['EXCEL', 'HTML', 'PDF']
  };
  editColumnsContent: ReportEditColumnsContext = {
    columns: []
  };
  saveReportContent: ReportSaveReportContext = new ReportSaveReportContext();
  mySavedReportsContent: ReportMySavedReportContext = {
    daysOfWeek: ['Moday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    daysOfMonth: [],
    reportFormats: ['EXCEL', 'HTML', 'PDF'],
    recurrenceTypes: ['daily', 'weekly', 'monthly'],
    reports: []
  };

  //grid init
  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  public total = 0;
  private data: Object[];

  //device is in mobile or desktop
  public isMobile = false;

  //kendo grid and dropdown
  @ViewChild(GridComponent) grid: GridComponent;
  @ViewChild('appFeatures') appFeatures: any;
  @ViewChild('inputParametersPopup') inputParametersPopup: ReportInputParametersComponent;
  public source: Array<{ text: string, value: number }> = [];
  public selectedValue: { text: string, value: number } = { text: "", value: null };
  public defaultItem: { text: string, value: number } = { text: "1", value: 1 };

  //button and page config 
  public buttonCount = 5;
  public info = true;
  public type: 'numeric' | 'input' = 'numeric';
  public pageSizes = true;
  public previousNext = true;
  //add remove column 
  public isShowDesktopExpandColumn = true;//show desktop expand column flag 
  public isShowMobileExpandColumn = true;//show mobile expand column flag 
  public columns: ColumnSetting[] = [];//desktop columns 
  public columnsOptional: ColumnSetting[] = [];//desktop optional columns 
  public mobileColumns: ColumnSetting[] = [];//mobile columns 
  public mobileColumnsOptional: ColumnSetting[] = [];//mobile optional 
  public configColumn: string[] = ['region', 'country', 'city', 'locationName', 'id',
    'name', 'email', 'segmentType', 'segmentTime', 'segmentDesignator'];  // value from mysaved report 

  //sort
  public sort: SortDescriptor[] = [];

  //diaolog windows open 
  public pnrid;// link to itenary detial page 
  public windowOpened = false;

  public windowState: WindowState;
  //array data bind to grid 
  travelLocation: TravelLocation[];

  constructor(
    private sharedService: SharedService,
    private travelLocationService: TravelLocationService,
    public activTravelService: ActivTravelService,
    private nrcService: NrcService,
    private toastrService: ToastrService,
    private reportFilterService: ReportFilterService,
    private activatedRoute: ActivatedRoute,
    private reportEmailService: ReportEmailService) {

    for (let i = 1; i < 32; i++) {
      this.mySavedReportsContent.daysOfMonth.push(i);
    }
    this.activatedRoute.paramMap.switchMap((params: ParamMap) => {
      return Observable.of(params.get('reportId'));
    }).subscribe(id => {
      if (this.gridView && id) {
        this.initFilterContent(this.mySavedReportsContent.reports.find(r => r.ReportID == id));
        this.loadData();
      }
    });
    this.windowState = "maximized";
  }

  ngOnInit(): void {
    this.sharedService.showOrHideMap();
    this.isMobile = this.activTravelService.isMobile();
    this.loadMySavedReports(() => {
      let reportId = this.activatedRoute.snapshot.paramMap.get('reportId');
      if (reportId || this.reportFilterService.containsFilters(this.filterContent)) this.loadData();
      else this.appFeatures.toggleFilter();
      this.filterContent.hasOrganization = !!globalConfig.isNc4AdminOrOrgAdmin;
    });
  }
  ngOnDestroy(): void {
    this.appFeatures.closePoup();
    globalConfig.travelLocationFilterContent = this.filterContent;
  }

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.skip = skip;
    this.pageSize = take;
    this.applyFilter();
  }

  public loadItems(): void {

    this.applyFilter();
  }

  public applyFilter() {
    let allData = this.travelLocation;
    let sort = this.sort;
    this.total = allData.length;

    this.gridView = {
      data: orderBy(allData, sort).slice(this.skip, this.skip + this.pageSize),
      //data:  allData.slice(this.skip, this.skip + this.pageSize),
      total: this.total
    };
    this.binddropdown();
    this.description = "(Displaying " + (this.skip + 1) + "-" + ((this.skip + this.pageSize) > this.total ? this.total : (this.skip + this.pageSize)) + " of " + (this.total) + " total records)";

    this.showLoading = false;
  }

  onFilterSubmited() {
    this.appFeatures.closePoup(true);
    this.loadData(true);
  }

  onEmailSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.sendReportEmail(path, this.emailContent, this.filterContent, [])
          .then(data => {
            this.toastrService.success("Report successfully emailed");
          });
      }
    });
  }

  onDownLoadReportSubmited(format: string) {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        let tmpColumns = [];
        this.editColumnsContent.columns.forEach(c => {
          if (c.isChecked) tmpColumns.push(c.name);
        });
        this.reportEmailService.downloadReport(this.rawData, format, path, tmpColumns);
      }
    });
  }

  onSendEmailSubmited(data: SavedReport) {
    this.PiiInfo.showPii = true;
    this.reportEmailService.sendEmailWithReport(data)
      .then(data => {
        this.toastrService.success("Email sent successfully");
      });
  }

  //apply add remove column 
  onEditColumnsSubmited() {
    //set mobile and deskopt column and optional column 
    this.applyConfigEditColumn();
  }

  private applyConfigEditColumn() {
    this.columns = [];
    this.mobileColumns = [];
    this.mobileColumnsOptional = [];
    this.sort = [];
    //count total checked column;
    var count = 0;

    var columnContent = this.editColumnsContent.columns;

    for (var i = 0; i < columnContent.length; i++) {
      let tempKey = columnContent[i].name;
      let tempTitle = columnContent[i].title;
      let ifCheck = columnContent[i].isChecked;
      var tempType = this.travelLocationService.fullColumns.find(x => x.field == columnContent[i].name).type;

      if (ifCheck) {
        count = count + 1;
        //add the desktop column

        this.columns.push({ field: tempKey, title: tempTitle, index: i, type: tempType });

        //add the mobile column and the max number is 2 and the other is optional
        //add the sort by default 2 columns
        if (count <= 2) {
          //add the sort 
          this.sort.push({ field: tempKey, dir: 'asc' });
          this.mobileColumns.push({ field: tempKey, title: tempTitle, index: i, type: tempType });
        } else {
          this.mobileColumnsOptional.push({ field: tempKey, title: tempTitle, index: i, type: tempType });
        }
      }
    }

    //set show expand column  flag 
    if (this.mobileColumns.length + this.mobileColumnsOptional.length <= 2) {
      this.isShowMobileExpandColumn = false;
    } else { this.isShowMobileExpandColumn = true; }

    this.applyFilter();

  }

  onSaveReportSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportFilterService.upsetSavedReport(path, this.saveReportContent, this.editColumnsContent.columns, this.mySavedReportsContent);
        this.onMySavedReportsSubmited(() => {
          if (!this.activatedRoute.snapshot.paramMap.get('reportId'))
            this.reportFilterService.resetSaveReport(this.saveReportContent);
        });
      }
    });
  }

  onMySavedReportsSubmited(success?: () => void) {
    this.PiiInfo.showPii = true;
    this.nrcService.updateMySavedReports(this.mySavedReportsContent.reports)
      .then(data => {
        let isDeleting = this.lastReportsCount > this.mySavedReportsContent.reports.length;
        this.lastReportsCount = this.mySavedReportsContent.reports.length;
        this.toastrService.success(isDeleting ? "Deleted report successfully" : "Reports saved successfully");
        if (typeof success === 'function') success();
      });
  }

  public binddropdown() {
    this.source = this.source.filter(item => item == { text: "", value: null });
    let totalPages = Math.floor(((this.total - 1) / this.pageSize) + 1);
    for (var i = 1; i <= totalPages; i++) {
      let drp = { text: String(i), value: i };
      this.source.push(drp);
    }

    if (totalPages > 0) {

      this.selectedValue = { text: "1", value: 1 };
    } else {
      this.selectedValue = { text: "", value: null };
    }
  }

  public valueChange(pageIndex: any): void {
    this.skip = (pageIndex.value - 1) * this.pageSize;
    this.applyFilter();
    this.selectedValue = { text: pageIndex.value, value: pageIndex.value };
  }

  private showExpandIcon(dataitem: any) {
    let icon = "+"
    let rowIndex = dataitem.index;
    let expandCollpase = this.travelLocation.filter(
      x => x.index == rowIndex)[0];
    if (expandCollpase.isexpand) {
      icon = "-"
    } else {
      icon = "+"
    }
    return icon;
  }

  public ShowHideSubContent(dataitem: any, rowIndex: any) {

    let expandCollpaseFilterFlagIndexs = this.travelLocation.filter(
      x => x.id == dataitem.id)[0];

    let tableIndex = expandCollpaseFilterFlagIndexs.index;

    if (!this.travelLocation[tableIndex].isexpand) {

      this.grid.expandRow(rowIndex);

      this.travelLocation[tableIndex].isexpand = true;

    } else {

      this.grid.collapseRow(rowIndex);
      this.travelLocation[tableIndex].isexpand = false;
    }
  }

  private loadData(isFilter?: boolean) {
    this.showLoading = true;
    this.travelLocationService.getTravelLocation(this.filterContent)
      .then(data => {
        if (data) {
          this.rawData = data;
          if (isFilter) this.toastrService.success('Filters successfully applied');
          if (data.Result && data.Result.length >= reportConfig.TravelLocationMaxRows) this.warning.showed = true;
          this.skip = 0;
          this.travelLocation = this.travelLocationService.mappingData(data);
          this.mapEditColumnsContext(this.travelLocation);
          this.mapSaveReportContext(this.travelLocation);
          this.applyConfigEditColumn();
          this.loadItems();
        }
      });
  }

  private mapEditColumnsContext(data: TravelLocation[]) {
    if (this.editColumnsContent.columns.length) return;

    var configColumn = this.configColumn;
    var fullColumns = this.travelLocationService.fullColumns;
    this.editColumnsContent.columns = [];

    for (var i = 0; i < configColumn.length; i++) {
      var tempCol = fullColumns.find(x => x.field == configColumn[i]);
      this.editColumnsContent.columns.push({
        title: tempCol.title,
        name: tempCol.field,
        isChecked: true
      });
    }
    for (var i = 0; i < fullColumns.length; i++) {
      var title = fullColumns[i].title;
      var name = fullColumns[i].field;

      if (!configColumn.find(x => x == name)) {
        this.editColumnsContent.columns.push({
          title: title,
          name: name,
          isChecked: false
        });
      }
    }



  }

  private mapSaveReportContext(data: TravelLocation[]) {
    if (data && data.length) {
      this.saveReportContent.filter = this.filterContent;
    }
  }

  private loadMySavedReports(loadData: () => any) {
    this.nrcService.getMySavedReports()
      .then(data => {
        if (data) {
          this.mySavedReportsContent.reports = data.Result.docTypeAttributes.UserProfile.userTravelSettings.savedReports;
          this.lastReportsCount = this.mySavedReportsContent.reports.length;
        }

        let reportId = this.activatedRoute.snapshot.paramMap.get('reportId');
        this.initFilterContent(this.mySavedReportsContent.reports.find(r => r.ReportID == reportId));
        loadData();
      })
      .catch(err => { this.initFilterContent(null); });
  }

  private initFilterContent(report: SavedReport) {
    if (report) {
      this.reportFilterService.mapFilterContent(report, this.filterContent);
      this.saveReportContent = {
        reportId: report.ReportID,
        reportName: report.ReportName,
        currentReportName: report.ReportName,
        filter: this.filterContent
      };
      if (report.ViewFields && report.ViewFields.length) {
        this.configColumn = [];
        report.ViewFields.forEach(f => {
          if (this.configColumn.indexOf(f) == -1) this.configColumn.push(f);
        });
      }
    }
    else if (globalConfig.travelLocationFilterContent) {
      this.filterContent = globalConfig.travelLocationFilterContent;
    }

    let reports = this.mySavedReportsContent.reports || [];
    this.saveReportContent.allExistingReports = reports.map(r => r.ReportName);
  }

  //client sorting function dataitme sorder name , order :asc or desc
  //private onSort(dataItem: any, order: any) {
  private onSort(event: any) {
    let dataItem = event.columns;
    let order = event.order;

    this.sort = [];
    this.sort.push({ field: dataItem.field, dir: order });

    this.travelLocation = orderBy(this.travelLocation, this.sort);
    //rearrange index order  
    for (var i = 0; i < this.travelLocation.length; i++) {
      this.travelLocation[i].index = i;
      this.travelLocation[i].isexpand = false;
      this.grid.collapseRow(i);
    }
    this.applyFilter();
  }

  //dialog windows open and close
  public GridDetialClickHanlder(dataItem: any, rowIndex: any) {

    this.pnrid = dataItem.id;
    this.windowOpened = true;

  }

  public close(component) {
    this.windowOpened = false;

  }

}
