import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PassengersOnFlight } from './passengers-on-flight.component';

describe('PassengersOnFlight', () => {
    let component: PassengersOnFlight;
    let fixture: ComponentFixture<PassengersOnFlight>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
        declarations: [PassengersOnFlight ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
      fixture = TestBed.createComponent(PassengersOnFlight);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
