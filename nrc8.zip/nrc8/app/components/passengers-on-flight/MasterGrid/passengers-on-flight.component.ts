import { Component, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { GridComponent, GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { ActivatedRoute, ParamMap } from "@angular/router";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/observable/of';

import { SharedService } from '../../../services/shared.service';
import { ActivTravelService, ColumnSetting } from '../../../services/activ-travel.service';
import { PassengersOnFlightService } from '../../../services/passengers-on-flight.service';
import { ReportEmailService } from "../../../services/report-email.service";
import { NrcService } from "../../../services/nrc.service";
import { ToastrService } from '../../../services/toastr.service';
import { ReportFilterService } from "../../../services/report-filter.service";
import { PassengerOnFlight } from '../../../models/PassengerOnFlight';
import { ReportInputParametersComponent } from "../../report-common/report-input-parameters/report-input-parameters.component";
import {
  ReportHeader,
  SavedReport,
  ReportFilterContext,
  ReportEmailContext,
  ReportEditColumnsContext,
  ReportSaveReportContext,
  ReportMySavedReportContext,
  EmailTravellerContext
} from "../../../models/ReportHeader";
import { FeaturesComponent } from '../../report-header/features/features.component';

declare var globalConfig: any;
declare var reportConfig: any;

@Component({
  selector: 'app-passengers-on-flight',
  templateUrl: './passengers-on-flight.component.html',
  styleUrls: ['./passengers-on-flight.component.css']
})
export class PassengersOnFlight implements OnInit, OnDestroy, ReportHeader {
  showLoading: boolean = false;
  private rawData: any;
  private lastReportsCount: number = 0;

  CDN = globalConfig.CDN.root;
  //header init 
  PiiInfo: { showPii: boolean } = { showPii: false };
  description: string;
  filterContent: ReportFilterContext = {
    hasTimeRange: true,
    dateTitle: 'Departure Date',
    dateRange: reportConfig && reportConfig.PassengersOnFlightMaxDays || 0,

    selectedOrganizations: [],
    hasMinPassenger: true
  };
  emailContent: ReportEmailContext = {
    outFields: ['TO', 'CC', 'BCC'],
    selectedOutField: 'TO',
    fileFormats: ['EXCEL', 'HTML', 'PDF']
  };
  editColumnsContent: ReportEditColumnsContext = {
    columns: []
  };
  saveReportContent: ReportSaveReportContext = new ReportSaveReportContext();
  mySavedReportsContent: ReportMySavedReportContext = {
    daysOfWeek: ['Moday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    daysOfMonth: [],
    reportFormats: ['EXCEL', 'HTML', 'PDF'],
    recurrenceTypes: ['daily', 'weekly', 'monthly'],
    reports: []
  };
  emailTravellerContent: EmailTravellerContext = {
    outFields: ['TO', 'BCC', 'CC'],
    selectedOutField: 'TO',
    recipients: []
  };

  //grid init 
  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  public total = 0;
  private data: Object[];

  //is on mobile device
  public isMobile = false;

  //kendo grid and dropdown
  @ViewChild('appFeatures') appFeatures: FeaturesComponent;
  @ViewChild(GridComponent) grid: GridComponent;
  @ViewChild('inputParametersPopup') inputParametersPopup: ReportInputParametersComponent;
  public source: Array<{ text: string, value: number }> = [];
  public selectedValue: { text: string, value: number } = { text: "", value: null };
  public defaultItem: { text: string, value: number } = { text: "1", value: 1 };

  //button and page config 
  public buttonCount = 5;
  public info = true;
  public type: 'numeric' | 'input' = 'numeric';
  public pageSizes = true;
  public previousNext = true;

  //add remove column 
  //add remove column 
  public isShowMobileExpandColumn = true;//show mobile expand column flag 
  public columns: ColumnSetting[] = [];//desktop columns 
  public mobileColumns: ColumnSetting[] = [];//mobile columns 
  public mobileColumnsOptional: ColumnSetting[] = [];//mobile optional 
  public configColumn: string[] = ['airline', 'flightNumber',
    'departureAirport', 'departureTime', 'arrivalAirport', 'arrivalTime', 'passengersCount'];

  //sort
  public sort: SortDescriptor[] = [];

  //diaolog windows open 
  public detailGridData;// link to detial grid page 
  public windowOpened = false;


  passengersOnFligh: PassengerOnFlight[];
  errorMessage: String;

  constructor(private sharedService: SharedService,
    private passengersOnFlightService: PassengersOnFlightService,
    public activTravelService: ActivTravelService,
    private nrcService: NrcService,
    private toastrService: ToastrService,
    private reportFilterService: ReportFilterService,
    private activatedRoute: ActivatedRoute,
    private reportEmailService: ReportEmailService) {
    for (let i = 1; i < 32; i++) {
      this.mySavedReportsContent.daysOfMonth.push(i);
    }
    this.activatedRoute.paramMap.switchMap((params: ParamMap) => {
      return Observable.of(params.get('reportId'));
    }).subscribe(id => {
      if (this.gridView && id) {
        this.initFilterContent(this.mySavedReportsContent.reports.find(r => r.ReportID == id));
        this.loadData();
      }
    });
  }

  ngOnInit(): void {
    this.sharedService.showOrHideMap();
    this.isMobile = this.activTravelService.isMobile();

    this.loadMySavedReports(() => {
      let reportId = this.activatedRoute.snapshot.paramMap.get('reportId');
      if (reportId || this.reportFilterService.containsFilters(this.filterContent)) this.loadData();
      else this.appFeatures.toggleFilter();
      this.filterContent.hasOrganization = !!globalConfig.isNc4AdminOrOrgAdmin;
    });
  }

  ngOnDestroy(): void {
    this.appFeatures.closePoup();
    globalConfig.passengersOnFlightFilterContent = this.filterContent;
  }

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.skip = skip;
    this.pageSize = take;
    this.applyFilter();
  }

  public loadItems(): void {
    this.applyFilter();
  }

  public applyFilter() {
    let allData = this.passengersOnFligh;
    let sort = this.sort;
    this.total = allData.length;

    this.gridView = {
      //data: allData.slice(this.skip, this.skip + this.pageSize),
      data: orderBy(allData, sort).slice(this.skip, this.skip + this.pageSize),
      total: this.total
    };
    this.binddropdown();

    this.description = this.activTravelService.getHeaderPagerDescription(this.skip, this.pageSize, this.total);

    this.showLoading = false;
  }


  public DetialGridClickHanlder(dataItem: any, rowIndex: any) {
    //console.log(dataItem);
    //console.log(rowIndex);

    let expandCollpaseFilterFlagIndexs = this.passengersOnFligh.filter(
      x => x.flightNumber == dataItem.flightNumber)[0];
    let tableIndex = expandCollpaseFilterFlagIndexs.index;

    if (!expandCollpaseFilterFlagIndexs.isdrilldown) {
      this.grid.expandRow(rowIndex);

      this.passengersOnFligh[tableIndex].isdrilldown = true;

    } else {
      if (!this.passengersOnFligh[tableIndex].isexpand) {
        this.grid.collapseRow(rowIndex);
      }

      this.passengersOnFligh[tableIndex].isdrilldown = false;
    }

  }

  onFilterSubmited() {
    this.appFeatures.closePoup(true);
    this.loadData(true);
  }

  onEmailSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.sendReportEmail(path, this.emailContent, this.filterContent, [])
          .then(data => {
            this.toastrService.success("Report successfully emailed");
          });
      }
    });
  }

  onDownLoadReportSubmited(format: string) {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        let tmpColumns = [];
        this.editColumnsContent.columns.forEach(c => {
          if (c.isChecked) tmpColumns.push(c.name);
        });
        this.reportEmailService.downloadReport(this.rawData, format, path, tmpColumns);
      }
    });
  }

  onSendEmailSubmited(data: SavedReport) {
    this.PiiInfo.showPii = true;
    this.reportEmailService.sendEmailWithReport(data)
      .then(data => {
        this.toastrService.success("Email sent successfully");
      });
  }

  onEditColumnsSubmited() {
    this.applyConfigEditColumn();
  }

  private applyConfigEditColumn() {
    this.columns = [];
    this.mobileColumns = [];
    this.mobileColumnsOptional = [];
    this.sort = [];
    //count total checked column;
    var count = 0;

    var columnContent = this.editColumnsContent.columns;

    for (var i = 0; i < columnContent.length; i++) {
      let tempKey = columnContent[i].name;
      let tempTitle = columnContent[i].title;
      let ifCheck = columnContent[i].isChecked;
      var tempType = this.passengersOnFlightService.fullColumns.find(x => x.field == columnContent[i].name).type;

      if (ifCheck) {
        count = count + 1;
        //add the desktop column and the max number is 8 and the other is optional 
        this.columns.push({ field: tempKey, title: tempTitle, index: i, type: tempType });

        //add the mobile column and the max number is 2 and the other is optional
        //add the sort by default 2 columns
        if (count <= 2) {
          //add the sort 
          this.sort.push({ field: tempKey, dir: 'asc' });

          this.mobileColumns.push({ field: tempKey, title: tempTitle, index: i, type: tempType });
        } else {
          this.mobileColumnsOptional.push({ field: tempKey, title: tempTitle, index: i, type: tempType });
        }
      }
    }

    if (this.mobileColumns.length + this.mobileColumnsOptional.length <= 2) {
      this.isShowMobileExpandColumn = false;
    } else { this.isShowMobileExpandColumn = true; }

    this.applyFilter();

  }

  onSaveReportSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportFilterService.upsetSavedReport(path, this.saveReportContent, this.editColumnsContent.columns, this.mySavedReportsContent);
        this.onMySavedReportsSubmited(() => {
          if (!this.activatedRoute.snapshot.paramMap.get('reportId'))
            this.reportFilterService.resetSaveReport(this.saveReportContent);
        });
      }
    });
  }

  onMySavedReportsSubmited(success?: () => void) {
    this.PiiInfo.showPii = true;
    this.nrcService.updateMySavedReports(this.mySavedReportsContent.reports)
      .then(data => {
        let isDeleting = this.lastReportsCount > this.mySavedReportsContent.reports.length;
        this.lastReportsCount = this.mySavedReportsContent.reports.length;
        this.toastrService.success(isDeleting ? "Deleted report successfully" : "Reports saved successfully");

        if (typeof success === 'function') success();
      });
  }

  onOpenEmailTravellerSubmited(data: any) {
    if (data && data.passengers && data.passengers.length) {
      this.emailTravellerContent = { outFields: ['TO', 'BCC', 'CC'], selectedOutField: 'TO', recipients: [] };
      let emails: string[] = [];
      data.passengers.forEach(d => {
        let t = d.email && d.email.toLowerCase();
        if (t && !emails.includes(t)) emails.push(t);
      });

      emails.forEach(e => {
        this.emailTravellerContent.recipients.push({
          email: e,
          isChecked: true
        });
      });
      this.appFeatures.toggleEmailTraveller(null, this.emailTravellerContent);
    }
  }

  onEmailTravellerSubmited() {
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.sendTravelerEmail(path, this.emailTravellerContent)
          .then(data => {
            this.toastrService.success("Email sent successfully");
          });
      }
    });
  }

  private showDrilldown(id) {

    let expandCollpase = this.passengersOnFligh.filter(
      x => x.id == id)[0];
    return expandCollpase.isdrilldown;
  }

  private showExpandColumn(dataItem: any) {

    let expandCollpase = this.passengersOnFligh.filter(
      x => x.flightNumber == dataItem.flightNumber)[0];
    return expandCollpase.isexpand;

  }


  public binddropdown() {

    this.source = this.source.filter(item => item == { text: "", value: null });

    let totalPages = Math.floor(((this.total - 1) / this.pageSize) + 1);

    for (var i = 1; i <= totalPages; i++) {
      let drp = { text: String(i), value: i };
      this.source.push(drp);
    }

    if (totalPages > 0) {

      this.selectedValue = { text: "1", value: 1 };
    } else {
      this.selectedValue = { text: "", value: null };
    }

  }


  public valueChange(pageIndex: any): void {
    this.skip = (pageIndex.value - 1) * this.pageSize;
    this.applyFilter();
    this.selectedValue = { text: pageIndex.value, value: pageIndex.value };

  }

  private showExpandIcon(dataitem: any) {
    let icon = "+"
    let rowIndex = dataitem.index;
    let expandCollpase = this.passengersOnFligh.filter(
      x => x.index == rowIndex)[0];
    if (expandCollpase.isexpand) {
      icon = "-"
    } else {
      icon = "+"
    }
    return icon;

  }

  public ShowHideSubContent(dataitem: any, rowIndex: any) {

    let expandCollpaseFilterFlagIndexs = this.passengersOnFligh.filter(
      x => x.flightNumber == dataitem.flightNumber)[0];

    let tableIndex = expandCollpaseFilterFlagIndexs.index;
    //console.log(this.passengersOnFligh[rowIndex]);

    this.passengersOnFligh[tableIndex]

    if (!this.passengersOnFligh[tableIndex].isexpand) {

      this.grid.expandRow(rowIndex);

      this.passengersOnFligh[tableIndex].isexpand = true;

    } else {
      if (!this.passengersOnFligh[tableIndex].isdrilldown) {
        this.grid.collapseRow(rowIndex);
      }
      this.passengersOnFligh[tableIndex].isexpand = false;
    }

  }

  private loadData(isFilter?: boolean) {
    this.showLoading = true;
    this.passengersOnFlightService.getpassengersOnFlight(this.filterContent).then(data => {
      if (data) {
        this.rawData = data;
        if (isFilter) this.toastrService.success('Filters successfully applied');
        this.skip = 0;
        this.passengersOnFligh = this.passengersOnFlightService.mappingData(data);
        this.mapEditColumnsContext(this.passengersOnFligh);
        this.mapSaveReportContext(this.passengersOnFligh);
        this.applyConfigEditColumn();
        this.loadItems();
      }
    });
  }

  private loadMySavedReports(loadData: () => any) {
    this.nrcService.getMySavedReports()
      .then(data => {
        if (data) {
          this.mySavedReportsContent.reports = data.Result.docTypeAttributes.UserProfile.userTravelSettings.savedReports;
          this.lastReportsCount = this.mySavedReportsContent.reports.length;
        }

        let reportId = this.activatedRoute.snapshot.paramMap.get('reportId');
        this.initFilterContent(this.mySavedReportsContent.reports.find(r => r.ReportID == reportId));
        loadData();
      })
      .catch(err => { this.initFilterContent(null); });
  }

  private initFilterContent(report: SavedReport) {
    if (report) {
      this.reportFilterService.mapFilterContent(report, this.filterContent);
      this.saveReportContent = {
        reportId: report.ReportID,
        reportName: report.ReportName,
        currentReportName: report.ReportName,
        filter: this.filterContent
      };
      if (report.ViewFields && report.ViewFields.length) {
        this.configColumn = [];
        report.ViewFields.forEach(f => {
          if (this.configColumn.indexOf(f) == -1) this.configColumn.push(f);
        });
      }
    }
    else if (globalConfig.passengersOnFlightFilterContent) {
      this.filterContent = globalConfig.passengersOnFlightFilterContent;
    }

    let reports = this.mySavedReportsContent.reports || [];
    this.saveReportContent.allExistingReports = reports.map(r => r.ReportName);
  }

  private mapEditColumnsContext(data: PassengerOnFlight[]) {
    if (this.editColumnsContent.columns.length) return;

    var configColumn = this.configColumn;
    var fullColumns = this.passengersOnFlightService.fullColumns;
    this.editColumnsContent.columns = [];

    for (var i = 0; i < configColumn.length; i++) {
      var tempCol = fullColumns.find(x => x.field == configColumn[i]);
      this.editColumnsContent.columns.push({
        title: tempCol.title,
        name: tempCol.field,
        isChecked: true
      });
    }
    for (var i = 0; i < fullColumns.length; i++) {
      var title = fullColumns[i].title;
      var name = fullColumns[i].field;

      if (!configColumn.find(x => x == name)) {
        this.editColumnsContent.columns.push({
          title: title,
          name: name,
          isChecked: false
        });
      }
    }
  }
  private mapSaveReportContext(data: PassengerOnFlight[]) {
    if (data && data.length) {
      this.saveReportContent.filter = this.filterContent;
    }
  }

  //private onSort(dataItem: any, order: any) {
  private onSort(event: any) {
    console.log(event.columns);
    console.log(event.order);
    let dataItem = event.columns;
    let order = event.order;
    this.sort = [];
    this.sort.push({ field: dataItem.field, dir: order });

    this.passengersOnFligh = orderBy(this.passengersOnFligh, this.sort);

    //rearrange index order  
    for (var i = 0; i < this.passengersOnFligh.length; i++) {
      this.passengersOnFligh[i].index = i;
      this.passengersOnFligh[i].isexpand = false;
      this.passengersOnFligh[i].isdrilldown = false;
      this.grid.collapseRow(i);
    }

    this.applyFilter();
  }

  //dialog windows open and close
  public GridDetialClickHanlder(dataItem: any, rowIndex: any) {
    this.detailGridData = dataItem;
    this.windowOpened = true;
  }

  public close(component) {
    this.windowOpened = false;

  }

}
