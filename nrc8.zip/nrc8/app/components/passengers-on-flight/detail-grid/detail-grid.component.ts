import { Component, ViewChild, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { GridDataResult, GridComponent, PageChangeEvent } from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs';
import { WindowState, WindowService, WindowCloseResult } from '@progress/kendo-angular-dialog';
import { ActivTravelService } from '../../../services/activ-travel.service';
import { PassengerOnFlight } from '../../../models/PassengerOnFlight';
import { ColumnSetting } from '../../../services/activ-travel.service';
import { ReportItinerayComponent } from "../../report-common/report-itineray/report-itineray.component";
import { max } from 'rxjs/operator/max';

@Component({
  selector: 'app-flight-detail-grid',
  templateUrl: './detail-grid.component.html',
  styleUrls: ['./detail-grid.component.css']
})
export class FlightDetailGridComponent implements OnInit {
  public gridView: GridDataResult;
  public pageSize = 50;
  public skip = 0;
  private data: Object[];
  public region;

  //kendo grid
  @ViewChild(GridComponent) grid: GridComponent;

  //is on mobile device
  public isMobile = false;

  public buttonCount = 5;
  public info = true;
  public type: 'numeric' | 'input' = 'numeric';
  public pageSizes = true;
  public previousNext = true;

  //diaolog windows open 
  public pnrid;// link to itenary detial page 
  public miniwindowOpened = false;
  public windowState: WindowState = 'maximized';

  observablePsgOnFlight: Observable<PassengerOnFlight[]>
  psgOnFlight: PassengerOnFlight[];
  errorMessage: String;
  flightNumber: string;

  @Output() emailTravellers: EventEmitter<any> = new EventEmitter();
  constructor(public activTravelService: ActivTravelService, private windowService: WindowService) { }
  ngOnInit(): void {
    this.isMobile = this.activTravelService.isMobile();
    this.loadItems();

  }

  @Input() public drillDownData: any;

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.skip = skip;
    this.pageSize = take;
    this.loadItems();
  }

  public loadItems(): void {
    if (this.drillDownData && this.drillDownData.passengers.length) {
      let flight = this.drillDownData.passengers[0];
      if (flight.segmentType = 'Flight') this.flightNumber = flight.segmentDesignator;
    }

    this.gridView = {
      data: (this.drillDownData as any).passengers.slice(this.skip, this.skip + this.pageSize),
      total: (this.drillDownData as any).passengers.length
    };
  }

  openEmailTravellers() {
    this.emailTravellers.emit(this.drillDownData);
  }

  public ShowHideSubContent(dataitem: any) {
    let travelers = (this.drillDownData as any).passengers;
    let rowIndex = dataitem.index;

    if (!travelers[rowIndex].isexpand) {

      this.grid.expandRow(rowIndex);

      travelers[rowIndex].isexpand = true;

    } else {

      this.grid.collapseRow(rowIndex);

      travelers[rowIndex].isexpand = false;
    }

  }

  private showExpandIcon(dataitem: any) {
    let icon = "+"
    let rowIndex = dataitem.index;
    let travelers = (this.drillDownData as any).passengers;
    let expandCollpase = travelers.filter(
      x => x.index == rowIndex)[0];
    if (expandCollpase.isexpand) {
      icon = "-"
    } else {
      icon = "+"
    }
    return icon;

  }

  public close() {
    this.miniwindowOpened = false;

  }
  public onCloseClick(e) {
    console.log(e);
    this.miniwindowOpened = false;

  }

  //show itnary detial for different screen size 
  public GridDetialClickHanlder(dataItem: any) {
    console.log(dataItem.pnrid);
    let left;
    let top;
    let windowExpression;
    //desktop show 
    if (!this.isMobile) {

      left = ((screen.width - 1024) / 2);
      top = ((screen.height - 680) / 2) - 60;
      windowExpression = {
        title: 'Itinerary Detail',
        content: ReportItinerayComponent,
        width: 680,
        height: 420,
        left: left,
        top: top

      }
    }
    //mobile show 
    else
    {
      let left = 0;
      let top = 0;
      windowExpression = {
        title: 'Itinerary Detail',
        content: ReportItinerayComponent,
        left: left,
        top: top

      }
    }
    const windowRef = this.windowService.open(windowExpression);
    const userInfo = windowRef.content.instance;
    userInfo.pnrid = dataItem.pnrid;
    console.log(userInfo.pnrid);
  }
  


  public detailFullColumns: ColumnSetting[] = [
     {
      field: 'region',
      title: 'Region',
      index: 1,
      type: 'text'
    }, {
      field: 'country',
      title: 'Country',
      index: 2,
      type: 'text'
    }, {
      field: 'city',
      title: 'City',
      index: 3,
      type: 'text'
    }, {
      field: 'airportOrlocation',
      title: 'Airport/Location Name',
      index: 4,
      type: 'text'
    }, {
      field: 'pnrid',
      title: 'PNRID',
      index: 0,
      type: 'hyperlink'
    }, {
      field: 'name',
      title: 'Name',
      index: 5,
      type: 'text'
    }, {
      field: 'email',
      title: 'Email',
      index: 6,
      type: 'text'
    }, {
      field: 'segmentType',
      title: 'Seg. Type',
      index: 7,
      type: 'text'
    }
    , {
      field: 'segmentTime',
      title: 'Seg. Time',
      index: 8,
      type: 'date'
    }, {
      field: 'segmentDesignator',
      title: 'Seg. Desgntr',
      index: 9,
      type: 'text'
    }
  ];

  public mobileColumns: ColumnSetting[] = [
    {
      field: 'pnrid',
      title: 'PNRID',
      index: 0,
      type: 'hyperlink'
    }, {
      field: 'name',
      title: 'Name',
      index: 1,
      type: 'text'
    }
  ];
}
