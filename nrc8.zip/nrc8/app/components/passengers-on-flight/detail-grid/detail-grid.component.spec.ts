import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightDetailGridComponent } from './detail-grid.component';

describe('FlightDetailGridComponent', () => {
  let component: FlightDetailGridComponent;
  let fixture: ComponentFixture<FlightDetailGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightDetailGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightDetailGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
