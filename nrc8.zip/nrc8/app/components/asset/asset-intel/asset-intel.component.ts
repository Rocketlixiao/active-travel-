import { Component, OnInit, Input, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { AssetIntelSort } from '../../../models/AssetIntelSort';
import { SortService } from '../../../services/sort.service';
declare var globalConfig: any;

@Component({
  selector: 'app-asset-intel',
  templateUrl: './asset-intel.component.html',
  styleUrls: ['./asset-intel.component.css']
})
export class AssetIntelComponent implements OnInit {
  @Input() data: any[];
  @Output() sortEvent = new EventEmitter<string>();

  incidentsAround: any[];
  orderProp = '-severity';
  assetIntelSort = new AssetIntelSort();
  sortA = this.assetIntelSort.sortA;
  sortB = this.assetIntelSort.sortB;
  sortC = this.assetIntelSort.sortC; 

  constructor(private sortService: SortService) { }

  ngOnInit() {
    globalConfig.callFormsUI();
  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed
    if (changes['data']) {
      if (this.data) {
        this.incidentsAround = this.data;
      }
    }
  }

  changeSort($event) {    
    let assetIntelSort = this.sortService.getAssetIntelSort($event);
    this.sortA = assetIntelSort.sortA;
    this.sortB = assetIntelSort.sortB;
    this.sortC = assetIntelSort.sortC;

    this.sortEvent.emit($event);
  }

}
