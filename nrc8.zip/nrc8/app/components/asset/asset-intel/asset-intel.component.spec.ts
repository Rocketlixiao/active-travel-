import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetIntelComponent } from './asset-intel.component';

describe('AssetIntelComponent', () => {
  let component: AssetIntelComponent;
  let fixture: ComponentFixture<AssetIntelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetIntelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetIntelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
