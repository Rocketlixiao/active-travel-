import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetForwardComponent } from './asset-forward.component';

describe('AssetForwardComponent', () => {
  let component: AssetForwardComponent;
  let fixture: ComponentFixture<AssetForwardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetForwardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetForwardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
