import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { NrcService } from '../../../services/nrc.service';
import { NotificationIncident } from '../../../models/NotificationIncident';
//import '../../../libs/globalConfig.js';
declare var globalConfig: any;

import * as $ from 'jquery';

@Component({
  selector: 'app-asset-forward',
  templateUrl: './asset-forward.component.html',
  styleUrls: ['./asset-forward.component.css']
})
export class AssetForwardComponent implements OnInit {

  @Input() data: any;
  forward: any = {};
  hasRecipients = false;
  OUTTO = "TO";
  OUTBCC = "BCC";
  OUTCC = "CC";
  formData = new NotificationIncident();

  constructor(private nrcService: NrcService) { }

  ngOnInit() {
    this.init();
  }

  ngOnChanges(changes: SimpleChanges) {   
    // only run when property "data" changed
    if (changes['data']) {
      if (this.data) {
        this.forward = this.data;
        this.hasRecipients = this.forward.Assets && this.forward.Assets.length > 0 ? false : true;
      }

    }
  }

  sendForwardNotification(formData) {
    var data = {
      Type: null,
      Name: null,
      Severity: null,
      City: null,
      State: null,
      Country: null,
      PersonalMessage: null,
      Address: null,
      Category: null,
      Gist: null,
      Occurred: null,
      Source: null,
      IncidentsAround: [],
      To: [],
      Bcc: [],
      Cc: []
    };

    Object.assign(data, this.forward);
    Object.assign(data, formData);
   
    this.nrcService.sendNotificationAsset(data).subscribe(res => {
      //reference code status at https://sendgrid.com/docs/API_Reference/Web_API_v3/Mail/errors.html.

      if (res.Status != 202) {
        var msgRegex = /(?:"message":")([^"]+)/;
        this.formData.requestError = res.Status == 200
          ? 'Your message is valid, but it is not queued to be delivered.'
          : (msgRegex.test(res.Message) ?
            res.Message.match(msgRegex)[1] :
            res.Message);
      }
      else {
        globalConfig.showOrHiddenModal('#forwardModal', 'hide');

        this.resetForm();
      }
      this.formData.isInSubmitting = false;
    },
      err => { this.nrcService.handleError(err); });

  }

  init() {

    this.formData.outField = this.OUTTO;
    this.formData.availableOutFields = [this.OUTTO, this.OUTBCC, this.OUTCC];
    this.formData.additionalRecipients = '';
    this.formData.personalMessage = '';
    this.formData.attachPDF = null;
    this.formData.isInSubmitting = false;
    //$(this.el.nativeElement).on('hidden.bs.modal', () => {
    //  $(this).modal('hide');
    //  this.cancelProcedure();//my internal reset function
    //});
    var that = this;
    $("#assetForwardModel").on('show.bs.modal', function () {

      that.formData.requestError = undefined;
      that.formData.isInSubmitting = false;
    });
  }

  handleBeforeSending() {
    this.formData.requestError = undefined;  
    var data = {
      PersonalMessage: this.formData.personalMessage,
      AttachPDF: this.formData.attachPDF,
      To: [],
      Bcc: [],
      Cc: []
    };
    var contactList = [];
    for (let asset of this.forward.Assets) {
      if (asset.isChecked) {
        for (var i = 0; i < asset.contacts.length; i++) {
          contactList.push(asset.contacts[i]);
        }
      }
    };
    var addRecipients = this.formData.additionalRecipients ? this.formData.additionalRecipients.split(';') : [];
    for (let item of addRecipients) {
      if (item) {
        contactList.push(item.trim());
      }
    };

    if (!contactList.length) {
      this.formData.requestError = 'Recipients list is empty';
      return;
    }

    this.formData.isInSubmitting = true;
    if (this.formData.outField === this.OUTTO) {
      data.To = contactList;
    }
    else if (this.formData.outField === this.OUTBCC) {
      data.Bcc = contactList;
    }
    else if (this.formData.outField === this.OUTCC) {
      data.Cc = contactList;
    }

    if (typeof (this.sendForwardNotification) === 'function') {
      this.sendForwardNotification(data);
    }
  };

  setRecipientsRequired() {

    //return !(this.forward.Assets.filter(item => item.isChecked)) || this.formData.additionalRecipients;
    this.hasRecipients = ((this.forward.Assets && (this.forward.Assets.filter(item => item.isChecked)).length > 0) || this.formData.additionalRecipients) ? true : false;
    
  }

  setOutFieldsRequired() {
    return this.formData.availableOutFields.indexOf(this.formData.outField) === -1;
  }

  cancelModal() {
    globalConfig.showOrHiddenModal('#forwardModal', 'hide');
    this.resetForm();
  };

  onInteract() {
    if (this.formData.requestError) {
      this.formData.requestError = undefined;
    }

    this.setRecipientsRequired();
  };

  resetForm() {

    this.formData.requestError = undefined;
    for (let asset of this.forward.Assets) {
      asset.isChecked = false;
    };

    this.formData.additionalRecipients = '';
    this.formData.personalMessage = '';
    this.formData.attachPDF = false;
    this.formData.outField = this.OUTTO;
  }

}
