import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, ParamMap, Params } from '@angular/router';
import { SharedService } from '../../../services/shared.service';
import { AutorefreshService } from '../../../services/autorefresh.service';
import { NrcService } from '../../../services/nrc.service';
import { Asset } from '../../../models/Asset';
import { Url } from '../../../models/Url';
import { CapitalizePipe } from '../../../pipes/capitalize.pipe';
import { AssetDetailComponent } from '../asset-detail/asset-detail.component';
import { AssetIntelSort } from '../../../models/AssetIntelSort';
import { SortService } from '../../../services/sort.service';
import { SimpleOrderByPipe } from '../../../pipes/simple-order-by.pipe';

//import '../../../libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-asset',
  templateUrl: './asset.component.html',
  styleUrls: ['./asset.component.css']
})
export class AssetComponent implements OnInit {
  @ViewChild(AssetDetailComponent) assetDetailComponent: AssetDetailComponent;
  tempAsset = new Asset();
  asset = new Asset();
  //sort array
  assetIntelSort = new AssetIntelSort();
  arrIntelSort: string[] = [this.assetIntelSort.sortA, this.assetIntelSort.sortB, this.assetIntelSort.sortC];
  simpleOrderByPipe = new SimpleOrderByPipe();

  forward: any = {};
  capitalize = new CapitalizePipe();

  paramsLocationId: string;
  paramsDrawer: string;

  constructor(private sharedService: SharedService, private sortService: SortService, private actRoute: ActivatedRoute, private nrcService: NrcService, private autorefreshService: AutorefreshService) { }

  ngOnInit() {
    this.sharedService.showOrHideMap();

    this.actRoute.params.subscribe((params: Params) => {
      if (params["locationId"]) {
        this.paramsLocationId = params["locationId"];

        this.nrcService.getAsset(this.paramsLocationId).then(data => {

          this.dataMapping(data);

          this.initAsset(this.tempAsset);

        });
      }

      if (params["drawer"]) {
        this.paramsDrawer = params["drawer"];
      }
    });
  }
  initAsset(ass: Asset) {

    if (!ass.id) {
      return;
    }
    this.asset = ass;

    //Merge the updates when page is loaded.
    this.autorefreshService.MergeUpdates(false);

    //forward, get asset data.
    this.mapForwardModel(this.asset);

    var that = this;
    //ensure proximities are pre-filled
    setTimeout(() => {
      that.sharedService.getProximitiesForDetailPage(function () {
        that.asset.objtype = globalConfig.getLegacyProximitiesById(that.asset.id);

        var thisAsset = (globalConfig.allProximities.assets || []).find(function (a) { return a.id === that.paramsLocationId; });

        if (thisAsset) {
          //get proximities incidents
          for (let item of thisAsset.n) {
            that.asset.IncidentsAround.push({
              id: item.id,
              risk: item.s,
              DistanceToAssetNumber: item.d,
              DistanceToAsset: item.d.toFixed(2) + ' ' + globalConfig.settingsData.DistanceUnit
            });
          };

          //get proximities incidents details
          var incidentsIds = that.asset.IncidentsAround.map(inc => inc.id).join(',');

          if (incidentsIds) {
            that.nrcService.getIncidentsByIds(incidentsIds).then(iData => {
              if (iData && iData.incidents) {
                var index = that.asset.IncidentsAround.length, length = index, statusNo = 0;
                while (index--) {
                  var dIncident = iData.incidents.find(function (i) { return i.incidents == that.asset.IncidentsAround[index].id; });
                  if (dIncident) {
                    dIncident = globalConfig.convertIncident(dIncident);
                    //Todo
                    //angular.merge(asset.IncidentsAround[index], dIncident);
                    that.asset.IncidentsAround[index] = { ...that.asset.IncidentsAround[index], ...dIncident }
                    statusNo = dIncident.severity > statusNo ? dIncident.severity : statusNo;
                  }
                  else {
                    that.asset.IncidentsAround.splice(index, 1);
                  }
                }

                //re-calculate asset status.
                if (that.asset.IncidentsAround.length !== length) {
                  var status = globalConfig.severityFactory.getValueByKey(statusNo) || globalConfig.SEVERITY_VALUE_NORMAL;
                  that.asset.ProximityStatusToDisplay = that.capitalize.transform(status);
                  that.asset.ProximityStatus = globalConfig.filter_toLowerCase(status);
                }

                that.asset.ProximityStatusToDisplay = that.asset.ProximityStatusToDisplay || that.capitalize.transform(thisAsset.s || globalConfig.SEVERITY_VALUE_NORMAL);
                that.asset.ProximityStatus = that.asset.ProximityStatus || globalConfig.filter_toLowerCase(thisAsset.s || globalConfig.SEVERITY_VALUE_NORMAL);
              }
              else {
                //set Proximities Status for Asset
                that.asset.ProximityStatusToDisplay = that.capitalize.transform(globalConfig.SEVERITY_VALUE_NORMAL);
                that.asset.ProximityStatus = globalConfig.filter_toLowerCase(globalConfig.SEVERITY_VALUE_NORMAL);
              }

              //build asset map               
              that.setupAssetMapTimeInterval(that.asset);
              //update forward model
              that.updateForwardModel(that.asset);
            },
              function (error) {
                console.log('failed to get around incidents');
              }
            );
          }
          else {
            //set Proximities Status for Asset
            that.asset.ProximityStatusToDisplay = that.capitalize.transform(globalConfig.SEVERITY_VALUE_NORMAL);
            that.asset.ProximityStatus = globalConfig.filter_toLowerCase(globalConfig.SEVERITY_VALUE_NORMAL);
            //build asset map             
            that.setupAssetMapTimeInterval(that.asset);
            //update forward model
            that.updateForwardModel(that.asset);
          }
        }
        else {
          //set Proximities Status for Asset
          that.asset.ProximityStatusToDisplay = that.capitalize.transform(globalConfig.SEVERITY_VALUE_NORMAL);
          that.asset.ProximityStatus = globalConfig.filter_toLowerCase(globalConfig.SEVERITY_VALUE_NORMAL);
          //build asset map           
          that.setupAssetMapTimeInterval(that.asset);
          //update forward model
          that.updateForwardModel(that.asset);
        }

        //scroll to incidents
        window.setTimeout(function () {
          if (globalConfig.filter_toLowerCase(that.paramsDrawer) === 'incidents') {
            globalConfig.scrollPage('.article-container .intel-row');
          }

        }, 500);
      });
    }, 0);

  }

  dataMapping(data) {

    this.tempAsset.sourceURI = 'javascript:void(0)';
    this.tempAsset.id = data.attributes.facilityid;
    this.tempAsset.locationName = data.attributes.name;
    this.tempAsset.streetAddress = data.attributes.street;
    this.tempAsset.city = data.attributes.city;
    this.tempAsset.state = data.attributes.stateprovince;
    this.tempAsset.country = data.attributes.country;
    this.tempAsset.zip = data.attributes.zip;
    this.tempAsset.latitude = data.attributes.lat;
    this.tempAsset.longitude = data.attributes.lon;
    this.tempAsset.type = data.attributes.type;
    this.tempAsset.contactManager = data.attributes.cName;
    this.tempAsset.cotactOfficePhone = data.attributes.cOffice;
    this.tempAsset.contactFax = data.attributes.cFax;
    this.tempAsset.contactCell = data.attributes.cCell;
    this.tempAsset.contactEmail = data.attributes.cEmail;
    //Todo
    //this.tempAsset.description = globalConfig.filter_linky(data.attributes.description, '_blank');
    this.tempAsset.description = data.attributes.description;
    if (this.tempAsset.description) {
      this.tempAsset.description = this.tempAsset.description.replace(/&#10;/g, '<br/>').replace(/\r\n/g, "<br/>").replace(/\n/g, "<br/>");
    }
    this.tempAsset.last_update = globalConfig.formatDate(parseInt(data.attributes.lastupdateddate));
    this.tempAsset.clientDate = globalConfig.getClientDate(parseInt(data.attributes.lastupdateddate));

    //#region waiting for another call
    this.tempAsset.ProximityStatusToDisplay = '';
    this.tempAsset.ProximityStatus = '';
    this.tempAsset.IncidentsAround = [];
    //#endregion

    if (globalConfig.filter_toLowerCase(data.attributes.country) === 'united states') {
      this.tempAsset.address = data.attributes.city + (data.attributes.stateprovince ? ', ' + data.attributes.stateprovince : '') + (data.attributes.zip ? ', ' + data.attributes.zip : '');
    }
    else {
      this.tempAsset.address = data.attributes.city + (data.attributes.country ? ', ' + data.attributes.country : '');
    }
    //get all urls
    var urls = [];
    if (data.nc4Attachments.length > 0) {
      for (var i = 0; i < data.nc4Attachments.length; i++) {
        var url = new Url();
        url.url_label = data.nc4Attachments[i].attachlabel;
        url.url = data.nc4Attachments[i].attachurl;
        urls.push(url);
      }
    }
    if (data.nc4Links.length > 0) {
      for (var i = 0; i < data.nc4Links.length; i++) {
        if (data.nc4Links[i] != null && data.nc4Links[i] != undefined) {
          var url = new Url();
          url.url_label = data.nc4Links[i].attachlabel;
          url.url = data.nc4Links[i].attachurl;
          urls.push(url);
        }
      }
    }
    this.tempAsset.Urls = urls;

  }

  //forward, get asset data
  mapForwardModel(asset) {
    this.forward = {
      Type: asset.type,
      Name: asset.locationName,
      Severity: this.capitalize.transform(asset.ProximityStatus),
      City: asset.city,
      State: asset.state,
      Country: asset.country,
      Address: asset.address,
      StreetAddress: asset.streetAddress,
      Latitude: asset.latitude,
      Longitude: asset.longitude,
      ClientDate: asset.clientDate,
      ContactManager: asset.contactManager,
      ContactOfficePhone: asset.cotactOfficePhone,
      ContactOfficeFax: asset.contactFax,
      ContactOfficeCell: asset.contactCell,
      ContactEmail: asset.contactEmail,
      Url: location.href || '',
      Description: asset.description,
      IncidentsAround: [],
      Assets: (asset.contactEmail || asset.contactemail) ? [{
        isChecked: false,
        facilityname: asset.locationName,
        contacts: (asset.contactEmail || asset.contactemail).split(/[,;]/).filter(function (c) { return !!c; })
      }] : []
    };

    //$scope.forward.Me, get current user email address
    this.nrcService.getUserInfo().then(data => {
      this.forward.Me = data && data[0] && data[0].emailaddress && data[0].emailaddress.split(/[,;]/)[0] || null;
    });
  }

  //forward, add asset-arround incidents when ready
  updateForwardModel(asset) {
    var thisLocation = /(?:http|https):\/\/[^/]+/.exec(window.location.href),
      path = (thisLocation ? thisLocation[0] : '') + '/nrc8/#/content/';
    this.forward.IncidentsAround = [];
    if (asset.IncidentsAround && asset.IncidentsAround.length > 1) {
      var incidentsAround = this.simpleOrderByPipe.transform(asset.IncidentsAround, this.arrIntelSort);;

      for (let item of incidentsAround) {
        this.forward.IncidentsAround.push({
          Title: item.name + ' | ' + item.address,
          Severity: item.risk,
          SeverityKey: globalConfig.severityFactory.getKeyByValue(item.risk),
          Category: globalConfig.filter_toLowerCase(item.category),
          Url: path + item.id,
          Gist: item.text,
          Date: new Date(item.date),
          ClientDate: item.clientDate,
          Location: item.location,
          DistanceToAsset: item.DistanceToAsset
        });
      };
    }

    this.forward.Severity = this.capitalize.transform(asset.ProximityStatus);
  };

  reSortForwardIncidentsAround(orderProp) {
    if (this.forward.IncidentsAround && this.forward.IncidentsAround.length > 1) {
      let intelSort = this.sortService.getAssetIntelSort(orderProp);
      this.arrIntelSort = [intelSort.sortA, intelSort.sortB, intelSort.sortC];
      this.forward.IncidentsAround = this.simpleOrderByPipe.transform(this.forward.IncidentsAround, this.arrIntelSort);
    }
  }

  setupAssetMapTimeInterval(asset) {
    //build asset map    
    this.assetDetailComponent.callAssetBuildMap(asset);
  }

  openForwardNotification(selector) {
    globalConfig.showModal(selector);
  };

}
