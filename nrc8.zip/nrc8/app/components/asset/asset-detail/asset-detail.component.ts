import { Component, OnInit, Input, SimpleChanges, ViewChild} from '@angular/core';
import { Asset } from '../../../models/Asset';
import { AssetMapComponent } from '../asset-map/asset-map.component';
import { MapService } from '../../../services/map.service';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Component({
  selector: 'app-asset-detail',
  templateUrl: './asset-detail.component.html',
  styleUrls: ['./asset-detail.component.css']
})
export class AssetDetailComponent implements OnInit {
  @ViewChild(AssetMapComponent) assetMapComponent: AssetMapComponent
  @Input() data: Asset;
  asset = new Asset();
  mapReady = false;
  mapComponentReadyObservable = new BehaviorSubject<boolean>(false);
  castMapComponentReadyObservable = this.mapComponentReadyObservable.asObservable();
 
  constructor(private mapService: MapService) {  

    this.mapService.load()
      .then(res => {       
        this.mapReady = true;                
      });
  } 

  ngOnInit() {
    this.detectAssetMapReady();
  }

  detectAssetMapReady() {
    let mapInterval = null;
    mapInterval = setInterval(() => {   
      if (this.mapReady && typeof (this.assetMapComponent.BuildAssetMap) != 'undefined') {     
        this.emitMapComponentReady(true);
        window.clearInterval(mapInterval);
        mapInterval = null;
      }
    },200)
  }

  emitMapComponentReady(val) {
    this.mapComponentReadyObservable.next(val);
  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed
    if (changes['data']) {
      if (this.data) {
        this.asset = this.data;
      }
    }   
  }  

  callAssetBuildMap(asset) {
   
    this.castMapComponentReadyObservable.subscribe(res => {     
      if (res) {
        
        this.assetMapComponent.BuildAssetMap(asset);
       
      }     
    })    
  }
}
