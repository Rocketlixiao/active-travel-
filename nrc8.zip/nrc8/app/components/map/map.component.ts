import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { SortService } from '../../services/sort.service';
import { PagerService } from '../../services/pager.service';
import { DOCUMENT } from '@angular/platform-browser';
import { ArticleSort } from '../../models/ArticleSort';
import { SimpleOrderByPipe } from '../../pipes/simple-order-by.pipe';
import {
  PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective
} from 'ngx-perfect-scrollbar';


//import '../../libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']

})
export class MapComponent implements OnInit {

  incidentsItems: any[];
  articleSort = new ArticleSort();
  //sort array
  arrSort: string[] = [this.articleSort.sortA, this.articleSort.sortB, this.articleSort.sortC, this.articleSort.sortD];

  public config: PerfectScrollbarConfigInterface = {};

  //pager object
  pager: any = {};

  //paged items
  pagedItems: any[];
  simpleOrderByPipe = new SimpleOrderByPipe();

  constructor(private sharedService: SharedService, private sortService: SortService, @Inject(DOCUMENT) private document: any, private pagerService: PagerService) {

  }

  ngAfterViewInit() {
    hideSlideListInPhone();
  }

  ngOnInit() {

    globalConfig.showLoader();
    globalConfig.timerJobHideLoader();

    this.sharedService.showOrHideMap();

    if (this.sortService.getArticleListCurrentSort()) {
      this.articleSort = this.sortService.getArticleSort(this.sortService.getArticleListCurrentSort());
      this.arrSort = [this.articleSort.sortA, this.articleSort.sortB, this.articleSort.sortC, this.articleSort.sortD];
    }

    this.sharedService.castIncidentsItems.subscribe(ins => {
      this.incidentsItems = ins;     
      
      // initialize to page 1
      if (this.incidentsItems && this.incidentsItems.length > 0) {      
        this.setPage(1);
      }
      else {
        this.setPage(0);
      }
     
    });

    if (globalConfig.allIncidentItems.length === 0) {

      this.sharedService.getIncidentsAssets(this.refreshClustersCallback);
    }
    else {
      this.refreshClustersCallback();
    }
  }

  setPage(page: number) {
    if (page == 0) {
     
      this.pagedItems = [];      
       
      this.pager.totalItems = 0;
      this.pager.currentPage = 0;
      this.pager.pageSize = 0;
      this.pager.totalPages = 0;
      this.pager.startPage = 0;
      this.pager.endPage = 0;
      this.pager.startIndex = 0;
      this.pager.endIndex = 0;
      this.pager.pages = 0;
      
    }
    else {
      if (page < 1 || (this.pager.totalPages>0 && page > this.pager.totalPages)) {
        return;
      }
   
      //sort incidentsItems at first
      this.incidentsItems = this.simpleOrderByPipe.transform(this.incidentsItems, this.arrSort);
      // get pager object from service
      this.pager = this.pagerService.getPager(this.incidentsItems.length, page);

      // get current page of items
      this.pagedItems = this.incidentsItems.slice(this.pager.startIndex, this.pager.endIndex + 1);
    }
  }

  refreshClustersCallback() {
    globalConfig.refreshClusters();
  }

  linkClick(id, event) {
    window.location.href = '/content/' + id;

    var e = window.event || event;
    if (e) {
      if (e.stopPropagation) {
        e.stopPropagation();
      } else {

        window.event.cancelBubble = true;
      }
    }

    return false;
  }

  launchIncident(item: any) {
    globalConfig.launchIncident(item);
  }

  assetsLinkClick(incidentId: string) {
    var impactedAssets = globalConfig.getImpactedAssets(incidentId);
    if (impactedAssets.length > 0) {
      window.location.href = '#/content/' + incidentId + '/assets';
    }

    return false;
  }


}
