import { Component, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { GridComponent, GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { ActivatedRoute, ParamMap } from "@angular/router";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/observable/of';

import { ActivTravelService } from '../../../services/activ-travel.service';
import { ExecutiveSummaryService } from '../../../services/executive-summary.service';
import { NrcService } from "../../../services/nrc.service";
import { ToastrService } from "../../../services/toastr.service";
import { ActiveTravel } from '../../../models/ActiveTravel';
import { SharedService } from '../../../services/shared.service';
import { ReportFilterService } from "../../../services/report-filter.service";
import { ReportEmailService } from "../../../services/report-email.service";
import {
  ReportHeader,
  ReportFilterContext,
  ReportEmailContext,
  SavedReport,
  ReportSaveReportContext,
  ReportMySavedReportContext,
  EmailTravellerContext
} from "../../../models/ReportHeader";

declare var globalConfig: any;

@Component({
  selector: 'app-executive-summary',
  templateUrl: './executive-summary.component.html',
  styleUrls: ['./executive-summary.component.css']
})
export class ExecutiveSummaryComponent implements OnInit, OnDestroy, ReportHeader {
  showLoading: boolean = false;
  private rawData: any;
  private lastReportsCount: number = 0;
  CDN = globalConfig.CDN.root;
  //header init 
  PiiInfo: { showPii: boolean } = { showPii: false };
  description: string;
  filterContent: ReportFilterContext = {
    hasRegion: true,
    hasCountry: true,
    hasRiskRating: true
  };
  emailContent: ReportEmailContext = {
    outFields: ['TO', 'BCC', 'CC'],
    selectedOutField: 'TO',
    fileFormats: ['EXCEL', 'HTML', 'PDF']
  };
  saveReportContent: ReportSaveReportContext = new ReportSaveReportContext();
  mySavedReportsContent: ReportMySavedReportContext = {
    daysOfWeek: ['Moday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    daysOfMonth: [],
    reportFormats: ['EXCEL', 'HTML', 'PDF'],
    recurrenceTypes: ['daily', 'weekly', 'monthly'],
    reports: []
  };
  emailTravellerContent: EmailTravellerContext = {
    outFields: ['TO', 'BCC', 'CC'],
    selectedOutField: 'TO',
    recipients: []
  };

  testlistitems: Array<string> = ["X-Small", "Small", "Medium", "Large", "X-Large", "2X-Large"];

  //grid init 
  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  public total = 0;
  private data: Object[];

  //is on mobile device
  public isMobile = false;

  //kendo grid and dropdown
  @ViewChild(GridComponent) grid: GridComponent;
  @ViewChild('appFeatures') appFeatures: any;
  public source: Array<{ text: string, value: number }> = [];
  public selectedValue: { text: string, value: number } = { text: "", value: null };
  public defaultItem: { text: string, value: number } = { text: "1", value: 1 };

  //sort
  public sort: SortDescriptor[] = [];

  //diaolog windows open 
  public detailActiveTravel;
  public windowOpened = false;

  //button and page config 
  public buttonCount = 5;
  public info = true;
  public type: 'numeric' | 'input' = 'numeric';
  public pageSizes = true;
  public previousNext = true;

  activeTravel: ActiveTravel[];
  errorMessage: String;

  constructor(private sharedService: SharedService,
    public executiveSummaryService: ExecutiveSummaryService,
    public activTravelService: ActivTravelService,
    private nrcService: NrcService,
    private toastrService: ToastrService,
    private reportFilterService: ReportFilterService,
    private activatedRoute: ActivatedRoute,
    private reportEmailService: ReportEmailService) {

    for (let i = 1; i < 32; i++) {
      this.mySavedReportsContent.daysOfMonth.push(i);
    }
    this.activatedRoute.paramMap.switchMap((params: ParamMap) => {
      return Observable.of(params.get('reportId'));
    }).subscribe(id => {
      if (this.gridView && id) {
        this.initFilterContent(this.mySavedReportsContent.reports.find(r => r.ReportID == id));
        this.loadData();
      }
    });
  }

  ngOnInit(): void {
    this.showLoading = true;
    this.sharedService.showOrHideMap();
    this.isMobile = this.activTravelService.isMobile();
    this.loadMySavedReports(() => {
      this.filterContent.hasOrganization = !!globalConfig.isNc4AdminOrOrgAdmin;
      this.loadData();
    });
  }

  ngOnDestroy(): void {
    this.appFeatures.closePoup();
    globalConfig.executiveSummaryFilterContent = this.filterContent;
  }

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.skip = skip;
    this.pageSize = take;
    this.applyFilter();
  }

  public loadItems(): void {

    this.applyFilter();
  }

  public applyFilter() {   
      let allData = this.activeTravel;
      this.total = allData.length;

      this.gridView = {
        data: allData.slice(this.skip, this.skip + this.pageSize),
        total: this.total
      };
      this.binddropdown();

      this.description = this.activTravelService.getHeaderPagerDescription(this.skip, this.pageSize, this.total);
      this.showLoading = false;    
  }

  onFilterSubmited() {
    this.appFeatures.closePoup(true);
    this.loadData(true);
  }

  onEmailSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.sendReportEmail(path, this.emailContent, this.filterContent, [])
          .then(data => {
            this.toastrService.success("Email sent successfully");
          });
      }
    });
  }

  onDownLoadReportSubmited(format: string) {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.downloadReport(this.rawData, format, path);
      }
    });
  }

  onSendEmailSubmited(data: SavedReport) {
    this.PiiInfo.showPii = true;
    this.reportEmailService.sendEmailWithReport(data)
      .then(data => {
        this.toastrService.success("Report successfully emailed");
      });
  }

  onSaveReportSubmited() {
    this.PiiInfo.showPii = true;
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportFilterService.upsetSavedReport(path, this.saveReportContent, [], this.mySavedReportsContent);
        this.onMySavedReportsSubmited(() => {
          if (!this.activatedRoute.snapshot.paramMap.get('reportId'))
            this.reportFilterService.resetSaveReport(this.saveReportContent);
        });
      }
    });
  }

  onOpenEmailTravellerSubmited(data: any) {
    if (data && data.travelers && data.travelers.length) {
      this.emailTravellerContent = { outFields: ['TO', 'BCC', 'CC'], selectedOutField: 'TO', recipients: [] };
      let emails: string[] = [];
      data.travelers.forEach(d => {
        let t = d.email && d.email.toLowerCase();
        if (t && !emails.some(e => t == e)) emails.push(t);
      });

      emails.forEach(e => {
        this.emailTravellerContent.recipients.push({
          email: e,
          isChecked: true
        });
      });
      this.appFeatures.toggleEmailTraveller(null, this.emailTravellerContent);
    }
  }

  onEmailTravellerSubmited() {
    this.activatedRoute.url.subscribe(segements => {
      if (segements && segements.length > 1) {
        let path = segements[1].path;
        this.reportEmailService.sendTravelerEmail(path, this.emailTravellerContent)
          .then(data => {
            this.toastrService.success("Email sent successfully");
          });
      }
    });
  }

  onMySavedReportsSubmited(success?: () => void) {
    this.PiiInfo.showPii = true;
    this.nrcService.updateMySavedReports(this.mySavedReportsContent.reports)
      .then(data => {
        let isDeleting = this.lastReportsCount > this.mySavedReportsContent.reports.length;
        this.lastReportsCount = this.mySavedReportsContent.reports.length;
        this.toastrService.success(isDeleting ? "Deleted report successfully" : "Reports saved successfully");
        if (typeof success === 'function') success();
      });
  }

  //private onSort(dataItem: any, order: any) {
  private onSort(event: any) {
    console.log(event.columns);
    console.log(event.order);
    let dataItem = event.columns;
    let order = event.order;
    this.sort = [];
    this.sort.push({ field: dataItem.field, dir: order });

    this.activeTravel = orderBy(this.activeTravel, this.sort);

    //rearrange index order  
    for (var i = 0; i < this.activeTravel.length; i++) {
      this.activeTravel[i].index = i;
      this.activeTravel[i].isdrilldown = false;
      this.grid.collapseRow(i);
    }

    this.applyFilter();
  }

  private showExpandColumn(id) {

    let expandCollpase = this.activeTravel.filter(
      x => x.id == id)[0];
    return expandCollpase.isexpand;

  }

  private showExpandIcon(dataitem: any) {
    let icon = "+"
    let rowIndex = dataitem.index;
    let expandCollpase = this.activeTravel.filter(
      x => x.index == rowIndex)[0];
    if (expandCollpase.isexpand) {
      icon = "-"
    } else {
      icon = "+"
    }
    return icon;

  }

  public binddropdown() {

    this.source = this.source.filter(item => item == { text: "", value: null });

    let totalPages = Math.floor(((this.total - 1) / this.pageSize) + 1);

    for (var i = 1; i <= totalPages; i++) {
      let drp = { text: String(i), value: i };
      this.source.push(drp);
    }

    if (totalPages > 0) {

      this.selectedValue = { text: "1", value: 1 };
    } else {
      this.selectedValue = { text: "", value: null };
    }

  }


  public valueChange(pageIndex: any): void {
    this.skip = (pageIndex.value - 1) * this.pageSize;
    this.applyFilter();
    this.selectedValue = { text: pageIndex.value, value: pageIndex.value };

  }

  public ShowHideSubContent(dataitem: any) {
    let rowIndex = dataitem.index;
    let expandCollpaseFilterFlagIndexs = this.activeTravel.filter(
      x => x.index == dataitem.index)[0];

    if (!this.activeTravel[rowIndex].isexpand) {

      this.grid.expandRow(rowIndex);

      this.activeTravel[rowIndex].isexpand = true;

    } else {
      if (!this.activeTravel[rowIndex].isdrilldown) {
        this.grid.collapseRow(rowIndex);
      }
      this.activeTravel[rowIndex].isexpand = false;
    }
  }

  private loadData(isFilter?: boolean) {
    this.executiveSummaryService.getExecutiveSummary(this.filterContent).then(data => {
      if (data) {
        this.rawData = data;

        if (isFilter) this.toastrService.success('Filters successfully applied');
        this.skip = 0;
        this.activeTravel = this.executiveSummaryService.mappingData(data);
        this.mapEditColumnsContext(this.activeTravel);
        this.mapSaveReportContext(this.activeTravel);
        this.loadItems();
      }
    });
  }

  private mapEditColumnsContext(data: ActiveTravel[]) {

  }

  private mapSaveReportContext(data: ActiveTravel[]) {
    if (data && data.length) {
      this.saveReportContent.filter = this.filterContent;
    }
  }

  private loadMySavedReports(loadData: () => any) {
    this.nrcService.getMySavedReports().then(data => {
      if (data) {
        this.mySavedReportsContent.reports = data.Result.docTypeAttributes.UserProfile.userTravelSettings.savedReports;
        this.lastReportsCount = this.mySavedReportsContent.reports.length;
      }

      let reportId = this.activatedRoute.snapshot.paramMap.get('reportId');
      this.initFilterContent(this.mySavedReportsContent.reports.find(r => r.ReportID == reportId));
      loadData();
    })
      .catch(err => { this.initFilterContent(null); });
  }

  private initFilterContent(report: SavedReport) {
    if (report) {
      this.reportFilterService.mapFilterContent(report, this.filterContent);
      this.saveReportContent = {
        reportId: report.ReportID,
        reportName: report.ReportName,
        currentReportName: report.ReportName,
        filter: this.filterContent
      };
    }
    else if (globalConfig.executiveSummaryFilterContent) {
      this.filterContent = globalConfig.executiveSummaryFilterContent;
    }

    let reports = this.mySavedReportsContent.reports || [];
    this.saveReportContent.allExistingReports = reports.map(r => r.ReportName);
  }

  //dialog windows open and close
  public GridDetialClickHanlder(dataItem: any) {
    this.detailActiveTravel = dataItem;
    this.windowOpened = true;
  }

  public close(component) {
    this.windowOpened = false;
  }
}

