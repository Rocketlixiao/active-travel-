/// <reference path="../../report-common/report-itineray/report-itineray.component.ts" />
/// <reference path="../../report-common/report-itineray/report-itineray.component.ts" />
import { Component, ViewChild, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { GridDataResult, GridComponent, PageChangeEvent } from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs';
import { WindowState, WindowService, WindowCloseResult } from '@progress/kendo-angular-dialog';

import { ActivTravelService } from '../../../services/activ-travel.service';
import { ActiveTravel } from '../../../models/ActiveTravel';
import { Travel } from '../../../models/Travel';
import { ColumnSetting } from '../../../services/activ-travel.service';
import { ReportItinerayComponent } from "../../report-common/report-itineray/report-itineray.component";
declare var globalConfig: any;

import * as $ from 'jquery';

@Component({
  selector: 'app-detail-grid',
  templateUrl: './detail-grid.component.html',
  styleUrls: ['./detail-grid.component.css']
})
export class DetailGridComponent implements OnInit {
  public gridView: GridDataResult;
  public pageSize = 50;
  public skip = 0;
  private data: Object[];
  public region;

  //kendo grid
  @ViewChild(GridComponent) grid: GridComponent;

  //is on mobile device
  public isMobile = false;

  public buttonCount = 5;
  public info = true;
  public type: 'numeric' | 'input' = 'numeric';
  public pageSizes = true;
  public previousNext = true;

  //diaolog windows open 
  public pnrid;// link to itenary detial page 
  public miniwindowOpened = false;
  public windowState: WindowState = 'maximized';

  public country = "";

  observableActiveTravel: Observable<ActiveTravel[]>
  errorMessage: String;

  @Output() emailTravellers: EventEmitter<any> = new EventEmitter();
  constructor(public activTravelService: ActivTravelService, private windowService: WindowService) { }
  ngOnInit(): void {

    this.isMobile = this.activTravelService.isMobile();
    this.loadItems();
  }

  @Input() public ActiveTravel: IActiveTravel;

  public pageChange({ skip, take }: PageChangeEvent): void {
    this.skip = skip;
    this.pageSize = take;
    this.loadItems();
  }

  public loadItems(): void {
    this.country = (this.ActiveTravel as any).country;
    this.gridView = {
      data: (this.ActiveTravel as any).travelers.slice(this.skip, this.skip + this.pageSize),
      total: (this.ActiveTravel as any).travelers.length
    };
  }

  openEmailTravellers() {
    this.emailTravellers.emit(this.ActiveTravel);
  }

  public ShowHideSubContent(dataitem: any) {
    let travelers = (this.ActiveTravel as any).travelers;
    let rowIndex = dataitem.index;

    if (!travelers[rowIndex].isexpand) {

      this.grid.expandRow(rowIndex);

      travelers[rowIndex].isexpand = true;

    } else {

      this.grid.collapseRow(rowIndex);

      travelers[rowIndex].isexpand = false;
    }

  }

  private showExpandIcon(dataitem: any) {
    let icon = "+"
    let rowIndex = dataitem.index;
    let travelers = (this.ActiveTravel as any).travelers;
    let expandCollpase = travelers.filter(
      x => x.index == rowIndex)[0];
    if (expandCollpase.isexpand) {
      icon = "-"
    } else {
      icon = "+"
    }
    return icon;

  }

  //show itnary detial for different screen size 
  public GridDetialClickHanlder(dataItem: any) {
   
    let left;
    let top;
    let windowExpression;
    //desktop show
    console.log(document.getElementById("dvRow").clientHeight);

    console.log(document.documentElement.offsetTop);

    
    if (!this.isMobile) {
     
      console.log(parent.screen.height);
      left = ((screen.width - 1024) / 2);
      top = ((screen.height - 680) / 2) - 60;
      windowExpression = {
        title: 'Itinerary Detail',
        content: ReportItinerayComponent,
        width: 680,
        height: 420,
        left: left,
        top: top

      }
    }
    //mobile show 
    else {
      let left = 0;
      let top = 0;
      windowExpression = {
        title: 'Itinerary Detail',
        content: ReportItinerayComponent,
        left: left,
        top: top

      }
    }
    const windowRef = this.windowService.open(windowExpression);
    const userInfo = windowRef.content.instance;
    userInfo.pnrid = dataItem.id;
    console.log(userInfo.pnrid);
  }


  public detailFullColumns: ColumnSetting[] = [
    {
      field: 'id',
      title: 'PNRID',
      index: 0,
      type: 'hyperlink'
    }, {
      field: 'city',
      title: 'City',
      index: 1,
      type: 'text'
    }, {
      field: 'name',
      title: 'Employee',
      index: 2,
      type: 'text'
    }, {
      field: 'email',
      title: 'Email',
      index: 2,
      type: 'text'
    }, {
      field: 'type',
      title: 'Type',
      index: 3,
      type: 'text'
    }, {
      field: 'startDate',
      title: 'Start Date',
      index: 4,
      type: 'date'
    }, {
      field: 'endDate',
      title: 'End Date',
      index: 5,
      type: 'date'
    }, {
      field: 'arrivalDate',
      title: 'Arrival Date',
      index: 6,
      type: 'date'
    }, {
      field: 'departureDate',
      title: 'Departure Date',
      index: 7,
      type: 'date'
    }
    , {
      field: 'locationType',
      title: 'Location Type',
      index: 8,
      type: 'text'
    }, {
      field: 'locationName',
      title: 'Location Name',
      index: 9,
      type: 'text'
    }
  ];

  public mobileColumns: ColumnSetting[] = [
    {
      field: 'id',
      title: 'Id',
      index: 0,
      type: 'hyperlink'
    }, {
      field: 'email',
      title: 'Email',
      index: 1,
      type: 'text'
    }
  ];

}

export interface IActiveTravel {
}
