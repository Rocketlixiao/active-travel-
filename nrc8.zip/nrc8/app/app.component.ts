import { Component, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';
import { environment } from '../environments/environment';

import { SettingsService } from './services/settings.service';
import { FilterService } from './services/filter.service';
import { BuildInfoService } from './services/build-info.service';
import { AutorefreshService } from './services/autorefresh.service';
import { ReportFilterService } from "./services/report-filter.service";
import { NrcService } from "./services/nrc.service";


//import './libs/globalConfig.js';
declare var globalConfig: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  bodylayout = 'list-layout';

  constructor(@Inject(DOCUMENT) private document: any, private router: Router, private buildInfoService: BuildInfoService, private autorefreshService: AutorefreshService, private settingsService: SettingsService, private filterService: FilterService, private reportFilterService: ReportFilterService, private nrcService: NrcService) {

  }

  ngOnInit() {
    this.filterService.getMultipleFiltersData();
    this.settingsService.getSettings();
    this.settingsService.getOrgSetting();
    this.buildInfoService.getBuildInfo();
    this.reportFilterService.getFilterDropdownItems().subscribe({ error: err => this.nrcService.handleError(err) });

    this.autorefreshService.autoRef();

    //tick and timeout session if no action
    globalConfig.timeOutSession();
  }
}
