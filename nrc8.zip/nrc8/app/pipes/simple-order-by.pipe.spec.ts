import { SimpleOrderByPipe } from './simple-order-by.pipe';

describe('SimpleOrderByPipe', () => {
  it('create an instance', () => {
    const pipe = new SimpleOrderByPipe();
    expect(pipe).toBeTruthy();
  });
});
