import { Pipe, PipeTransform, NgZone, ChangeDetectorRef, OnDestroy } from '@angular/core';

@Pipe({
  name: 'timeAgo', pure: false
})
export class NC4TimeAgoPipe implements PipeTransform, OnDestroy {


  private changeDetectorRef;
  private ngZone;
  private timer;

  constructor(changeDetectorRef: ChangeDetectorRef, ngZone: NgZone) {
  this.changeDetectorRef = changeDetectorRef;
  this.ngZone = ngZone;
}
    /**
     * @param {?} value
     * @return {?}
     */

  transform(value: string): string {
    var _this = this;
    this.removeTimer();
    var d = new Date(value);
    var now = new Date();
    var seconds = Math.round(Math.abs((now.getTime() - d.getTime()) / 1000));
    var timeToUpdate = (Number.isNaN(seconds)) ? 1000 : this.getSecondsUntilUpdate(seconds) * 1000;
    this.timer = this.ngZone.runOutsideAngular(function () {
      if (typeof window !== 'undefined') {
        return window.setTimeout(function () {
          _this.ngZone.run(function () { return _this.changeDetectorRef.markForCheck(); });
        }, timeToUpdate);
      }
      return null;
    });
    var minutes = Math.round(Math.abs(seconds / 60));
    var hours = Math.round(Math.abs(minutes / 60));
    var days = Math.round(Math.abs(hours / 24));
    var months = Math.round(Math.abs(days / 30.416));
    var years = Math.round(Math.abs(days / 365));
    if (Number.isNaN(seconds)) {
      return '';
    }
    else if (seconds <= 45) {
      return 'a few seconds ago';
    }
    else if (seconds <= 90) {
      return 'a minute ago';
    }
    else if (minutes <= 45) {
      return minutes + ' minutes ago';
    }
    else if (minutes <= 90) {
      return 'an hour ago';
    }
    else if (hours <= 24) {
      return hours + ' hours ago';
    }
    else if (hours <= 42) {
      return 'a day ago';
    }
    else if (days <= 30) {
      return days + ' days ago';
    }
    else if (days <= 45) {
      return 'a month ago';
    }
    else if (days <= 365) {
      return months + ' months ago';
    }
    else if (days <= 548) {
      return 'a year ago';
    }
    else {
      // (days > 545)
      return years + ' years ago';
    }
  }


  ngOnDestroy(): void {
    this.removeTimer();
  }
  private removeTimer() {
    if (this.timer) {
      window.clearTimeout(this.timer);
      this.timer = null;
    }
  }
  private getSecondsUntilUpdate(seconds) {
    var min = 60;
    var hr = min * 60;
    var day = hr * 24;
    if (seconds < min) {
      // less than 1 min, update every 2 secs
      return 2;
    }
    else if (seconds < hr) {
      // less than an hour, update every 30 secs
      return 30;
    }
    else if (seconds < day) {
      // less then a day, update every 5 mins
      return 300;
    }
    else {
      // update every hour
      return 3600;
    }
  }

}

