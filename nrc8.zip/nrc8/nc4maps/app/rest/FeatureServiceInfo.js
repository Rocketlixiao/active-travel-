//deprecated, no longer in use.  can be used for testing purposes
define([
	"dojo/_base/lang",
	"app/widgets/AlertBox/AlertBox",
	"dojo/dom-construct",
	"dojo/_base/array",
	"dojo/_base/declare",
	"dojo/Deferred",
	"dojo/domReady!"
],function (lang, AlertBox, domConstruct, array, declare, Deferred){
	/*
	 * This class is basically showing information for a specific feature service
	 * 
	 */
	return declare(null, {
		
		constructor: function(p_url){
			this._getFeatureServiceInfo(p_url);
			this._alertBox = new AlertBox();
		},
		
		_getFeatureServiceInfo: function(p_url)
		{
			var deferred = new Deferred();
			dojo.xhrPost({
				url: p_url,
		        handleAs: "json",
		        postData: {
		            f: "json",
		        },
		        load:  function(response) {
		        	deferred.resolve(response);
		        },
			    error: lang.hitch(this,  function(err){
			    	deferred.resolve(false);
			    	this._alertBox.error("Unable to load Feature Service")
			    })
			});
			deferred.then(lang.hitch(this,function(responseResults){
				var data = eval(responseResults); 
				var serviceDesc = domConstruct.create("p", {innerHTML:responseResults.serviceDescription}, divServiceDesc);
				if(responseResults.layers != null && responseResults.layers.length > 0)
				{
					array.forEach(responseResults.layers, function(p_layer){
						var li = domConstruct.create("li", {}, "ulLayers");
						var link = domConstruct.create("a", {href:  "/FeatureServer?f=html", innerHTML: p_layer.name}, li);
					});
				}
			}));
			return deferred.promise;			//return a promise...the 'then()' code will be executed when the post is done
		}
		
		
	});
	
});
		
	