define([
	"dojo/_base/lang",
	"app/widgets/AlertBox/AlertBox",
	"dojo/dom-construct",
	"dojo/_base/array",
	"dojo/_base/declare",
	"dojo/Deferred",
	"dojo/domReady!"
],function (lang, AlertBox, domConstruct, array, declare, Deferred){
	/*
	 * This class is basically showing the REST Services Catalog
	 * 
	 */
	return declare(null, {
		
		constructor: function(p_url){
			this._createServiceCatalog(p_url);
			this._alertBox = new AlertBox();
		},
		
		_createServiceCatalog: function(p_url)
		{
			var deferred = new Deferred();
			dojo.xhrPost({
				url: p_url,
		        handleAs: "json",
		        postData: {
		            f: "json",
		        },
		        load:  function(response) {
		        	deferred.resolve(response);
		        },
			    error: lang.hitch(this,  function(err){
			    	deferred.resolve(false);
			    	this._alertBox.error("Unable to load Feature Services")
			    })
			});
			deferred.then(lang.hitch(this,function(responseResults){
				var data = eval(responseResults); 
				var arrDataLayerGroup = data.DataLayerGroups; 
				//this._alertBox.prompt("executing create list");	
				this._beginCreateServiceList(arrDataLayerGroup, this);
			}));
			return deferred.promise;			//return a promise...the 'then()' code will be executed when the post is done
		},
		
		
		/*
		 * recursive method that goes through array of groups
		 * 
		 */
		
		_beginCreateServiceList: function(p_arrGroups, p_context)
		{
			array.forEach(p_arrGroups, function(p_currGroup){
				//currgroup is an object (nc4mapsLayerGroup)
				if(p_currGroup.name !== ("rootgroup"))
				{
					var ul = domConstruct.create("p", {innerHTML: "<b>" + p_currGroup.name + "</b> (Feature Service)" }, serviceList);
					//var ul = domConstruct.create("p", {innerHTML: "<br/><a href='" +  p_currGroup.id + "/FeatureServer?f=html'>" + p_currGroup.name + " (Feature Service)</a> "}, serviceList);
				}
				p_context._createServiceList(p_currGroup, p_context);
			});
		},
		
		
		/*
		 * Helper function that will never get called on its own.  Will process each group.
		 * 
		 */
		_createServiceList: function(p_data, p_context)
		{ 
			//takes in one nc4maps group
			var p_currGroup = p_data;
				
			if(p_currGroup != null && p_currGroup.layers != null && p_currGroup.layers.length > 0)				//check for layers
			{
				var currGroupLayers = p_currGroup.layers;
				array.forEach(currGroupLayers, function(p_layer){
					var li = domConstruct.create("li", {}, serviceList);
					var link = domConstruct.create("a", {href: p_layer.url + "?f=html", innerHTML: p_layer.name + " (Feature Layer)"}, li);
					//domConstruct.place(link, dojo.byId("serviceList"), "last");
				});
			}
			if(p_currGroup != null && p_currGroup.groups != null && p_currGroup.groups.length > 0)	//check for groups w/in groups
			{
				
				p_context._beginCreateServiceList(p_currGroup.groups, p_context);		
			}
		}
				
	})
	
});
		
	