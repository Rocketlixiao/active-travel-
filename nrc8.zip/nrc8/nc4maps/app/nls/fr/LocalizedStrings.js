define({
    application: {
        "applicationTitle": "NC4 Map Module"
    },
    basemap: {
        "firstBasemapLetter": "A",
        "secondBasemapLetter": "T",
        "thirdBasempaLetter": "R",
        "firstBasemapTooltip": "Aerial",
        "secondBasemapTooltip": "Topography",
        "thirdBasempaTooltip": "Roads"
    }
});
