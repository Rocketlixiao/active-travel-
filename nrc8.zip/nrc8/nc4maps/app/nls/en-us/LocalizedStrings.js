define({
    root: {
        application: {
            "applicationTitle": "NC4 Map Module"
        },
        AddressLocator: {
            "placeHolder": "Find an address or place",
            "infoWindowTitle": "Search Result"
        },
        LoadingShelter: {
            "lblLoading": "Loading"
        },
        Mylocation: {
            "errorMessages": "Location not found"
        },
        AddLayer: {
            "errorMessages": {
                "invalidURLError": "Invalid URL. Please enter a valid url.",
                "invalidFormatError": "Invalid Format. Please enter a valid format(.gif/.png/.bmp/.jpg).",
                "invalidFormat": "Invalid format.",
                "emptyUrl": "Please enter URL.",
                "emptyExtent": "Please fill the required fields.",
                "exceptionError": "Unable to add layer.",
                "featureCollectionError": "Error in downloading feature collection data.\nDetails:\n",
                "layerOptions": "Layer Options",
                "emptyLayer": "Please enter Layer name",
                "selectMapServer": "Please select Cached/Dynamic",
                "notCompatible": "Layer has been added, but is not compatible with the current base map."
            },
            "displayMessages": {
                "message": "What type of data are you referencing?",
                "layerUrl": "Layer Url:",
                "layermessage": "Layer Name:",
                "ImglayerUrl": "Image Url:",
                "Imagebounds": "Image Bounds to use:",
                "Size": "Image Size(Height,Width):",
                "LayerFormatType": "image/png",
                "LayerFormat": "Layer Format",
                "LayerProjectionName": "Projection",
                "LayerProjectionDescription": "Destination Projection same as projection",
                "layerAddas": "Add as",
                "Cached": "Cached",
                "Dynamic": "Dynamic",
                "AddBasemap": "Add as Basemap",
                "iconGeoRSS": "Icon:",
                "WmsMaxHeight": "Maximum Height (pixels)",
                "WmsMaxWidth": "Maximum Width (pixels)"
            },
            "layerSetting": {
                "layers": [{
                    "label": "An ArcGIS Server Map Service",
                    "value": "WebMapServer",
                    "sampleUrl": "e.g.&#32;http://&lt;ServerName&gt;/&lt;InstanceName&gt;/rest/services/&lt;ServiceName&gt;/&lt;MapServer&gt;/&lt;LayerId&gt;"
                }, {
                    "label": "An ArcGIS Server Feature Service",
                    "value": "WebService",
                    "sampleUrl": "e.g.&#32;http://&lt;ServerName&gt;/&lt;InstanceName&gt;/rest/services/&lt;ServiceName&gt;/&lt;FeatureServer&gt;/&lt;LayerId&gt;"
                }, {
                    "label": "An ArcGIS Feature Collection",
                    "value": "FeatureCollection",
                    "sampleUrl": "e.g. http://&lt;enter URL&gt;"
                }, {
                    "label": "A KML File",
                    "value": "KML",
                    "sampleUrl": "e.g. http://&lt;enter URL&gt;"
                }, {
                    "label": "GeoRSS Feed",
                    "value": "GeoRSSFeed",
                    "sampleUrl": "e.g.&#32;http://geocommons.com/overlays/188692.atom"
                }, {
                    "label": "WMS (Web Map Service)",
                    "value": "WebMapService",
                    "sampleUrl": "e.g. http://&lt;enter URL&gt;"
                }, {
                    "label": "Web Accessible Image",
                    "value": "WebAccessibleImage",
                    "sampleUrl": " "
                }, {
                    "label": "WMTS (Web Map Tiled Service)",
                    "value": "WebMapTiledService",
                    "sampleUrl": "e.g. http://&lt;enter URL&gt;"
                }, {
                    "label": "CSV Layer",
                    "value": "csvlayer",
                    "sampleUrl": "HINT : Please make sure the file consists of latitude and longitude values in SR 4326 "
                }],
                "btnAddLabel": "Add Layer"
            }
        },
        Bookmark: {
            "buttonAdd": "Add",
            "bookmarkName": "Bookmark Name",
            "emptyBookmark": "Please enter a bookmark name.",
            "saveBookmarkService": "Successfully saved bookmark(s).",
            "invalidService": "Bookmark service is not available.",
            "buttonSave": "Save",
            "buttonDelete": "Delete",
            "nameExists": "Name already exists. Please enter a different name.",
            "deleteBookmark": "OK to delete bookmark.",
            "emptySelectedBookmark": "Please select bookmark.",
            "errorBookmark": "Bookmark service unavailable.",
            "saveBookmark": "OK to save bookmark(s).",
            "errorBookmarkTextbox": "Special characters are not allowed.",
            "deleteBookmarkService": "Bookmark deleted successfully.",
            "noProjection": "No re-projection",
            "spatialReferenceError": "Unable to project current spatialReference to 4326"
        },
        Print: {
            "title": "Print",
            "printinfo": "Select layout and format to print map.",
            "printLayout": "Layout",
            "printFormat": "Format",
            "printMapButton": "Print Map",
            "printTitle": "Map Title",
            "emptyURL": "Please select the required fields.",
            "printOptions": "Print Options",
            "PrintError": "Print service is not available.",
            "PrintingAuthor": "Geared by NC4 "
        },
        ReverseGeocode: {
            "errorMessages": {
                "revGeocodeError": "Address not found. \nTry clicking on some other location or zoom-in to the map."
            },
            "infoTemplate": "Location"

        },
        Measurement: {
            "clearToolTip": "Reset",
            "measurementHint": "Click on the map to get coordinates:- "
        },
        Intersect: {
            "selectBoundingArea": "Select the bounding area: ",
            "layer": "Layer: ",
            "element": "Element: ",
            "applyIntersect": "Intersect",
            "selectOutputData": "Select output data (Layer):",
            "hint": "Use CTRL+CLICK for multiple selections",
            "hintRequired": "*You MUST select Report Id and Global Report Id if you plan to save results",
            "apply": "Apply",
            "select": "---Select---",
            "selectLayer": "Please select layer",
            "selectElement": "Please select element",
            "selectLayerAndElement": "Please select layer & element",
            "noResultsFound": "No result found",
            "lblCommonFields": "FIELDS COMMON TO SELECTED LAYERS",
            "lblElement": "   Select Element   ",
            "lblLayer": "   Select Layer   ",
            "all": "All",
            "perimeter": "Fire Perimeter",
            "notAddedOnMap": " layer not added on map.",
            "selectLayerAndFields": "Please select layer & Fields.",
            "selectOutputDataLayer": "Select output data (layer).",
            "selectFieldsForReport": "Select fields for report.",
            "selectBoundingLayer": "Select bounding area layer.",
            "selectBoundingElement": "Select bounding area element.",
            "addLayerOnMap": "Please add layer on map."
        },
        QueryBuilder: {
            "layoutName": "Attribute Query",
            "selectLayer": "Select Layer",
            "selectField": "Select Fields",
            "btnUniquevalue": "Get Unique Values",
            "btnVerify": "Verify",
            "btnSearch": "Search",
            "btnClear": "Clear",
            "btnEqual": "=",
            "btnGreaterlessthan": "<>",
            "btnLessthan": "<",
            "btnGreaterthanEqual": ">=",
            "btnUnderscore": "_",
            "btnPercentage": "%",
            "btnGreaterthan": ">",
            "btnLike": "Like",
            "btnLessthanEqual": "=<",
            "btnAnd": "And",
            "btnOpenBracket": "(",
            "btnClosedBracket": ")",
            "btnOr": "Or",
            "btnNot": "Not",
            "btnIs": "IsNull",
            "verifiedQuerySuccess": "Query successfully verified",
            "verifiedQueryError": "Query not verified",
            "queryError": "Service is not available ",
            "layerNotSelected": "Please select layer"
        },
        CustomIcons: {
            "height": "Height(px)",
            "width": "Width(px)",
            "select": "Select One",
            "reportType": "Report Type:",
            "customIcon": "Custom Icons:",
            "save": "Save",
            "subReportType": "Sub Report Type:",
            "status": "Status:",
            "selectReportType": "Please select report type",
            "SelectsubReportType": "Please select sub report type",
            "statusReport": "Please select status",
            "currentIcon": "Current Icon:",
            "selectOneIcon": "Please select any one icon",
            "saveSuccess": "Icon saved successfully",
            "saveError": "Unable to save the Icon",
            "validValues": "Please enter valid values"
        },
        DefaultOptions: {
            "defaultOption": "Default Options:",
            "cuurentBasemap": "Set current Base Map as default",
            "cuurentBookmark": "Set current Bookmark as default",
            "measuringUnit": "Measuring Unit",
            "defaultOpacity": "Initial Opacity for layers",
            "defaultRefreshRate": "Initial Refresh Rate for layers",
            "geocoderType": "Geocoder Type",
            "geocodeServiceURL": "Geocode Service URL:",
            "geocodeServiceKey": "Geocode Service Key",
            "geocodeMaxResults": "Maximum Geocode Results",
            "geocodeMinScore": "Minimum Score (ArcGIS Geocode Service Only)",
            "geometryServiceURl": "Geometry Service URL",
            "maxPointRequest" : "Max Points per Request",
            "intersectService": "ArcGIS Online Intersect Service",
            "customIntersectService": "Custom ArcGIS Intersect Service",
            "routingService": "Routing Service",
            "printServiceURL": "Print Service URL",
            "invalidFormat": "Please enter a valid number"
        },
        BasemapGallery: {
            "lblCustomBaseMap": "Custom Base Maps",
            "lblEsriBingBaseMap": "Base Maps"
        },
        StatusBar: {
            "error": "error in mouse-move operation"
        },
        DataLayer: {
            "turnOnLayer": "Please turn on the layer.",
            "saveLayer": "Layer saved successfully.",
            "deleteLayer": "Layer deleted successfully.",
            "unableToSave": "Unable to Save the layer.",
            "notChangeOpacityRefresh": "Cannot change the opacity and refresh rate for heat map.",
            "extentNotFound": "Layer Extent was not found.",
            "notAddedOnMap": "Layer was not added on the map.",
            "conformToDelete": "Click OK to delete layer.",
            "notCompatible": "Non-compatible Layer(s) exists.  Please see Data Layer Tree for more details."
        },
        Common: {
        	"wmsPartialNotSupported": "Several WMS Data Layers may not be compatible while current base map is in use."
        }
    }
    // TODO: define other locales as needed
});
