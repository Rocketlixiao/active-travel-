/* called from index.html.  This module loads other modules, so index.html does not need a callback.  This also is a singleton (doesn't return declare function), which makes sense since it is the main
 * entry point
 */
define.amd.jQuery = true;

define([
  "dijit/registry",
  "app/coreLibrary/Utils",
  "app/widgets/Map/Map",
  "dojo/i18n!app/nls/LocalizedStrings",
  "dojo/aspect",
  "dojo/_base/lang",
  "dojo/promise/all",
  "dojo/_base/array",	//can possible replace with standard javascript array function
  "dojo/Deferred",
  "dojo/on",
  "loglevel/loglevel",
  "esri/dijit/Scalebar",
  "esri/request",
  "esri/config",
  "esri/tasks/GeometryService",
  "esri/urlUtils",
  "esri/graphicsUtils",
  "app/widgets/Notifications/NC4Notification",
  //"esri/geometry/Point",	//TODO: Load only on showlocation
  //"esri/symbols/PictureMarkerSymbol",	//TODO: Load only on showlocation
  //"esri/graphic",		//TODO: Load only on showlocation
  "esri/geometry/Extent",
  //"esri/SpatialReference",  //TODO: Load only on showlocation
  //"esri/geometry/webMercatorUtils", //TODO: Load only on showlocation
  //"dojo/number",  //TODO: Load only on showlocation
  //"esri/tasks/ProjectParameters",  //TODO: Load only on showlocation    
  "esri/geometry/Point",
  "esri/SpatialReference",
  "app/widgets/Map/NC4Cluster",
  "dojo/domReady!",
  "esri/IdentityManager",
  "dijit/Dialog"

], function (registry, Utils, Map, LocalizedStrings, aspect, lang, all, array, Deferred, on, log, Scalebar, esriRequest, esriConfig, GeometryService, urlUtils, graphicsUtils, NC4Notification, Extent, Point, SpatialReference, NC4Cluster, Dialog) {
  //init global map parameters
  globalConfig.esriPoint = Point;
  globalConfig.esriSpatialReference = new SpatialReference({ wkid: 4326 });
  globalConfig.esriExtent = Extent;

  var url = location.href.toString();
  var urlObject = urlUtils.urlToObject(url), queryParam = null, mapMode = null;
  if (urlObject.query) {
    queryParam = urlObject.query;
    mapMode = queryParam.mapMode;
  }

  var _nc4Notify = new NC4Notification();


  esriRequest({
    //url: "../nc4maps/rest/default/read?mode=" + mapMode, //TODO, for RC, would have to add 'baseUrl' variable or something since it will be embedded ... TODO
    url: "/nrc8/nc4maps/rcAngular.json",// current map Mode is standard.
    content: lang.mixin({
      f: "jsonp"
    }, null),
    callbackParamName: "callback",
    load: lang.hitch(this, function (response) {

      response.configs = response;
      if (!response.configs) {
        log.error("application configuration is missing in map mode service, hence unable to launch map component.");
        return;
      }
      /*
       * The response object will consist of default database values, as well as a config object (values from prop file)
       */
      var config = response.configs;
      //config.generalSettings.proxyPageURL = "proxy.ashx";
      /**
       * Set the loglevel from config file.
       */
      var loglevel = config.generalSettings.logLevel ? config.generalSettings.logLevel : "ERROR";
      log.setLevel(loglevel);

      var utils = new Utils();
      utils.setLog(log);
      //set the default values from the properties file first!
      utils.configGeneralSettings = config.generalSettings;
      utils.setNc4Notify(new NC4Notification);
      this._nc4Notify = utils.nc4Notify;
      /*
       * james - overwrite the default values if the database values exist
       */
      utils.configGeneralSettings.mapMode = mapMode;
      if (response.routingServiceUrl && response.routingServiceUrl != "")
        utils.configGeneralSettings.routingServiceUrl = response.routingServiceUrl;
      if (response.printServiceUrl && response.printServiceUrl != "")
        utils.configGeneralSettings.printService = response.printServiceUrl;

      if (response.geometryServiceUrl && response.geometryServiceUrl != "")
        utils.configGeneralSettings.geometryServiceURL = response.geometryServiceUrl;

      if (response.maxPtPerRequest > 0)
        utils.configGeneralSettings.maxPointRequest = response.maxPtPerRequest;
      else
        utils.configGeneralSettings.maxPointRequest = 1500

      if (response.geocodeUrl && response.geocodeUrl != "")
        utils.configGeneralSettings.geocodeUrl = response.geocodeUrl;
      if (response.geocodeScore && response.geocodeScore != "")
        utils.configGeneralSettings.geocodeScore = response.geocodeScore;
      if (response.geocodeResults && response.geocodeResults != "")
        utils.configGeneralSettings.geocodeResults = response.geocodeResults;
      if (response.defaultRefRate && response.defaultRefRate != "")
        utils.configGeneralSettings.defaultRefRate = response.defaultRefRate;
      if (response.defaultOpacity && response.defaultOpacity != "")
        utils.configGeneralSettings.defaultOpacity = response.defaultOpacity;

      if (response.defaultMeasUnit && response.defaultMeasUnit != "")
        utils.configGeneralSettings.defaultMeasUnit = response.defaultMeasUnit;
      if (response.defaultOpacity && response.defaultOpacity != "")
        utils.configGeneralSettings.defaultOpacity = response.defaultOpacity;
      if (response.defaultRefRate && response.defaultRefRate != "")
        utils.configGeneralSettings.defaultRefRate = response.defaultRefRate;
      if (response.geocodeUrl && response.esriGeocodeServiceURL != "")
        utils.configGeneralSettings.esriGurl = response.esriGeocodeServiceURL;

      if (utils.configGeneralSettings.popupStyle && utils.configGeneralSettings.popupStyle != "") {
        //"app/stylesheets/rcStylesLegacy.css"
        var fileref = document.createElement("link");
        fileref.setAttribute("rel", "stylesheet");
        fileref.setAttribute("type", "text/css");
        fileref.setAttribute("href", utils.configGeneralSettings.popupStyle);
        if (typeof fileref != "undefined")
          document.getElementsByTagName("head")[0].appendChild(fileref);
      }

      //check if bookmark was saved to db, if not, zoom to initial extent of map service
      if (response.bookmark) {
        var dbBookmark = response.bookmark;

        if (dbBookmark.id && dbBookmark.id != "")
          utils.configGeneralSettings.defaultBookmark = dbBookmark.id;
        if (dbBookmark.name && dbBookmark.name != "")
          utils.configGeneralSettings.defaultBookmarkName = dbBookmark.name;
        if (dbBookmark.extent) {
          var dbExtent = dbBookmark.extent;
          if (dbExtent.xmin && dbExtent.xmin != "" && dbExtent.ymin && dbExtent.ymin != "" && dbExtent.ymax && dbExtent.ymax != "" && dbExtent.xmax && dbExtent.xmax != "" &&
            dbExtent.spatialReference && dbExtent.spatialReference.wkid && dbExtent.spatialReference.wkid != "") {
            var dbInitialExtent = dbExtent.xmin + "," + dbExtent.ymin + "," + dbExtent.xmax + "," + dbExtent.ymax;
            utils.configGeneralSettings.defaultBookmarkExtent = dbInitialExtent;

            utils.configGeneralSettings.defaultBookmarkSr = dbExtent.spatialReference.wkid;
          }
        }

      }
      //check for database value
      if (response.basemap) {
        var dbBasemap = response.basemap;
        if (dbBasemap.id && dbBasemap.id != "" && dbBasemap.id != null) {
          log.debug("id is valid, saving");
          utils.configGeneralSettings.defaultBaseMap = dbBasemap.id;
          if (dbBasemap.name && dbBasemap.name != "")
            utils.configGeneralSettings.defaultBaseMapName = dbBasemap.name;
          if (dbBasemap.url && dbBasemap.url != "")
            utils.configGeneralSettings.defaultBaseMapUrl = dbBasemap.url;
          if (dbBasemap.isCached && dbBasemap.isCached != "")
            utils.configGeneralSettings.defaultBaseMapCached = dbBasemap.isCached;
        }
        else {
          log.debug("id, not valid, attempting to get saved gallery id");
          //if the id of the basemap db was null, check basemap from online gallery:
          if (response.defaultBaseMap && response.defaultBaseMap != "" && response.defaultBaseMap != null) {
            log.debug("basemap obj exist, but id was not valid.  Saved gallery basemap is : " + response.defaultBaseMap);
            utils.configGeneralSettings.defaultBaseMap = response.defaultBaseMap;
          }
        }

      }
      else {
        //if the basemap object doesn't exist for some reason, check if a basemap id exist (not an object), which is from the basemap gallery:
        if (response.defaultBaseMap && response.defaultBaseMap != "" && response.defaultBaseMap != null) {
          log.debug("setting to gallery bm, as default: " + response.defaultBaseMap);

          utils.configGeneralSettings.defaultBaseMap = response.defaultBaseMap;
        }
      }

      //save the initial basemap, in case the user updates default options but doesn't want to update the basemap.
      utils.configGeneralSettings.initialBaseMap = utils.configGeneralSettings.defaultBaseMap;

      //james - when is this ever called?
      app.setEsriAPIDefaults = (function () {
        /**
        * Accessing geometry service from config file
        * The Geometry service is used by application developers to perform geometric calculations and web editing.
        */
        if (config.generalSettings.geometryServiceURL) {
          esriConfig.defaults.geometryService = new GeometryService(config.generalSettings.geometryServiceURL);
        } else {
          log.warn("Geometry Service URL is not configured.");
        }
        esriConfig.defaults.io.corsDetection = false;
        esriConfig.defaults.io.timeout = 300000;
        /**
        * Accessing proxy file url from config file.
        */
        if (config.generalSettings.proxyPageURL) {
          esriConfig.defaults.io.proxyUrl = config.generalSettings.proxyPageURL;
        } else {
          log.warn("Proxy page url is not set.");
        }
      })();



      if (dijit.byId("mapContainerNode")) {
        dijit.byId("mapContainerNode").destroyRecursive();
      }
      /**
      * Instantiated the map. Place in the 'mapContainerNode' div
      * James - this creates the new widgets/Map/Map.js object, 
      * It passes in the attributes that can directly be used in the Map object. 
      */
      app.map = new Map({
        config: config,
        LocalizedStrings: LocalizedStrings,
        appUtils: utils,
        mode: mapMode
      }, "mapContainerNode");							//this should be a variable that is used throughout the app TODO: replace mapContainerNode with var from configurations
      log.info("Map instantiated.");
      var scalebar = new Scalebar({
        map: app.map.map,
        scalebarStyle: "line",
        scalebarUnit: "dual",
        attachTo: "bottom-left"
      });
      on(app.map.map, "load", function () {

        app.loadFloatingWidgets = (function () {
          var widgets = {},
            deferredArray = [];
          var navExist = false;
          var deferred = new Deferred();
          var widgetConfig = config.FloatingWidgets[0];
          require([widgetConfig.WidgetPath, "dojo/dom-style"], function (Widget, domStyle) {

            widgets[widgetConfig.WidgetPath] = new Widget({
              map: app.map.map,
              config: widgetConfig,
              appUtils: utils
            });


          });

          // TODO - create a showLocation object?
          if (mapMode === "showLocation") {
            require(["esri/geometry/Point", "esri/symbols/PictureMarkerSymbol", "esri/graphic", "esri/SpatialReference", "esri/geometry/webMercatorUtils",
              "dojo/number", "esri/tasks/ProjectParameters"], function (Point, PictureMarkerSymbol,
                Graphic, SpatialReference, webMercatorUtils, number, ProjectParameters) {
                //TODO - take into consideration SR ? make it a requirement ?
                var latitude = null, longitude = null, sr = null;
                if (queryParam.latitude || queryParam.y) {
                  latitude = queryParam.latitude || queryParam.y;
                }
                if (queryParam.longitude || queryParam.x) {
                  longitude = queryParam.longitude || queryParam.x;
                }
                if (queryParam.sr) {
                  sr = new SpatialReference({ wkid: queryParam.sr });
                }
                else {
                  //TODO create status area notificaiton, defaulting to current sr of map
                  sr = app.map.map.spatialReference;
                }
                log.debug("sr: ", sr);

                var validLat = !isNaN(parseFloat(latitude)) && isFinite(latitude);
                var validLong = !isNaN(parseFloat(longitude)) && isFinite(longitude);
                if (!latitude || !longitude) {
                  alertBox.prompt("Coordinate values are required parameters, please contact your NC4 Maps support.");
                  return;
                }
                if (!validLat || !validLong) {
                  alertBox.prompt("Coordinate values are not valid");
                  return;
                }
                var symbol = new PictureMarkerSymbol({
                  "url": "./app/images/popupSymbol.png",
                  "height": 20,
                  "width": 15
                });
                var point = new Point(longitude, latitude, sr);
                log.debug("point: ", point);


                log.debug("curr extent: ", app.map.map.extent)
                log.debug(" sr: " + app.map.map.spatialReference.wkid);

                var currSR = app.map.map.spatialReference;

                if (sr.wkid == currSR.wkid) {
                  log.debug("request projection is the same as current projection");

                  var pointsame = new Point([longitude, latitude]);
                  log.debug("pointsame: ", pointsame);
                  app.map.map.graphics.add(new Graphic(pointsame, symbol));	//for some reason, couldn't add the Point using the constructor with the sr, so did it this way
                  app.map.map.centerAndZoom(new Point(parseFloat(pointsame.x), parseFloat(pointsame.y), pointsame.spatialReference), //for some reason, the coordinates in the point same were strings
                    number.format((app.map.map.getMaxZoom() / 2), { places: 0 }));

                }
                else if (sr.wkid == "4326") {
                  if (currSR.wkid == "102100" || currSR.wkid == "102113" || currSR.wkid == "3857" || currSR.wkid == "3785") {
                    //lat lon to web mercator
                    var projectedPoint = webMercatorUtils.geographicToWebMercator(point);
                    log.debug("projectedPoint 1: ", projectedPoint);
                    app.map.map.graphics.add(new Graphic(projectedPoint, symbol));
                    //var newExtent = new Extent(projectedPoint.x - 1,projectedPoint.y - 1,projectedPoint.x + 1,projectedPoint.y + 1, currSR);
                    app.map.map.centerAndZoom(projectedPoint, number.format((app.map.map.getMaxZoom() / 2), { places: 0 }));
                    //log.debug("newExtent: " , newExtent);
                    //app.map.map.setExtent(newExtent);
                  }
                  else {
                    var params = new ProjectParameters();
                    params.geometries = [point];
                    params.outSR = new SpatialReference(currSR.wkid);
                    //callsite
                    this.gsvc = new GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL);
                    gsvc.project(params, lang.hitch(this, function (geometries) {
                      log.debug("geometrys: ", geometries);
                      app.map.map.centerAndZoom(geometries, number.format((app.map.map.getMaxZoom() / 2), { places: 0 }));

                    }), lang.hitch(this, function (error) {
                      this._nc4Notify.error("unable to show location due to failed coordinate conversion");
                    }));
                    //new SR and current SR is not the same, and it is not geographic to web mercator, use geometry service

                  }
                  //app.map.map.setExtent( new Extent(projectedPoint.x,projectedPoint.y,projectedPoint.x, projectedPoint.y,
                  //new SpatialReference({ wkid:4326 })), true );
                }
                //else if web mercator
                //{}
                else if (sr.wkid == "102100" || sr.wkid == "102113" || sr.wkid == "3857" || sr.wkid == "3785") {
                  //if web mercator to lat lon
                  if (currSR.wkid == "4326") {
                    var geographicPoint = webMercatorUtils.webMercatorToGeographic(point);
                    log.debug("geographicPoint: ", geographicPoint);
                    app.map.map.graphics.add(new Graphic(geographicPoint, symbol));
                    app.map.map.centerAndZoom(geographicPoint, number.format((app.map.map.getMaxZoom() / 2), { places: 0 }));


                  }
                  else {
                    //request sr is webmercator and current map sr is a custom SR (non lat lon / web mercator)
                    var params = new ProjectParameters();
                    params.geometries = [point];
                    params.outSR = new SpatialReference(currSR.wkid);
                    //callsite
                    this.gsvc = new GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL);
                    geometryService.project(params, lang.hitch(this, function (geometries) {
                      log.debug("geometrys: ", geometries);
                      app.map.map.centerAndZoom(geometries, number.format((app.map.map.getMaxZoom() / 2), { places: 0 }));
                    }), lang.hitch(this, function (error) {
                      this._nc4Notify.error("unable to show location due to failed coordinate conversion");
                    }));
                  }
                }
                else {
                  //passed in coords is custom SR, and curr SR is not a custom SR, so need geom service to convert
                  var params = new ProjectParameters();
                  params.geometries = [point];
                  params.outSR = new SpatialReference(currSR.wkid);
                  //callsite
                  this.gsvc = new GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL);
                  geometryService.project(params, lang.hitch(this, function (geometries) {
                    log.debug("geometrys: ", geometries);
                    app.map.map.centerAndZoom(geometries, number.format((app.map.map.getMaxZoom() / 2), { places: 0 }));

                  }), lang.hitch(this, function (error) {
                    this._nc4Notify.error("unable to show location due to failed coordinate conversion");
                  }));
                }

              });

          }
          all(deferredArray).then(lang.hitch(this, function () { }));
        })();

        app.clusterMgr = new NC4Cluster({
          map: app.map.map,
          appUtils: utils
        });
      });
      app.map.addBaseMapLayer();

      if (response.configs.appHeaderType != null && response.configs.appHeaderType == "none") {
        //no header, so map goes all the way to the top of the window.

        require(["dojo/dom", "dojo/dom-style"], function (dom, domStyle) {
          var header = dom.byId("headerNC4Maps");
          domStyle.set(header, "height", "0px");
          domStyle.set(header, "display", "none");
          var mapContainer = dom.byId("mapContainerNode");
          domStyle.set(mapContainer, "height", "100%");
        });

        //use up whole screen, this means that we need to adjust map div to use up whole window (mess with mapContainerNode)
      }
      else if (response.configs.appHeaderType != null && response.configs.appHeaderType == "custom") {

        require(["dojo/dom", "dojo/dom-style"], function (dom, domStyle) {
          var header = dom.byId("headerNC4Maps");
          domStyle.set(header, "height", "0%");
          domStyle.set(header, "display", "none");
          var mapContainer = dom.byId("mapContainerNode");
          domStyle.set(mapContainer, "height", "100%");
        });
      }
      else {
        //default case
        require(["app/widgets/AppHeader/AppHeader"], function (AppHeader) {

          app.appHeader = new AppHeader({
            config: config,
            appUtils: utils
          });
          app.appHeader.loadHeaderWidgets(app.map.map);
          log.debug("appHeader: ", app.appHeader);
        });

      }
      return app;
    }),
    error: lang.hitch(this, function (err) {
      log.error("err: ", err);
      alert(err);
    })
  });
});







