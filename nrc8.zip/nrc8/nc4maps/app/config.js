define([], function() {
    var baseUrl = "http://demo4.nc4.us/eteamTraining/nc4maps/";
    return {
        generalSettings: {
            /*
            Requirement:
            1. Basemap defined here is assumed to be a cached ArcGIS Map Service.
            2. To support different type of map, code has to be modified.
            3. All basemap are assumed to be in same spatial reference.
            4. Only one basemap can be set as default. If multiple default basemap are set to default fist default basemap will be given preference.
            5. If default is not defined first basemap defined here will be considered as default
            */
            basemaps: [{
                "url": "http://services.arcgisonline.com/arcgis/rest/services/World_Street_Map/MapServer",
                "isDefault": false
            }, {
                "url": "http://services.arcgisonline.com/arcgis/rest/services/World_Topo_Map/MapServer",
                "isDefault": true
            }, {
                "url": "http://services.arcgisonline.com/arcgis/rest/services/World_Imagery/MapServer",
                "isDefault": false
            }],
            /*
            Use following application to get the extent:
            http://psstl.esri.com/apps/extenthelper/
            Extent should be define in basemap spatial reference.
            */
            defaultExtent: "-17635551.16595117,1139187.8777356804,-4270689.6443482265,7117174.985861156",

            defaultBookmark: "test Base map",
            defaultBaseMap: "10",
            defaultMeasUnit: "metrics",
            defaultOpacity: "1",
            defaultRefRate: "10",
            geocodeService: "bing",
            geocodeUrl: "test geocode service",
            geocodeKey: "test geocode key",
            geocodeScore: 0,
            geocodeResults: 0,
            geometryServiceUrl: "test geometry service",
            routingServiceUrl: "routing service",
            printServiceUrl: "test print",
            onlineIntersectService: "test online intersect service",
            customIntersectService: "test custom intersect",

            /*
            Specify the spatial reference for the extent.
            */
            defaultExtentSpatialRef: "102100",

            /*Service will be default either Esri or Bing or Google*/
            service: "Esri",

            /**
             * Esri Geocode service is required for: -
             * Geocoding (address to co-ordinates)
             * Reverse geocoding (co-ordinates to address) operations.
             */
            esriGeocodeServiceURL: "http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer",

            /**
             * Esri Geocode service is required for: -
             * Reverse geocoding (co-ordinates to address) operation.
             */
            bingGeocodeServiceURL: "http://dev.virtualearth.net/REST/v1/Locations/",

            /**
             * Esri Geocode service is required for: -
             * Reverse geocoding (co-ordinates to address) operation.
             */

            bingAccessKey: "AhbeoOinKb6Xem0M7a6Fug0-60OggkzXRXVl-9nnwFK7rBAVrV1HiJXYoFO6oRXO",

            /*Print service are required for the Print widget*/
            printService: "http://sampleserver6.arcgisonline.com/arcgis/rest/services/Utilities/PrintingTools/GPServer/Export%20Web%20Map%20Task",

            /*Geometry Service URL*/
            geometryServiceURL: "http://tasks.arcgisonline.com/ArcGIS/rest/services/Geometry/GeometryServer",

            //Proxy page should be hosted on same server where application is hosted.
            proxyPageURL: "proxy.ashx",

            /*
            Following log levels are supported. Useful for troubleshooting the deployed application during support phase.
            "TRACE" 
            "DEBUG" 
            "INFO" 
            "WARN"
            "ERROR" 
            "SILENT"
            Default value will be ERROR.
            */
            logLevel: "INFO"
        },

        // Set application title
        ApplicationName: "Map Component",

        AppHeaderWidgets: [{
            WidgetPath: "app/widgets/Print/Print",
            label: "Print"
        }, {
            WidgetPath: "app/widgets/DefaultOptions/DefaultOptions",
            label: "Default Options",
            MeasuringUnit: ["English", "Metrics"],
            GeocoderType: ["ArcGis World Geocode Service", "Bing Location Service", "Custom ArcGIS Location Service"],
            saveDefaultsOptions: baseUrl + "rest/default/save"
        }, {
            WidgetPath: "app/widgets/BasemapGallery/BasemapGallery",
            label: "Basemap Gallery",
            CustomBasemapDeleteService: baseUrl + "rest/services/customLayerRemove",
            CustomBasemapRetriveService: baseUrl + "rest/layertree/custom/basemaps",
            basemapGallery: {
                showArcGISBasemaps: false,
                basemaps: [{
                    "layers": [{
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/world_street_map.jpg",
                    "title": "Streets"
                }, {
                    "layers": [{
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/imagery.jpg",
                    "title": "Imagery"
                }, {
                    "layers": [{
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/NatGeo_World_Map/MapServer"
                    }],
                    "title": "National Geographic",
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/natgeo.jpg"
                }, {
                    "layers": [{
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/topo_map_2.jpg",
                    "title": "World Topographic"
                }, {
                    "layers": [{
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/Ocean_Basemap/MapServer"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/Ocean.jpg",
                    "title": "Ocean"
                }, {
                    "layers": [{
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/World_Shaded_Relief/MapServer"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/World_Shaded_Relief.jpg",
                    "title": "World Shaded Relief"
                }, {
                    "layers": [{
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/World_Physical_Map/MapServer"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/World_Physical_Map.jpg",
                    "title": "World Physical Map"
                }, {
                    "layers": [{
                        "url": "http://server.arcgisonline.com/ArcGIS/rest/services/World_Terrain_Base/MapServer"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/World_Terrain_Base.jpg",
                    "title": "World Terrain Base"
                }, {
                    "layers": [{
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer"
                    }, {
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Reference/MapServer"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/World_Light_Gray.jpg",
                    "title": "World Light Gray"
                }, {
                    "layers": [{
                        "url": "http://services.arcgisonline.com/ArcGIS/rest/services/USA_Topo_Maps/MapServer"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/USA_Topo_Maps.jpg",
                    "title": "USA Topographic"
                }, {
                    "layers": [{
                        "url": "http://mapsurl.appspot.com/bing/#011DAusmkFkl8uFAAAA",
                        "type": "BingMapsRoad"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/bing_road_map.jpg",
                    "title": "Bing-Road"
                }, {
                    "layers": [{
                        "url": "http://mapsurl.appspot.com/bing/#013DAusmkFkl8uFAAAA",
                        "type": "BingMapsAerial"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/bing_arial_map.jpg",
                    "title": "Bing-Aerial"
                }, {
                    "layers": [{
                        "url": "http://mapsurl.appspot.com/bing/#014DAusmkFkl8uFAAAA",
                        "type": "BingMapsHybrid"
                    }],
                    "thumbnailUrl": "app/widgets/BasemapGallery/images/bing_hybrid_map.jpg",
                    "title": "Bing-Aerial with Labels"
                }],
                bingMapsKey: "AhbeoOinKb6Xem0M7a6Fug0-60OggkzXRXVl-9nnwFK7rBAVrV1HiJXYoFO6oRXO"
            }
        }, {
            WidgetPath: "app/widgets/Bookmark/Bookmark",
            bookmarkService: baseUrl + "rest/bookmarks",
            deleteBookmarkService: baseUrl + "rest/bookmarks/customBookmarkRemove",
            saveBookmarkServiceUrl: baseUrl + "rest/bookmarks/customBookmarkAdd",
            label: "Bookmark"
        }, {
            WidgetPath: "app/widgets/Directions/Directions",
            label: "Directions",
            routeService: "route.arcgis.com", //Route and traffic service are mandatory for direction widget
            trafficService: "traffic.arcgis.com"
        }, {
            WidgetPath: "app/widgets/Measurement/Measurement",
            label: "Measurement"
        }, {
            WidgetPath: "app/widgets/Locate/Locate",
            label: "Locate"
        }, {
            WidgetPath: "app/widgets/Intersect/Intersect",
            label: "Intersect",
            exportToCSV: baseUrl + "rest/jsontocsv",
            saveResults: "http://demo4.nc4.us/eteamTraining/atlas/intersectLayersSave.jsp"
        }, {
            WidgetPath: "app/widgets/Draw/Draw",
            label: "Draw",
            createOverlayURL: baseUrl + "rest/nc4mapsOverlay/write",
            responseOverlayURL: baseUrl + "rest/nc4mapsOverlay/read?id=",
            createOverlayLabel: "Create Overlay Layer",
            saveOverlayLabel: "Save Overlay",
            saveOverlayPlaceHolder: "Overlay Layer Name",
            overlayMessage: "Please use the below mentioned tools for drawing"
        }, {
            WidgetPath: "app/widgets/QueryBuilder/QueryBuilder",
            label: "Attribute Query",
            exportToCSV: baseUrl + "rest/jsontocsv"
        }, {
            WidgetPath: "app/widgets/WidgetGallery/WidgetGallery",
            label: "More"
        }, {
            WidgetPath: "app/widgets/CustomIcons/CustomIcons",
            label: "Custom Icons",
            iconSuggestURL: baseUrl + "rest/icon/iconSuggest",
            setCustomIconURL: baseUrl + "rest/icon/setCustomIcon",
            uniqueValueIconURL: baseUrl + "rest/icon/uniqueValueIcon",
            iconStatusURL: baseUrl + "rest/icon/field3",
            subReportTypeURL: baseUrl + "rest/icon/field2",
            reportTypeURL: baseUrl + "rest/icon"
        }, {
            WidgetPath: "app/widgets/AddLayer/AddLayer",
            label: "Add Layer",
            defaultOpacity: "100",
            defaultRefRate: "10",
            CustomLayerTreeLayerService: baseUrl + "rest/layertree/custom/datalayers",
            CustomBasemapSaveService: baseUrl + "rest/services/customLayersAdd"
        }, {
            WidgetPath: "app/widgets/Legend/Legend",
            label: "Legend"
        }, {
            WidgetPath: "app/widgets/DataLayers/DataLayers",
            LayerTreeService: baseUrl + "rest/layertree",
            CustomLayerTreeService: baseUrl + "endpoint/demolayertree.json",
            CustomLayerSaveService: baseUrl + "rest/services/customLayersAdd",
            CustomLayerDeleteService: baseUrl + "rest/services/customLayerRemove",
            CustomLayerUpdateService: baseUrl + "rest/services/customLayerUpdate",
            BussinessLayerUpdateService: baseUrl + "rest/services/reportLayerUpdateById",
            OverlayUpdateService: baseUrl + "rest/nc4mapsOverlay/update",
            OverlayDeleteService: baseUrl + "rest/nc4mapsOverlay/delete",
            OverlayURL: baseUrl,
            label: "Data Layers"
        }],
        FloatingWidgets: [{
            WidgetPath: "app/widgets/ReverseGeocode/ReverseGeocode",
            label: "ReverseGeocode"
        }, {
            WidgetPath: "app/widgets/Navigation/Navigation",
            label: "Navigation"
        }, {
            WidgetPath: "app/widgets/AddressLocator/AddressLocator",
            label: "AddressLocator"
        }, {
            WidgetPath: "app/widgets/MyLocation/MyLocation",
            label: "MyLocation"
        }, {
            WidgetPath: "app/widgets/StatusBar/StatusBar",
            label: "StatusBar"
        }, {
            WidgetPath: "app/widgets/BookmarkRefresh/BookmarkRefresh",
            label: "BookmarkRefresh"
        }, {
            WidgetPath: "app/widgets/ZoomHistory/ZoomHistory",
            label: "ZoomHistory"
        }, {
            WidgetPath: "app/widgets/Help/Help",
            label: "Help"
        }]
    };
});
