define([
    "app/config",
    "app/coreLibrary/Utils",
    "app/widgets/Map/Map",
    "app/widgets/AppHeader/AppHeader",
    "dojo/i18n!app/nls/LocalizedStrings",
    "dojo/_base/lang",
    "dojo/promise/all",
    "dojo/_base/array",
    "dojo/Deferred",
    "dojo/on",
    "loglevel/loglevel",
    "esri/config",
    "esri/tasks/GeometryService",
    "dojo/domReady!"
], function(config, Utils, Map, AppHeader, LocalizedStrings, lang, all, array, Deferred, on, log, esriConfig, GeometryService) {
    var app = {};
    /**
     * Set the loglevel from config file.
     */
    var loglevel = config.generalSettings.logLevel ? config.generalSettings.logLevel : "ERROR";
    log.setLevel(loglevel);
    var utils = new Utils();
    utils.configGeneralSettings = config.generalSettings;
    app.setEsriAPIDefaults = (function() {
        /**
         * Accessing geometry service from config file
         * The Geometry service is used by application developers to perform geometric calculations and web editing.
         */
        if (config.generalSettings.geometryServiceURL) {
            esriConfig.defaults.geometryService = new GeometryService(config.generalSettings.geometryServiceURL);
        } else {
            log.warn("Geometry Service URL is not configured.");
        }
        esriConfig.defaults.io.corsDetection = false;
        /**
         * Accessing proxy file url from config file.
         */
        if (config.generalSettings.proxyPageURL) {
            esriConfig.defaults.io.proxyUrl = config.generalSettings.proxyPageURL;
        } else {
            log.warn("Proxy page url is not set.");
        }
    })();
    /**
     * Instantiated the map.
     */
    app.map = new Map({
        config: config,
        LocalizedStrings: LocalizedStrings,
        log: log,
        appUtils: utils
    }, "mapContainerNode");
    log.info("Map instantiated.");

    on(app.map.map, "load", function() {
        app.loadFloatingWidgets = (function() {
            var widgets = {},
                deferredArray = [];
            array.forEach(config.FloatingWidgets, function(widgetConfig) {
                var deferred = new Deferred();
                widgets[widgetConfig.WidgetPath] = null;
                require([widgetConfig.WidgetPath], function(Widget) {
                    widgets[widgetConfig.WidgetPath] = new Widget({
                        map: app.map.map,
                        config: widgetConfig,
                        appUtils: utils
                    });
                    deferred.resolve(widgetConfig.WidgetPath);
                });
                deferredArray.push(deferred.promise);
            });
            all(deferredArray).then(lang.hitch(this, function() {}));
        })();
    });

    app.map.addBaseMapLayer();

    window.onbeforeunload = function(e) {
        if (utils.customLayerCount) {
            e = e || window.event;
            // For IE and Firefox prior to version 4
            if (e) {
                e.returnValue = "You made changes to 'Settings' and did not save. Do you still wish to close the window?";
            }
            // For Safari
            return "You made changes to 'Settings' and did not save. Do you still wish to close the window?";
        }
    };

    app.appHeader = new AppHeader({
        config: config,
        appUtils: utils
    });
    app.appHeader.loadHeaderWidgets(app.map.map);

    return app;
});
