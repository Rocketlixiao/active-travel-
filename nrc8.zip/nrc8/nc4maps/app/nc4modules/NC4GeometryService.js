//NC4GeometryService.js
define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "esri/tasks/ProjectParameters",    
    "esri/tasks/GeometryService",
    "esri/geometry/webMercatorUtils",
    "esri/request"
], function(declare, lang, ProjectParameters, GeometryService, webMercatorUtils, esriRequest) {
	return declare([], {
		
	
	/*
	 * This module is responsibile for encapsulating a geometry service utility class
	 * 
	 */
	externalGeometryServiceUrl: "",	
	gsvc: null,
	appUtils: null,
		
	//this.appUtils.configGeneralSettings.geometryServiceURL
	constructor: function(p_externalGeometryService, p_appUtils)
	{
		this.externalGeometryServiceUrl = p_externalGeometryService;
		this.gsvc = new GeometryService(p_externalGeometryService);
		this.appUtils = p_appUtils;
		console.log("nc4 geometry service created: this: ", this);
	},
	
	/*
	 * similiar to ESRI's project, but first attempt to use the built in client side services (4326 <--> 102100 conversions)
	 * params:
	 * p_projectParam: ESRI ProjectParameter object
	 * p_contextObj: the context in which to execute the callback functions
	 * p_callback: the callback function that will be executed after successful projecting
	 * p_errback: the callback function that will be executed after an error
	 * returns:
	 * 		Array of Geometries
	 */
	project: function(p_projectParam, p_contextObj, p_callBack, p_errBack, p_disabled)		//accept ProjectParameter instead
	{
		if(p_disabled && p_disabled == true)
		{
			//quick way to temporarily/permanently disable this service, just call callback:
			this.appUtils.log.debug("nc4project: request for project for disabled feature");
    		var callback = lang.hitch(p_contextObj, p_callBack);
    		callback(p_projectParam.geometries);
    		return;
		}
		console.log("NC4Geometry.project: ProjectParams: " , p_projectParam);
		var geometries = p_projectParam.geometries;
    	var inputGeomSR = geometries[0].spatialReference;
    	var inWkid = inputGeomSR.wkid;
    	var outSR = p_projectParam.outSR;
    	var outWkid = outSR.wkid;
    	
    	if(inWkid == outWkid)
    	{
    		this.appUtils.log.debug("nc4project: Incoming SR equals outgoing SR, returning original geometries");
    		var callback = lang.hitch(p_contextObj, p_callBack);
    		callback(geometries);
    	}
    	else if(inWkid == 4326 && outSR.isWebMercator())
    	{
    		this.appUtils.log.debug("nc4project: Incoming SR is 4326, outgoing is mercator");
    		this.appUtils.log.debug("nc4project: currentGeomes: ", geometries);
    		
    		var updatedGeometries = [];
    		for(var i = 0; i<geometries.length; i++)
    		{
    			updatedGeometries[i] = webMercatorUtils.geographicToWebMercator(geometries[i]);   

    		}
    		this.appUtils.log.debug("nc4project: updatedGeoms: ", updatedGeometries);
    		var callback = lang.hitch(p_contextObj, p_callBack);
    		callback(updatedGeometries);
    	}
    	else if(inputGeomSR.isWebMercator() && outWkid == 4326)
    	{
    		this.appUtils.log.debug("nc4project: Incoming SR is mercator, outgoing is 4326");
    		var updatedGeometries = [];
    		for(var i = 0; i<geometries.length; i++)
    		{
    			updatedGeometries[i] = webMercatorUtils.webMercatorToGeographic(geometries[i]);   

    		}
    		this.appUtils.log.debug("nc4project: updatedGeoms: " , updatedGeometries);
   			var callback = lang.hitch(p_contextObj, p_callBack);
   			callback(updatedGeometries);
    	}
    	else
        {
    		this.appUtils.log.debug("1nc4project: need to use geometry service");
    		this.gsvc.project(p_projectParam, lang.hitch(p_contextObj, p_callBack), lang.hitch(p_contextObj, p_errBack));
    		
    		/*
    		dojo.xhrPost({
            	url: "http://localhost:8080/eteam/nc4maps/proxy.jsp?" + this.externalGeometryServiceUrl + "/project",
            	handleAs: "json",
            	postData: {
            		 f: "json",
                     inSR: inWkid,
                     outSR: outWkid,
                     geometries: JSON.stringify(geometries)
            	},
            	load: lang.hitch(p_contextObj, p_callBack),
                error: lang.hitch(p_contextObj, p_errBack)
            });
            */
    		
    		/*
    	      var g = geometries[0];
              var params = { f:"json", geometries:JSON.stringify(g), inSR:inWkid,  							//TODO: make sure to create esri geometry object first
                  outSR:outWkid, //transformation:atransformation, transformForward:atransformForward  
              };  
    
              var requestHandle = new esriRequest({  
                  url:this.externalGeometryServiceUrl + "/project",
                  content:params,  
                  callbackParamName:"callback",  
                  load:lang.hitch(p_contextObj, p_callBack)
              }, {useProxy:false});  
*/

        }
	}
	
	
	})
})