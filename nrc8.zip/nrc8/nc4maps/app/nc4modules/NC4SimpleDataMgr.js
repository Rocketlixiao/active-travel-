
/**
 * Simple Data Manager object.  The idea is that it listens to an event, takes in a URL, and use the data to add to the map.  If the layer already exists,
 * delete the current layer first.
 */

//nc4 function
var nc4DataService = {};

nc4DataService.sendNewFilterCriteria = function(p_filterCriteria, p_layerMetaData)
{
	//TODO: temp code, eventually comment back in and take hardcoded values out
	//var newFilterCriteria = p_filterCriteria;
	
	/*
	 * var clusterDetail = {
							basemap: 0,
							bbox: 0,
							geometryType: "esriGeometryPoint",
							heatMap: 0,
							id: "Minor Incidents",
							imgHeight: 0,
							imgWidgth: 0,
							isCached: 0,
							name: "Minor",
							opacity: 100,
							parent: "nimcInc",
							refresh: 0,
							sr: 0,
							state: 1,
							tileSizeH: 0,
							tileSizeW: 0,
							type: "featureService",
							url: "http://rcdevjt:8080/nc4maps/rest/services/nimcinc/FeatureServer/minor",
							popupInfo: "<div id='pushpinCaption_header' ><div class='pushpinCaption_title'>${incidentcategory}: ${incidenttype}</div><div class='pushpinCaption_address'>${city}, ${stateprovince}</div><div class='pushpinCaption_updated'>Last Updated ${updateddate}</div></div><div id='pushpinCaption'><table width='0' height='0' cellpadding='0' cellspacing='0'><tr><td><img src='/maps/images/InfoBox/infobox_bg_mid.jpg'/></td></tr></table><div id='pushpinCaption_body'><div class='pushpinCaption_gist'>${gist}</div> </div><div id='pushpinCaption_footer'><div id='pushpinCaption_drilldown_logo'><img onclick=\"require(['app/nc4modules/NC4Utils'],function(nc4utils){var utils = new nc4utils(); utils.goToExternal('https://manager.everbridge.net/universe?1459922004520#nc4-${incidentid}.${incactivityid}','Are you sure that you want to navigate away from your current external window?')})\" src='/maps/images/feature/Everbridge_UI_IN.png' /></div></div></div>"
						 };
	 */
	
	try
	{
		var newFilterCriteria = 
		{
			datatypes: ["inc","adv"]
			, since: 1459893915202
			//, till:
			, incseverity: ["unknown", "minor", "moderate"]
			, inctype: "security"
			, inccategories: []
			//,regions?
		};
		//send to left side
		/**TODO for Gerald **/
		
		
		/* send to map
		 * First, use data from filter (data types should have an associated URL (rest/servicecs/Intel/FeatuerServer/all)) as well as meta data...pass
		 * all of that to the publish function below:
		 */
		var featureLayerObj = "get from RC Filter Object, includes URL to Feature Layer and layer meta-data";
		//rest/servicecs/Intel/FeatuerServer/all/
		//need to build "where" then use QueryTask(layerURL)
		require(["dojo/topic"], function(topic){topic.publish("nc4/filterchanged",  featureLayerObj);	});		

	}
	catch(error)
	{
		console.error("error: " , error);
	}
	
	
	
}


nc4DataService.sendNewPreset = function(p_preset)
{
	var newFilterCriteria = p_preset.filterCriteria;
	
	//attempt to update map first
	var newBaseMap = p_preset.basemap;
	var newBookmark = p_preset.extent;
	var newSR = p_preset.SR;
	
	var newMapState = {
			basemap: p_preset.basemap,
			newBookmark: p_preset.extent,
			newSR: p_preset.SR
	}
	
	require(["dojo/topic"], function(topic){
		 topic.publish("nc4/presetchanged",  newMapState);		
	});		
	nc4DataService.sendNewFilterCriteria(newFilterCriteria);
}