//2.8.2016 Currently not in use - an example of how a kmllayer module were to look if we extract it from the code instead of having similiar
//implementation in the various widgets

//NC4GeometryService.js
define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "esri/tasks/ProjectParameters",    
    "esri/geometry/webMercatorUtils",
    "esri/request",
    "esri/graphicsUtils",
], function(declare, lang, ProjectParameters, GeometryService, webMercatorUtils, esriRequest, graphicsUtils) {
	return {
	
	_validateKmlLayer: function(strUrl) {
		this._shelter.show();
        var cmpString,requestHandle;
        
        esriConfig.defaults.io.alwaysUseProxy = true;
        requestHandle = esriRequest({		
            "url": strUrl,
            "content": lang.mixin({
                "f": "json"
            }, null),
            "callbackParamName": "callback"
        });
        
        //check for error first
        requestHandle.then(lang.hitch(this, function(response) {}), lang.hitch(this, function(error) {
            cmpString = lang.trim(error.message);

            if (cmpString.toLowerCase() === "Access is denied.".toLowerCase()) {
                this._shelter.hide();
                //this.nc4Notify.error(sharedNls.AddLayer.errorMessages.invalidURLError);
            }
        }));
        if (_.contains(strUrl, ".kml") || _.contains(strUrl, ".kmz")) {
            return true;
        	//this._addKMLLayer(strUrl);
        } else {
            this._shelter.hide();
            this.nc4Notify.error(sharedNls.AddLayer.errorMessages.invalidURLError);
            return false;
        }
    },
    
    /**
     * This function adds KML  layer else throws exception.
     * @param {string} strUrl - Url for kml layer.
     */
    _addKMLLayer: function(strUrl) {
        var kml,layerId,layerInfo, 
        template = new InfoTemplate("Attributes", "${*}"), 
        layerIDkml = "KML_" + this._LayerId + "_layer",
        treeNodeID = "KML_" + this._LayerId;
        
        esriConfig.defaults.io.alwaysUseProxy = true;
        
        kml = new KMLLayer(strUrl, {
            id: layerIDkml,
            name: this._layerName,
            outFields: ["*"],
            infoTemplate: template,
            opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
            refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0
        });
        
        kml.customLayerType = "kml";
        this.map.addLayer(kml);
        this.appUtils.customLayerCount++;
        
        var layerDetail = {
            "type": "kml",
            "url": strUrl,
            "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
            "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
            "bbox": 0,
            "id": treeNodeID,
            "name": this._layerName,
            "state": 1,
            "sr": 102100,
            "basemap": 0,
            "parent": "customLayers",
            "layerFromAddLayer": true
        };
        
        this.appUtils.customLayerAdded(layerDetail);
        this.appUtils.customLayerNameAdded(this._layerName);
        
        this.own(on(kml, "load", lang.hitch(this, function (evt) {
            esriConfig.defaults.io.alwaysUseProxy = false;
            
            var mapSR = this.map.spatialReference,
            layerOutSR = evt.layer._outSR,
            isValidSR;
            
            /*
            if (mapSR.wkid) {
                isValidSR = mapSR._isWebMercator() && layerOutSR._isWebMercator() || mapSR.wkid === layerOutSR.wkid;
            } else if (mapSR.wkt) {
                isValidSR = mapSR.wkt === layerOutSR.wkt;
            } else {
                layerDetail.strike = "Yes";
                this._shelter.hide();
                return;
            }
            if (!isValidSR) {
                if (mapSR._isWebMercator() && 4326 === layerOutSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else if (layerOutSR._isWebMercator() && 4326 === mapSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else {
                    layerDetail.strike = "Yes";
                    if (this.isOpen === true) {
                        this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.notCompatible);
                    }
                    this.appUtils.layerAddedOnBasemap(true);
                    this._shelter.hide();
                    return;
                }
            }
            */
            //layerId = this.map.graphicsLayerIds[this.map.graphicsLayerIds.length - 1];
            //layerInfo = this.map.getLayer(layerId);
            var lyrExtent = graphicsUtils.graphicsExtent(evt.layer.graphics)
            this.map.setExtent(lyrExtent);
            this._LayerId++;
            this._shelter.hide();
            domAttr.set(this._txtLayerUrl, "displayedValue", "");
            domAttr.set(this._txtLayerName, "displayedValue", "");
        })));
        this.own(on(kml, "error", lang.hitch(this, function (evt) {
            esriConfig.defaults.io.alwaysUseProxy = false;
            var message = evt.error.message;
            var notValid = message.indexOf("Unable to load KML");
            if (notValid !== -1) {
                //layerDetail.strike = "Yes";
                if (this.isOpen === true) {
                    this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.notCompatible);
                }
                this.appUtils.layerAddedOnBasemap(true);
                this._shelter.hide();
            } else {
                this.map.removeLayer(kml);
                this._shelter.hide();
            }
        })));
    },
    
    /*
     * function to zoom to layer's extent
     */
    _zoomToExtent: function(kml){
    	var layers = kml.getLayers();
        var allGraphics = [];
        for(var i = 0; i < layers.length; i++)
        {
        	var lyr = layers[i];
        	if ( lyr.graphics && lyr.graphics.length > 0 ) 
          	  allGraphics = allGraphics.concat(lyr.graphics);
        }
       
        if(allGraphics.length > 0)
        {
        	var kmlExtent = graphicsUtils.graphicsExtent(allGraphics);
        	
            var layer = this.map.getLayer(this.map.layerIds[0]);
            var baseMapExtent = layer.fullExtent;
        	
            if(baseMapExtent.contains(kmlExtent))
            	this.map.setExtent(kmlExtent);
            else
            	this.map.setExtent(baseMapExtent);
        }
    }
	
	}
})