define([
        "dojo/_base/declare",], function(declare){
	return declare([], {
		
		//function to open an external window, displaying a confirmation if it is already open
		goToExternal: function(p_url, p_everbridgeConfirm)
		{
			var p_windowName = "External";
			//var windowParams = "menubar=yes, scrollbars=yes, status=yes, resizable=yes, titlebar=yes, toolbar=yes";
			
			if(p_url.indexOf("_rdate_") >= 0)
			{
				p_url = p_url.replace("_rdate_", new Date().getTime());
			}
			
			if( window.externalWindow && !(window.externalWindow == null) && !window.externalWindow.closed ) 
			{
				if( confirm(p_everbridgeConfirm) )
					window.externalWindow = window.open(p_url, p_windowName);
			}
			else
			{
				//window.externalWindow = {};
				window.externalWindow = window.open(p_url, p_windowName);
				
				//setTimeout( function(){ window.externalWindow.location = p_url; }, 2000);
							//assign location separately, so IE will return an object.
			}
		},
	

	    escapeHTML: function(html) {
	    	var escape = document.createElement('textarea');
	        escape.textContent = html;
	        return escape.innerHTML; 
	    },
	
	    unescapeHTML: function (html) {
	        escape.innerHTML = html;
	        return escape.textContent;
	    },
		
	});
});