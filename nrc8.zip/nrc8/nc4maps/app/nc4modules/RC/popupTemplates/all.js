/*
*this is a placehodler for an alternate popup implementation.  Where we place all templates here, thus being able to easily use JS functions.  Then we place
*the path to this module w/in the standardConfigs.json, and initialize/require this on application start up
*/
define([
        "dojo/_base/declare",
        "dojo/_base/lang"
], function(declare, lang
){
	return declare([],{			//constructor? or postcreate? _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin
	
		constructor: function(p_options)
		{
		},
		
		/*
		 * p_featureArray: each should have ID, Feature Service Name, Feature Layer Name, Feature Name for display
		 */
		createClusterListTemplate: function(p_callbackEvent, p_graphic)
		{
			var ct = "";
			ct += "<table>";
			
			if(p_graphic.attributes.clusteredIds && p_graphic.attributes.clusteredIds)
			{
				var arrCIds = p_graphic.attributes.clusteredIds.split(",");
				ct += "<tr><img src='" + p_graphic.symbol.url + "' /> " + arrCIds.length + " Overlapping Items</tr>";
				var arrCNames = p_graphic.attributes.clusteredNames.split(",");
				for(var i = 0; i<arrCIds.length; i++)
				{
					var currId = arrCIds[i];
					var newItem = "<tr><td align='left' valign='middle' height='24px'>" + (i + 1) + "</td><td align='left' valign='middle'>"
								+ "<span id='" + currId + "' style=\"cursor: pointer; text-decoration: underline;\" "
								+		"onclick=\"require(['dojo/topic'], function(topic)"
										+ 	"{topic.publish('" + p_callbackEvent + "', '" + currId + "','" + p_graphic.attributes.sid + "','" + p_graphic._layer.id + "');}) \">"
								+	arrCNames[i]
								+ "</span>"
								+ "</td></tr>";
					ct += newItem;
				}
			}
			ct += "</table>";
			var rc10 = 
		    	"<div  class='infowindow-content '>"
			     + "<div class='content-wrap'>"
			     	+ "<div class='title'>&nbsp;</div>"
			     + "</div>"
			     + "</div>"
			     + "<div class='infowindow-additional'>"
			     + "<div class='additional-detail'>" + ct + "</div>"
			     + "</div>";
			return rc10;
		}
	})
});