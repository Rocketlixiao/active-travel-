define([
        "dojo/_base/declare",
        "dojo/topic",
        "dojo/_base/lang",
        "dojo/dom",
        "esri/request",
        "app/widgets/Notifications/NC4Notification"
], function(declare, topic, lang, dom, esriRequest, NC4Notification
){
	return declare([],{			//constructor? or postcreate? _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin
	
		map: null,

		constructor: function()
		{
		},
		
		clearOne: function( p_fac )
		{
			var url = 'rest/proximitymanager/clearone';
			
			var rClearOne = esriRequest({
				url:url,
				content: {
					rand: Math.random() * 10000,
					facid: p_fac
				},
				handleAs: "text"
			});
			
			rClearOne.then( lang.hitch(this, function(response){
				topic.publish("refreshLayer", "_fac__cluster");
			}), function(error){
				new NC4Notification().error("Unable to acknowledge proximity OR proxmity has been previously acknowledge.  Please refresh.")
			});
			
		},
		
		muteOne: function(p_fac)
		{
			var url = 'rest/proximitymanager/muteone';
			
			var rClearOne = esriRequest({
				url:url,
				content: {
					rand: Math.random() * 10000,
					facid: p_fac
				},
				handleAs: "text"
			});
			
			rClearOne.then( lang.hitch(this, function(response){
				topic.publish("refreshLayer", "_fac__cluster");
			}), function(error){
				new NC4Notification().error("Unable to cancel proximity request OR proxmity has been previously cancel.  Please refresh.")
			});
			
		},
		
		clearAll: function()
		{
			var url = 'rest/proximitymanager/clearall';
			
			var rClearAll = esriRequest({
				url:url,
				content: {
					rand: Math.random() * 10000
				},
				callbackParamName: "",
				form: null,
				handleAs: "text",
				timeout: 60000
			},{
				usePost: true
			});
			
			rClearAll.then( function(response){
				topic.publish("refreshLayer", "_fac__cluster");
				
			}, function(error){
				new NC4Notification().error("Unable to acknowledge all proximity request at this time.")
			});
		}
	})
})
	
