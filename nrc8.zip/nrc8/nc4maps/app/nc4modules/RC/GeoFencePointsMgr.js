/*
 * RC module to add points to the  center of polygons (geo-fence layer).  Must be called/created after all layers have been created.
 */
define([
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/topic",
        "dojo/on",
        "esri/layers/GraphicsLayer",
        "esri/geometry/Point",
        "esri/graphic",
        "esri/symbols/PictureMarkerSymbol"
], function(declare, lang, topic, on, GraphicsLayer, Point, Graphic, PictureMarkerSymbol
){
	return declare([],{
	
		map: null,
		lyrId: null,
		ptsLyr: null,
		evtVisibility: null,
		
		constructor: function(p_lyrId, p_map)
		{
			this.map = p_map
			this.lyrId = p_lyrId;
			this.createLyr(this.lyrId);
			this.attachEvents();
		},
		
		createLyr: function(p_lyrId)
		{
			var gfLyr = this.map.getLayer(p_lyrId);
			if(gfLyr == null)
				return;
			if(this.ptsLyr != null)
				this.ptsLyr.clear();
			else
			{
				this.ptsLyr = new GraphicsLayer({
	                "id": "_ignore_geofence_points",
	                "addedType": "graphics",
	                "opacity": 1	
	               // infoTemplate: new InfoTemplate("Attributes", "")
	            });
			}
			if(this.map.getLayer("_ignore_geofence_points"))
				this.map.removeLayer(this.map.getLayer("_ignore_geofence_points"));
			this.ptsLyr.setInfoTemplate(gfLyr.infoTemplate)
			var fenceGraphics = gfLyr.graphics;
			
			for(var i = 0; i < fenceGraphics.length; i++)
			{
				var currFence = fenceGraphics[i].geometry;
				var currCenter = this.getCenter(currFence);//currFence.getCentroid();
				var currAttr = fenceGraphics[i].attributes;
				currAttr.clusterTitle = currAttr.geofencename;
				var url = "/maps/images/icons/Geofence/new.png";
				try{url = "/maps/images/icons/Geofence/" + currAttr.geofencetype + ".png";}
				catch(error){}
				//maps/images/icons/Geofence/danger.png
//maps/images/icons/Geofence/safe.png
				var pms = PictureMarkerSymbol(url, 24, 24);
				/*
				var sms = new SimpleMarkerSymbol().setStyle(
	        		    SimpleMarkerSymbol.STYLE_SQUARE).setColor(
	        		    new Color([255,0,0,0.5]));*/
				var newG = new Graphic(currCenter, pms, currAttr, null);
				this.ptsLyr.add(newG);
			}
			if(this.map.getLayer("_ignore_geofence_points") == null)
				this.map.addLayer(this.ptsLyr);
		},
		
		attachEvents: function()
		{
			this.evtRem = topic.subscribe("layer_removed", lang.hitch(this, function(p_lyrId){
				if(p_lyrId == "geofences_heatlayer" || p_lyrId == "geofences_cluster")
				{
					this.ptsLyr.clear();
					if(!this.map.getLayer(this.ptsLyr.id))
						this.map.removeLayer(this.ptsLyr);
					this.ptsLyr = null;
					this.evtRem.remove();
				}
			}))
			 on(this.ptsLyr, "mouse-over", lang.hitch(this, function(evt) {
                 this.map.setMapCursor("pointer");
             }));
             on(this.ptsLyr, "mouse-out", lang.hitch(this, function(evt) {
                 this.map.setMapCursor("default");
             }));
		},
		
		getCenter: function(p_geometry)
		{
			var xtent = p_geometry.getExtent();
			var x = ( ( xtent.xmax - xtent.xmin ) / 2 ) + xtent.xmin;
			var y = ( ( xtent.ymax - xtent.ymin ) / 2 ) + xtent.ymin;
			return new Point(x,y,this.map.spatialReference);
		}
	
	})
})
	
