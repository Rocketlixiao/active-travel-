define([
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/topic",
        "dojo/html",
        "dojo/dom",
        "dojo/dom-style",
        "dojo/on",
        "esri/request",
        "esri/geometry/Point",
        "esri/SpatialReference",
        "esri/geometry/webMercatorUtils"
], function(declare, lang, topic, html, dom, domStyle, on, esriRequest, Point, SpatialReference, webMercatorUtils
){
	return declare([],{			//constructor? or postcreate? _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin
	
		constructor: function(p_options)
		{
		},
		pushMessageToDevice: function(p_gpsDevices, p_message, p_success, p_failure, p_command)
		{
			 var sendTxtCheckin = esriRequest({
				url:"/maps/tools/mobilePush.jsp",
				handleAs: "text",
				content: {
					rand: Math.random() * 10000,
					devices: JSON.stringify(p_gpsDevices)
					, message: p_message
					, command: p_command
				}},
				{
					usePost: true
				}
			 );
			
			 sendTxtCheckin.then(p_success, p_failure);
			 
		},
		
		//TODO: pass in layer id
		sendCheckIn: function( p_lyrId, p_id, p_memberid, p_name, p_orgid, p_deviceid, p_lastResp)
		{
			domStyle.set("checkInRequest", "display", "none");
			domStyle.set("checkInLoading", "display", "block");
			
			var baseUrl = "/esa/jsonoutput/sendcheckin";
			var url = baseUrl + "/" + p_memberid + "/" + p_deviceid;
			var strPushMessage = "Administrator has requested that you check in"; 

			var devices = [];
			
			var checkInDevice = {id: p_id, memberid: p_memberid, name: p_name, orgid: p_orgid, deviceid: p_deviceid};
			
			devices.push(checkInDevice);
			
			
			this.pushMessageToDevice( 
					devices
					, strPushMessage, 
					lang.hitch(this, function()
					{ 
						//on success, update database, getIconsFor Refresh, then update popup
						 var updateDbCheckin = esriRequest({
							url:url,
							content: {
								rand: Math.random() * 10000,
								devices: devices
							}},
							{
								usePost: true
							});
						 
						 updateDbCheckin.then(
								 lang.hitch(this, function(response, p_lastResp){
									 //refresh layer, which will trigger cluster
									 //update popup clietn side
									 //topic.publish("refreshLayer", p_lyrId + "_cluster");
									 
									 this.popupPushSuccess("checkin", "p_gpsDeviceTODO", "Check In request has been initiated.", p_lastResp);
									 this.refreshAllLyrs();

								 }),
								 lang.hitch(this, function(){this.popupPushFailure()})
						 );
						 
					})
					, lang.hitch(this, function(){this.popupPushFailure()}), 
					"checkin" 
			);
		},

		refreshAllLyrs: function()
		{
			 topic.publish("refreshLayer", "mobile_cluster", 1);

		},
		
		cancelCheckIn: function( p_lyrId, p_id, p_memberid, p_name, p_orgid, p_deviceid, p_lastResp)
		{
			domStyle.set("checkInCancel", "display", "none");
			domStyle.set("checkInLoading", "display", "block");
			
			var baseUrl = "/esa/jsonoutput/cancelcheckin";
			var url = baseUrl + "/" + p_memberid + "/" + p_deviceid;
			var strPushMessage = "An administrator from your organization has canceled the previous check in request."; 
			
			var returnType = "JSON";
			var async = false;
			var type = "POST";
			var devices = [];
			
			var checkInCancelDevice = {id: p_id, memberid: p_memberid, name: p_name, orgid: p_orgid, deviceid: p_deviceid};
			
			devices.push(checkInCancelDevice);
			
			this.pushMessageToDevice( 
					devices
					, strPushMessage, 
					lang.hitch(this, function()
					{ 
						//on success, update database, getIconsFor Refresh, then update popup
						 var updateDbCheckin = esriRequest({
							url:url,
							content: {
								rand: Math.random() * 10000,
								devices: devices
							}},
							{
								usePost: true
							});
						 
						 updateDbCheckin.then(
								 lang.hitch(this, function(response){
							 //refresh layer, which will trigger cluster
							 //update popup clietn side
							 //topic.publish("refreshLayer", p_lyrId + "_cluster");
									 
							 this.popupPushSuccess("checkincancel", "p_gpsDeviceTODO", "Check In Request cancelled has been sent.", p_lastResp);
							 this.refreshAllLyrs();
						 }), 
						 	lang.hitch(this, function(error){this.popupPushFailure()})
						 );
					})
					, lang.hitch(this, function(){this.popupPushFailure()}), 
					"checkincancel" 
			);
			
		},

		resetPanic : function(  p_lyrId, p_id, p_memberid, p_name, p_orgid, p_deviceid, p_lastResp, p_gpsDevice, p_isonline, p_coordtimemillis)
		{
			
			var baseUrl = "/esa/jsonoutput/resetpanic";
			var strPushMessage = "An administrator from your organization has acknowledged your emergency signal.";
			var strResultMessage =  "Emergency Assist Acknowedgement was sent to mobile user";
			
			var currDateTimeMilli = new Date().getTime(); //TODO revisit when finish timezone research
			if( p_isonline == "false" || ( parseInt(p_coordtimemillis, 10) < ( currDateTimeMilli - 86400000 ) ) )
			{
				strResultMessage += "<br/><br/><b>Note:</b> Icon will now disappear from map.";
				if(p_isonline == "false")
					strResultMessage += " (ActivPoint user is logged off).";
				else
					strResultMessage += " (ActivPoint user's last ping exceeds 24 hours).";
			} 
			
			var url = baseUrl + "/" + p_memberid + "/" + p_deviceid;
			var returnType = "JSON";
			var async = false;
			var type = "POST";
			
			var clearDistress = esriRequest(
					{
						url:url,
						content: {
							rand: Math.random() * 10000
						}
					},
					{
						usePost: true
					}
			);
			
			clearDistress.then(lang.hitch(this, function(response){
				{ 
					//(p_memberId, p_fullName, p_orgId, p_deviceId, p_message, p_success, p_failure)
					var devices = [];
					//we don't want to pass all device info to push, just what's required:
					var resetDevice = {id: p_id, memberid: p_memberid, name: p_name, orgid: p_orgid, deviceid: p_deviceid};
					devices.push(resetDevice);
					
					this.pushMessageToDevice( devices, strPushMessage, lang.hitch(this, function()
							{ 
								//refreshlayer
								//topic.publish("refreshLayer", p_lyrId + "_cluster");
								
								this.popupPushSuccess("resetPanic", "p_gpsDeviceTODO", strResultMessage); 
								this.refreshAllLyrs();
								//nc4ClusterManager.cluster(); TODO Cluster doesn't necessarily execultes after getIconsForRefresh
							}) ,
							lang.hitch(this, function(error){this.popupPushFailure()}),
							"unset"
					); 
				};
			}),
			lang.hitch(this, function(error){this.popupPushFailure()})
			);
		},

		getTrackInfo : function(p_id, p_memberid, p_deviceid, p_histCount, p_orgid, p_lid, p_lastResponse)
		{
			//view the last 20 pings
			var baseUrl = "/esa/jsonoutput/deviceHistory"; //TODO: update to select unique ...coordtime form database, since coordinate time tells how old a coordinate is.
			
			var url = baseUrl + "/" + p_memberid + "/" + p_deviceid + "/" + p_histCount;

			
			var getTrack = esriRequest({
				url: url
			});
			
			getTrack.then(lang.hitch(this, function(response){
				this.viewTrack(response,p_id,p_memberid, p_deviceid, p_lid);
			}), lang.hitch(this, function(){
				this.viewTrackFailure();
			}));
			
		},

		viewTrack : function(p_data,p_id,p_memberid, p_deviceid, p_lid)
		{ 
			//domStyle.set("birdLoading", "display", "none");
			
			//var p_data = eval([{"gpsstatus":0,"memberid":"6ebd2994a64840a1f90183e965a7ff3","batterystatus":0,"ostype":"ANDROID","coordinatetime":{"date":5,"day":4,"hours":7,"minutes":48,"month":11,"nanos":713878000,"seconds":52,"time":1386258532713,"timezoneOffset":480,"year":113},"updateddate":{"date":31,"day":5,"hours":8,"minutes":35,"month":0,"nanos":461000000,"seconds":4,"time":1391186104461,"timezoneOffset":480,"year":114},"createddate":{"date":31,"day":5,"hours":8,"minutes":35,"month":0,"nanos":461000000,"seconds":4,"time":1391186104461,"timezoneOffset":480,"year":114},"devicetoken":"6ebd2994a64840a1f90183e965a7ff3","osversion":"4.1.2","deviceid":"6ebd2994a64840a1f90183e965a7ff3","batterylevel":0,"panicstatus":0,"organizationid":"6ebd2280a64840a1f90183e96569dda","loggedin":0,"devicename":"QA Hyatt Full Access1's device","longitude":27.222638875803212117754926019986977482,"latitude":46.6531645056977145318457181513077854459,"mobiledeviceid":"0EC0752025364360804DC360FD138EEB","the_day":5}]);
			//p_data = [{latitude: 15.2342, longitude: -80.23423}];
			var arrHistory = eval(p_data); //[{latitude: 15.2342, longitude: -80.23423},{latitude: 20.4325, longitude: -90.2435},{latitude: 30.345, longitude: -100.3245},{latitude: 40.32, longitude: -110.1},{latitude: 50.22, longitude: -111.345},{latitude: 60.44, longitude: -130.11}];
			
			//variables used to save how many checkins were at the same location, and the last time
			//		the user actually moved, in addition to which direction.
			var sameLocationCount = 1;
			var sameLocationLat = null;
			var sameLocationLon = null;
			var firstDiffLocationIndex = 0;
			var boolDoneWithDir = false;
			var speed = "Not Available";
			
			var arrCoords = [];
			var arrPoints = [];
			
			for(var i = 0; i < arrHistory.length; i++)
			{
				var currLatLon = arrHistory[i];
				if(typeof currLatLon != "object")
					continue;
				var latitude = currLatLon.latitude;//.toFixed(2);
				var longitude = currLatLon.longitude;//.toFixed(2);

				//check for valid coords (if null, then it is a 0,0 coord)
				if(!currLatLon.coordinatetime)
					continue;
				
				//get speed
				if(i == 0)
					if(currLatLon.speed != null)
						speed = currLatLon.speed;
				/*
				if(sameLocationLat == null && sameLocationLon == null)
				{
					sameLocationLat = latitude;
					sameLocationLon = longitude;
				}
				else
				{
					//check for same location only until the first difference is found, or at end of history list
					if(boolDoneWithDir == false)
					{
						if(sameLocationLat == latitude & sameLocationLon == longitude)
							sameLocationCount++;
						else
						{
							firstDiffLocationIndex = i;
							boolDoneWithDir = true;
						}
					}
				}
				*/
			
				var newPoint = new Point(longitude, latitude, new SpatialReference(4326));
				newPoint = webMercatorUtils.geographicToWebMercator(newPoint);   
				arrPoints.push( newPoint );					//coords for points
				arrCoords.push([newPoint.x, newPoint.y]); //coords for line
			}
			
			var p_options = {};
			p_options.tracks = arrCoords;
			p_options.fId = p_id;
			p_options.lId = p_lid;
			p_options.div = "birdMap" + p_id;
			p_options.points = arrPoints;
			p_options.sr = 102100;
			
			domStyle.set("popupBottomButtons", "display", "none");
			domStyle.set("viewTrackButtons", "display", "block");
			on(dom.byId("popupDetailBack"), "click", function(){
				p_options.markers = [];
				p_options.graphic = null;
				topic.publish("addGraphicDialogMap", p_options);
				domStyle.set("viewTrackButtons", "display", "none");
				domStyle.set("popupBottomButtons", "display", "block");
			});
			topic.publish("addGraphicTracksDialogMap", p_options);
		},

		getMph : function(p_lat1, p_lon1, p_lat2, p_lon2, p_timeMilli1, p_timeMilli2)
		{
			var distance = getDistanceFromLatLonInKm( p_lat1, p_lon1, p_lat2, p_lon2 ); 
		},

		getDirectionFromLatLon : function(p_fromLat, p_fromLon, p_toLat, p_toLon)
		{
			var dir = "";
			
			if( (parseFloat(p_toLat) == parseFloat(p_fromLat)) && (parseFloat(p_toLon) == parseFloat(p_fromLon)) )
				dir = "N/A";
			else
			{
				if(parseFloat(p_toLat) > parseFloat(p_fromLat))
					dir += "N";
				else if (parseFloat(p_toLat) < parseFloat(p_fromLat))
					dir += "S";
				else
					dir += "";
				
				if(parseFloat(p_toLon) > parseFloat(p_fromLon))
					dir += "E";
				else if (parseFloat(p_toLon) < parseFloat(p_fromLon))
					dir += "W";
				else 
					dir += "";
			}
			
			return dir;
		},
		

		getDirectionForDevice : function(p_memberId, p_deviceId)
		{
			var url = "data/gpsDevices/getGpsDeviceData.jsp";
			console.log("memberID: " + p_memberId);
			console.log("deviceID: " + p_deviceId);
			var returnType = "text";
			var async = true;
			var type = "GET";
			var success = nc4GpsDeviceMgr.createTelemetryInfo;
			var failure = nc4GpsDeviceMgr.getDirectionFailure;
			var data = {
					mId: p_memberId
					, dId: p_deviceId
					, type: "dirDev"
			};
			
			util.getDataAjax(url, returnType, async, type, success, failure, data);

		},

		getDirection : function(p_latestLat, p_latestLon, p_sLatestLat, p_sLatestLon)
		{
			var url = "data/gpsDevices/getGpsDeviceData.jsp";
			
			var returnType = "text";
			var async = false;
			var type = "GET";
			var success = nc4GpsDeviceMgr.createTelemetryInfo;
			var failure = nc4GpsDeviceMgr.getDirectionFailure;
			var data = {
					lat1: p_sLatestLat
					, lon1: p_sLatestLon
					, lat2: p_latestLat
					, lon2: p_latestLon
					, type: "dir"
			};
			
			util.getDataAjax(url, returnType, async, type, success, failure, data);

		},

		createTelemetryInfo : function(p_dir, p_speed)
		{
			var dir = p_dir || "";
//			var speed = p_speed || "";
			$j("#divTelemetry").html("Direction: " + dir + "<br/>" + "Speed (mph): " + p_speed);
			$j("#divTelemetry").show(1000);
		},

		getDirectionFailure : function()
		{
			$j("#divTelemetry").html("Unavailable");
		},

		popupPushFailure : function()
		{
			alert("failure");
			/*
			$j("#popupSmallMap").hide();
			$j("#popupBottomButtons").hide();
			
			$j("#popupBottomButtons2").show();
			
			$j("#locationDetail").html("<b><br/><br/>Message cannot be sent at this time.  Please try again later.<b>");
			$j("#locationDetail").show();
			*/
		},
		popupPushSuccess : function(p_type, p_data, p_resultMessage, p_lastResp)
		{			
			if( p_type && p_type == "checkin" )
			{
				
				html.set(dom.byId("divCheckIn"), this.getTempClientCheckInDivP(p_lastResp));
				//rebind checkin action for checkin button click.  p_data is the gpsDevice
				/*
				$j("#checkInCancel").click(function(){
					nc4GpsDeviceMgr.cancelCheckIn(p_data);
				});*/
			}
			else if( p_type && p_type == "checkincancel" )
			{
				html.set(dom.byId("divCheckIn"), this.getTempClientCheckInDiv(p_lastResp));
				/*
				$j("#checkInRequest").click(function(){
					this.sendCheckIn(p_data);
				});*/
			}
				if(p_resultMessage == "" || p_resultMessage == null)
					p_resultMessage = "Message Sent!";
					
				//topic.publish("hideshowdivs", ["popupSmallMap", "popupBottomButtons", "popupCheckInButtons"], ["locationDetail"]);
				try
				{
					domStyle.set("popupSmallMap", "display", "none");		//hide small map
					domStyle.set("popupBottomButtons", "display", "none");		//hide small map
					domStyle.set("popupCheckInButtons", "display", "none");		//hide small map
				}
				catch(e){}
				
				html.set(dom.byId("locationDetail"), "<b>"+p_resultMessage+"<b>");
				domStyle.set("locationDetail", "display", "block");
		},
		
		//after check in action update div temporarily until user clicks on popup again
		getTempClientCheckInDivP: function()
		{
			var sb = "";
			//sb.append("<div id='divCheckIn'>");
			sb+="<b>Check In Sent: </b><br/><i>Sent less than 1 minute ago.</i><br/>";
			sb+="<b>Check In Delivered: </b><br/><i>Not Yet Delivered</i>";
			sb+="<div id='popupCheckInButtons'><img id='checkInLoading' style='display:none' src='/maps/images/loading.gif' /><button class='captionButton large2 right' id='checkInCancel' onclick=''>Cancel</button></div><br/></div>";
					
			return sb;
		},
		getTempClientCheckInDiv: function(p_lastResp)
		{
			var sb = "";
			//sb.append("<div id='divCheckIn'>");
			sb+="<b>Check In Received: </b><br/>";
			if(p_lastResp && p_lastResp != null)
				sb+=p_lastResp;
			else
				sb+="N/A <br/>";
			sb+="<div id='popupCheckInButtons'><button class='captionButton large2 right' id='checkInRequest'>Request</button></div><br/>";		
			return sb;
		}/*
		nc4GpsDevice.prototype.getClickCheckIn = function()
		{

			var checkInSection = "<div id='divCheckIn'>" +
				"<b>Check In Received: </b><br/>" + 
				( this.checkin ? this.checkin_resp + "&nbsp;" + this.checkin : "n/a" ) + "<br/>" +
				"<div id='checkInLoading' style='display:none'><img src='/maps/images/loading.gif' /></div>";
			if( this.paused != 'true' )
				checkInSection += ( this.status == "PANIC" ? "" : "<div id='popupCheckInButtons'><button class='captionButton large2 right' id='checkInRequest'>Request</button></div><br/>" );
			
			checkInSection += "</div>";
			
			return checkInSection;
		};*/


	})
})