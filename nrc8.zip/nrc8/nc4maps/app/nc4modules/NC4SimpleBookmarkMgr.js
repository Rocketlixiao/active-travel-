
/**
 * Simple Bookmark Object.  The idea is that it listens to an event, takes in an extent, and use the data to add to update the current extent of the map. 
 */

define([
        "dojo/_base/declare",
        "dojo/_base/lang"
    ], function(declare, Clustering, lang) {
    	return declare([], {
    		_appUtils: {},
    		_clustering: {},
    		_map: {},
    		
    		constructor: function(p_appUtils, p_map)
    		{
    			this._appUtils = p_appUtils;
    			this._map = p_map;
    		},
    		
    		_initSubscriptions: function(p_context)
    		{
    			
    			topic.subscribe("nc4/presetchanged", lang.hitch(p_context, function(p_preset){
                    var getBookmarkextent = {
                        "name": domAttr.get(evt.currentTarget.id, "name"),
                        "xmin": domAttr.get(evt.currentTarget.id, "xmin"),
                        "ymin": domAttr.get(evt.currentTarget.id, "ymin"),
                        "xmax": domAttr.get(evt.currentTarget.id, "xmax"),
                        "ymax": domAttr.get(evt.currentTarget.id, "ymax"),
                        "spatialReference": domAttr.get(evt.currentTarget.id, "spatialReference")
                    };
                    this.appUtils.layerExtent(getBookmarkextent);
                    this._ServiceBookmarkResults(getBookmarkextent);
                }));
                this._storeBookmarkNames.push(lang.trim(this.textBookmarkName.value));
                this.textBookmarkName.value = "";
                domAttr.set(this.textBookmarkName, "displayedValue", "");
                if (this.config.saveBookmarkServiceUrl) {
                    this._btnSaveBookmark.disabled = false;
                    html.removeClass(this._btnSaveBookmark.domNode, "hide");
                    html.addClass(this._btnSaveBookmark.domNode, "show");
                } else {
                    this._btnSaveBookmark.disabled = true;
                    html.addClass(this._btnSaveBookmark.domNode, "hide");
                    html.removeClass(this._btnSaveBookmark.domNode, "show");
                }
    		},
    		
    		_createClusterLayer: function(p_clusterDetail)
    		{
    			
    		},
    		
    		_removeClusterLayer: function()
    		{
    			
    		}
    		
    		
    		
    	});
});