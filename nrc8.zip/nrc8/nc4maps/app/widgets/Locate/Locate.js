define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/dom-class",
    "dojo/_base/html",
    "dojo/dom-style",
    "dojo/text!./LocateTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/aspect",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/form/Button",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter"
], function (
    declare,
    lang,
    on,
    domClass,
    html,
    domStyle,
    template,
    sharedNls,
    aspect,
    _WidgetBase,
    _TemplatedMixin,
    Button,
    WidgetPanel,
    LoadingShelter
) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "Locate",
        baseClass: "Widget-Locate",
        templateString: template,
        sharedNls: sharedNls,
        _measurement: null,
        isOpen: false,
        _shelter: null,
        _panel: null,
        _saveLocation: null,
        _reset: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 35 + "%"
        },

        postCreate: function () {
            this.inherited(arguments);
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetLocateIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
            this._saveLocation = new Button({
                label: "Save"
            }, this.saveButton);
            this._reset = new Button({
                label: "Reset"
            }, this._clearButtonDiv);
            this._attachWidgetRelatedEvents();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function () {
                this.map = null;
                this.map = this.appUtils.mapInstance;
                html.empty(this._measurementDiv);
                this._getMeasurment();
            }));
            this._getMeasurment();
            domStyle.set(this._reset.domNode, "visibility", "hidden");
            domStyle.set(this._saveLocation.domNode, "visibility", "hidden");
        },

        /**
        * Display the panel.
        */
        show: function () {
            if (!this.isOpen) {
                domClass.add(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                if (this._measurement) {
                    this._measurement.setTool("location", true);
                }
            } else {
                this.hide();
            }
        },

        /**
        * Hide the panel
        */
        hide: function () {
            var activeTool;
            this.isOpen = false;
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
            }
            activeTool = this._measurement.getTool();
            if (activeTool) {
                this._measurement.setTool(activeTool.toolName, false);
            }
            domStyle.set(this._reset.domNode, "visibility", "hidden");
            domStyle.set(this._saveLocation.domNode, "visibility", "hidden");
            this._measurement.clearResult();
        },

        /**
        * Setting the widget panel position.
        */
        _placeWidgetContainer: function () {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
        * Attach widget related events. Resize the widget panel on window resize.
        */
        _attachWidgetRelatedEvents: function () {
            on(window, "resize", lang.hitch(this, function () {
                this._panel.resize();
            }));
        },

        /**
        * Initialize 'Measurement' widget, set default area and length unit.
        */
        _getMeasurment: function () {
            require(["esri/dijit/Measurement",
                "esri/units"
            ], lang.hitch(this, function (Measurement, esriUnits) {
                var json = {};
                json.map = this.map;
                /**
                * In ArcGIS JavaScript API 3.12 for 'Measurement' widget following units are not supported:-
                * For area - ARES, SQUARE_INCHES, SQUARE_MILLIMETERS, SQUARE_CENTIMETERS, SQUARE_DECIMETERS.
                * For length - CENTIMETERS, DECIMAL_DEGREES, DECIMETERS, INCHES, NAUTICAL_MILES, POINTS, UNKNOWN.
                */
                json.defaultAreaUnit = esriUnits.SQUARE_MILES; //Setting default area unit to 'Sq Miles'.
                json.defaultLengthUnit = esriUnits.MILES; //Setting default length unit to 'Miles'.
                var test = html.create("div", {}, this._measurementDiv);
                this._measurement = new Measurement(json, test);
                this._measurement.startup();
                this._measurement.setTool("location", true);

                on(this._saveLocation, "click", lang.hitch(this, function () {
                    this._saveLocationResult();
                }));
                on(this._reset, "click", lang.hitch(this, function () {
                    this._clearMeasurementGraphics();
                }));
                on(this.map, "click", lang.hitch(this, function () {
                    if (this.config.EnableSave) {
                        domStyle.set(this._saveLocation.domNode, "visibility", "visible");
                        domStyle.set(this._reset.domNode, "visibility", "visible");
                    }
                }));
                this.measurementHint.textContent = sharedNls.Measurement.measurementHint;
                this._shelter.hide();
            }));
        },

        /**
        * Clear the Measurement graphics on map and deactivate the Measurement tool.
        */
        _clearMeasurementGraphics: function () {
            var activeTool = this._measurement.getTool();
            this._measurement.clearResult();
            if (activeTool) {
                this._measurement.setTool(activeTool.toolName, true);
            }
            domStyle.set(this._reset.domNode, "visibility", "hidden");
            domStyle.set(this._saveLocation.domNode, "visibility", "hidden");
        },
        _saveLocationResult: function () {
            //this._alertBox.prompt("Longitude :" + this._measurement.markerLocationX + "   and Latitude :" + this._measurement.markerLocationY + "   values are sent to NC4 Main Solution");
            //cf
        	//this.config.nc4SaveFunction = "require(['dojo/query', 'dojo/html'], function(query, html){var controller = window.opener.UberController;if(controller){var inputLat = query('input[name=\"geoLocationLatitude\"]', window.opener.document)[0];dojo.attr(inputLat, 'value', y);var inputLon = query('input[name=\"geoLocationLongitude\"]', window.opener.document)[0];dojo.attr(inputLon,'value', x);var latDiv = query('div[cname=\"geoLocationLatitude\"]', window.opener.document )[0];controller.valueChangeObserver(null, latDiv);var lonDiv = query('div[cname=\"geoLocationLongitude\"]', window.opener.document )[0];controller.valueChangeObserver(null, lonDiv);window.close();return true;}else{alert('debug: no window.opener.UberController object');}});";
        	var nc4SaveFunction = new Function('x', 'y', this.config.nc4SaveFunction);
        	nc4SaveFunction(this._measurement.markerLocationX,this._measurement.markerLocationY)
        }

    });
});
