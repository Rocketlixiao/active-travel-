define([
    "dojo/_base/declare",
    "dijit/_WidgetBase",
    "dojo/dom",
    "dojo/dom-construct",
    "dojo/dom-attr",
    "dojo/dom-style",
    "dojo/query",
    "dojo/aspect",
    "dojo/_base/lang",
    "esri/dijit/HomeButton",
    "esri/geometry/Extent"
], function(declare, _WidgetBase, dom, domConstruct, domAttr, domStyle, query, aspect, lang, HomeButton, Extent) {
    return declare([_WidgetBase], {

        postCreate: function() {
            this.inherited(arguments);
            this._initializeNavigation();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
                this._initializeNavigation();
            }));
        },

        /**
         * Create 'Home Button' object and place it after 'zoom out' button
         */
        _initializeNavigation: function() {
            var home,
                zoomOut = query(".esriSimpleSliderDecrementButton"),
                zoomIn = query(".esriSimpleSliderIncrementButton");
            
            (zoomIn.length > 0) ? domAttr.set(zoomIn[0], "title", "Zoom In"): null; //jshint ignore:line
            (zoomOut.length > 0) ? domAttr.set(zoomOut[0], "title", "Zoom Out"): null; //jshint ignore:line
            
            var navNode = dom.byId("#mapContainerNode");
            var nl = query(".esriSimpleSlider", navNode);
            
            if(this.config.top)
            	domStyle.set(nl[0], "top", this.config.top)
            if( this.config.left)
            	domStyle.set(nl[0], "left", this.config.left);
            
            /**
             * Create esri 'Home Button' widget
             */
            home = this._addHomeButton();
            domConstruct.place(home.domNode, query(".esriSimpleSliderDecrementButton")[0], "after");
            if(this.appUtils.configGeneralSettings.defaultBookmarkExtent && this.appUtils.configGeneralSettings.defaultBookmarkExtent != null && this.appUtils.configGeneralSettings.defaultBookmarkExtent.split(",").length == 4 && this.appUtils.configGeneralSettings.defaultBookmarkSr){
                extent = this.appUtils.configGeneralSettings.defaultBookmarkExtent.split(",");
                defaultExtentSpatialRef = this.appUtils.configGeneralSettings.defaultBookmarkSr;
                initialExtent = new Extent({
                    "xmin": parseFloat(extent[0]),
                    "ymin": parseFloat(extent[1]),
                    "xmax": parseFloat(extent[2]),
                    "ymax": parseFloat(extent[3]),
                    "spatialReference": {
                        "wkid": parseInt(defaultExtentSpatialRef, 10)
                    }
                });
                home.extent = initialExtent;
            }
            else{
                home.extent = this.map.extent;
            }
            home.startup();
        },

        /**
         * Load esri 'Home Button' widget which sets map extent to default extent
         * @returns {object} home - Home button widget
         */
        _addHomeButton: function() {
            var home = new HomeButton({
                map: this.map
            }, domConstruct.create("div", {}, null));

            var btn = home.domNode.querySelector('.home');
            if (btn) btn.setAttribute('title', 'Home');

            return home;
        }
    });
});
