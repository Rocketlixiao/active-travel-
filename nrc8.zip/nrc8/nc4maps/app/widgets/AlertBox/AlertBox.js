define([
    "dojo/_base/declare",
    "dojo/Deferred",
    "dijit/_WidgetBase",
    "dojo/_base/lang",
    "dojo/dom-construct",
    "dojo/on",
    "dijit/Dialog",
    "dijit/form/Button"
], function(declare, Deferred, _WidgetBase, lang, domConstruct, on, Dialog, Button) {
    return declare(_WidgetBase, {

        /**
         * Creates digit dialog with 'Success' title and display custom message when operation performed successfully
         * @param {string} strMessage - Custom message to display.
         */
        success: function(strMessage) {
            var alertDialog = new Dialog({
                title: "Success",
                Class: "alertDialogDimention"
            });
            this._setContent(alertDialog, strMessage, "alert-icon-success");
        },

        /**
         * Creates digit dialog with 'Confirmation' title and display custom message
         * when some decision to be made by the user
         * @param {string} strMessage - Custom message to display.
         * @returns {deferred} deferred.promise - result of deferred.
         */
        confirm: function(strMessage) {
            var contentDiv, btnCancel, btnDiv, btnOk, deferred;
            deferred = new Deferred();
            var alertDialog = new Dialog({
                title: "Confirmation",
                Class: "alertDialogDimention"
            });
            contentDiv = domConstruct.create("div", {
                "class": "alert-content"
            });
            //Icon 
            domConstruct.create("div", {
                "class": "alert-icon alert-icon-confirmation"
            }, contentDiv);
            //Message
            domConstruct.create("div", {
                "class": "alert-message",
                "innerHTML": strMessage
            }, contentDiv);
            //button
            btnDiv = domConstruct.create("div", {
                "class": "alert-buttonContainer"
            }, contentDiv);
            btnOk = new Button({
                label: "OK"
            });
            on(btnOk, "click", lang.hitch(this, function() {
                alertDialog.hide();
                deferred.resolve(true);
            }));
            btnOk.placeAt(btnDiv).startup();
            btnCancel = new Button({
                label: "Cancel",
                onClick: lang.hitch(this, function() {
                    alertDialog.hide();
                    deferred.cancel(false);
                })
            });
            btnCancel.placeAt(btnDiv).startup();
            alertDialog.set("content", contentDiv);
            alertDialog.show();
            return deferred.promise;
        },

        /**
         * Creates digit dialog with 'Error' title and display custom message when error occurred
         * @param {string} strMessage - Custom message to display.
         */
        error: function(strMessage) {
            var alertDialog = new Dialog({
                title: "Error",
                Class: "alertDialogDimention"
            });
            this._setContent(alertDialog, strMessage, "alert-icon-failed");
        },

        /**
         * Creates digit dialog with 'Notification' title and display custom message in case to notify the user
         * @param {string} strMessage - Custom message to display.
         */
        prompt: function(strMessage) {
            var alertDialog = new Dialog({
                title: "Notification",
                Class: "alertDialogDimention"
            });
            this._setContent(alertDialog, strMessage, "alert-icon-prompt");
        },

        /**
         * Creates digit dialog with 'Success' title and display custom message
         * @param {object} alertDialog - object of digit dialog.
         * @param {string} strMessage - Custom message to display.
         * @param {string} iconClass - Class to be added for icon, specifying the type.
         */
        _setContent: function(alertDialog, strMessage, iconClass) {
            var contentDiv = domConstruct.create("div", {
                "class": "alert-content"
            });
            //Icon 
            domConstruct.create("div", {
                "class": "alert-icon " + iconClass
            }, contentDiv);
            //Message
            domConstruct.create("div", {
                "class": "alert-message",
                "innerHTML": strMessage
            }, contentDiv);
            alertDialog.set("content", contentDiv);
            alertDialog.show();
        }
    });
});
