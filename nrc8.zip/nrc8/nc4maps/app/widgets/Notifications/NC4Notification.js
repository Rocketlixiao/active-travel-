define([
        "dojo/_base/declare",
        "jquerylib/jquery2_2",
        "jqueryplugins/toastr2_1_2/toastr"
], function(declare,
		 $, toastr	
){
	
	return declare([],{			//constructor? or postcreate? _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin

		
		constructor: function(p_options)
		{
			//if creating object at a later time, and want to use the current settings
			//if(p_useCurrentState)
				//return;
			toastr.$ = $;
			
			this.setDefaults();
			
		},
		
		setDefaults: function(p_options)
		{
			//set the defaults
			
			toastr.options.showMethod = "slideDown";
			toastr.options.hideMethod = "slideUp";
			toastr.options.closeMethod = "slideUp";
			toastr.options.preventDuplicates = true;
			toastr.options.timeOut = 5000;
			toastr.options.progressBar = true;
			toastr.options.positionClass =  "toast-bottom-right";
			toastr.options.tapToDismiss = true;
		
		},
		/*
		addDataLayerLoading: function(p_arrDataLayersLoading, p_lyrId)
		{
			this.info("Data is Loading");
		},

		removeDataLayerLoading: function(p_arrDataLayersLoading, p_lyrId)
		{
			require(["dojo/_base/array"], function(array){
				var pos = array.indexOf(p_arrDataLayersLoading, p_lyrId);
				if(pos >= 0)
					p_arrDataLayersLoading.splice(pos, 1);
				if(p_arrDataLayersLoading.length <= 0 && this._dataLayerLoadingInfo != null)
					this.hide(this._dataLayerLoadingInfo);
			});
		},*/
		
		setTimeout: function(p_timeout)
		{
			toastr.options.timeOut = p_timeout;
		},
		
		disableTimeout: function()
		{
			toastr.options.timeOut = 0;
		},
		
		enableTimeout: function()
		{
			toastr.options.timeOut = 5000;
		},
		
		toggleCloseButton: function(p_enable)
		{
			toastr.options.closeButton = p_enable; //true means to enable
		},
		
		debug: function(p_message)
		{
			toastr.debug(p_message);
		},
		
		info: function(p_message)
		{
			return toastr.info(p_message);
		},
		
		//this is use in clustering() for biz data layers
		info2: function(p_options, p_messageType, p_title, p_message)
		{
			toastr.options = p_options;							 //TODO, should use something similar to the message fxn below, where it passes in temp options

			var tst = toastr[p_messageType](p_message, p_title);
			this.setDefaults();		//this really is not needed.  TODO, should use something similar to the message fxn below, where it passes in temp options
			return tst;
		},
		
		//message is used to display layer settings
		message: function(p_message, p_options)
		{
			return toastr.displayContent(p_message, "", p_options); //can also pass in 2nd and 3rd agrs, "title" and "optionsOverride"
		},
		
		warn: function(p_message)
		{
			toastr.warning(p_message);
		},
		
		error: function(p_message)
		{
			//all errors needs to be acknowledged
			this.disableTimeout();
			var errTst = toastr.error(p_message);
			this.enableTimeout();
			
			return errTst;
		},
		
		hide: function(p_toastrToHide)
		{
			console.info("toastr: " , toastr);
			if(p_toastrToHide)
			{
				toastr.clear(p_toastrToHide, {force: true} );
				p_toastrToHide = null;
			}
		},
		
		success: function(p_message)
		{
			toastr.success(p_message)
		},
		
		confirm: function(p_message)
		{
			
			toastr.info('<div>' + p_message + '</div><div><button type="button" id="okBtn" class="btn btn-primary" onclick="return true">Yes</button><button type="button" id="surpriseBtn" class="btn" onclick="return false">No</button></div>');
		}
	})
})






