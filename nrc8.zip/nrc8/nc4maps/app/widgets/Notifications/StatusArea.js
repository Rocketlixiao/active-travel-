define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/html",
	"dojo/_base/array",
	"dojo/aspect",
	"dojo/on",
	"dojo/dom",
    "dojo/dom-construct",
	"dojo/dom-attr",
	"dojo/dom-class",
	"dojo/dom-style",
	"dojo/query",
	//"dojo/text!./AppHeaderTemplate.html",
	"dijit/_WidgetBase",
	"dijit/_TemplatedMixin",
	"dijit/_WidgetsInTemplateMixin",
	"dojo/fx/Toggler",
	"dijit/registry"      
], function(
		 declare,
		    lang,
		    html,
		    array,
		    aspect,
		    on,
		    dom,
		    domConstruct,
		    domAttr,
		    domClass,
		    domStyle,
		    query,
		    template,
		    _WidgetBase,
		    _TemplatedMixin,
		    _WidgetsInTemplateMixin,
		    Toggler,
		    registry		
){
	
	return declare([],{			//constructor? or postcreate? _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin
		/**updates the status area with a message
         * p_statusObject: an object with an ID, icon, and status message
         * 
         */
		
		//instance variables
		id:"",
		name:"",
		message:"",
		icon:"",
		statusAreaId: "",
		
		constructor: function(p_statusObject)
		{
			console.log("p_statusObject: ", p_statusObject);
			this.id = p_statusObject.id || "";
			this.name = p_statusObject.name || "";
			this.message = p_statusObject.message || "";
			this.icon = p_statusObject.icon || "";
			this.statusAreaId = p_statusObject.statusAreaId;
		},
		
        updateStatusArea: function(p_statusAreaId)
        {
        	//construct the message
        	var html = "<img id='statusIcon' src='" + this.icon + "' /> " + this.message;
        	
        	//check if a message already exists and if so, erase current message
        	var currMessage = dom.byId(p_statusAreaId).innerHTML;
        	var currIcon = dom.byId("appStatusIcon").innerHTML;
        	if(currMessage.length > 0)
        		dom.byId(p_statusAreaId).innerHTML = "";
        	if(currIcon.length > 0)
        	{
        		dom.byId("appStatusIcon").innerHTML = "";
        		clearInterval(window.interval);
        	}
        	
        	//create the message and prepend
        	var statusIcon = domConstruct.create("span", {innerHTML: "!"}, dom.byId("appStatusIcon"), "first");
        	var statusMessage = domConstruct.create("span", {innerHTML: this.message}, dom.byId(p_statusAreaId), "first");
        	
        	//create dismiss button as a toggler since dismiss button will always be the same
        	var toggler = new dojo.fx.Toggler({
        		node: "applicationStatusWidgetContainer",
        		showDuration: 0,
        		hideDuration: 0
        	});
        	
        	//show the notification message
        	domStyle.set("btnDismiss", "visibility", "visible");
        	toggler.show();
        	
        	
        	//add event handler associated with the click on the dismiss btton.
        	on(dom.byId("btnDismiss"), "click", function(e){
        		  toggler.hide();
        		  statusMessage.innerHTML = "";
        		  statusIcon.innerHTML = "";
        	});
        	
        	var interval = window.setInterval(function(){
        	    if(domStyle.get("appStatusIcon", "visibility") == "hidden"){
        	    	domStyle.set("appStatusIcon", "visibility", "visible");
        	    }else{
        	    	domStyle.set("appStatusIcon", "visibility", "hidden");
        	    }
        	}, 1000); //the 1000 here is milliseconds and determines how often the interval should be run
        	/*
        	 *    
        	
        	   
        	dojo.connect(btnDismiss, "onclick", function(evt){
	      		  dom.byId(p_statusAreaId).innerHTML = "";
	      	  });
        	
        	*/
        },
        
        clearStatusArea: function(p_statusAreaAtRuntime)
        {
        	dom.byId(p_statusAreaAtRuntime).innerHTML = "";
        }
        
	})
})






