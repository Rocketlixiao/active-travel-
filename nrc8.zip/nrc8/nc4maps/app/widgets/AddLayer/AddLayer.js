define([
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/_base/html",
    "dojo/on",
    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/dom",
    "dojo/touch",
    "dojo/string",
    "dijit/registry",
    "dojo/dom-attr",
    "dojo/text!./AddLayerTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/dom-style",
    "dojo/mouse",
    "dojo/aspect",
    "dojo/query",
    "dijit/_TemplatedMixin",
    "dijit/form/Select",
    "dijit/form/TextBox",
    "dijit/form/RadioButton",
    "dijit/form/ValidationTextBox",
    "dijit/form/Button",
    "dijit/_WidgetBase",
    "esri/request",
    "esri/layers/ArcGISTiledMapServiceLayer",
    "esri/layers/ArcGISDynamicMapServiceLayer",
    "app/widgets/DataLayers/ArcGISMSmanager",
    "app/widgets/DataLayers/ArcGISMSCachedManager",
    "esri/layers/FeatureLayer",
    "esri/layers/KMLLayer",
    "esri/layers/CSVLayer",
    "esri/layers/GeoRSSLayer",
    "esri/graphicsUtils",
    "esri/InfoTemplate",
    "esri/geometry/Point",
    "esri/graphic",
    "esri/SpatialReference",
    "esri/geometry/Extent",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter",
    "app/widgets/Navigation/Navigation",
    //"app/widgets/DataLayers/WMSManager",
    "esri/layers/WMSLayer",
    "dojo/dom-construct",
    "esri/layers/MapImageLayer",
    "esri/layers/MapImage",
    "esri/layers/WMTSLayer",
    "esri/layers/WMTSLayerInfo",
    "esri/map",
    "esri/symbols/PictureMarkerSymbol",
    "esri/renderers/SimpleRenderer",
    "esri/config",
    "lodash/lodash"
], function(
    declare,
    array,
    lang,
    html,
    on,
    Deferred,
    all,
    dom,
    touch,
    string,
    registry,
    domAttr,
    template,
    sharedNls,
    domStyle,
    mouse,
    aspect,
    dojoQuery,
    _TemplatedMixin,
    Select,
    TextBox,
    RadioButton,
    ValidationTextBox,
    Button,
    _WidgetBase,
    esriRequest,
    ArcGISTiledMapServiceLayer,
    ArcGISDynamicMapServiceLayer,
    ArcGISMSmanager,
    ArcGISMSCachedManager,
    FeatureLayer,
    KMLLayer,
    CSVLayer,
    GeoRSSLayer,
    graphicsUtils,
    InfoTemplate,
    Point,
    Graphic,
    SpatialReference,
    Extent,
    WidgetPanel,
    LoadingShelter,
    Navigation,
    //WMSManager,
    WMSLayer,
    domConstruct,
    MapImageLayer,
    MapImage,
    WMTSLayer,
    WMTSLayerInfo,
    Map,
    PictureMarkerSymbol,
    SimpleRenderer,
    esriConfig,
    _
) {
    var clazz = declare([_WidgetBase, _TemplatedMixin], {
        name: "AddLayer",
        baseClass: "widget-AddLayer",
        sharedNls: sharedNls,
        templateString: template,
        isOpen: false,
        _shelter: null,
        _getImglayerdata: [],
        _panel: null,
        _sampleUrl: null,
        _cmbLayerType: null,
        _layerFormatType: null,
        _txtLayerUrl: null,
        _txtLayerName: null,
        _arrLayersOnMap: null,
        _layerName: null,
        _alertCount: null,
        _count: null,
        _nc4Notify: null,
        _btnAddLayer: null,
        _btnAddBasemap: null,
        _txtImgBounds: null,
        _txtImgSize: null,
        _LayerId: 1,
        _rdoCached: null,
        _rdoDynamic: null,
        _txtGeoRSS: null,
        _getCustombasemap: [],
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },
        _btnValidate: null,
        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
         */
        postCreate: function() {
            this.inherited(arguments);
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetAddLayerIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
        	this.nc4Notify = this.appUtils.nc4Notify;
            this._createWidgetUI();
            this._attachWidgetRelatedEvents();
            this._serviceLayerNames();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
            this._shelter.hide();
        },

        /**
         * Display the widget panel.
         */
        show: function() {
            if (!this.isOpen) {
                html.addClass(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
               // esriConfig.defaults.io.alwaysUseProxy = true;
                this.isOpen = true;
                this.appUtils.sidePanelOpen(this.isOpen);
            } else {
                this.hide();
            }
        },

        /**
         * Hide the widget panel
         */
        hide: function() {
            this.isOpen = false;
            esriConfig.defaults.io.alwaysUseProxy = false;
            html.removeClass(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
            }
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Create widget UI.
         * Combo box to select layer type and display information related to selected type.
         */
        _createWidgetUI: function() {
            domAttr.set(this.selectLayerMessage, "innerHTML", sharedNls.AddLayer.displayMessages.message);
            domAttr.set(this.lableLayerurl, "innerHTML", sharedNls.AddLayer.displayMessages.layerUrl);
            this._cmbLayerType = new Select();
            this._cmbLayerType.placeAt(this.cmbLayerTypeDiv).startup();
            this._layerFormatType = new Select();
            this._layerFormatType.placeAt(this.layerFormatDiv).startup();
            this._sampleUrl = sharedNls.AddLayer.layerSetting.layers[0].sampleUrl;
            array.forEach(sharedNls.AddLayer.layerSetting.layers, lang.hitch(this, function(layer) {
                this._cmbLayerType.addOption({
                    label: layer.label,
                    value: layer.value,
                    sampleUrl: layer.sampleUrl
                });
            }));
            domAttr.set(this.labExampleDiv, "innerHTML", this._sampleUrl);
            this._txtLayerUrl = new TextBox({
                "class": "urlTextbox"
            }, this.txtLayerURLDiv);
            domAttr.set(this.LayerMessage, "innerHTML", sharedNls.AddLayer.displayMessages.layermessage);
            this._txtLayerName = new TextBox({
                "class": "urlTextbox"
            }, this.Layerdiv);
            domAttr.set(this.lblIconGeoRss, "innerHTML", sharedNls.AddLayer.displayMessages.iconGeoRSS);
            this._txtGeoRSS = new TextBox({
                "class": "urlTextbox"
            }, this.iconGeoRssDIV);
            domStyle.set(this.iconGeoRSSContainer, "display", "none");
            this._txtImgBounds = new ValidationTextBox({
                "class": "txtImgBounds",
                "regExp": "^[0-9,-. ]*$",
                "invalidMessage": sharedNls.AddLayer.errorMessages.invalidFormat
            }, this.txtImageBoundsDiv);
            domAttr.set(this.lablesize, "innerHTML", sharedNls.AddLayer.displayMessages.Size);
            this._txtImgSize = new ValidationTextBox({
                "class": "txtSizeBounds",
                "regExp": "^[0-9,. ]*$",
                "maxlength": "15",
                "invalidMessage": sharedNls.AddLayer.errorMessages.invalidFormat
            }, this.txtSizeDiv);
            domStyle.set(this.wmsLayerFormat, "display", "none");
            this._layerFormatType.addOption({
                label: sharedNls.AddLayer.displayMessages.LayerFormatType,
                value: sharedNls.AddLayer.displayMessages.LayerFormatType
            });
            domStyle.set(this.lableImgContainer, "display", "none");
            domStyle.set(this.LayerProjection, "display", "block");
            this._rdoCached = new RadioButton({
                checked: false,
                value: "Cached",
                name: "projection"
            }, this.rdoCached).startup();
            this._rdoDynamic = new RadioButton({
                checked: false,
                value: "Dynamic",
                name: "projection"
            }, this.rdoDynamic).startup();
            this._btnAddLayer = new Button({
                label: sharedNls.AddLayer.layerSetting.btnAddLabel
            }, this.btnAddDiv);
            this._btnAddBasemap = new Button({
                label: sharedNls.AddLayer.displayMessages.AddBasemap
            }, this.btnAddBasemapDiv);
            domStyle.set(this.btnAddBasemapDivHide, "display", "block");
            on(this._txtLayerUrl, "keydown", lang.hitch(this, function(evt) {
                if (evt.keyCode === 13) {
                    var inputUrl = lang.trim(this._txtLayerUrl.displayedValue);
                    this._getProjection(inputUrl);
                }
            }));
            on(this._btnAddBasemap, "click", lang.hitch(this, function(evt) {
                this._addCustomBasemap();
            }));
            
            this._btnValidate = new Button({
                label:"Validate"
            }, this.btnValidateDiv);
            on(this._btnValidate, "click", lang.hitch(this, function (evt) {
                var inputUrl = lang.trim(this._txtLayerUrl.displayedValue);
                this._getProjection(inputUrl);
            }));
            domStyle.set(this.btnValidateDivHide, "display", "block");
        },

        /**
         * Function to add custom base map in base map Gallery widget.
         */
        _addCustomBasemap: function() {
            if (this._cmbLayerType.value === "WebMapServer") {
                this._shelter.show();
                var customBaseMapName = this._txtLayerName.displayedValue;
                if (customBaseMapName !== "") {
                    var customBaseMapUrl = lang.trim(this._txtLayerUrl.displayedValue);
                    if (customBaseMapUrl !== "") {
                       
                        //if (this.nonEditableTextboxDiv.textContent !== " ") {
                        if (document.getElementById("Cached").checked || document.getElementById("Dynamic").checked) {
                            esriConfig.defaults.io.alwaysUseProxy = true;
                            esriRequest({
                                url: customBaseMapUrl,
                                content: lang.mixin({
                                    f: "json"
                                }, null),
                                callbackParamName: "callback",
                                load: lang.hitch(this, function (response) {
                                    esriConfig.defaults.io.alwaysUseProxy = false;
                                    var isCached = 0;
                                    if (document.getElementById("Cached").checked) {
                                    	isCached = 1;
                                        if (!response.hasOwnProperty("tileInfo")) {
                                            this._shelter.hide();
                                            domAttr.set(this._txtLayerUrl, "displayedValue", "");
                                            domAttr.set(this._txtLayerName, "displayedValue", "");
                                            this.nonEditableTextboxDiv.textContent = "";
                                            dojoQuery(".rdoProjection input[type=radio]").forEach(
                                                function(node) {
                                                    var radioButton = registry.getEnclosingWidget(node);
                                                    if (radioButton) {
                                                        radioButton.set("checked", false);
                                                    }
                                                }
                                            );
                                            //this.nc4Notify.warn("Unable to add as cached layer");
                                            this.nc4Notify.error("Unable to add as cached layer");
                                            this._shelter.hide();
                                            return false;
                                        }
                                    }
                                    if (document.getElementById("Dynamic").checked) {
                                        if (response.hasOwnProperty("tileInfo")) {
                                            domAttr.set(this._txtLayerUrl, "displayedValue", "");
                                            domAttr.set(this._txtLayerName, "displayedValue", "");
                                            this.nonEditableTextboxDiv.textContent = "";
                                            dojoQuery(".rdoProjection input[type=radio]").forEach(
                                                function(node) {
                                                    var radioButton = registry.getEnclosingWidget(node);
                                                    if (radioButton) {
                                                        radioButton.set("checked", false);
                                                    }
                                                }
                                            );
                                            this.nc4Notify.warn("Unable to add as dynamic layer");
                                            this._shelter.hide();
                                            return false;
                                        }
                                    }
                                    var layer = this.map.getLayer(this.map.layerIds[0]);
                                    var currentBasemapSR = layer.spatialReference.wkid;
                                    var selectedBasemapSR = response.fullExtent.spatialReference.wkid;
                                    if (currentBasemapSR === selectedBasemapSR) {
                                        this._changeBasemapWithSameSR(customBaseMapUrl, customBaseMapName);
                                    } else {
                                        this._changeBasemapWithDiffSR(response, customBaseMapUrl, customBaseMapName);
                                    }
                                    this._saveCustomBasemap(customBaseMapUrl, customBaseMapName, isCached);
                                }),
                                error: lang.hitch(this, function(err) {
                                	this.nc4Notify.error(err);
                                    this._shelter.hide();
                                })
                            });
                        } else {
                            this.nc4Notify.warn("Please select Cached/Dynamic");
                            this._shelter.hide();
                        }
                    } else {
                    	this.nc4Notify.warn("Please enter the layer URL");
                        this._shelter.hide();
                    }
                } else {
                    this.nc4Notify.warn("Please enter a name for the layer");
                    this._shelter.hide();
                }
            }
        },

        /**
         * Function to save custom base map.
         */
        _saveCustomBasemap: function(customBaseMapUrl, customBaseMapName, p_isCached) {
        	var arcGIS_type = "";
        	if(p_isCached == 1)
        		arcGIS_type = "arcgis_cached_service";
        	else
        		arcGIS_type = "arcgis_dynamic_service";
            var jsonSaveBasemap = [{
                "layer_name": customBaseMapName,
                "layer_type": arcGIS_type,
                "url": customBaseMapUrl,
                "is_baseMap": "1",
                "is_cached": p_isCached,
                "tileSizeH": "234",
                "tileSizeW": "234",
                "sub-layers": "[est]"
            }];
            var objJson = JSON.stringify(jsonSaveBasemap);
            esriRequest({
                url: this.config.CustomBasemapSaveService,
                content: lang.mixin({
                    customLayers: objJson
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, function(response) {
                    if (response.success === true) {
                        this.nc4Notify.success("Base map was successfully saved");
                        this.appUtils.addCustomBaseMapFromAddLayer(true);
                        domAttr.set(this._txtLayerUrl, "displayedValue", "");
                        domAttr.set(this._txtLayerName, "displayedValue", "");
                        this.nonEditableTextboxDiv.textContent = "";
                        dojoQuery(".rdoProjection input[type=radio]").forEach(
                            function(node) {
                                var radioButton = registry.getEnclosingWidget(node);
                                if (radioButton) {
                                    radioButton.set("checked", false);
                                }
                            }
                        );
                        this._shelter.hide();
                    }
                }),
                error: lang.hitch(this, function(err) {
                    //this.nc4Notify.error("Unable to Save the basemap");
                    this.nc4Notify.error("Unable to save base map");
                    this._shelter.hide();
                })
            });
        },

        /**
         * Function to get all layers on the map.
         */
        _getLayersOnMap: function() {
            this._arrLayersOnMap = [];
            for (var i = 0; i < this.map.graphicsLayerIds.length; i++) {
                var objLayer = this.map.getLayer(this.map.graphicsLayerIds[i]);
                this._arrLayersOnMap.push(objLayer);
            }
            for (var j = 0; j < this.map.layerIds.length; j++) {
                var objLayers = this.map.getLayer(this.map.layerIds[j]);
                this._arrLayersOnMap.push(objLayers);
            }
        },

        /**
         * Function to change base map with same spatial reference.
         * @param {string} selectedBasemapUrl - Base map url
         * @param {string} customBaseMapName - Base map name
         */
        _changeBasemapWithSameSR: function(customBaseMapUrl, customBaseMapName) {
            var sameSRBaseMap;
            var k = 0;
            var layer = this.map.getLayer(this.map.layerIds[k]);
            this.map.removeLayer(layer);
            if (document.getElementById("Cached").checked) {
                esriConfig.defaults.io.alwaysUseProxy = true;
                sameSRBaseMap = new ArcGISTiledMapServiceLayer(customBaseMapUrl, {
                    id: customBaseMapName,
                    visible: true
                });
                esriConfig.defaults.io.alwaysUseProxy = false;
            }
            if (document.getElementById("Dynamic").checked) {
                esriConfig.defaults.io.alwaysUseProxy = true;
                sameSRBaseMap = new ArcGISDynamicMapServiceLayer(customBaseMapUrl, {
                    id: customBaseMapName,
                    visible: true,
                    opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,				//james - same as this.appUtils.configGeneralSettings.defaultOpacity
                    refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0
                });
                esriConfig.defaults.io.alwaysUseProxy = false;
            }
            this.map.addLayer(sameSRBaseMap);
            this.map.reorderLayer(sameSRBaseMap, 0);
            on(sameSRBaseMap, "load", lang.hitch(this, function() {
                this.map.autoResize = true;
                this.map.enableKeyboardNavigation();
                this.appUtils.updateMapInstance(this.map);
                this.appUtils.addCustomBaseMapFromAddLayer(true);
                this._shelter.hide();
            }));
        },

        /**
         * Function to change base map with different spatial reference.
         * @param {string} selectedBasemapUrl - Base map url
         * @param {string} customBaseMapName - Base map name
         */
        _changeBasemapWithDiffSR: function(response, customBaseMapUrl, customBaseMapName) {
            var k = 0;
            var layer = this.map.getLayer(this.map.layerIds[k]);								//remove current base map
            this.map.removeLayer(layer);
            this._getLayersOnMap();
            this.map.destroy();																	//destroys the map
            var initialExtent = new Extent({
                "xmin": response.fullExtent.xmin,
                "ymin": response.fullExtent.ymin,
                "xmax": response.fullExtent.xmax,
                "ymax": response.fullExtent.ymax,
                "spatialReference": {
                    "wkid": response.fullExtent.spatialReference.wkid
                }
            });
            var map = new Map(this.appUtils.mapNode, {											//re-create the map
                extent: initialExtent
            });
            this.map = map;
            if (document.getElementById("Cached").checked) {
                var diffSRBasemap;
                esriConfig.defaults.io.alwaysUseProxy = true;
                diffSRBasemap = new ArcGISTiledMapServiceLayer(customBaseMapUrl, {
                    id: customBaseMapName,
                    visible: true,
                    opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,				//james - same as this.appUtils.configGeneralSettings.defaultOpacity
                    refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0
                });
                esriConfig.defaults.io.alwaysUseProxy = false;
            }
            if (document.getElementById("Dynamic").checked) {
                esriConfig.defaults.io.alwaysUseProxy = true;
                diffSRBasemap = new ArcGISDynamicMapServiceLayer(customBaseMapUrl, {
                    id: customBaseMapName,
                    visible: true,
                    opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,				//james - same as this.appUtils.configGeneralSettings.defaultOpacity
                    refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0
                });
                esriConfig.defaults.io.alwaysUseProxy = false;
            }
            this.map.addLayer(diffSRBasemap);
            this.map.reorderLayer(diffSRBasemap, 0);													//add base map
            on(diffSRBasemap, "load", lang.hitch(this, function() {
                this.map.autoResize = true;
                this.map.enableKeyboardNavigation();
                array.forEach(this._arrLayersOnMap, lang.hitch(this, function(layer) {
                    this.map.addLayer(layer);															//re-add layers
                }));
                this.appUtils.updateMapInstance(this.map);
                this._shelter.hide();
            }));
        },

        /**
         * Attach widget related events
         */
        _attachWidgetRelatedEvents: function() {
        	on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
            }));
            on(this._cmbLayerType, "change", lang.hitch(this, function(option) {
                if (option == "WebAccessibleImage") {
                    domAttr.set(this.lableLayerurl, "innerHTML", sharedNls.AddLayer.displayMessages.ImglayerUrl);
                    domAttr.set(this.labExampleDiv, "innerHTML", "");
                    domAttr.set(this._txtLayerUrl, "displayedValue", "");
                    domAttr.set(this._txtLayerName, "displayedValue", "");
                    domAttr.set(this._txtImgBounds, "displayedValue", "");
                    domAttr.set(this._txtImgSize, "displayedValue", "");
                    domAttr.set(this.lableImgurl, "innerHTML", sharedNls.AddLayer.displayMessages.Imagebounds);
                    domStyle.set(this.lableImgContainer, "display", "block");
                    domStyle.set(this.wmsLayerFormat, "display", "none");
                    domStyle.set(this.LayerProjection, "display", "none");
                    domStyle.set(this.btnAddBasemapDivHide, "display", "none");
                    domStyle.set(this.btnValidateDivHide, "display", "none");
                    html.removeClass(this.btnAddLayerDiv, "btnAddLayerDiv");
                    html.addClass(this.btnAddLayerDiv, "btnAddLayerMargin");
                    domStyle.set(this.iconGeoRSSContainer, "display", "none");
                } else {
                    domAttr.set(this.lableLayerurl, "innerHTML", sharedNls.AddLayer.displayMessages.layerUrl);
                    array.forEach(this._cmbLayerType.options, lang.hitch(this, function(layer) {
                        if (layer.value == option) {
                            domAttr.set(this._txtLayerUrl, "displayedValue", "");
                            domAttr.set(this.labExampleDiv, "innerHTML", layer.sampleUrl);
                            domStyle.set(this.lableImgContainer, "display", "none");
                            domStyle.set(this._layerFormatType, "display", "none");
                            domAttr.set(this._txtLayerName, "displayedValue", "");
                            domStyle.set(this.wmsLayerFormat, "display", "none");
                            domStyle.set(this.LayerProjection, "display", "none");
                            domStyle.set(this.btnAddBasemapDivHide, "display", "none");
                            domStyle.set(this.btnValidateDivHide, "display", "none");
                            html.removeClass(this.btnAddLayerDiv, "btnAddLayerDiv");
                            html.addClass(this.btnAddLayerDiv, "btnAddLayerMargin");
                            domStyle.set(this.iconGeoRSSContainer, "display", "none");
                        }
                    }));
                }
                if (option == "GeoRSSFeed") {
                    domStyle.set(this.iconGeoRSSContainer, "display", "block");
                }
                if (option == "WebMapService") {
                    domStyle.set(this.wmsLayerFormat, "display", "block");
                }
                if (option == "WebMapServer") {
                    domStyle.set(this.LayerProjection, "display", "block");
                    domStyle.set(this.btnAddBasemapDivHide, "display", "block");
                    domStyle.set(this.btnValidateDivHide, "display", "block");
                    html.addClass(this.btnAddLayerDiv, "btnAddLayerDiv");
                    html.removeClass(this.btnAddLayerDiv, "btnAddLayerMargin");
                }
            }));
            on(this._btnAddLayer, touch.press, lang.hitch(this, function(e) {
                this._shelter.show(sharedNls.LoadingShelter.lblLoading);
                this._addLayer();
            }));
        },

        /**
         *This function validates the layer provided by the user and depending on the type adds the required layer.
         */
        _addLayer: function() {
            var inputUrl = lang.trim(this._txtLayerUrl.displayedValue),
                isValidUrl,
                imgBounds,
                imgSize,
                i,
                j,
                layerNames,
                serviceLayerNames,
                regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
            this._layerName = lang.trim(this._txtLayerName.displayedValue);
            if (this.appUtils.customLayerServiceName.length > 0) {
                for (i = 0; i < this.appUtils.customLayerServiceName.length; i++) {
                    serviceLayerNames = this.appUtils.customLayerServiceName[i].toUpperCase();
                    if (serviceLayerNames == this._layerName.toUpperCase()) {
                    	this.nc4Notify.warn(sharedNls.Bookmark.nameExists);
                        this._shelter.hide();
                        return false;
                    }
                }
            }
            if (this.appUtils.customLayerName.length > 0) {
                for (j = 0; j < this.appUtils.customLayerName.length; j++) {
                    layerNames = this.appUtils.customLayerName[j].toUpperCase();
                    if (layerNames == this._layerName.toUpperCase()) {
                    	this.nc4Notify.warn(sharedNls.Bookmark.nameExists);
                        this._shelter.hide();
                        return false;
                    }
                }
            }
            if (inputUrl === "") {
                this._shelter.hide();
                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.emptyUrl);
            } else if (this._layerName === "") {
                this._shelter.hide();
                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.emptyLayer);
            } else {
                isValidUrl = regexp.test(inputUrl); //Validating the url provided using regular expression.
                if (inputUrl !== "" && isValidUrl === true) {
                    if (this._cmbLayerType.value == "KML") {
                        this._addKMLLayer(inputUrl);
                    } else if (this._cmbLayerType.value == "WebService") {
                        //For adding feature server/layers.
                        this._addLayerFromWebService(inputUrl);
                    } else if (this._cmbLayerType.value == "WebMapServer") {
                        //For adding map server layers.
                    	this._addLayerFromWebMapServer(inputUrl);
                    } else if (this._cmbLayerType.value == "FeatureCollection") {
                        this._getFeatureCollectionLayerData(inputUrl);
                    } else if (this._cmbLayerType.value == "GeoRSSFeed") {
                        var geoRSSIcon = this._txtGeoRSS.displayedValue;
                        this._addGeoRssFeeds(inputUrl, geoRSSIcon);
                    } else if (this._cmbLayerType.value == "WebMapService") {				
                        //For adding wms layer.
                    	//var maxHeight = this.wmsMaxHeight.value || "0";
                    	//var maxWidth = this.wmsMaxWidth.value || "0";
                    	//var wmsMgr = new WMSManager(this._layerName, this.appUtils, this.map, inputUrl, [], Number(maxWidth), Number(maxHeight) );
                    	//var parentTreeNodeId = "WebMapService_" + this._LayerId;
                    	//wmsMgr._addWebMapService(this._shelter, this._LayerId, parentTreeNodeId, true, true);
                    	this._LayerId++;
                    } else if (this._cmbLayerType.value == "WebAccessibleImage") {
                        imgBounds = this._txtImgBounds.displayedValue;
                        imgSize = this._txtImgSize.displayedValue;
                        this._validateImgformat(inputUrl, imgBounds, imgSize);
                    } else if (this._cmbLayerType.value == "WebMapTiledService") {
                        this._addWebMapTiledService(inputUrl);
                    } else if (this._cmbLayerType.value == "csvlayer") {
                        this._addCSVLayer(inputUrl);
                    }
                } else {
                    this._shelter.hide();
                    this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.invalidURLError);
                }
            }

        },

        _serviceLayerNames: function() {
            esriRequest({
                url: this.config.CustomLayerTreeLayerService,
                content: lang.mixin({
                    f: "json"
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, function(response) {
                    if (response.DataLayerGroups[0].id === "customLayers") {
                        for (var h = 0; h < response.DataLayerGroups[0].layers.length; h++) {
                            this.appUtils.customLayerServiceNames(response.DataLayerGroups[0].layers[h].name);
                        }
                    }
                }),
                error: lang.hitch(this, function(err) {
                    //this.nc4Notify.error("Service is not available.");
                	this.nc4Notify.error("Service is not available.");
                    this._shelter.hide();
                })
            });
        },


        /**
         *This function validates the layer url.
         */
        _getProjection: function(evt) {
            var isValidUrl,
                inputUrl = lang.trim(this._txtLayerUrl.displayedValue),
                params,
                regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
            if (inputUrl === "") {
                this._shelter.hide();
                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.emptyUrl);
            } else {
                isValidUrl = regexp.test(inputUrl); //Validating the url provided using regular expression.
                if (inputUrl !== "" && isValidUrl === true) {
                    params = {
                        "f": "json"
                    };
                    esriConfig.defaults.io.alwaysUseProxy=true;
                    esriRequest({
                        url: inputUrl,
                        content: params,
                        handelAs: "json",
                        load: lang.hitch(this, this._showResults),
                        error: lang.hitch(this, this._showerr)
                    }, {
                        useProxy: false
                    });
                    esriConfig.defaults.io.alwaysUseProxy=false;
                } else {
                    this._shelter.hide();
                    this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.invalidURLError);
                }
            }
        },

        /**
         *Function to display the results after validates the layer url.
         */
        _showResults: function(responce) {
            this.nonEditableTextboxDiv.innerHTML = "Supported " + " : " + responce.fullExtent.spatialReference.wkid;
            this.lastMapServiceWkid = responce.fullExtent.spatialReference.wkid;
            document.getElementById("Cached").disabled = true;
            document.getElementById("Dynamic").disabled = false;
            dojoQuery(".rdoProjection input[type=radio]").forEach(
                function(node) {
                    var radioButton = registry.getEnclosingWidget(node);
                    if (radioButton && radioButton.value === "Dynamic") {
                        radioButton.set("checked", true);
                    }
                }
            );
            if (responce.hasOwnProperty("tileInfo")) {
                document.getElementById("Dynamic").disabled = true;
                document.getElementById("Cached").disabled = false;
                dojoQuery(".rdoProjection input[type=radio]").forEach(
                    function(node) {
                        var radioButton = registry.getEnclosingWidget(node);
                        if (radioButton && radioButton.value === "Cached") {
                            radioButton.set("checked", true);
                        }
                    }
                );
            }
        },

        /**
         *Function to display the error results after validates the layer url.
         */
        _showerr: function(res) {
            this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.invalidURLError);
        },

        /**
         * This function validates the url (by checking if the url contains string '.gif|jpg|png|bmp'). If valid call '_webAccessibleImage()'  else throws exception.
         * @param {string} inputUrl - Url for Image layer.
         * @param {string} imgBounds - Image Extents for Web Accessible Image.
         * @param {string} imgSize - Height and Width for Web Accessible Image.
         */
        _validateImgformat: function(inputUrl, imgBounds, imgSize) {
            var isValidUrl,
                regboundswidth = /^[0-9,-. ]*$/i,
                regexpimg = /\.(gif|jpg|png|bmp)$/i;
            isValidUrl = regexpimg.test(inputUrl);
            if (imgBounds.trim() === "" || regboundswidth.test(imgBounds) === false) {
                this._shelter.hide();
                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.emptyExtent);
            } else if (imgSize.trim() === "" || regboundswidth.test(imgSize) === false) {
                this._shelter.hide();
                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.emptyExtent);
            } else if (inputUrl !== "" && isValidUrl === true) {
                this._webAccessibleImage(inputUrl, imgBounds, imgSize);
            } else {
                this._shelter.hide();
                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.invalidFormatError);
            }
        },

        /**
         * This function validates the url (by checking if the url contains string '.kml'). If valid call '_addKMLLayer()'  else throws exception.
         * @param {string} strUrl - Url for kml layer.
         */
        //james - removing this for now, it doesn't seem to be working correctly and is just a waste of a request
        /*
        _validateKmlLayer: function(strUrl) {
            var cmpString,
                requestHandle;
            //esriConfig.defaults.io.alwaysUseProxy = true;
            requestHandle = esriRequest({		//jameskml
                "url": strUrl
            });
            requestHandle.then(lang.hitch(this, function(response) {}), lang.hitch(this, function(error) {
                cmpString = lang.trim(error.message);

                if (cmpString.toLowerCase() === "Access is denied.".toLowerCase()) {
                    this._shelter.hide();
                    this.nc4Notify.error(sharedNls.AddLayer.errorMessages.invalidURLError);
                    return;
                }
                if (_.contains(strUrl, ".kml") || _.contains(strUrl, ".kmz")) {
                    this._addKMLLayer(strUrl);
                } else {
                    this._shelter.hide();
                    this.nc4Notify.error(sharedNls.AddLayer.errorMessages.invalidURLError);
                    return;
                }
            }));
            
        },
	*/
        /**
         * This function adds KML  layer else throws exception.
         * @param {string} strUrl - Url for kml layer.
         */
        _addKMLLayer: function(strUrl) {
            var kml,
                layerId,
                layerInfo,
                template = new InfoTemplate("Attributes", "${*}"),
                layerIDkml = "KML_" + this._LayerId + "_layer",
                treeNodeID = "KML_" + this._LayerId;
           // esriConfig.defaults.io.alwaysUseProxy = true;
            kml = new KMLLayer(strUrl, {
                id: layerIDkml,
                name: this._layerName,
                outFields: ["*"],
                infoTemplate: template,
                opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0,
                outSR: this.map.spatialReference
            });
            kml.customLayerType = "kml";
            this.map.addLayer(kml);
            this.appUtils.customLayerCount++;
            var layerDetail = {
                "type": "kml",
                "url": strUrl,
                "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
                "bbox": 0,
                "id": treeNodeID,
                "name": this._layerName,
                "state": 1,
                "sr": 102100,
                "basemap": 0,
                "parent": "customLayers",
                "layerFromAddLayer": true
            };
            this.appUtils.customLayerAdded(layerDetail);
            this.appUtils.customLayerNameAdded(this._layerName);
            this.own(on(kml, "load", lang.hitch(this, function (evt) {
                layerId = this.map.graphicsLayerIds[this.map.graphicsLayerIds.length - 1];
                layerInfo = this.map.getLayer(layerId);
                
                var layers = kml.getLayers();
                var allGraphics = [];
                for(var i = 0; i < layers.length; i++)
                {
                	var lyr = layers[i];
                	if ( lyr.graphics && lyr.graphics.length > 0 ) 
                  	  allGraphics = allGraphics.concat(lyr.graphics);
                }
               
                if(allGraphics.length > 0)
                {
                	var kmlExtent = graphicsUtils.graphicsExtent(allGraphics);
                	
                    var layer = this.map.getLayer(this.map.layerIds[0]);
                    var baseMapExtent = layer.fullExtent;
                	
                    if(baseMapExtent.contains(kmlExtent))
                    	this.map.setExtent(kmlExtent);
                    else
                    	this.map.setExtent(baseMapExtent);
                }
                
                this._LayerId++;
                this._shelter.hide();
                domAttr.set(this._txtLayerUrl, "displayedValue", "");
                domAttr.set(this._txtLayerName, "displayedValue", "");
            })));
            this.own(on(kml, "error", lang.hitch(this, function (evt) {
                esriConfig.defaults.io.alwaysUseProxy = false;
                var message = evt.error.message;
                var notValid = message.indexOf("Unable to load KML");
                if (notValid !== -1) {
                    layerDetail.strike = "Yes";
                    if (this.isOpen === true) {
                        this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.notCompatible);
                    }
                    this.appUtils.layerAddedOnBasemap(true);
                    this._shelter.hide();
                } else {
                    this.map.removeLayer(kml);
                    this._shelter.hide();
                }
            })));
        },
        
        
        /**
         * This function adds KML  layer else throws exception.
         * @param {string} strUrl - Url for MapTiled layer.
         */
        _addWebMapTiledService: function(strUrl) {
            var layerInfo;
            layerInfo = new WMTSLayerInfo({
                identifier: "opengeo:countries",
                tileMatrixSet: "EPSG:4326",
                format: "png"
            });
            var options = {
                serviceMode: "KVP",
                layerInfo: layerInfo,
                id: "WMTS_" + this._LayerId + "_layer",
                name: this._layerName
            };
            var wmtsLayer = new WMTSLayer(strUrl, options);
            this.map.addLayer(wmtsLayer);
            var layerDetail = {
                "type": "wmts",
                "url": strUrl,
                "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
                "bbox": 0,
                "id": "WMTS_" + this._LayerId,
                "name": this._layerName,
                "state": 1,
                "sr": 102100,
                "basemap": 0,
                "parent": "customLayers",
                "layerFromAddLayer": true
            };
            this.appUtils.customLayerAdded(layerDetail);
            this.appUtils.customLayerNameAdded(this._layerName);
            this.own(on(wmtsLayer, "load", lang.hitch(this, function(evt) {
                this._LayerId++;
                this._shelter.hide();
                domAttr.set(this._txtLayerUrl, "displayedValue", "");
                domAttr.set(this._txtLayerName, "displayedValue", "");
            })));
            this.own(on(wmtsLayer, "error", lang.hitch(this, function(evt) {
                var message = evt.error.message;
                var notValid = message.indexOf("Unable to load image");
                if (notValid !== -1) {
                    layerDetail.strike = "Yes";
                    this.appUtils.layerAddedOnBasemap(true);
                    if (this.isOpen === true) {
                        this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.notCompatible);

                    }
                    this.appUtils.layerAddedOnBasemap(true);
                    this._shelter.hide();
                } else {
                    this.map.removeLayer(wmtsLayer);
                    this._shelter.hide();
                }
            })));
        },

       

        /**
         * This function validates the url( by checking if the url contains FeatureServer/MapServer ), if valid adds web service layer else throws exception.
         * @param {string} strUrl - Url for WebService.
         */
        _addLayerFromWebService: function(strUrl) {
                if (strUrl.indexOf("FeatureServer/") !== -1 || strUrl.indexOf("MapServer/") !== -1) {		//Feature Layer may have MapServer string in it instead
                    var process = this._addFeatureLayer(strUrl, "customLayers", "", "arcgis_map_service");
                    process.then(lang.hitch(this, function(evt) {
                        this._shelter.hide();
                    }));
                } else if (strUrl.indexOf("FeatureServer") !== -1) {
                    var mapServerTreeNodeID = "WebService_" + this._LayerId;
                    var webFeatureServerLayer = {
                        "id": mapServerTreeNodeID,
                        "name": this._layerName,
                        "state": 1,
                        "parent": "customLayers",
                        "layerFromAddLayer": true,
                        "type": "arcgis_map_service",
                        "url": strUrl,
                        "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                        "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0
                    };
                    this._LayerId++;
                    this.appUtils.customLayerCount++;
                    this.appUtils.customLayerAdded(webFeatureServerLayer);
                    this.appUtils.customLayerNameAdded(this._layerName);
                    if(strUrl.indexOf(location.hostname) >= 0)
                    	esriConfig.defaults.io.alwaysUseProxy = false;
                    else
                    	esriConfig.defaults.io.alwaysUseProxy = true;
                    esriRequest({
                        url: strUrl,
                        content: lang.mixin({
                            f: "json"
                        }, null),
                        callbackParamName: "callback",
                        load: lang.hitch(this, function (response) {
                            esriConfig.defaults.io.alwaysUseProxy = false;
                            var deferredArray = [];
                            array.forEach(response.layers, lang.hitch(this, function(layer) {
                                deferredArray.push(this._addFeatureLayer(strUrl + "/" + layer.id, mapServerTreeNodeID, layer.name, "arcgis_map_service", deferredArray));
                            }));
                            all(deferredArray).then(lang.hitch(this, function() {
                                this._shelter.hide();
                            }));
                        }),
                        error: lang.hitch(this, function (err) {
                            esriConfig.defaults.io.alwaysUseProxy = false;
                            this._shelter.hide();
                            this.nc4Notify.error(err);
                        })
                    });
                }
            
        },

        /**
         * This function to add map server on map and it's checks the map server is dynamic layer or cached layer.
         * @param {string} strUrl - Url for map server.
         */
        _addLayerFromWebMapServer: function(strUrl) {
            if (document.getElementById("Cached").checked || document.getElementById("Dynamic").checked) {
                if (document.getElementById("Cached").checked) 
                {
                	var cachedMgr = new ArcGISMSCachedManager(this._layerName, this.appUtils, this.map, strUrl, this._shelter, null, 100, 0);
                    cachedMgr._addCachedServiceToMap(sharedNls.AddLayer.errorMessages.notCompatible, this.lastMapServiceWkid);
                    cachedMgr._addCachedServiceNodeToLayerTree();
                } 
                else if (document.getElementById("Dynamic").checked) {
                    //this._addDynamicMapServer(strUrl);
                	var arcGisMSmgr = new ArcGISMSmanager(this._layerName, this.appUtils, this.map, strUrl, this._LayerId, this._shelter, null, true);
                	arcGisMSmgr._addDynamicServiceInfoToTree();
                	arcGisMSmgr._addDynamicMapServer3(null, true, true);
                } else {
                    this._shelter.hide();
                    this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.selectMapServer);
                }
            } else {
                this._shelter.hide();
                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.selectMapServer);
            }
        },

        /**
         * This function to add single map server on map. james
         * @param {string} strUrl - Url for map server.
         * @param {string} parentID - parentID for map server.
         * @param {string} layerName - layerName for map server.
         */
        _addFeatureLayer: function(strUrl, parentID, layerName) {
            this._alertCount = 0;
            this._alertOpen = false;
            var deferred = new Deferred();
            var featurLayer;
            var webMapServerDynamicLayer;
            var layerID = "WebService_" + this._LayerId + "_layer";
            var treeNodeID = "WebService_" + this._LayerId;
            var name = (layerName) ? layerName : this._layerName;
            
            if(strUrl.indexOf(location.hostname) >= 0)
            	esriConfig.defaults.io.alwaysUseProxy = false;
            else
            	esriConfig.defaults.io.alwaysUseProxy = true;
            featurLayer = new FeatureLayer(strUrl, {
                outFields: ["*"],
                id: layerID,
                name: this._layerName,
                opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0
            });
            featurLayer.customLayerType = "arcgis_map_service";
            this.map.addLayer(featurLayer);
            this._LayerId++;
            this.appUtils.customLayerCount++;
            on(featurLayer, "load", lang.hitch(this, function (evt) {
                esriConfig.defaults.io.alwaysUseProxy = false;
                webMapServerDynamicLayer = {
                    "type": "arcgis_map_service",
                    "url": strUrl,
                    "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                    "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
                    "bbox": 0,
                    "id": treeNodeID,
                    "name": name,
                    "state": 1,
                    "sr": 102100,
                    "basemap": 0,
                    "parent": parentID,
                    "layerFromAddLayer": true
                };
                if (evt.target.geometryType === "") {
                    deferred.resolve(true);
                    webMapServerDynamicLayer.strike = "Yes";
                    webMapServerDynamicLayer.unSupportedLayer = "Yes";
                    this.appUtils.customLayerAdded(webMapServerDynamicLayer);
                    this.appUtils.layerAddedOnBasemap(true);
                    domAttr.set(this._txtLayerUrl, "displayedValue", "");
                    domAttr.set(this._txtLayerName, "displayedValue", "");
                    this.nonEditableTextboxDiv.textContent = "";
                    dojoQuery(".rdoProjection input[type=radio]").forEach(
                        function(node) {
                            var radioButton = registry.getEnclosingWidget(node);
                            if (radioButton) {
                                radioButton.set("checked", false);
                            }
                        }
                    );
                    if (this.isOpen === true) {
                        this._alertCount++;
                        if (this._alertCount === 1) {
                            this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.notCompatible);
                        }
                    }
                    return deferred.promise;
                } else {
                    setTimeout(lang.hitch(this, function() {
                        deferred.resolve(true);
                        this.appUtils.customLayerAdded(webMapServerDynamicLayer);
                        this.appUtils.customLayerNameAdded(this._layerName);
                    }), 1000);
                    domAttr.set(this._txtLayerUrl, "displayedValue", "");
                    domAttr.set(this._txtLayerName, "displayedValue", "");
                    this.nonEditableTextboxDiv.textContent = "";
                    dojoQuery(".rdoProjection input[type=radio]").forEach(
                        function(node) {
                            var radioButton = registry.getEnclosingWidget(node);
                            if (radioButton) {
                                radioButton.set("checked", false);
                            }
                        }
                    );
                    this.map.setExtent(evt.target.fullExtent);
                    featurLayer.on("mouse-over", lang.hitch(this, function() {
                        this.map.setMapCursor("pointer");
                    }));
                    featurLayer.on("mouse-out", lang.hitch(this, function() {
                        this.map.setMapCursor("default");
                    }));
                    var contentinfo = new InfoTemplate(),
                        temdata = "";
                    contentinfo.setTitle("Attributes");
                    for (var i = 0; i < evt.target.fields.length; i++) {
                        temdata = temdata + "<div style='font-weight: bold;max-width:150px;width:125px;float: left;'>" + evt.target.fields[i].name + " </div> <div style='white-space: nowrap;line-height:5px'> ${" + evt.target.fields[i].name + "}</div><br/>";
                    }
                    contentinfo.setContent("<div style='float:left'>" + temdata + "</div>");
                    featurLayer.setInfoTemplate(contentinfo);
                }
            }));
            on(featurLayer, "error", lang.hitch(this, function (evt) {
                esriConfig.defaults.io.alwaysUseProxy = false;
                deferred.resolve(true);
                if (evt.target.geometryType !== "") {
                    if (evt.error.message === "Unable to draw graphic (null): Unable to complete  operation.") {
                        webMapServerDynamicLayer.strike = "Yes";
                        if (this.isOpen === true) {
                            if (this._alertCount === 0) {
                                this._alertCount++;
                                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.notCompatible);
                            }
                        }
                        this.appUtils.layerAddedOnBasemap(true);
                    }
                }
            }));
            return deferred.promise;
        },

        /**
         * This function adds GeoRSS layer else throws exception.
         * @param {string} strUrl - Url for GeoRSSFeed.
         */
        _addGeoRssFeeds: function(strUrl, geoRSSIcon) {
            var options = null;
            if (geoRSSIcon) {
                options = {
                    id: "GeoRSSFeed_" + this._LayerId + "_layer",
                    name: this._layerName,
                    opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                    refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0,
                    pointSymbol: new PictureMarkerSymbol(geoRSSIcon, 25, 25),
                    outSpatialReference: this.map.spatialReference
                };
            } else {
                options = {
                    id: "GeoRSSFeed_" + this._LayerId + "_layer",
                    name: this._layerName,
                    opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                    refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0,
                    outSpatialReference: this.map.spatialReference
                };
            }
           // esriConfig.defaults.io.alwaysUseProxy = true;
            var georss = new GeoRSSLayer(strUrl, options),
                layers,
                template = new InfoTemplate("Attributes", "${*}"); // create an info template, "${name}", "${description}");
            georss.customLayerType = "georss";
            this.map.addLayer(georss);
            this.appUtils.customLayerCount++;
            this.own(on(georss, "load", lang.hitch(this, function(evt) {
                /*
                 * Set the info template for the feature layers that make up the GeoRSS layer.
                 * The GeoRSS layer contains one feature layer for each geometry type.
                 */
                esriConfig.defaults.io.alwaysUseProxy = false;
                var geoRssLayer = {
                    "type": "georss",
                    "url": strUrl,
                    "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                    "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
                    "bbox": 0,
                    "id": "GeoRSSFeed_" + this._LayerId,
                    "name": this._layerName,
                    "state": 1,
                    "sr": 102100,
                    "basemap": 0,
                    "parent": "customLayers",
                    "layerFromAddLayer": true
                };
                this.appUtils.customLayerAdded(geoRssLayer);
                this.appUtils.customLayerNameAdded(this._layerName);
                /*
                var basemap = this.map.getLayer(this.map.layerIds[0]);
                var mapSR = basemap.spatialReference;
                var layer = this.map.getLayer(evt.target.id);
                var layerOutSR = layer.spatialReference;
                if (mapSR._isWebMercator() && 4326 === layerOutSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else if (layerOutSR._isWebMercator() && 4326 === mapSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else {
                    geoRssLayer.strike = "Yes";
                    if (this.isOpen === true) {
                        this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.notCompatible);
                    }
                    this.appUtils.layerAddedOnBasemap(true);
                    this._shelter.hide();
                }
                */
                layers = georss.getFeatureLayers();
                array.forEach(layers, function(l) {
                    l.setInfoTemplate(template);
                });
                this.map.setExtent(evt.layer.fullExtent);
                this._LayerId++;
                this._shelter.hide();
                domAttr.set(this._txtLayerUrl, "displayedValue", "");
                domAttr.set(this._txtLayerName, "displayedValue", "");
                domAttr.set(this._txtGeoRSS, "displayedValue", "");
            })));
            this.own(on(georss, "error", lang.hitch(this, function (evt) {
                esriConfig.defaults.io.alwaysUseProxy = false;
                this.map.removeLayer(georss);
                this._shelter.hide();
                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.invalidURLError);
            })));
        },
        
        /**
         * This function adds  Web Accessible Image else throws exception.
         * @param {string} strUrl - Url for Web Accessible Image.
         * @param {string} imgBounds - Image Extents for Web Accessible Image.
         * @param {string} imgSize - Height and Width for Web Accessible Image.
         */
        _webAccessibleImage: function(strUrl, imgBounds, imgSize) {
            var extent,
                getMapImage,
                mapimglayer,
                size;
            esriConfig.defaults.io.alwaysUseProxy = true;
            mapimglayer = new MapImageLayer({
                id: "WebAccessibleImage_" + this._LayerId + "_layer",
                name: this._layerName,
                opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0
            });
            extent = imgBounds.split(",");
            size = imgSize.split(",");
            getMapImage = new MapImage({
                "extent": {
                    "xmin": parseFloat(extent[0]),
                    "ymin": parseFloat(extent[1]),
                    "xmax": parseFloat(extent[2]),
                    "ymax": parseFloat(extent[3])
                },
                "href": strUrl,
                "height": size[0],
                "width": size[1]
            });
            
            on(this.map, "layer-reorder", lang.hitch(this, function() {
                this._shelter.hide();
            }));
            mapimglayer.addImage(getMapImage);
            this.appUtils.customLayerCount++;
            var webAccessibleImageLayer = {
                "type": "image",
                "url": strUrl,
                "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
                "bbox": 0,
                "id": "WebAccessibleImage_" + this._LayerId,
                "name": this._layerName,
                "state": 1,
                "sr": 102100,
                "basemap": 0,
                "parent": "customLayers",
                "layerFromAddLayer": true,
                "imgBounds": {
                    "xmin": parseFloat(extent[0]),
                    "ymin": parseFloat(extent[1]),
                    "xmax": parseFloat(extent[2]),
                    "ymax": parseFloat(extent[3])
                },
                "imgHeight": size[0],
                "imgWidth": size[1],
                "saveBounds": imgBounds
            };
            var basemap = this.map.getLayer(this.map.layerIds[0]);
            var basemapSR = basemap.spatialReference.wkid;
            if (basemapSR !== 102100 && basemapSR !== 4326) {
                webAccessibleImageLayer.strike = "Yes";
                if (this.isOpen === true) {
                    this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.notCompatible);
                }
                this.appUtils.layerAddedOnBasemap(true);
            }
            this.appUtils.customLayerAdded(webAccessibleImageLayer);
            this.appUtils.customLayerNameAdded(this._layerName);
            mapimglayer.customLayerType = "image";
            this._getImglayerdata.push(this.map.addLayer(mapimglayer));
            this._LayerId++;
            this.map.reorderLayer(mapimglayer, 1);
            esriConfig.defaults.io.alwaysUseProxy = false;
            domAttr.set(this._txtLayerUrl, "displayedValue", "");
            domAttr.set(this._txtImgBounds, "displayedValue", "");
            domAttr.set(this._txtImgSize, "displayedValue", "");
            domAttr.set(this._txtLayerName, "displayedValue", "");
        },

        /**
         * This function adds WMS layer else throws exception.
         * @param {string} strUrl - Url for WMS layer.
         */
        _addCSVLayer: function(strUrl) {
            var csvLayer,
                template;
            esriConfig.defaults.io.alwaysUseProxy = true;
            csvLayer = new CSVLayer(strUrl, {
                id: "CSVLayer_" + this._LayerId + "_layer",
                name: this._layerName,
                opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0
            });
            template = new InfoTemplate("Attributes", "${*}");
            csvLayer.customLayerType = "csv";
            this.map.addLayer(csvLayer);
            this.appUtils.customLayerCount++;
            var csvLayers = {
                "type": "csv",
                "url": strUrl,
                "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
                "bbox": 0,
                "id": "CSVLayer_" + this._LayerId,
                "name": this._layerName,
                "state": 1,
                "sr": 102100,
                "basemap": 0,
                "parent": "customLayers",
                "layerFromAddLayer": true
            };
            this.appUtils.customLayerAdded(csvLayers);
            this.appUtils.customLayerNameAdded(this._layerName);
            this.own(on(csvLayer, "load", lang.hitch(this, function (evt) {
                esriConfig.defaults.io.alwaysUseProxy = false;
                this.map.setExtent(evt.layer.fullExtent);
                this._LayerId++;
                this._shelter.hide();
                domAttr.set(this._txtLayerUrl, "displayedValue", "");
                domAttr.set(this._txtLayerName, "displayedValue", "");
                csvLayer.on("mouse-over", lang.hitch(this, function() {
                    this.map.setMapCursor("pointer");
                }));
                csvLayer.on("mouse-out", lang.hitch(this, function() {
                    this.map.setMapCursor("default");
                }));
                var contentinfo = new InfoTemplate(),
                    temdata = "";
                contentinfo.setTitle("Attributes");
                for (var i = 0; i < evt.layer.fields.length; i++) {
                    temdata = temdata + "<div style='font-weight: bold;max-width:150px;width:125px;float: left;'>" + evt.layer.fields[i].name + " </div> <div style='white-space: nowrap;line-height:5px'> ${" + evt.layer.fields[i].name + "}</div><br/>";
                }
                contentinfo.setContent("<div style='float:left'>" + temdata + "</div>");
                csvLayer.setInfoTemplate(contentinfo);
            })));
            this.own(on(csvLayer, "error", lang.hitch(this, function (evt) {
                esriConfig.defaults.io.alwaysUseProxy = false;
                if (evt.error.message === "Unable to draw graphic (null): Cannot read property '0' of null") {
                    csvLayers.strike = "Yes";
                    this.appUtils.layerAddedOnBasemap(true);
                    if (this.isOpen === true) {
                        this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.notCompatible);
                    }
                    this.appUtils.layerAddedOnBasemap(true);
                    this._shelter.hide();
                } else {
                    this._shelter.hide();
                }
            })));
        },

        /**
         * This function adds BaseMap else throws exception. 
         * @param {string} strUrl - Url for BaseMap layer.
         */
        _addBaseMap: function(strUrl) {
            var addbasemapLayer;
            esriConfig.defaults.io.alwaysUseProxy = true;
            addbasemapLayer = new ArcGISTiledMapServiceLayer(strUrl, {
                id: "getBasemap_" + this._LayerId,
                name: this._layerName,
                visible: true
            });
            this._getCustombasemap.push(this.map.addLayer(addbasemapLayer));
            this.own(on(addbasemapLayer, "load", lang.hitch(this, function (evt) {
                esriConfig.defaults.io.alwaysUseProxy = false;
                this._LayerId++;
                this._shelter.hide();
                domAttr.set(this._txtLayerUrl, "displayedValue", "");
                domAttr.set(this._txtLayerName, "displayedValue", "");
                if (this.map._layers.defaultBasemap.id == "defaultBasemap") {
                    var obj = this.map.getLayer("defaultBasemap");
                    this.map.removeLayer(obj);
                }
            })));
            esriConfig.defaults.io.alwaysUseProxy = false;
        },

        /**
         * This function validates the url by sending esri request, if valid pass the layer data to _addFeatureCollection() for adding feature collection.
         * @param {string} strUrl - Url for feature collection.
         * @param {string} strName - UFeature collection layer name.
         */
        _getFeatureCollectionLayerData: function(strUrl, strName) {
            var requestHandle = esriRequest({
                url: strUrl,
                callbackParamName: "jsoncallback"
            });
            requestHandle.then(lang.hitch(this, function(data) {
                this._addFeatureCollection(data, strUrl, strName);
            }), lang.hitch(this, function(error) {
                this._shelter.hide();
                this.nc4Notify.error(sharedNls.AddLayer.errorMessages.featureCollectionError + error);
            }));
        },

        /**
         * This function adds feature layer (feature collection object) to the map.
         * @param {object} data - Feature collection data object.
         * @param {string} strName - UFeature collection layer name.
         */
        _addFeatureCollection: function(data, strUrl, strName) {
            var featureCollection,
                featureLayer;
            featureCollection = {
                "layerDefinition": data.layerDefinition,
                "featureSet": {
                    "features": [],
                    "geometryType": "esriGeometryPoint"
                }
            };
            featureLayer = new FeatureLayer(featureCollection, {
                id: "FeatureCollection_" + this._LayerId + "_layer",
                name: this._layerName,
                outFields: ["*"],
                infoTemplate: new InfoTemplate("Attributes", "${*}"),
                opacity: this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                refreshInterval: this.appUtils.configGeneralSettings.defaultRefRate || 0
            });
            featureLayer.name = strName || "Feature Collection Layer";
            this.map.addLayer(featureLayer);
            this.appUtils.customLayerCount++;
            var featureCollectionLayer = {
                "layerTitle": "FeatureCollection",
                "type": "feature",
                "url": strUrl,
                "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
                "bbox": 0,
                "id": "FeatureCollection_" + this._LayerId,
                "name": this._layerName,
                "state": 1,
                "sr": 102100,
                "basemap": 0,
                "parent": "customLayers",
                "layerFromAddLayer": true
            };
            this.appUtils.customLayerAdded(featureCollectionLayer);
            this.appUtils.customLayerNameAdded(this._layerName);
            //setTimeout: loading of layers sometimes take time, so wait for 500seconds.
            setTimeout(lang.hitch(this, function() {
                var extent,
                    featuresList = [],
                    unionExtent = null;
                array.forEach(data.features, lang.hitch(this, function(item) {
                    var geometry = new Point(item.geometry.x, item.geometry.y, this.map.spatialReference),
                        graphic;
                    graphic = new Graphic(geometry);
                    graphic.setAttributes(item.attributes);
                    extent = new Extent(graphic.geometry.x - 1, graphic.geometry.y - 1, graphic.geometry.x + 1, graphic.geometry.y + 1, graphic.geometry.spatialReference);
                    if (unionExtent) {
                        unionExtent = unionExtent.union(extent);
                    } else {
                        unionExtent = new Extent(graphic.geometry.x - 1, graphic.geometry.y - 1, graphic.geometry.x + 1, graphic.geometry.y + 1, graphic.geometry.spatialReference);
                    }
                    featuresList.push(graphic);
                }));
                if (!strName) {
                    this.map.setExtent(unionExtent);
                }
                featureLayer.applyEdits(featuresList, null, null);
                this._LayerId++;
                this._shelter.hide();
                domAttr.set(this._txtLayerUrl, "displayedValue", "");
                domAttr.set(this._txtLayerName, "displayedValue", "");
            }), 500);
        }
    });
    return clazz;
});
