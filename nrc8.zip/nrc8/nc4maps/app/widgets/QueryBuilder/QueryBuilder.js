define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/on",
    "dojo/dom",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/dom-attr",
    "dojo/text!./QueryBuilderTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/aspect",
    "dojo/date/locale",
    "dojo/store/Memory",
    "dojo/_base/window",
    "dojo/json",
    "dgrid/OnDemandGrid",
    "dgrid/Keyboard",
    "dgrid/Selection",
    "dgrid/extensions/Pagination",
    "dijit/registry",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/Select",
    "dijit/form/TextBox",
    "dijit/form/Button",
    "dijit/form/MultiSelect",
    "dijit/form/Textarea",
    "esri/tasks/LegendLayer",
    "esri/layers/FeatureLayer",
    "esri/IdentityManager",
    "esri/tasks/Geoprocessor",
    "esri/tasks/QueryTask",
    "esri/tasks/query",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/BottomPanel/BottomPanel",
    "app/widgets/LoadingShelter/LoadingShelter"
], function (
    declare,
    html,
    lang,
    array,
    on,
    dom,
    domClass,
    domConstruct,
    domAttr,
    template,
    sharedNls,
    aspect,
    locale,
    Memory,
    win,
    JSON,
    Grid,
    Keyboard,
    Selection,
    Pagination,
    registry,
    _WidgetBase,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    Select,
    TextBox,
    Button,
    MultiSelect,
    Textarea,
    LegendLayer,
    FeatureLayer,
    IdentityManager,
    Geoprocessor,
    QueryTask,
    Query,
    WidgetPanel,
    BottomPanel,
    LoadingShelter
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        name: "QueryBuilder",
        baseClass: "widget-QueryBuilder",
        sharedNls: sharedNls,
        templateString: template,
        isOpen: false,
        _shelter: null,
        _btnIntersect: null,
        _arrStore: null,
        _gridData: null,
        _dupData: null,
        _count: 0,
        _arrStoreForFields: null,
        _singleElementGeometry: null,
        _allElementGeometry: [],
        _arryIntersection: [],
        _tempArray: [],
        _bottomPanel: null,
        _exportParams: null,
        _arrResponse: null,
        _currentSelectedElement: null,
        _unionGeometry: null,
        arrLayerFields: [],
        _arrLayerAliasFields: [],
        _selectedFeild: [],
        _selectedUniqueValues: [],
        _selectedLayerFeild: [],
        _resultColumnNames: [],
        textareaunique: [],
        _panel: null,
        textareafeild: [],
        _arrResultValues: [],
        textareaResult: [],
        uniqueFeildValues: [],
        _storeButtonValues: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },


        /**
        * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
        * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
        */
        postCreate: function () {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetQueryBuilderIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
            this._nc4Notify = this.appUtils.nc4Notify;
            this._queryLayerType = new Select();
            this._queryLayerType.placeAt(this.queryLayerTypeDiv).startup();
            this._attachWidgetRelatedEvents();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function () {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
        },

        /**
        * Get the selected layer in "multi select" combo box and get fields of layer.
        */
        _getLayersOnMap: function () {
            this._shelter.show();
            this._queryLayerType.options.length = 0;
            this.textareaResult.value = "";
            if (this.layersOnMap) {
                while (this.layersOnMap.domNode.hasChildNodes()) {
                    this.layersOnMap.domNode.removeChild(this.layersOnMap.domNode.lastChild);
                    this.queryLabel.domNode.value = "";
                    this.textareaResult.value = "";
                    this.uniqueFieldValues.domNode.innerHTML = "";
                }
            }
            var i,
                objLayer,
                selectItem;
            this._arrStore = [];
            for (i = 0; i < this.map.graphicsLayerIds.length; i++) {
                objLayer = this.map.getLayer(this.map.graphicsLayerIds[i]);
                selectItem = {};
                selectItem.value = objLayer.id;
                if (objLayer._params.name) {
                    selectItem.label = objLayer._params.name; //get the custom layer name given by the user while adding layer.
                } else {
                    selectItem.label = objLayer.overlayCustomLayerType;
                }
                this._arrStore.push(selectItem);
            }
            if (this._queryLayerType.options.length === 0) {
                this._queryLayerType.addOption({
                    label: sharedNls.QueryBuilder.selectLayer,
                    value: sharedNls.QueryBuilder.selectLayer
                });
            }
            array.forEach(this._arrStore, lang.hitch(this, function (layer) {
                if (this._queryLayerType.options.length !== 0) {
                    this._queryLayerType.addOption({
                        label: layer.label,
                        value: layer.value
                    });
                }
            }));
            for (var key = 0; key < this._queryLayerType.options.length; key++) {
                if (this._queryLayerType.options[key].label === "Drawing") {
                    this._queryLayerType.options[key].disabled = true;
                }
            }
            this._shelter.hide();
        },

        /**
        * Get the selected layer in "multi select" combo box and get fields of layer.
        * @param {string} evt : selected layer value
        */
        _getSelectedLayer: function (evt) {
            var item,
                m,
                j,
                objLayer;
            objLayer = this.map.getLayer(evt);
            this._arrLayerAliasFields = [];
            if (this.map.getLayer(evt)._fileds) {
                for (m = 0; m < objLayer._fileds.length; m++) {
                    var selectItem = {};
                    selectItem.value = objLayer._fileds[m].name;
                    selectItem.field = objLayer._fileds[m].alias;
                    selectItem.label = objLayer._fileds[m].alias;
                    selectItem.type = objLayer._fileds[m].type;
                    this.arrLayerFields.push(selectItem);
                    var obj = {};
                    obj.field = objLayer._fileds[m].name;
                    obj.label = objLayer._fileds[m].alias;
                    this._arrLayerAliasFields.push(obj);
                    this._shelter.hide();
                }
            } else {
                if (objLayer.fields) {
                    for (j = 0; j < objLayer.fields.length; j++) {
                        if (objLayer.fields[j].type !== "esriFieldTypeGeometry") {
                            var selectItem1 = {};
                            selectItem1.value = objLayer.fields[j].name;
                            selectItem1.field = objLayer.fields[j].alias;
                            selectItem1.label = objLayer.fields[j].alias;
                            selectItem1.type = objLayer.fields[j].type;
                            this.arrLayerFields.push(selectItem1);
                            var objFields = {};
                            objFields.field = objLayer.fields[j].name;
                            objFields.label = objLayer.fields[j].alias;
                            this._arrLayerAliasFields.push(objFields);
                            this._shelter.hide();
                        }
                    }
                }
            }
            for (item in this.arrLayerFields) {
                if (this.arrLayerFields.hasOwnProperty(item)) {
                    var options = win.doc.createElement("option");
                    options.textContent = this.arrLayerFields[item].label;
                    options.value = this.arrLayerFields[item].value;
                    this.layersOnMap.domNode.appendChild(options);
                    this._shelter.hide();
                }
            }
            this._shelter.hide();
        },

        /**
        * This function to get selected layer field value .
        */
        _getSelectedField: function () {
            this._shelter.show();
            this.uniqueFieldValues.domNode.innerHTML = "";
            this._selectedFeild = [];
            // var arrSelectedFeild = [];
            for (var l = 0; l < this.layersOnMap.domNode.childNodes.length; l++) {
                if (this.layersOnMap.domNode.childNodes[l].selected === true) {
                    this._selectedFeild.push(this.layersOnMap.domNode.childNodes[l].value);
                    //  arrSelectedFeild.push(this.layersOnMap.domNode.childNodes[l].value);
                }
            }
            this.textareafeild = dom.byId(this.queryLabel.domNode);
            if (this._selectedFeild.length === 0) {
                this._shelter.hide();
                return false;
            }
            var cursorPositions = domAttr.get(this.queryLabel.domNode, "cursorPosition");
            if (cursorPositions) {
                var cur = cursorPositions.split(",");
                var val = domAttr.get(this.queryLabel.domNode, "value");
                var str = val.substring(0, parseInt(cur[0], 10)) + this._selectedFeild[0] + val.substring(parseInt(cur[1], 10));
                domAttr.set(this.queryLabel.domNode, "value", str);
                this.queryLabel.domNode.focus();
                this.queryLabel.domNode.setSelectionRange(parseInt(cur[0], 10) + this._selectedFeild[0].length, parseInt(cur[0], 10) + this._selectedFeild[0].length);
            } else {
                this.textareafeild.value = this.textareafeild.value + this._selectedFeild[0] + " ";
            }
            this._shelter.hide();
        },

        /**
        * After selecting the layer field from multi combo box and it displays the results in text area.
        */
        _getUniqueFeilds: function () {
            this._shelter.show();
            var j,
                objselectedLayerUrl,
                selectedLayer,
                QueryTaskFeild,
                QueryFeild;
            this.uniqueFieldValues.domNode.innerHTML = "";
            this._selectedUniqueValues = [];
            selectedLayer = this._queryLayerType._lastValueReported;
            objselectedLayerUrl = this.map.getLayer(selectedLayer);
            if (objselectedLayerUrl === undefined) {
                this._nc4Notify.warn(sharedNls.QueryBuilder.layerNotSelected);
                this._shelter.hide();
                return false;
            }
            if (this._selectedFeild.length === 0) {
                this._nc4Notify.warn("Please select field");
                this._shelter.hide();
                return false;
            }
            QueryTaskFeild = new QueryTask(objselectedLayerUrl.url);
            QueryFeild = new Query();
            QueryFeild.where = "1=1";
            QueryFeild.returnDistinctValues = true;
            QueryFeild.returnGeometry = false;
            QueryFeild.outFields = [this._selectedFeild];
            QueryTaskFeild.execute(QueryFeild, lang.hitch(this, function (response) {
                if (response.features.length === 0) {
                    this._nc4Notify.warn("Unique values are not found for the selected field");
                    this._shelter.hide();
                    return false;
                }
                for (j = 0; j < response.features.length; j++) {
                    for (var selectedField in response.features[j].attributes) {
                        if (response.features[j].attributes[selectedField] !== "" || response.features[j].attributes[selectedField] !== null) {
                            if (this._selectedUniqueValues.indexOf(response.features[j].attributes[selectedField]) === -1) {
                                this._selectedUniqueValues.push(response.features[j].attributes[selectedField]);
                            }
                        }
                    }
                }
                for (var k = 0; k < this._selectedUniqueValues.length; k++) {
                    var textcont = win.doc.createElement("option");
                    textcont.textContent = this._selectedUniqueValues[k] + "\n";
                    this.uniqueFieldValues.domNode.appendChild(textcont);
                    this._shelter.hide();
                }
            }), lang.hitch(this, function (err) {
                this._nc4Notify.error(err);
                this._shelter.hide();
            }));
        },

        /**
        * This function is storing the selected unique values.
        */
        _getUnqiueSelectedFeilds: function () {
            this._shelter.show();
            var uniquevalueString;
            this._selectedLayerFeild = [];
            for (var l = 0; l < this.uniqueFieldValues.domNode.childNodes.length; l++) {
                if (this.uniqueFieldValues.domNode.childNodes[l].selected === true) {
                    this._selectedLayerFeild.push(this.uniqueFieldValues.domNode.childNodes[l].label);
                }
            }
            this.uniqueFeildValues = dom.byId(this.queryLabel.domNode);
            if (!this._storeButtonValues) {
                this._storeButtonValues = "";
            }
            for (var k = 0; k < this.arrLayerFields.length; k++) {
                if (this.arrLayerFields[k].value === this._selectedFeild[0]) {
                    if (this.arrLayerFields[k].type === "esriFieldTypeString" || this.arrLayerFields[k].type === "esriFieldTypeOID") {
                        uniquevalueString = "'" + this._selectedLayerFeild + "'";
                    } else {
                        uniquevalueString = this._selectedLayerFeild;
                    }
                }
            }
            if (this._selectedLayerFeild.length === 0) {
                uniquevalueString = "";
            }
            var cursorPositions = domAttr.get(this.queryLabel.domNode, "cursorPosition");
            if (cursorPositions) {
                var cur = cursorPositions.split(",");
                var val = domAttr.get(this.queryLabel.domNode, "value");
                var str = val.substring(0, parseInt(cur[0], 10)) + uniquevalueString + val.substring(parseInt(cur[1], 10));
                domAttr.set(this.queryLabel.domNode, "value", str);
                this.queryLabel.domNode.focus();
                this.queryLabel.domNode.setSelectionRange(parseInt(cur[0], 10) + uniquevalueString.length, parseInt(cur[0], 10) + uniquevalueString.length);
            } else {
                this.uniqueFeildValues.value = this.uniqueFeildValues.value + uniquevalueString + " ";
            }
            this._shelter.hide();

        },

        /**
        * This function displays the values of button values, selected fields and selected unique values.
        @param {object} obj - Obj for Button values.
        */
        _getSelectedVal: function (obj) {
            this._shelter.show();
            this._storeButtonValues = obj.currentTarget.value;
            var uniquevalueString;
            this.textareaResult = dom.byId(this.queryLabel.domNode);
            if (this._selectedLayerFeild.length === 0) {
                uniquevalueString = " ";
            }
            for (var k = 0; k < this.arrLayerFields.length; k++) {
                if (this.arrLayerFields[k].value === this._selectedFeild[0]) {
                    if (this.arrLayerFields[k].type === "esriFieldTypeString" || this.arrLayerFields[k].type === "esriFieldTypeOID") {
                        uniquevalueString = "'" + this._selectedLayerFeild + "'";
                    } else {
                        uniquevalueString = this._selectedLayerFeild;
                    }
                }
            }
            var cursorPositions = domAttr.get(this.queryLabel.domNode, "cursorPosition");
            if (cursorPositions) {
                var cur = cursorPositions.split(",");
                var val = domAttr.get(this.queryLabel.domNode, "value");
                var str = val.substring(0, parseInt(cur[0], 10)) + obj.currentTarget.value + val.substring(parseInt(cur[1], 10));
                domAttr.set(this.queryLabel.domNode, "value", str);
                this.queryLabel.domNode.focus();
                this.queryLabel.domNode.setSelectionRange(parseInt(cur[0], 10) + obj.currentTarget.value.length, parseInt(cur[0], 10) + obj.currentTarget.value.length);
            } else {
                this.textareaResult.value = this.textareaResult.value + obj.currentTarget.value + " ";
            }
            this._shelter.hide();
        },

        /**
        * This function verify query and fetch the count for query.
        */
        _btnVerifyResult: function () {
            this._shelter.show();
            var objselectedLayerUrl,
                selectedLayer,
                textareaRes,
                QueryTaskSearch,
                QuerySearch;
            selectedLayer = this._queryLayerType._lastValueReported;
            textareaRes = dom.byId(this.queryLabel.domNode);
            objselectedLayerUrl = this.map.getLayer(selectedLayer);
            if (!objselectedLayerUrl) {
                this._nc4Notify.warn("Please select the required fields to verify the query");
                this._shelter.hide();
                return false;
            }
            if (textareaRes.value === "") {
                this._nc4Notify.warn("Please build the query");
                this._shelter.hide();
                return false;
            }
            QueryTaskSearch = new QueryTask(objselectedLayerUrl.url);
            if (objselectedLayerUrl.url === null) {
                this._nc4Notify.error(sharedNls.QueryBuilder.verifiedQueryError);
                this._shelter.hide();
                return false;
            }
            QuerySearch = new Query();
            QuerySearch.where = textareaRes.value;
            QueryTaskSearch.executeForCount(QuerySearch, lang.hitch(this, function (count) {
                if (count > 0) {
                    this._nc4Notify.success(sharedNls.QueryBuilder.verifiedQuerySuccess);
                    this._shelter.hide();
                    return false;
                } else {
                    this._nc4Notify.error(sharedNls.QueryBuilder.verifiedQueryError);
                    this._shelter.hide();
                    return false;
                }
            }), lang.hitch(this, function (err) {
                this._nc4Notify.error(sharedNls.QueryBuilder.queryError);
                this._shelter.hide();
                return false;
            }));
        },

        /**
        * This function search the results for query and it displays the data in grid.
        */
        _btnSearchResults: function () {
            this._shelter.show();
            var j,
                objselectedLayerUrl,
                selectedLayer,
                textareaRes,
                QueryTaskSearch,
                QuerySearch;
            selectedLayer = this._queryLayerType._lastValueReported;
            textareaRes = dom.byId(this.queryLabel.domNode);
            objselectedLayerUrl = this.map.getLayer(selectedLayer);
            if (objselectedLayerUrl === undefined) {
                this._shelter.hide();
                return false;
            }
            QueryTaskSearch = new QueryTask(objselectedLayerUrl.url);
            if (objselectedLayerUrl.url === null) {
                this._nc4Notify.error("No result found");
                this._shelter.hide();
                return false;
            }
            if (textareaRes.value === "") {
                this._nc4Notify.error("No result found");
                this._shelter.hide();
                return false;
            }
            array.forEach(this._selectedFeild, lang.hitch(this, function (layer) {
                var isItDate = layer.indexOf("date");
                if (isItDate !== -1) {
                    this._getDate(this._selectedLayerFeild);
                }
            }));
            QuerySearch = new Query();
            QuerySearch.where = textareaRes.value;
            QuerySearch.returnGeometry = true;
            QuerySearch.outFields = ["*"];
            QueryTaskSearch.execute(QuerySearch, lang.hitch(this, function (response) {
                this._arrResultValues = [];
                this._resultColumnNames = [];
                if (response.features.length > 0) {
                    for (var key in response.features[0].attributes) {
                        if (response.features[0].attributes.hasOwnProperty(key)) {
                            var obj = {};
                            obj.field = key;
                            obj.label = key;
                            this._resultColumnNames.push(obj);
                        }
                    }
                    for (j = 0; j < response.features.length; j++) {
                        var dataObj = {};
                        for (var selectedField in response.features[j].attributes) {
                            if (response.features[j].attributes[selectedField] !== "" || response.features[j].attributes[selectedField] !== null) {
                                dataObj[selectedField] = response.features[j].attributes[selectedField];
                                dataObj.id = j;
                            }
                        }
                        this._arrResultValues.push(dataObj);
                        this._shelter.hide();
                    }
                    this._showDataOnGrid(this._resultColumnNames, this._arrResultValues);
                } else {
                    this._nc4Notify.error("No result found");
                    this._shelter.hide();
                    return false;
                }
            }), lang.hitch(this, function (err) {
                this._nc4Notify.error(err);
                this._shelter.hide();
                return false;
            }));
        },

        _getDate: function (dateformat) {
            var pattern;
            if (this.appUtils.configGeneralSettings.databaseType === "sqlserver2005") {
                pattern = "yyyy-MM-dd, h:m:s.SSS";
            } else {
                pattern = "dd-MM-yyyy, h:m:s.SSS";
            }
            var date = locale.format(new Date(dateformat), {
                datePattern: pattern,
                selector: "date"
            });
            this._selectedLayerFeild = date;
        },

        /**
        * This function displays the data in grid and showing grid on bottom panel.
        * @param {resultKeyNames} resultKeyNames -Displays the Column names
        * @param {resultValues} resultValues -Displays the result values
        */
        _showDataOnGrid: function (resultKeyNames, resultValues) {
            var CustomGrid,
                x = 15;
            CustomGrid = declare([Grid, Keyboard, Selection, Pagination], {
                keepScrollPosition: true,
                pagingLinks: false,
                store: new Memory({
                    data: []
                }),
                pagingTextBox: true,
                firstLastArrows: true,
                rowsPerPage: x
            });
            var widgetBottomPanel = registry.byId("NC4BottomPanel");
            if (widgetBottomPanel) {
                this._bottomPanel = widgetBottomPanel;
            }
            if (!this._bottomPanel) {
                this._bottomPanel = new BottomPanel({
                    id: "NC4BottomPanel",
                    resultTitle: "Results",
                    appUtils: this.appUtils
                });
            } else {
                if (this._bottomPanel.bottomPanelResultContainer.clientHeight === 0) {
                    this._bottomPanel._openBottomPanel();
                }
            }
            this._bottomPanel.saveReportIcon.hidden = true;
            this._bottomPanel.bottomPanelResultContainer.innerHTML = "";
            this.appUtils.bottomPanelGrid = new CustomGrid({
                //columns: resultKeyNames
                columns: this._arrLayerAliasFields
            }, this._bottomPanel.bottomPanelResultContainer);
            on(this._bottomPanel.searchTextboxIcon, "click", lang.hitch(this, function () {
                this._searchDataInGrid();
            }));
            on(this._bottomPanel.exportExcelIcon, "click", lang.hitch(this, function () {
                this._exportToExcel();
            }));
            on(this._bottomPanel.searchTextbox, "keyUp", lang.hitch(this, function () {
                if (this._bottomPanel.searchTextbox.displayedValue === "") {
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                    this.appUtils.bottomPanelGrid.setStore(new Memory({
                        data: this._dupData
                    }));
                    this.appUtils.bottomPanelGrid.startup();
                    this._shelter.hide();
                }
            }));
            setTimeout(lang.hitch(this, function () {
                var data = [];
                this._gridData = data;
                this._dupData = data;
                this.appUtils.bottomPanelGrid.refresh();
                this.appUtils.bottomPanelGrid.resize();
                this.appUtils.bottomPanelGrid.setStore(new Memory({
                    data: resultValues
                }));
                this.appUtils.bottomPanelGrid.startup();
                /* Converting grid data into json format */
                this._exportParams = {};
                for (var item = 0; item < this._arrResultValues.length; item++) {
                    if (this._arrResultValues[item].grid && this._arrResultValues[item].headerNode) {
                        this._arrResultValues[item].grid = null;
                        this._arrResultValues[item].headerNode = null;
                    }
                }
                this._shelter.hide();
            }, 1000));
        },

        /**
        * Function to search data in grid.
        */
        _searchDataInGrid: function () {
            var resultData = [];
            var str = this._bottomPanel.searchTextbox.value;
            if (str) {
                var j;
                for (var i = 0; i < this._arrResultValues.length; i++) {
                    var count = 0;
                    for (j in this._arrResultValues[i]) {
                        if (count === 0) {
                            if (j !== "id") {
                                if (this._arrResultValues[i][j] !== null) {
                                    var strObj = this._arrResultValues[i][j].toString();
                                    if (strObj === str) {
                                        count++;
                                        resultData.push(this._arrResultValues[i]);
                                    }
                                }
                            }
                        }
                    }
                }
                if (resultData) {
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                    this.appUtils.bottomPanelGrid.setStore(new Memory({
                        data: resultData
                    }));
                    this.appUtils.bottomPanelGrid.startup();
                    this._shelter.hide();
                }
            }
        },

        /**
        * Function to export to csv of grid data
        */
        _exportToExcel: function () {
            var excelContent = {
                "Values": this._arrResultValues
            };
            this._exportParams = JSON.stringify(excelContent);
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            var form = document.createElement("form");
            var postData = document.createElement("input");
            form.method = "POST";
            form.id = "someForm";
            form.action = this.config.exportToCSV;
            form.target = "_blank";
            postData.value = this._exportParams;
            postData.name = "json";
            postData.type = "text";
            form.appendChild(postData);
            document.body.appendChild(form);
            form.submit();
            this._shelter.hide();
        },

        /**
        * After clicking the clear button it clear's the query result text area div.
        */
        _btnClearDiv: function () {
            this.textareaResult.value = "";
            this.textareafeild.value = "";
            this._storeButtonValues = "";
            this.uniqueFieldValues.domNode.innerHTML = "";
            this.layersOnMap.reset();
        },

        /**
        * Display the widget panel.
        */
        show: function () {
            if (!this.isOpen) {
                html.addClass(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                this._getLayersOnMap();
                this.appUtils.sidePanelOpen(this.isOpen);
                if (this.appUtils.bottomPanelGrid) {
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                }
            } else {
                this.hide();
            }
        },

        /**
        * Hide the widget panel
        */
        hide: function () {
            this.isOpen = false;
            html.removeClass(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
                if (this.appUtils.bottomPanelGrid) {
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                }
            }
        },

        /**
        * Setting the widget panel position.
        */
        _placeWidgetContainer: function () {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
        * Attach widget related events
        */
        _attachWidgetRelatedEvents: function () {
        	on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function () {
                this._panel.resize();
                if (this.appUtils.bottomPanelGrid) {
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                }
            }));
            on(this.queryLabel.domNode, "blur", lang.hitch(this, function () {
                var start = this.queryLabel.domNode.selectionStart,
                    end = this.queryLabel.domNode.selectionEnd;
                domAttr.set(this.queryLabel.domNode, "cursorPosition", [start, end]);
            }));

            on(this.queryLabel.domNode, "focus", lang.hitch(this, function () {
                var cursorPosition = domAttr.get(this.queryLabel.domNode, "cursorPosition");
                if (cursorPosition) {
                    var cur = cursorPosition.split(",");
                    this.queryLabel.domNode.setSelectionRange(parseInt(cur[0], 10), parseInt(cur[1], 10));
                }
            }));
            on(this._queryLayerType, "change", lang.hitch(this, function (evt) {
                this._count = 0;
                this.layersOnMap.domNode.innerHTML = "";
                this.uniqueFieldValues.domNode.innerHTML = "";
                this.layersOnMap.reset();
                this.textareafeild.value = "";
                this._storeButtonValues = "";
                this.arrLayerFields.splice(0);
                if (this._queryLayerType.value === "Select Layer") {
                    if (this._count === 0) {
                        this._nc4Notify.warn(sharedNls.QueryBuilder.layerNotSelected);
                        this._shelter.hide();
                        this._count++;
                        return false;
                    }
                }
                this._getSelectedLayer(evt);
            }));
        }
    });
});
