define([
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/dom",
    "dojo/on",
    "dojo/text!./LegendTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/aspect",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "esri/dijit/Legend",
    "esri/layers/FeatureLayer",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter"
], function(
    declare,
    array,
    html,
    lang,
    dom,
    on,
    template,
    sharedNls,
    aspect,
    _WidgetBase,
    _TemplatedMixin,
    Legend,
    FeatureLayer,
    WidgetPanel,
    LoadingShelter
) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "Legend",
        baseClass: "widget-Legend",
        templateString: template,
        sharedNls: sharedNls,
        _shelter: null,
        _legend: null,
        isOpen: false,
        _panel: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },

        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
         */
        postCreate: function() {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetLegendIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
            this._nc4Notify = this.appUtils.nc4Notify;
            this._attachWidgetRelatedEvents();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
            aspect.after(this.appUtils, "refreshLegend", lang.hitch(this, function() {
                if (this.appUtils.isLegendRefresh === true) {
                    this._refreshLegend();
                }
            }));
            this._createLegend();
        },

        /**
         * Display the widget panel.
         */
        show: function() {
            this._shelter.show();
            if (!this.isOpen) {
                html.addClass(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this._refreshLegend();
                this.isOpen = true;
                this.appUtils.sidePanelOpen(this.isOpen);
            } else {
                this.hide();
            }
            setTimeout(lang.hitch(this, function() {
                this._shelter.hide();
            }), 500);
        },

        /**
         * Hide the widget panel
         */
        hide: function() {
            this.isOpen = false;
            html.removeClass(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
            }
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Widget Related Events, resize widget panel on window resize.
         */
        _attachWidgetRelatedEvents: function() {
        	on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
            }));
        },

        /**
         * Create the legend widget for all visible layers present on map.
         */
        _createLegend: function() {
            var arrLayerInfo = [];
            if (this._legend) {
                html.empty(this.legendDiv);
                this._legend.destroyRecursive(true);
            }
            arrLayerInfo = this._getLayerInfoFromLayerIds(arrLayerInfo);
            arrLayerInfo = this._getLayerInfoFromGraphicsLayerIds(arrLayerInfo);
            this._legend = new Legend({
                map: this.map,
                autoUpdate: true,
                layerInfos: arrLayerInfo
            }, this.legendDiv);
            this._legend.startup();
            this._shelter.hide();
        },

        /**
         * Refresh the legend widget for added/removed layers.
         */
        _refreshLegend: function() {
            this._nc4Notify.info("Loading Legend");
            var arrLayerInfo = [];
            arrLayerInfo = this._getLayerInfoFromLayerIds(arrLayerInfo);
            arrLayerInfo = this._getLayerInfoFromGraphicsLayerIds(arrLayerInfo);
            this._legend.refresh(arrLayerInfo);
            this.appUtils.isLegendRefresh = false;
        },

        /**
         * Get all the layers using layer's id in in map's 'layerIds' object and store them in array to be shown in legend.
         * @param {Array} arrLayerInfo - Array to get list of objects and each object contain layer and title.
         * @returns {Array} arrLayerInfo - Array of objects and each object contain layer and title to be shown in legend.
         */
        _getLayerInfoFromLayerIds: function(arrLayerInfo) {
            /*Hear to add and remove legends of layers*/
            array.forEach(this.map.layerIds, lang.hitch(this, function(layerId) {
                var layerInfo, layerTitle;
                var currentBM = this.map.layerIds[0];
                if (layerId !== currentBM) {
                    layerInfo = this.map.getLayer(layerId);
                    if (layerInfo.className !== "heatmapImgLyr") {
                        var currentTitle = (layerInfo._params) ? layerInfo._params.name : ((layerInfo._options) ? layerInfo._options.name : "");
                        layerTitle = currentTitle || layerInfo.name || layerInfo.title || layerInfo.id || "Custom_Layer";
                        arrLayerInfo.push({
                            layer: layerInfo,
                            title: layerTitle
                        });
                    }
                }
            }));
            return arrLayerInfo;
        },

        /**
         * Get all the layers using layer's id in in map's 'graphicsLayerIds' object and store them in array to be shown in legend.
         * @param {Array} arrLayerInfo - Array to get list of objects and each object contain layer and title.
         * @returns {Array} arrLayerInfo - Array of objects and each object contain layer and title to be shown in legend.
         */
        _getLayerInfoFromGraphicsLayerIds: function(arrLayerInfo) {
            /*We will get the "feature collection" and "web service" layers in graphiclayerids.*/
            array.forEach(this.map.graphicsLayerIds, lang.hitch(this, function(layerId) {
                var layerInfo,
                    currentTitle;
                if (layerId.indexOf("FeatureCollection_") !== -1 || layerId.indexOf("WebService_") !== -1 || layerId.indexOf("_cluster") !== -1 || layerId.indexOf("_layer") !== -1 || layerId.indexOf("_heatlayer") !== -1) {
                    layerInfo = this.map.getLayer(layerId);
                    currentTitle = (layerInfo._params) ? layerInfo._params.name : ((layerInfo._options) ? layerInfo._options.name : "");
                    if (layerId.indexOf("_cluster") !== -1) {
                        if(this.appUtils.configGeneralSettings.omitLegendLayers){
                            for(var i = 0; i < this.appUtils.configGeneralSettings.omitLegendLayers.length; i++){
                                if(currentTitle.indexOf(this.appUtils.configGeneralSettings.omitLegendLayers[i]) !== -1)
                                    return;
                            }
                        }
                        var featurLayer = new FeatureLayer(layerInfo.url, {
                            name: currentTitle || layerInfo.name || layerInfo.title || layerInfo.id
                        });
                        arrLayerInfo.push({
                            layer: featurLayer,
                            title: currentTitle || layerInfo.name || layerInfo.title || layerInfo.id
                        });
                    } else if (layerInfo.url) {
                        arrLayerInfo.push({
                            layer: layerInfo,
                            title: currentTitle || layerInfo.name || layerInfo.title || "Feature Layer"
                        });
                    }
                }
            }));
            return arrLayerInfo;
        }
    });
});
