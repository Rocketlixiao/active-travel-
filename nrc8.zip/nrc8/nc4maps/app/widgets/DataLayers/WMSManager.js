define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/i18n!../../nls/LocalizedStrings",
    "esri/geometry/webMercatorUtils",
    "esri/layers/WMSLayer",
    "esri/SpatialReference",
    "esri/layers/WMSLayerInfo",
    "esri/geometry/Extent",
    "dojo/on",
    "esri/request"
], function(declare, lang, sharedNls, webMercatorUtils, WMSLayer,SpatialReference, WMSLayerInfo, Extent, on, esriRequest) {
	return declare([], {
		
	
	/*
	 * This module is responsibile for encapsulating all common methods in order for WMS Layer to be added
	 * 
	 */
	
	_layerName: "",
	appUtils: null,
	map: null,
	_leafLayers: [],
	_url: "",
	_shelter: null,
	nc4Notify: null,
	_wmsLayer: null,
	_subLyrsOn: [],
	_subLyrInitialMaxThreshold: 10,
	_maxWidth: 0,
	_maxHeight: 0,
		
	constructor: function(p_rootWmsLayerName, p_appUtils, p_map, p_url, p_subLyrsOn, p_maxWidth, p_maxHeight)
	{
		this.appUtils = p_appUtils;
		this._layerName = p_rootWmsLayerName;
		this.map = p_map;
		this._url = p_url;
		this.nc4Notify = this.appUtils.nc4Notify;
		this._subLyrsOn = p_subLyrsOn;
		this._maxWidth = p_maxWidth;
		this._maxHeight = p_maxHeight;
	},
	
	/**
     * This function adds WMS layer else throws exception.
     * @param {string} strUrl - Url for WMS layer.
     */
    _addWebMapService: function (p_shelter, p_layerId, p_parentId,  p_setUpParentNode, p_setUpSubNodes, p_node_lyrMetaData) {
    	this._shelter = p_shelter;
        esriConfig.defaults.io.alwaysUseProxy = false;
       
        var requestHandle = esriRequest({
            url: "nc4proxy.jsp?" + this._url + "?request=GetCapabilities&service=WMS&_d_=" + new Date().getTime(),
            handleAs: "xml",
            useProxy: false
        });
        requestHandle.then(lang.hitch(this, function (response) {
            this._wmsRequestSucceeded(response, p_layerId, p_parentId, p_setUpParentNode, p_setUpSubNodes, p_node_lyrMetaData);
        }), lang.hitch(this, this.requestFailed));
        
    },
    
    
    /**
     * This function to use the metadata from the GetCapabilities request to the WMS and create/add the WMS Layer to the map
     * @param {object} response - Result object.
     * @param {string} strUrl - Url for WMS layer.
     */
    _wmsRequestSucceeded: function(response, p_layerId, p_parentId, p_setUpParentNode, p_setUpSubNodes, p_node_lyrMetaData) 
    {
    	
    	
        var wmsCapabilities = this.xmlToJson(response); console.info("x: " , wmsCapabilities);

        //set version:
        var rootLayer;
        var version = "";
        try
        {
        	rootLayer = wmsCapabilities.WMS_Capabilities.Capability.Layer;
        	version = "1.3.0";
        }
        catch(error){}

        var maxHeight = "";
        var maxWidth = "";
        if(rootLayer == null)
        {
        	try
        	{
        		rootLayer = wmsCapabilities.WMT_MS_Capabilities[1].Capability.Layer;
        		version = "1.1.1";
        	}catch(error){}
        }
        
        var layersFromMetaData = [];
        try
        {
        	layersFromMetaData = rootLayer.Layer || [];  //rootLayer.Layer
        }
        catch(error)
        {
        	console.error("error parsing wms meta data: ", error);
    		this.nc4Notify.error("Unable to parse WMS Data, please check that URL is correct and service is working.");
    		this._shelter.hide();
    		return;
        }
        
        console.info("rootLayer: ", rootLayer);
    	
    	//get all root layer bbox:
        /*
        var bboxForCurrentMap = null;
        if(rootLayer.BoundingBox)
        {
        	bboxForCurrentMap = this.getAllWmsBbox(version, rootLayer.BoundingBox).extentForCurrentMap;
        }
        else if(rootLayer.EX_GeographicBoundingBox)
        {
        	bboxForCurrentMap = rootLayer.EX_GeographicBoundingBox;
        }
        else if(rootLayer.LatLonBoundingBox)
        {
        	//according to spec, latlon bounding box will always exist
        	var ogcLatLonBbox = rootLayer.LatLonBoundingBox;
        	ogcLatLonBbox["@attributes"].SRS = "4326";
        	bboxForCurrentMap = this.getAllWmsBbox(version, ogcLatLonBbox).extentForCurrentMap;
        }
        else
        	console.log("lat lon bounding box could not be found");
    	
        console.info("bboxForCurrentMap: " , bboxForCurrentMap);
    	*/
        //var rootLayerSRs = []; not in use atm
    	//rootLayerSrs = this.getLayerSRsAsInts(rootLayer);
        
        //****************************************************//
        //loop through each sub layers now:
        var visibleLayers = []; //this should take into account sub layers on
       
        var p_layerInfos  = [];
        var arrLayerInfos = this.exploreLayerInfos(rootLayer, layersFromMetaData, version, p_layerInfos, 0);
        this._leafLayers = arrLayerInfos;
        
        //JT: If an object was passed in, it was passed in to save the leaf layers to, for later use
        if(p_node_lyrMetaData)
        	p_node_lyrMetaData.allSubLyrs = this._leafLayers
        
        //jt: this will only be true from all layer (initial adding
        if(p_setUpParentNode == true)
    		this.setUpParentNode(p_parentId, this._leafLayers);
        
        /*
        if(p_setUpSubNodes == true)
        {
        	this.p_parentId = p_parentId;
        	this.p_layerId = p_layerId;
        	this.p_setUpSubNodes = p_setUpSubNodes;
        }*/
		//JT: add some logic here to check size of sub layers.  If too many, don't turn any of them on., give friendly message
        
        if(this._subLyrsOn != null && this._subLyrsOn.length > 0)
        {
        	visibleLayers = this._subLyrsOn;
        }
        else if(arrLayerInfos.length >= this._subLyrInitialMaxThreshold)
			visibleLayers.push(arrLayerInfos[arrLayerInfos.length - 1].name)
        else
        {
        	for(var i = 0; i < arrLayerInfos.length; i ++)	
        		visibleLayers.push(arrLayerInfos[i].name);	
        }
        
        
        
        /*
        var wmsResourceInfo = {
        		extent: bboxForCurrentMap,
        		layerInfos: arrLayerInfos,
        		version: version
        };
        
        if(this._maxHeight > 0) wmsResourceInfo.maxHeight = this._maxHeight;
        if(this._maxWidth > 0) wmsResourceInfo.maxWidth = this._maxWidth;
       
        //create resource info so we do not have to send another request: james
        console.info("wmsResourceInfo: ", wmsResourceInfo);
        
       
        if(wmsResourceInfo.extent && wmsResourceInfo.extent != null)
        	this.map.setExtent(wmsResourceInfo.extent);
        */
        var parentId = p_parentId+"_layer" || "WebMapService_" + p_layerId + "_layer";
        var wmsLayer = new WMSLayer("nc4proxy.jsp?" + this._url + "?t", {				//JT: hack: for some reason, the params that gets appended to the URL starts with "=&", causing things to break
        	//resourceInfo: wmsResourceInfo,
            format: "png",
            visibleLayers: visibleLayers,
            id: parentId,
            version: version,
            name: this._layerName
        });
        
        
        wmsLayer.customLayerType = "wms";
        
        
        this.map.addLayer(wmsLayer);
        this.appUtils.customLayerCount++;
        this._wmsLayer = wmsLayer;
        
        this.initialLoad = true;
        this._wmsLayer.on("load", lang.hitch(this, function(evt){
        	if(this.initialLoad === false)
        		return;
        	
        	if(this._maxHeight > 0) wmsLayer.maxHeight = this._maxHeight;
            if(this._maxWidth > 0) wmsLayer.maxWidth = this._maxWidth;
            this.initialLoad = false;
        }));
        
        
        this._wmsLayer.on("update-start", lang.hitch(this, function(evt){
        	var options = {
            		"showMethod": "slideDown",
            		"hideMethod": "slideUp",
            		"closeMethod": "slideUp",
            		"preventDuplicates": true,
            		"timeOut": 0,
            		"extendedTimeOut": 0,
            		"progressBar": true,
            		"onclick": null,
            		"positionClass":  "toast-bottom-right",
            		"tapToDismiss": true
            	};
        	this.layerLoadingInfo = this.nc4Notify.info2(options, "info", "Layer Update:", "Loading WMS Layer(s)");
        }));
        
       // this.initialLoadForUpdateEnd = true;
        this._wmsLayer.on("update-end", lang.hitch(this, function(evt) 
        {
        	if(this.layerLoadingInfo != null)
        		this.nc4Notify.hide(this.layerLoadingInfo);
        	//hack: since load event isn't guaranteed to fire ( if service has redirects , such as http://sdf.ndbc.noaa.gov/wms)
        	//		use the update event, and only do it once.
        	var layer = evt.layer || evt.target;
        	
        	//JT, do we need this anymore if we're not evening tryingto zoom to extent?
        	/*
        	if(this.initialLoadForUpdateEnd && this.initialLoadForUpdateEnd === true)
        	{
        		if(this.p_setUpSubNodes == true)
                {
                	this._addWMSSubLayers(this.p_parentId, this.p_layerId);
                }
        		this.initialLoadForUpdateEnd = false;
        		this._shelter.hide();
        		return;
        	}
        	else
        	{}//	this.initialLoadForUpdateEnd = true;
        	*/
        	//on intial load only, zoom to extent:
        	/*
        	var layer = evt.layer || evt.target;
        	var newExtent = {};
        	if(layer.fullExtent)
        	{
        		var xmin = parseInt(layer.fullExtent.xmin);
        		var ymin = parseInt(layer.fullExtent.ymin);
        		var xmax = parseInt(layer.fullExtent.xmax);
        		var ymax = parseInt(layer.fullExtent.ymax);
        		var wkid = layer.fullExtent.spatialReference.wkid;
        		newExtent = new Extent(xmin,ymin,xmax,ymax,new SpatialReference(wkid));
            	this.map.setExtent(newExtent);
        	}*/
            this._shelter.hide();
           // domAttr.set(this._txtLayerUrl, "displayedValue", "");
           // domAttr.set(this._txtLayerName, "displayedValue", "");
        }));
        this._wmsLayer.on("error", lang.hitch(this, function(evt) {
            var message = evt.error.message;
            var layer = evt.layer || evt.target;
        	
            var notValid = message.indexOf("Unable to load image");
            if (notValid !== -1) {
            	//if user is on the same base map, check to see if we already displayed this error message.  If so, just ignore and move on
            	if( layer.lastBaseMapWithError == this.appUtils.mapInstance)
            	{
            		this._shelter.hide();
            		return;
            	}
            	else
            		layer.lastBaseMapWithError = this.appUtils.mapInstance;
            	this.nc4Notify.warn("Unable to load image for WMS '" + this._layerName + "'.  Please check capabilities for SRS/CRS compatibility and maximum image width/height if applicable.");
                this.appUtils.layerAddedOnBasemap(true); //For wms strike out
                this._shelter.hide();
            } else {
                this._shelter.hide();
            }
        }));
    },
    
    /**
     * function to get Layer's SRs as array of WKID (ints)
     */
    getLayerSRsAsInts: function(p_layer)
    {
    	//get all rootlayer SRs
    	var rootLayerSRs = [];
        if(p_layer.CRS || p_layer.SRS)
        {
        	var rootLyrProj = p_layer.CRS || p_layer.SRS || [];
        	for (var k = 0; k < rootLyrProj.length; k++)
            {
            	try{
            		rootLayerSRs.push(parseInt(rootLyrProj[k]['#text'].substring(5)));	//need to account for CRS, not just epsg
            	}catch(error)
            	{
            		console.info("error getting root layer's SRS/CRS (wms) : ", error);
            	}
            }
        }
        return rootLayerSRs;
    },
    
    /**
     * This function to display the error results of wms layer.
     * @param {object} error - error object.
     */
    requestFailed: function (error, io) {
        esriConfig.defaults.io.alwaysUseProxy = false;
        this._shelter.hide();
        this.nc4Notify.warn("Unable to find GetCapabilities file");
    },
    
    
    /**
     * function to set up parent node and trigger any events.
	 * Since we do not know what type of layer tree/ data filter exist, just trigger events and let the subscribers do the work.
     * -must be called by caller (Add Layer) since other widgets such as Data Layer / Base Map Gallery will not need this
     */
    
    //This is only ccalled from AddLayer, so set state to true
    setUpParentNode: function(p_parentId, p_allSubLyrs)
    {
    	//setting up parent node (no sr needed since it is a grouping)
        
        var webMapServiceLayer = {
            "type": "wms",
            "url": this._url,
            "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
            "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
            "bbox": 0,
            "id": p_parentId,
            "name": this._layerName,
            "state": 1,
            "sr": "",
            "basemap": 0,
            "parent": "customLayers",
            "allSubLyrs": p_allSubLyrs,
            "layerFromAddLayer": true
        };
        this.appUtils.customLayerAdded(webMapServiceLayer);		//adds to gobal customLayerCollectionArray, data layer widget subscribes to this.
        this.appUtils.customLayerNameAdded(this._layerName);	//adds to global customLayerServiceName array , used so you don't add duplicate names
    },
    
    
    /**
     * similar to  setUpParentNode
	 *This function to add sub-layers of wms layer.
     * @param {string} strUrl - Url for WMS layer.
     * @param {string} parentID - parentID for WMS layer.
     * @param {string} layerName - layerName for WMS layer.
     * @param {string} index -index for WMS layer.
     */
    /* 7.27.2016 no longer in use */
    _addWMSSubLayers: function(parentID, p_layerId) {
        //this._addWMSSubLayers("", p_parentNodeId, this._layerName + "_layer" + "_" + p_lyrCount, p_lyrCount, allSrs);	//james- todo: give a more proper sub layer name
    	
    	var subLayersAdded = [];
    	for(var i = 0; i<this._leafLayers.length; i++)
    	{
    		p_layerId++;
    		var currLeafLyr = this._leafLayers[i];
    		var treeNodeID = "WebService_" + parentID + "_" + p_layerId + "_sublayer"; console.info("child treenode id: " + treeNodeID);
    		//var lyrCount = i+1;
            var name = currLeafLyr.title || currLeafLyr.name || this._layerName + "_layer" + "_" + p_layerId;
            
            
            var mapWkid = this.map.spatialReference.wkid;
            /*
            var subLayerWebMercator = false;
            	if(this.map.spatialReference.isWebMercator())
            	{
            		for(var j = 0; j < wmsSubLyrSRs.length; j++)
            		{
            			if(p_subLyrSRs[j] == 102113 || p_subLyrSRs[j] == 102100 || p_subLyrSRs[j] == 3857)
            			{
            				subLayerWebMercator = true;
            				break;
            			}
            		}
            	}
            var strike = "No";	
            if(p_subLyrSRs.indexOf(mapWkid) || subLayerWebMercator == true )
            {
            	strike = "Yes";
            }	*/	
            var state = 0;
            
            
            try
            {
            	if(this._leafLayers.length >= this._subLyrInitialMaxThreshold)
            	{	
            		if( i == this._leafLayers.length - 1)
        				state = 1;
            	}
            	else if(this._subLyrsOn == null || this._subLyrsOn.length <= 0)
            		state = 1;
            	else
            	{
            		if(this._subLyrsOn.length > 0)
                    {
                    	if(this._subLyrsOn.indexOf(name) >= 0)
                    		state = 1;
                    }
            	}
            	
            }
            catch(error){
            	//do nothing since its probably just not defined
            }
            
            var webMapServerDynamicLayer = {
                "type": "wms",
                //"url": this._url,	JT IMPORTANT: There should be NO URL for Sub layers, since the data layer tree on click depends on this for its _toggleLayerFromService function
                "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
                "bbox": 0,
                "id": treeNodeID,
                "name": name,
                "state": state,
                "sr": currLeafLyr.spatialReferences || [],
                "basemap": 0,
                "parent": parentID,
                "layerFromAddLayer": true,
                "index": i
                //"strike": strike
            };
            try
            {
            	subLayersAdded.push(webMapServerDynamicLayer);
            	
                var currSrs = currLeafLyr.spatialReferences;
                var mapIsWebMerc = this.map.spatialReference.isWebMercator();
                var containsNonCompat = true
                
                for(var j = 0; j < currSrs.length; j++)
            	{
            		var currSr = currSrs[j];
            		//if the current map proj is not listed as a supported proj explicitly, just show a warning
            		if( this.map.spatialReference.wkid == currSr || 
            				(mapIsWebMerc == true && (currSr == 102113 || currSr == 102100 || currSr == 3857) ) )
            		{
            			containsNonCompat = false;
            			break;
            		}
            	}
                if(containsNonCompat == true )
    				this.nc4Notify.warn(sharedNls.Common.wmsPartialNotSupported); //(NOte title from service, not custom name
            }
            catch(error)
            {
            	console.info("wms sub layer already added: " , webMapServerDynamicLayer);
            	console.info("possible error: " , error);
            }
            
    	}
    	this.appUtils.customLayerAdded(subLayersAdded, true);
        this.appUtils.customLayerNameAdded(this._layerName);
        
    },
    
    /**
     * Helper function for request suceeeded JT
     * returns object container array of all extent, and an extent for the current map if possible
     * 
     */
    getAllWmsBbox: function(p_version, p_bbox)
    {
    	var mapSrWkid = this.map.spatialReference.wkid;
    	var bboxForCurrentMap;
    	var allWmsBbox = [];
    	console.info("pbbox: ", p_bbox);
    	if(p_version == "1.3.0")
        {
        	if(p_bbox.constructor === Array)
        	{
        		for(var rooti = 0; rooti < p_bbox.length; rooti++)
        		{
        			var currBbox = p_bbox[rooti]["@attributes"];
        			var strSR = currBbox.CRS;
        			var split = strSR.split(":");
        			var wkid = parseInt(split[1]);
        			var currServiceExtent;
        			require(["esri/SpatialReference"], function(SpatialReference){
            			if(wkid == 4326)
            				currServiceExtent = new Extent(parseInt(currBbox.miny), parseInt(currBbox.minx), parseInt(currBbox.maxy), parseInt(currBbox.maxx), new SpatialReference(wkid));
                    	else
                    		currServiceExtent = new Extent(parseInt(currBbox.minx), parseInt(currBbox.miny), parseInt(currBbox.maxx), parseInt(currBbox.maxy), new SpatialReference(wkid));
            		});
        			allWmsBbox.push(currServiceExtent);
        			
            		var wkid = currServiceExtent.wkid;
            		if(wkid == mapSrWkid || (currServiceExtent.spatialReference.isWebMercator() && this.map.spatialReference.isWebMercator()))
            			bboxForCurrentMap = currServiceExtent;
        		}
        	}
        	else
        	{
        		var currBbox = p_bbox["@attributes"];
    			var strSR = currBbox.CRS;
        		var split = strSR.split(":");
    			var wkid = parseInt(split[1]);
        		var currServiceExtent;
    			require(["esri/SpatialReference"], function(SpatialReference){
        			if(wkid == 4326)
        				currServiceExtent = new Extent(parseInt(currBbox.miny), parseInt(currBbox.minx), parseInt(currBbox.maxy), parseInt(currBbox.maxx), new SpatialReference(wkid));
                	else
                		currServiceExtent = new Extent(parseInt(currBbox.minx), parseInt(currBbox.miny), parseInt(currBbox.maxx), parseInt(currBbox.maxy), new SpatialReference(wkid));
        		});
    			allWmsBbox.push(currServiceExtent);
    			bboxForCurrentMap = currServiceExtent;
        	}
        }
        else if( p_version == "1.1.1")
        {
        	var currBbox = p_bbox["@attributes"];
			var strSR = currBbox.SRS;
			var wkid;
			if(strSR.constructor === Array)
			{
				var split = strSR.split(":");
				wkid = parseInt(split[1]);
			}
			else
			{
				wkid = strSR;
			}
    		
    		var currServiceExtent;
			require(["esri/SpatialReference"], function(SpatialReference){
    			currServiceExtent = new Extent(parseInt(currBbox.minx), parseInt(currBbox.miny), parseInt(currBbox.maxx), parseInt(currBbox.maxy), new SpatialReference(wkid));
    		});
			allWmsBbox.push(currServiceExtent);
			bboxForCurrentMap = currServiceExtent;
        }
        else
        {
        	console.info("WMS ADD-tested for v1.3 and 1.1.1 and failed. ");
        	var currServiceExtent;
        	require(["esri/SpatialReference"], function(SpatialReference) { /* code goes here */ 
        		currServiceExtent = new Extent(-179.99, -89.99, 179.99, 89.99, new SpatialReference(4326));
    		});
        	allWmsBbox.push(currServiceExtent);
        }
        return {
        	extentForCurrentMap: bboxForCurrentMap,
        	allBbox: allWmsBbox
        };
    },
    
    /**
     * helper function to get all SRS/CRS for current wms sub layer
     */
    getAllWmsSr: function(p_version, p_layer)
    {
    	var allSrs = [];
        if(p_version == "1.1.1")
        {
        	if(p_layer.SRS)
        	{
        		var subLyrProjs = p_layer.SRS;
        		for (var k = 0; k < subLyrProjs.length; k++)
                {
                	try{
                		allSrs.push(parseInt(subLyrProjs[k]['#text'].substring(5)));
                	}catch(error)
                	{
                		//do nothing for now
                	}
                }
        	}
        	else
        		return [];
        }
        else
        {
        	if(p_layer.CRS)
        	{
        		var subLyrProjs = p_layer.CRS;
        		for (var k = 0; k < subLyrProjs.length; k++)
                {
                	try{
                		allSrs.push(parseInt(subLyrProjs[k]['#text'].substring(5)));	//TODO: need to account for CRS, not just EPSG
                	}catch(error)
                	{
                		//do nothing for now
                	}
                }
        	}
        	else 
        		return [];		
        }
        return allSrs;
    },
    
    
    /**
     *function to get the Geographic bounding box of a layer or sub layer 
     */
    getGeoBbox: function(p_geoBbox)
    {
    	if(p_geoBbox && p_geoBbox != null)
    	{
    		try
    		{
    			var west = parseInt(p_geoBbox.westBoundLongitude["#text"]);
    			var south = parseInt(p_geoBbox.southBoundLatitude["#text"]);
    			var east = parseInt(p_geoBbox.eastBoundLongitude["#text"]);
    			var north = parseInt(p_geoBbox.northBoundLatitude["#text"]);
    			return new Extent(west,south,east,north,
    					new SpatialReference(4326));
    		}catch(error)
    		{
    			return new Extent(-179.99, -89.99, 179.99, 89.99,
    					new SpatialReference(4326));
    		}
    	}
    },
    
    /**
     * WMS Specification states that a WMS can have Layers ordered in a hierarchical manner, with no limits.  Thus, need a recursive
     * function to gather all of the actual layer meta data, and place into one array (not the root layers).
     *p_rootLyrMetaData: this is the wms service Capability.Layer object
     *p_layer: can be a root layer object, a leaf layer object, or an array of layers (root or leaf),
     */
    exploreLayerInfos: function(p_rootLyrMetaData, p_layer, p_version, p_layerInfos, p_lyrCount)
    {
        if(p_layer.constructor === Array)
        	{
        		for(var i = 0; i<p_layer.length; i++)
        		{
        			var currLyr = p_layer[i];
        			//if name is null, still at parent node
        			if(currLyr.Name == null || currLyr.Layer != null)
        			{
        				var consolidatedRootMetaData = this.gatherRootLayerMeta(p_rootLyrMetaData, currLyr);
        				p_layerInfos = this.exploreLayerInfos(consolidatedRootMetaData, currLyr.Layer, p_version, p_layerInfos);
        			}
        			else
        			{
        				var currLayerInfo = this.gatherActualLyrInfo(p_version, currLyr, p_rootLyrMetaData, p_lyrCount);
        				console.info("currLyrInfo: ", currLayerInfo);
        				p_layerInfos.push(currLayerInfo);
        			}
        		}
        	}
        	else
        	{
        		if(p_layer.Name == null)
        		{
        			var consolidatedRootMetaData = this.gatherRootLayerMeta(p_rootLyrMetaData, p_layer);
        			p_layerInfos = this.exploreLayerInfos(consolidatedRootMetaData, p_layer.Layer, p_version, p_layerInfos);
        		}
        		else
        		{
        			var currLayerInfo = this.gatherActualLyrInfo(p_version, p_layer, p_rootLyrMetaData, p_lyrCount);
    				console.info("currLyrInfo: ", currLayerInfo);
    				p_layerInfos.push(currLayerInfo);
        		}
        	}
        return p_layerInfos;
    },
    
    gatherActualLyrInfo: function(p_version, p_currLyrMeta, p_rootLyrMetaData, p_lyrCount)
    {
    	var currLyrMeta = p_currLyrMeta;
    	var version = p_version;
    	var allBbox = [];
    	var bboxForCurrentMap;
        if(currLyrMeta.BoundingBox)
        {
        	var obj = this.getAllWmsBbox(version, currLyrMeta.BoundingBox);
        	allBbox = obj.allBbox;
        	bboxForCurrentMap = obj.extentForCurrentMap;
        }
        
      //get all rootlayer SRs
        var rootLayerSRs = [];
        if(p_rootLyrMetaData != null)
        {
        	if(p_rootLyrMetaData.CRS || p_rootLyrMetaData.SRS)
            {
            	var rootLyrProj = p_rootLyrMetaData.CRS || p_rootLyrMetaData.SRS || [];
            	
            	//can be array or obj
            	if(rootLyrProj.constructor == Array)
            	{
            		for (var k = 0; k < rootLyrProj.length; k++)
                    {
                    	try{
                    		rootLayerSRs.push(parseInt(rootLyrProj[k]['#text'].substring(5)));	//need to account for CRS, not just epsg
                    	}catch(error)
                    	{
                    		console.info("error getting root layer's SRS/CRS (wms) : ", error);
                    	}
                    }
            	}
            	else
            	{
            		try
            		{
            			rootLayerSRs.push(parseInt(rootLyrProj['#text'].substring(5)));
            		}
            		catch(error)
            		{
                		console.info("error getting root layer's SRS/CRS (wms) : ", error);
                	}
            	}
            	
            }
        }
        
        var allSrs = this.getAllWmsSr(version, currLyrMeta);
        allSrs = allSrs.concat(rootLayerSRs);	//add parent SRS/CRS
        
        console.info("****ALL SRs: " + allSrs);     
        p_lyrCount++;
        //this._addWMSSubLayers("", p_parentNodeId, this._layerName + "_layer" + "_" + p_lyrCount, p_lyrCount, allSrs);	//james- todo: give a more proper sub layer name

        var bboxForCurrentLayer = this.getGeoBbox(currLyrMeta.EX_GeographicBoundingBox);
        
        var currLayer = currLyrMeta;
        var currLayerInfo;
        require(["esri/layers/WMSLayerInfo"], function(WMSLayerInfo){
        	currLayerInfo = new WMSLayerInfo({
            	name: currLayer.Name["#text"],
            	title: currLayer.Name["#text"],
            	spatialReferences: allSrs,
            	allExtents: allBbox,
            	extent: bboxForCurrentLayer,				//TODO use EX_GeographicBoundingBox
            	legendURL: "",
            	subLayers: [],
            	description: ""
            });
        	
        });
        console.info("currLayerInfo: " , currLayerInfo);
    	return currLayerInfo;
    },
    
    gatherRootLayerMeta: function(p_rootLyrMeta, p_currLyrMeta, p_version)
    {
    	if(p_rootLyrMeta && p_rootLyrMeta != null )
    	{
    		if( !( p_rootLyrMeta.Title && p_currLyrMeta.Title && p_rootLyrMeta.Title == p_currLyrMeta.Title) )
    		{
				
				try
				{
					p_currLyrMeta.BoundingBox = p_currLyrMeta.BoundingBox.concat(p_rootLyrMeta.BoundingBox);

					if(p_version == "1.3.0")
	    			{
	            		p_currLyrMeta.CRS = p_currLyrMeta.CRS.concat(p_rootLyrMeta.CRS);
	    			}
	    			else 
	    				p_currLyrMeta.CRS = p_currLyrMeta.SRS.concat(p_rootLyrMeta.SRS);
	    			
				}
    			catch(error){
    				//do nothing
    				}
    		}
    	}
    	return {
    		BoundingBox: p_currLyrMeta.BoundingBox,
    		CRS: p_currLyrMeta.CRS,
    		EX_GeographicBoundingBox: p_currLyrMeta.EX_GeographicBoundingBox,
    		Title: p_currLyrMeta.Title
    	};
    },

    /**
     * This function to convert data into json format.
     * @param {object} xml - results.
     */
    xmlToJson: function(xml) {
        // Create the return object
        try
        {
        	var obj = {};
            if (xml.nodeType == 1) { // element
                // do attributes
                if (xml.attributes.length > 0) {
                    obj["@attributes"] = {};
                    for (var j = 0; j < xml.attributes.length; j++) {
                        var attribute = xml.attributes.item(j);
                        obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
                    }
                }
            } else if (xml.nodeType == 3) { // text
                obj = xml.nodeValue;
            }
            // do children
            if (xml.hasChildNodes()) {
                for (var i = 0; i < xml.childNodes.length; i++) {
                    var item = xml.childNodes.item(i);
                    var nodeName = item.nodeName;
                    if (typeof(obj[nodeName]) == "undefined") {
                        obj[nodeName] = this.xmlToJson(item);
                    } else {
                        if (typeof(obj[nodeName].push) == "undefined") {
                            var old = obj[nodeName];
                            obj[nodeName] = [];
                            obj[nodeName].push(old);
                        }
                        obj[nodeName].push(this.xmlToJson(item));
                    }
                }
            }
        }
    	catch(error)
    	{
    		console.error("error parsing wms meta data: ", error);
    		this.nc4Notify.error("Unable to parse WMS Data, please check that URL is correct and service is working.");
    		this._shelter.hide();
    	}
        return obj;
    },
    
	
	});
})