define([
    "dojo/_base/declare",
    "app/widgets/Draw/DrawingLayer",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/on",
    "dojo/aspect",
    "dojo/dom",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/topic",
    "dojo/text!./DataWidgetLite.html",                                                                              //importing this html file as a text to pass into the require/define constructor
    "dijit/TooltipDialog",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/TitlePane",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/DataList/DataList",
    "app/widgets/DataOptions/DataOptions",
    "esri/config"
    ], 
    function(
    declare,
    DrawingLayer,
    html,
    lang,
    array,
    on,
    aspect,
    dom,
    domClass,
    domStyle,
    topic,
    template,
    TooltipDialog,
    _WidgetBase,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    TitlePane,
    WidgetPanel,
    DataList,
    DataOptions,
    esriConfig
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        name: "DataWidgetLite",
        baseClass: "widget-DataLayers",
        templateString: template,
        isOpen: false,
        _panel: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },

        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
         */
        postCreate: function() {        	
        	this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetDataLayersIcon"
            }, null);
            this._placeWidgetContainer();
            if(this.appUtils.configGeneralSettings.dlOpt && this.appUtils.configGeneralSettings.dlOpt==1)
            {
                this.titlePaneDataOptions.startup();
                var dOpt = new DataOptions(this.titlePaneDataOptions, this.map, this.appUtils.configGeneralSettings.dlOptHaloLyrs, this.appUtils.configGeneralSettings.showTravelerInfoLyr, this.appUtils.configGeneralSettings.acknowledgeProximityLyr, this._layerData);
            }
            	if( this.appUtils.configGeneralSettings.rd &&  this.appUtils.configGeneralSettings.rd != null &&
               		 this.appUtils.configGeneralSettings.rd.length > 0)
               	{
               		this.titlePaneDataList.startup();
               		try{
                   		domStyle.set(dom.byId("app/widgets/DataLayers/DataWidgetLite"), "overflow-y", "auto");
               		} catch (error){}
               		
               		var dlist = new DataList(this.titlePaneDataList);
               	}
               	else
               	{
               		try{
               			dijit.byId("titlePaneDataList").destroy();
               		}
               		catch(e)
               		{
               			try{
               				dijit.byId("dijit_TitlePane_2").destroy();
               			}
               			catch(f)
               			{
               				console.log("unable to remove recent data div");
               			}
               		}
               	}
            this._attachWidgetRelatedEvents();
            
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
        },


        /**
         * Function to attach events to layer's.
         * @param {array} arrLayers - Layers list.
         */
        _attachLayerEvents: function(arrLayers) {
            array.forEach(arrLayers, lang.hitch(this, function(layer) {
                this.own(on(layer, "load", lang.hitch(this, "_performLoadEventOperations")));
                this.own(on(layer, "error", lang.hitch(this, "_performErrorEventOperations")));
            }));
        },

        /**
         * Display the widget panel.
         */
        show: function() {
            if (!this.isOpen) {
                domClass.add(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                this.appUtils.sidePanelOpen(this.isOpen);
            } else {
                this.hide();
            }
        },

        /**
         * Hide the widget panel
         */
        hide: function() {
            this.isOpen = false;
            esriConfig.defaults.io.alwaysUseProxy = false;
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
            }
            this.appUtils.getTreeNodeForBasemap(this._dataLayerTreeStore);
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Attach widget related events
         */
        _attachWidgetRelatedEvents: function() {
            on(this.map, "click", lang.hitch(this, function(){this.hide()}));   //james
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
            }));
        }
        

    });
});
