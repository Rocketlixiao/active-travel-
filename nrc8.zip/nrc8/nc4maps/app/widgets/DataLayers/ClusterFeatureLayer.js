define([
  "dojo/_base/declare",
  "dojo/_base/array",
  "dojo/_base/lang",
  "dojo/_base/Color",
  "dojo/dom-style",
  "dojo/query",
  "dojo/on",
  "dojo/_base/connect",
  "dojo/promise/all",
  "esri/SpatialReference",
  "esri/geometry/Point",
  "esri/graphic",
  "esri/symbols/SimpleMarkerSymbol",
  "esri/symbols/PictureMarkerSymbol",
  "esri/symbols/SimpleLineSymbol",
  "esri/symbols/SimpleFillSymbol",
  "esri/symbols/TextSymbol",
  "esri/symbols/Font",
  "esri/renderers/ClassBreaksRenderer",
  "esri/renderers/UniqueValueRenderer",
  "esri/request",
  "esri/symbols/jsonUtils",
  "esri/renderers/jsonUtils",
  "esri/dijit/PopupTemplate",
  "esri/layers/GraphicsLayer",
  "esri/tasks/query",
  "esri/tasks/QueryTask",
  "esri/InfoTemplate",
  "dojo/dom-construct",
  "dojo/dom-attr",
  "dojo/dom",
  "dojo/topic",
  "esri/geometry/Extent",
  "app/widgets/Notifications/NC4Notification",
  "esri/tasks/ProjectParameters",
  "app/nc4modules/NC4GeometryService",
  "app/nc4modules/NC4Utils",
  "esri/geometry/webMercatorUtils",
  "app/widgets/DataLayers/MappingLayerData"
], function (
  declare, arrayUtils, lang, Color, domStyle, query, on, connect, all,
  SpatialReference, Point, Graphic,
  SimpleMarkerSymbol, PictureMarkerSymbol, SimpleLineSymbol, SimpleFillSymbol, TextSymbol, Font,
  ClassBreaksRenderer, UniqueValueRenderer,
  esriRequest, symbolJsonUtils, rendererJsonUtil,
  PopupTemplate, GraphicsLayer, Query, QueryTask,
  InfoTemplate, domConstruct, domAttr, dom, topic, Extent, NC4Notification, ProjectParameters, GeometryService, NC4Utils, webMercatorUtils, MappingLayerData
) {

    function concat(a1, a2) {
      return a1.concat(a2);
    }

    function toPoints(features) {
      var len = features.length;
      var points = [];
      while (len--) {
        var g = features[len];
        points.push(
          new Graphic(
            g.geometry.getCentroid(),
            g.symbol, g.attributes,
            g.infoTemplate
          ));
      }
      return points;
    }

    //02.19.2016 - they seem to have copied from https://github.com/Esri/cluster-layer-js
    return declare([GraphicsLayer], {
      constructor: function (options) {
        this.nc4Utils = new NC4Utils();
        // options:
        //   url:  string
        //    URL string. Required. Will generate clusters based on Features returned from map service.
        //   outFields:  Array?
        //    Optional. Defines what fields are returned with Features.
        //   objectIdField:  String?
        //    Optional. Defines the OBJECTID field of service. Default is "OBJECTID".
        //   where:  String?
        //    Optional. Where clause for query.
        //   useDefaultSymbol:  Boolean?
        //    Optional. Use the services default symbology for single features.
        //   returnLimit:  Number?
        //    Optional. Return limit of features returned from query. Default is 1000.
        //   distance:  Number?
        //     Optional. The max number of pixels between points to group points in the same cluster. Default value is 50.
        //   labelColor:  String?
        //     Optional. Hex string or array of rgba values used as the color for cluster labels. Default value is #fff (white).
        //   labelOffset:  String?
        //     Optional. Number of pixels to shift a cluster label vertically. Defaults to -5 to align labels with circle symbols. Does not work in IE.
        //   resolution:  Number
        //     Required. Width of a pixel in map coordinates. Example of how to calculate:
        //     map.extent.getWidth() / map.width
        //   showSingles:  Boolean?
        //     Optional. Whether or graphics should be displayed when a cluster graphic is clicked. Default is true.
        //   zoomOnClick:  Boolean?
        //     Optional. Will zoom the map when a cluster graphic is clicked. Default is true.
        //   singleSymbol:  MarkerSymbol?
        //     Marker Symbol (picture or simple). Optional. Symbol to use for graphics that represent single points. Default is a small gray SimpleMarkerSymbol.
        //   singleRenderer:  Renderer?
        //     Optional. Can provide a renderer for single features to override the default renderer.
        //   singleTemplate:  PopupTemplate?
        //     PopupTemplate</a>. Optional. Popup template used to format attributes for graphics that represent single points. Default shows all attributes as "attribute = value" (not recommended).
        //   maxSingles:  Number?
        //     Optional. Threshold for whether or not to show graphics for points in a cluster. Default is 1000.
        //   font:  TextSymbol?
        //     Optional. Font to use for TextSymbol. Default is 10pt, Arial.
        //   spatialReference:  SpatialReference?
        //     Optional. Spatial reference for all graphics in the layer. This has to match the spatial reference of the map. Default is 102100. Omit this if the map uses basemaps in web mercator.
        this._clusterTolerance = -1; // options.distance || 50;
        this._clusterData = [];
        this._clusters = [];
        this._clusterLabelColor = options.labelColor || "#000";
        // labelOffset can be zero so handle it differently
        this._clusterLabelOffset = (options.hasOwnProperty("labelOffset")) ? options.labelOffset : -5;
        // graphics that represent a single point
        this._singles = []; // populated when a graphic is clicked
        this._showSingles = options.hasOwnProperty("showSingles") ? options.showSingles : true;
        this._zoomOnClick = options.hasOwnProperty("zoomOnClick") ? options.zoomOnClick : true;
        // symbol for single graphics
        // var sms = SimpleMarkerSymbol;
        //var sls = SimpleLineSymbol;
        this._singleSym = options.singleSymbol; // || new sms("circle", 6, null, new Color("#888"));
        this._singleTemplate = options.singleTemplate || new InfoTemplate("Attributes", this.popupInfo);
        this._maxSingles = options.maxSingles || 1000;

        this._font = options.font || new Font("15px").setFamily("Arial");
        this._sr = options.spatialReference || new SpatialReference({ "wkid": 102100 });

        this._zoomEnd = null;
        this.popupInfo = options.popupInfo;
        this.popupEndpoint = options.popupEndpoint,
          this.url = options.url || null;																	//Should be the URL to the Feature Service
        this._outFields = options.outFields || ["*"];
        this.queryTask = new QueryTask(this.url);														//New QueryTask w/ the Feature Service URL
        this._where = options.where || null;
        this._useDefaultSymbol = options.hasOwnProperty("useDefaultSymbol") ? options.useDefaultSymbol : false;
        this._returnLimit = options.returnLimit || 1000;
        this._singleRenderer = options.singleRenderer;		//only used in legend widget?
        this.appUtils = options.appUtils;
        //  this._objectIdField = options.objectIdField || "OBJECTID";

        if (!this.url) {
          throw new Error("url is a required parameter");
        }
        this._clusterCache = {};
        this._objectIdCache = [];
        this._objectIdHash = {};
        this.queryForResults = null;
        this.detailsLoaded = false;
        this.name = options.name || "";
        this._query = new Query();

        this.MODE_SNAPSHOT = options.hasOwnProperty("MODE_SNAPSHOT") ? options.MODE_SNAPSHOT : true;
        this.mode = options.mode;
        this._shelter = null;

        //jt
        this.layerId = options.id || "";
        this.gIds = options.gIds || "";
        this.gIdsKeepNew = options.gIdsKeepNew || [];
        this.popW = options.popW || 270;
        this.popH = options.popH || 710;
        this.service = options.service || "";
        this.isGroupService = options.isGroupService || false;
        this.cacheServiceDetails = options.cacheServiceDetails;
        this._getServiceDetails();
        this.visibleLyrs = options.visibleLyrs || null;
        this.isFirstLoad = true;
        this._isPin = options.isPin || 0;
        this.mappingLayerData = new MappingLayerData();

      },
      _setupQuery: function () {
        var qry = new Query();

        if (this.layerId.indexOf('_fac_') >= 0) {
          this._clusterResolution = app.map.map.extent.getWidth() / app.map.map.width;
          this._query.geometry = app.map.map.extent;
          this._query.returnGeometry = true;
          this._query.outFields = ["*"];
          var cz = this._map.getZoom();
          if (cz <= 1)
            cd = 31;
          else if (cz <= 2)
            cd = 31;
          else if (cz <= 4)
            cd = 37;
          else if (cz <= 6)
            cd = 40;
          else if (cz <= 7)
            cd = 54;
          else if (cz <= 9)
            cd = 42;
          else
            cd = 40;
          this._query.where = '1=1&showonmap=all&resolution=' + this._clusterResolution + '&distance=' + cd + '&minCluster=' + this.appUtils.configGeneralSettings.clThreshold;

        }
        else {
          this._query.returnGeometry = null;
          this._query.where = null;
        }
      },
      _getServiceDetails: function () {
        this.getFromCache = false;
        if (this.cacheServiceDetails && this.cacheServiceDetails != null && this.cacheServiceDetails.length > 0) {
          for (var i = 0; i < this.cacheServiceDetails.length; i++) {
            var currSd = this.cacheServiceDetails[i];
            if ((currSd.layerId && currSd.layerId == this.layerId))//|| (this.isGroupService == true && currSd.service == this.service))
            {
              this.getFromCache = true;
              this.detailsLoaded = true;//reset this so that reCluster() is called
              this.mappingLayerData = new MappingLayerData();
              this._processFLResponse(currSd.servicedetails);
            }
          }
        }

        //if (this.getFromCache == false) {

        //    this.queryTask = new QueryTask(this.url);
        //    this._setupQuery();
        //    /*debug code*/
        //    //if (this.layerId.indexOf('_fac_') >= 0) {
        //    //    this.currentExecuteSD = esriRequest({
        //    //        url: this.url,
        //    //        content: lang.mixin({
        //    //            f: "json"
        //    //        }, null),
        //    //        callbackParamName: "callback"
        //    //    }).then(lang.hitch(this, lang.hitch(this, function (response) {
        //    //        this.cacheServiceDetails.push({ "url": this.url, "servicedetails": response, "service": this.service });
        //    //        this._processFLResponse(response);

        //    //    })), lang.hitch(this, function (err) {
        //    //        console.error("clusterfeaturelayer err: ", err);
        //    //        this.emit("load-error", this);
        //    //    })
        //    //        );
        //    //}
        //    //else {
        //    //    this.currentExecuteSD = this.queryTask.execute(this._query).then(
        //    //        lang.hitch(this, function (response) {
        //    //            this.cacheServiceDetails.push({ "url": this.url, "servicedetails": response, "service": this.service });
        //    //            this._processFLResponse(response);

        //    //        }), lang.hitch(this, function (err) {
        //    //            console.error("clusterfeaturelayer err: ", err);
        //    //            this.emit("load-error", this);
        //    //        })
        //    //    );

        //    //}
        //    /*end debug code*/
        //    //this.currentExecuteSD = this.queryTask.execute(this._query).then(
        //    //    lang.hitch(this, function (response) {
        //    //        this.cacheServiceDetails.push({ "url": this.url, "servicedetails": response, "service": this.service });
        //    //        this._processFLResponse(response);

        //    //    }), lang.hitch(this, function (err) {
        //    //        console.error("clusterfeaturelayer err: ", err);
        //    //        this.emit("load-error", this);
        //    //    })
        //    //);
        //}

      },

      _filter: function () {
        //get an array of all grpahics NOT equals to the filter type
        for (var i = 0; i < this.graphics.length; i++) {
          var currG = this.graphics[i];
          if (this.visibleLyrs.indexOf(currG.attributes.type) < 0) {
            currG.hide();
            currG.attributes.turnedOff = 1;
          }
          else {
            currG.show();
            currG.attributes.turnedOff = 0;
          }
        }

        topic.publish("nc4ClusterIcons_RL");

      },

      _setVisibleLyrs: function (p_visibleLyrs) {
        this.visibleLyrs = p_visibleLyrs;
      },

      _getVisibleLyrs: function () {
        return this.visibleLyrs;
      },

      _processFLResponse: function (response) {

        //randy:mapping response for single popup
        this.queryForResults = response;
        response = this.mappingLayerData.mappingResults(response, this.layerId, 'render');

        var jsonRenderer = response.drawingInfo.renderer;

        //this._defaultRenderer = rendererJsonUtil.fromJson(jsonRenderer); //this._singleRenderer != null ? this._singleRenderer : 

        //jt trying this code out for renderer due to blurry icons
        var rFS = jsonRenderer;
        if (rFS != null && rFS.type && rFS.type == "uniqueValue") {
          //create uv
          var defaultSymbol = new PictureMarkerSymbol(rFS.defaultSymbol)
          this._defaultRenderer = new UniqueValueRenderer(defaultSymbol, rFS.field1, rFS.field2, rFS.field3, ",");//UniqueValueRenderer(rendFromService);
          var arrUvi = rFS.uniqueValueInfos;
          for (var i = 0; i < arrUvi.length; i++) {
            var currUVI = arrUvi[i];
            var currSymbol = currUVI.symbol;
            if (currSymbol.type == "esriPMS")
              var newPms = new PictureMarkerSymbol(currSymbol.url, currSymbol.width, currSymbol.height).setOffset(currSymbol.xoffset, currSymbol.yoffset);
            var newUVIObj = {
              description: "",
              label: currUVI.label,
              symbol: newPms,
              value: currUVI.value
            };
            this._defaultRenderer.addValue(newUVIObj)
          }
        }
        //end jt


        arrayUtils.forEach(response.fields, function (field) {
          this._fileds = response.fields;
          if (field.type === "esriFieldTypeOID") {
            this._objectIdField = field.name;

          }
        }, this);

        if (response.objectIdField)
          this._objectIdField = response.objectIdField;

        this.native_geometryType = response.geometryType;
        if (response.geometryType === "esriGeometryPolygon") {
          this._useDefaultSymbol = false;
          console.info("polygon geometry will be converted to points");
        }
        this.emit("details-loaded", response);
      },

      _getDefaultSymbol: function (g) {
        var rend = this._defaultRenderer;
        if (!this._useDefaultSymbol || !rend) {
          return this._singleSym;
        } else {
          return rend.getSymbol(g);
        }
      },

      _getRenderedSymbol: function (feature) {
        var attr = feature.attributes;
        if (attr.clusterCount === 1) {
          if (!this._useDefaultSymbol) {
            return this._singleSym;
          }
          var rend = this._defaultRenderer;
          if (!rend) { // something went wrong getting default renderer
            return null;
          } else {
            return rend.getSymbol(feature);
          }
        } else {
          return null;
        }
      },

      //This is the call that initiates the '_onIdsReturend', which initiates the request for the Feature Set (query to Feature Layer)
      _reCluster: function () {
        if (this._map) {
          // update resolution
          this._clusterResolution = this._map.extent.getWidth() / this._map.width;
          //this._getObjectIds(this._map.extent);
          this._onIdsReturned();
        }
      },

      //02.19.2016 - they seem to have copied from https://developers.arcgis.com/javascript/jssamples/layers_point_clustering.html
      // override esri/layers/GraphicsLayer methods
      _setMap: function (map, surface) {

        this._query.outSpatialReference = map.spatialReference;
        this._query.returnGeometry = true;
        this._query.outFields = this._outFields;
        // listen to extent-change so data is re-clustered when zoom level changes
        // this._extentChange = on(map, "zoom-end", lang.hitch(this, "_reCluster")); JT removing old clustering in favor of new RC influenced clustering

        var layerAdded = on(map, "layer-add", lang.hitch(this, function (e) {
          if (e.layer === this) {
            layerAdded.remove();
            if (!this.detailsLoaded) {
              on.once(this, "details-loaded", lang.hitch(this, function () {
                this.emit("load-data", null);
                this._reCluster();
              }));
            }
            else {
              this.emit("load-data", null);
              this._reCluster();
            }
          }
        }));

        // GraphicsLayer will add its own listener here
        var div = this.inherited(arguments);
        return div;
      },

      _unsetMap: function () {
        this.inherited(arguments);
        // this._extentChange.remove();
      },

      _onClusterClick: function (map, e) {

        //JT Hack ,since using custom popup, only way to resize: if 0, uses defaults, height currently not respected
        this._map.infoWindow.options.defaultWidth = this.popW;
        this._map.infoWindow.options.defaultHeight = this.popH;

        if (this._map.halo && this._map.halo == "click") {
          try {

            var currObjtype = e.graphic.attributes.objtype;
            if (currObjtype != null && currObjtype.indexOf("highlight") >= 0) {
              e.graphic.attributes.objtype = e.graphic.attributes.objtypeO;
              var sym = this._getRenderedSymbol(e.graphic);
              e.graphic.setSymbol(sym);
              topic.publish("dlUpdateItem", e.graphic);
            }
          } catch (error) { log.error(error); }
        }
        if (e.graphic) {
          attr = e.graphic.attributes;
        }
        if (attr && attr.clusterCount >= 1) {	//all items is always at least size of 1, so all biz data goes through this.

          var contentinfo;

          //if feature is a server side cluster:
          if (attr.objtype && attr.objtype == "cluster") {
            var templatePath = attr.popPath;
            require([templatePath], lang.hitch(e, function (TemplateMaker) {
              var tm = new TemplateMaker();
              var template = new InfoTemplate(e.graphic.attributes.lid, tm.createClusterListTemplate("cgC_server", e.graphic));
              e.graphic.setInfoTemplate(template);

            }));
          }
          //if feature has the html endpoint defined, then use it. randy comments it because signle location could popup by design.
          //else if (e.graphic._layer.popupEndpoint && e.graphic._layer.popupEndpoint == true) {
          //    contentinfo = new InfoTemplate("&nbsp;", "Loading...");
          //    e.graphic.setInfoTemplate(contentinfo);
          //    topic.publish("loadHtmlPopup", e.graphic); //._layer.url, e.graphic.id);
          //}
          //if feature is a single icon and none of the above.
          else {
            title = this.nc4Utils.escapeHTML(this.name) || "Attributes";
            contentinfo = this.mappingLayerData.createSingleTemplate(this.layerId, attr);
            //contentinfo = new InfoTemplate(title, this.popupInfo);
            e.graphic.setInfoTemplate(contentinfo);
          }
          //client side clustering popups is generated later
        }

        if (globalConfig.isDockPopupMode) {
          map.centerAndZoom(e.graphic.geometry, globalConfig.paperAirplane.zoomlevel);
        }
      },

      pointToExtent: function (map, point, symbolSize) {
        //calculate map coords represented per pixel
        var pixelWidth = map.extent.getWidth() / map.width;
        //calculate map coords for tolerance in pixel
        var toleraceInMapCoords = symbolSize * pixelWidth;
        //calculate & return computed extent
        return new Extent(point.x - toleraceInMapCoords,
          point.y - toleraceInMapCoords,
          point.x + toleraceInMapCoords,
          point.y + toleraceInMapCoords,
          map.spatialReference);
      },

      //the call to this was commented out by CT, it is no longer in use
      _getObjectIds: function (extent) {
        if (this.url) {
          var ext = extent || this._map.extent;
          this._query.objectIds = null;
          if (this._where) {
            this._query.where = this._where;
          }
          if (!this.MODE_SNAPSHOT) {
            this._query.geometry = ext;
          }
          if (!this._query.geometry && !this._query.where) {
            this._query.where = "1=1";
          }
          this.queryTask.executeForIds(this._query).then(
            lang.hitch(this, "_onIdsReturned"), lang.hitch(this, "_onError")
          );
        }
      },

      _onError: function (err) {
        if (err.status == 400) {
          //TODO : place error message somewhere that is not too intrusive
          //alert("Unable to reach the configured Geometry Service.  Please contact your NC4 Maps Administrator.");
          /*
          var status = new StatusArea({
              id: "geometry",
              message: "Error with Geometry Service.",
              icon: "http://d13yacurqjgara.cloudfront.net/users/124652/screenshots/1307854/loading_icon05.gif"
          });
          */
          //create new NC4Notification since it's not passed in.
          var status = new NC4Notification();
          status.error("Geometry Service is invalid, please check URL in Default Configurations Widget");
        }
        else if (err.message && err.message.indexOf("Request canceled") >= 0) {//do nothing, it was cancelled
          this.emit("load-cancel", this);
        }
        else {
          console.error("clusterFeatLyr error object: ", err);
          this.emit("load-error", this);
        }
      },

      //JT refresh graphics from server w/o destroying layer (nc4bbox)
      _refreshGraphicsBbox: function () {
        //this._map.infoWindow.hide();
        try {
          if (this.currentExecuteSD && this.currentExecuteSD.isFulfilled() == false)
            return;

          //this.currentExecuteSD.cancel();
          //this.emit("load-done", this.id); no need, havent added to array of loadings yet.

          /*
          if(this.currentExecute)
          {
              this.currentExecute.cancel();
              this.emit("load-done", this.id);
          }*/
          if (this.currentExecute && this.currentExecute.isFulfilled() == false)
            return;
        } catch (e) { console.log("error canceling previous request", e); }

        this.emit("load-data", null);
        this.queryForResults = null;
        this._onIdsReturned();
        if (this.isDrillDown && this.isDrillDown == true)
          this.isDrillDown = false;
        // else
        //     this.infoWindow.hide();
      },

      _refreshGraphics: function (p_hideP) {
        if (p_hideP && p_hideP == 1) { }
        else
          this._map.infoWindow.hide();
        try {
          if (this.currentExecute && this.currentExecute.isFulfilled() == false)
            return;
          //this.currentExecute.cancel();
        } catch (e) { console.log("canceling previous request", e); }

        this.emit("load-data", null);
        this.queryForResults = null;
        this._onIdsReturned();
      },

      //james- this is where the query to the feature service occurs, and returns the actual feature set w/ geometry information
      _onIdsReturned: function () {

        //  var uncached = difference(results, this._objectIdCache.length, this._objectIdHash);
        var uncached = null;
        this._objectIdCache = concat(this._objectIdCache, uncached);

        if (!this.queryForResults) {
          //this._query.geometry = null;
          //if (this.mode && this.mode == "nc4bbox")
          //    this._query.geometry = this._map.extent;

          //this._clusterResolution = this._map.extent.getWidth() / this._map.width;
          //var gIds = "";
          //this.gIdsKeepNew = [];
          //if (this._map.getLayer(this.layerId)) {
          //    //must be a refresh, capture graphics ids and remove
          //    var currLyr = this._map.getLayer(this.layerId);
          //    var gLen = currLyr.graphics.length;
          //    var gIds = "";
          //    for (var i = 0; i < gLen; i++) {
          //        if (this._map.halo && this._map.halo == "click") {
          //            //keep array of items to keep highlighted
          //            try {

          //                var currObjtype = currLyr.graphics[i].attributes.objtype;
          //                if (currObjtype != null && currObjtype.indexOf("highlight") >= 0) {
          //                    this.gIdsKeepNew.push(currLyr.graphics[i].id);
          //                }
          //            } catch (error) { log.error(error); }
          //        }
          //        gIds += currLyr.graphics[i].id;
          //        if (i < gLen - 1)
          //            gIds += ",";
          //    }
          //    this.gIds = gIds;
          //}

          ////will not exist because we remove the layer already :(
          //if (this.gIds != null && this.gIds != "") {
          //    if (this.gIdsKeepNew != null && this.gIdsKeepNew != "")
          //        this._query.where = "1=1&resolution=" + this._clusterResolution + "&distance=" + this.appUtils.configGeneralSettings.cd + "&gIds=" + this.gIds + "&gIdsKeepNew=" + this.gIdsKeepNew;
          //    else
          //        this._query.where = "1=1&resolution=" + this._clusterResolution + "&distance=" + this.appUtils.configGeneralSettings.cd + "&gIds=" + this.gIds;
          //}
          //else
          //    this._query.where = "1=1&resolution=" + this._clusterResolution + "&distance=" + this.appUtils.configGeneralSettings.cd;

          //if (this.appUtils.configGeneralSettings.clThreshold != null && this.appUtils.configGeneralSettings.clThreshold != "")
          //    this._query.where += "&minCluster=" + this.appUtils.configGeneralSettings.clThreshold;



          /*debug code*/
          //if (this.layerId.indexOf('_fac_') >= 0) {
          //    this.currentExecuteSD = esriRequest({
          //        url: this.url,
          //        content: lang.mixin({
          //            f: "json"
          //        }, null),
          //        callbackParamName: "callback"
          //    }).then(lang.hitch(this, function (response) {
          //        this._processFLResponse(response);
          //        this._onFeaturesReturned(response);
          //    }), lang.hitch(this, "_onError")
          //        );
          //}
          //else {
          //    this.currentExecute = this.queryTask.execute(this._query).then(
          //        lang.hitch(this, function (response) {
          //            this._processFLResponse(response);
          //            this._onFeaturesReturned(response);
          //        }), lang.hitch(this, "_onError")
          //    );

          //}
          /*end debug code*/

          //mark the current layer has been installed
          if (globalConfig.allMapLayers.length > 0) {
            for (var k = 0; k < globalConfig.allMapLayers.length; k++) {
              if (globalConfig.allMapLayers[k].toLowerCase() == this.layerId.toLowerCase()) {
                globalConfig.allMapLayers.splice(k, 1);
              }
            }
          };

          if (this.layerId.indexOf('_nimc_') >= 0 || this.layerId.toLowerCase().indexOf('_isa_cybertech_india') >= 0) {

            var response = this.mappingLayerData.getIncidentsByLayerId(this.layerId);
            this.cacheServiceDetails.push({ "layerId": this.layerId, "servicedetails": response, "service": this.service });
            this._processFLResponse(response);
            this._onFeaturesReturned(response);

          }
          else {

            if (isDebugMode) {
              //debug mode
              this.currentExecute = esriRequest({
                url: this.url,
                content: lang.mixin({
                  f: "json"
                }, null),
                callbackParamName: "callback"
              }).then(lang.hitch(this, lang.hitch(this, function (response) {
                this.cacheServiceDetails.push({ "layerId": this.layerId, "servicedetails": response, "service": this.service });
                this._processFLResponse(response);
                this._onFeaturesReturned(response);

              })), lang.hitch(this, function (err) {
                console.error("clusterfeaturelayer err: ", err);
                this.emit("load-error", this);
              })
                );

            }
            else {
              //prod mode
              this.queryTask = new QueryTask(this.url);
              this._setupQuery();
              this.currentExecute = this.queryTask.execute(this._query).then(
                lang.hitch(this, function (response) {
                  this.cacheServiceDetails.push({ "layerId": this.layerId, "servicedetails": response, "service": this.service });
                  this._processFLResponse(response);
                  this._onFeaturesReturned(response);
                }), lang.hitch(this, "_onError")
              );
            }


          }
        }
        else {
          this._onFeaturesReturned(this.queryForResults);
        }
      },

      //james - seems to be getting an array of clustered features w/in the current extent
      _inExtent: function () {
        //var start = new Date().valueOf();
        //console.debug("#inExtent start");
        var valid = [];
        if (this._map) {
          var ext = this._map.extent;
          var len = this._objectIdCache.length;


          while (len--) {
            var oid = this._objectIdCache[len];
            var cached = this._clusterCache[oid];
            if (cached && ext.contains(cached.geometry)) {
              valid.push(cached);
            }
          }
        }
        //var end = new Date().valueOf();
        //console.debug("#inExtent end", (end - start)/1000);
        return valid;
      },

      _onFeaturesReturned: function (results) {

        //randy: mapping points data for cluster               
        results = this.mappingLayerData.mappingResults(results, this.layerId, 'points');

        if (results) {
          this.queryForResults = results;
        }
        var inExtent = this._inExtent();
        var features;
        if (this.native_geometryType === "esriGeometryPolygon") {
          features = toPoints(results.features);
        } else {
          features = results.features;
        }
        var len = features.length;
        if (this.appUtils.configGeneralSettings.layerCount) {
          this.emit("cluster-count", { "lyrId": this.layerId, "clusterLength": results.layerSize });
        }

        if (results.useBbox && !eval(results.useBbox))
          this.mode = "snapshot";

        //if the server is siginifying to reproject its lat lon on the client... (NC4 option)
        if (results.latLon_clientProjectOnly) {
          var params = new ProjectParameters();

          var geometries = [];
          for (var i = 0; i < features.length; i++) {
            geometries[i] = features[i].geometry;
          }

          params.geometries = geometries;
          params.outSR = this._map.spatialReference;

          this.inExtent = inExtent;
          this.features = features;


          var gsvc = new GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL, this.appUtils);
          gsvc.project(params, this, function (p_geometries) {
            for (var i = 0; i < p_geometries.length; i++) {
              this.features[i].geometry = p_geometries[i];
            }

            this._clusterData.length = 0;
            this.clear();
            var len = this.features.length;
            if (len) {
              arrayUtils.forEach(this.features, function (feat) {
                this._clusterCache[feat.attributes[this._objectIdField]] = feat;
              }, this);
            }
            this._clusterData = concat(this.features, inExtent);
            this._clusterGraphics();
          }, function () {
            console.error("unable to update projection for: " + this.name);
          });
        }
        else {
          this._clusterData.length = 0;
          this.clear(); //clears all clusters and points
          if (len) {
            arrayUtils.forEach(features, function (feat) {
              this._clusterCache[feat.attributes[this._objectIdField]] = feat;
            }, this);
          }
          this._clusterData = concat(features, inExtent);
          this._clusterGraphics();
        }
      },

      // public ClusterLayer methods
      updateClusters: function () {
        this.clearCache();
        this._reCluster();
      },
      clearCache: function () {
        // Summary: Clears the cache for clustered items
        arrayUtils.forEach(this._objectIdCache, function (oid) {
          delete this._objectIdCache[oid];
        }, this);
        this._objectIdCache.length = 0;
        this._clusterCache = {};
        this._objectIdHash = {};
      },

      add: function (p) {
        // Summary:  The argument is a data point to be added to an existing cluster. If the data point falls within an existing cluster, it is added to that cluster and the cluster"s label is updated. If the new point does not fall within an existing cluster, a new cluster is created.
        //
        // if passed a graphic, use the GraphicsLayer"s add method
        if (p.declaredClass) {
          this.inherited(arguments);
          return;
        }
      },

      clear: function () {
        // Summary:  Remove all clusters and data points.
        this.inherited(arguments);
        this._clusters.length = 0;
      },

      clearSingles: function (singles) {
        // Summary:  Remove graphics that represent individual data points.
        var s = singles || this._singles;
        arrayUtils.forEach(s, function (g) {
          this.remove(g);
        }, this);
        this._singles.length = 0;
      },

      onClick: function (e) {
        this._onClusterClick(this._map, e);
      },

      // internal methods
      _clusterGraphics: function () {
        this.clear();
        // first time through, loop through the points
        //JT TODO: Fix this so we don't go through a loop

        for (var j = 0, jl = this._clusterData.length; j < jl; j++) {
          // see if the current feature should be added to a cluster
          var point = this._clusterData[j].geometry || this._clusterData[j];
          var feature = this._clusterData[j];
          this._clusterCreate(feature, point);
        }
        this._showAllClusters();
      },

      // point passed to clusterCreate isn"t within the
      // clustering distance specified for the layer so
      // create a new cluster for it
      _clusterCreate: function (feature, p) {

        var clusterId = this._clusters.length + 1;
        // console.log("cluster create, id is: ", clusterId);
        // p.attributes might be undefined
        if (!p.attributes) {
          p.attributes = {};
        }
        p.attributes = feature.attributes;
        feature.attributes.clusterId = p.attributes.clusterId = clusterId;
        // create the cluster
        var cluster = {
          "x": p.x,
          "y": p.y,
          "attributes": feature.attributes
        };
        cluster.attributes.clusterCount = 1;
        cluster.attributes.clusterId = clusterId;
        cluster.attributes.extent = [p.x, p.y, p.x, p.y];
        this._clusters.push(cluster);
      },

      _showAllClusters: function () {

        for (var i = 0, il = this._clusters.length; i < il; i++) {
          this._showCluster(this._clusters[i]);
        }
        this.emit("clusters-shown", this._clusters);
        this.emit("load-done", this.layerId);
      },

      _showCluster: function (c) {
        var point = new Point(c.x, c.y, this._sr);
        var g = new Graphic(point, null, c.attributes);
        g.id = c.attributes[this._objectIdField];				//JT: id will be used in NC4Cluster, and recent inicdent list to update item in list

        var sym = this._getRenderedSymbol(g);
        if (this._isPin && this._isPin == 1)
          sym.setOffset(0, sym.height / 2);
        if (sym != null) {
          g.setSymbol(sym);

          g.symbol.setHeight(g.symbol.height);
          g.symbol.setWidth(g.symbol.width);
        }
        this.add(g);
        if (this.visibleLyrs && this.visibleLyrs != null) {
          if (this.visibleLyrs.indexOf(g.attributes.type) >= 0) {
            g.show();
            g.attributes.turnedOff = 0;
          }
          else {
            g.hide();
            g.attributes.turnedOff = 1;
          }
        }
        else if (this.getFromCache == false) //must be first load AND user hasn't mess with filter
        {
          g.show();
          g.attributes.turnedOff = 0;
        }
        else {
          g.show();
          g.attributes.turnedOff = 0;
        }

        // code below is used to not label clusters with a single point
        /*
        if (c.attributes.clusterCount < 2) {
            return;
        }
 
        // show number of points in the cluster
        var label = new TextSymbol(c.attributes.clusterCount.toString())
            .setColor(new Color(this._clusterLabelColor))
            .setOffset(0, this._clusterLabelOffset)
            .setFont(this._font);
        this.add(
            new Graphic(
                point,
                label,
                c.attributes
            )
        );
        */
      },

      _updateLabel: function (c) {
        // find the existing label
        var label = arrayUtils.filter(this.graphics, function (g) {
          return g.symbol &&
            g.symbol.declaredClass == "esri.symbol.TextSymbol" &&
            g.attributes.clusterId == c.attributes.clusterId;
        });
        if (label.length == 1) {
          // console.log("update label...found: ", label);
          this.remove(label[0]);
          var newLabel = new TextSymbol(c.attributes.clusterCount)
            .setColor(new Color(this._clusterLabelColor))
            .setOffset(0, this._clusterLabelOffset)
            .setFont(this._font);
          this.add(
            new Graphic(
              new Point(c.x, c.y, this._sr),
              newLabel,
              c.attributes)
          );
        } else {
          console.log("didn not find exactly one label: ", label);
        }
      }
    });
  });
