define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/i18n!../../nls/LocalizedStrings",
    "esri/layers/ArcGISTiledMapServiceLayer",
    "esri/SpatialReference"
], function(declare, lang, on, sharedNls, ArcGISTiledMapServiceLayer, SpatialReference) {
	return declare([], {

		/*
		 * This is a class to encapsulate utility methods for an ArcGIS Cached Service
		 * 
		 */
		_layerId: "",
		_layerName: "",
		_url: "",
		appUtils: null,
		map: null,
		_shelter: null,
		nc4Notify: null,
		
		//provided URL to a map service
		constructor: function(p_serviceName, p_appUtils, p_map, p_url, p_shelter, p_id, p_opacity, p_refresh)
		{
			if(arguments.length > 0)
			{
				this._layerName = p_serviceName;
				this.appUtils = p_appUtils;
				this.map = p_map;
				this._url = p_url;
				if(this.appUtils)
					this.nc4Notify = this.appUtils.nc4Notify;
				this._shelter = p_shelter;
				
				this._layerId = "arcgis_cached_service" + this._layerName;
				if(p_id && p_id != null)
					this._layerId = p_id;
				
				this.opacity = 1;
				this.refreshRate = 0;
				
				if(p_opacity)
					this.opacity = p_opacity;
				else
					this.opacity = this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1;
					
				this.refreshRate = 0;
				if(p_refresh)
					this.refreshRate = p_refresh;
				else
					this.refreshRate = this.appUtils.configGeneralSettings.defaultRefRate || 0;
				
				this.cachedServiceMetaData = {
				        "type": "arcgis_cached_service", //"Cached",
				        "url": p_url,
				        "opacity": this.opacity,
				        "refresh": this.refreshRate,
				        "bbox": 0,
				        "id": this._layerId,
				        "name": this._layerName,
				        "state": 1,
				       // "sr": addCachedLayer.spatialReference.wkid,
				        "basemap": 0,
				        "parent": "customLayers",
				        "layerFromAddLayer": true
				    };
				
			}
			
			
		},
		
		_addCachedServiceToMap: function(p_errorMessage, p_wkid)
		{
			var mapLyr = this.map.getLayer(this._layerId);
            if(mapLyr != null)
            	return;
            esriConfig.defaults.io.alwaysUseProxy = true;					
            var cachedLayer = new ArcGISTiledMapServiceLayer(this._url, {
                id: this._layerId,
                name: this._layerName,
                visible: true,
                opacity: this.opacity,
                refreshInterval: this.refreshRate
            });
        
            	 esriConfig.defaults.io.alwaysUseProxy = false;			
		    cachedLayer.customLayerType = "arcgis_cached_service";
		    this.map.addLayer(cachedLayer);														//TODO: jt - no error handling here, what if code doesn't go in IF statemtn/
		    this.appUtils.customLayerCount++;
		    
		    //now that we have the sr, set the meta data:
		    this.cachedServiceMetaData.sr = p_wkid;
		    
		    //var visibleAtScale = cachedLayer.visibleAtMapScale;
		    
		    var projectionMatch = false;
		    
		    
		    //create new SpatialReference object in order to compare?
		    var cachedServiceSR = new SpatialReference(p_wkid);
		    if( p_wkid == this.map.spatialReference.wkid || (cachedServiceSR._isWebMercator() && this.map.spatialReference._isWebMercator()) )
		    	projectionMatch = true;
		    
		    this.errorMessage = p_errorMessage || sharedNls.DataLayer.errorMessages.notCompatible;
		    if (projectionMatch === false) {
		    	this.cachedServiceMetaData.strike = "Yes";
		        this.nc4Notify.warn(this.errorMessage); //ArcGIS Cached Map Service is not compatible with current Base Map.
		    }
		    /*
		    else if(visibleAtScale == false) //show only one error message
		    	this.nc4Notify.warn("Layer may not be visible at this scale");
		    */
		    this.appUtils.customLayerNameAdded(this._layerName);
		    
		    on(cachedLayer, "load", lang.hitch(this, function (evt) {
		    	this._shelter.hide();
		    	
		    	if( evt.layer.spatialReference.wkid == this.map.spatialReference.wkid || 
		        		(cachedLayer.spatialReference._isWebMercator() && this.map.spatialReference._isWebMercator()) )
		        	this.map.setExtent(evt.layer.fullExtent);
		    	/*
		        document.getElementById("Cached").disabled = false;
		        document.getElementById("Dynamic").disabled = false;
		        domAttr.set(this._txtLayerUrl, "displayedValue", "");
		        domAttr.set(this._txtLayerName, "displayedValue", ""); 
		        this.nonEditableTextboxDiv.textContent = ""; */
		    }));
		    
		   
		   on(cachedLayer, "error", lang.hitch(this, function(evt) {
		        if (evt.error.message === "Unable to add Cached Map Service.") {
		        	this.cachedServiceMetaData.strike = "Yes";
		            this.nc4Notify.warn("Error during attempt to add layer.");
		        } 
		        this._shelter.hide();
		    }));
		},
		
		_addCachedServiceAsBaseMap: function()
		{
			var mapLyr = this.map.getLayer(this._layerId);
            if(mapLyr != null)
            	return;
            esriConfig.defaults.io.alwaysUseProxy = true;					
            var cachedLayer = new ArcGISTiledMapServiceLayer(this._url, {
                id: this._layerId,
                name: this._layerName,
                visible: true,
                opacity: this.opacity,
                refreshInterval: this.refreshRate
            });
            esriConfig.defaults.io.alwaysUseProxy = false;			
		    this.map.addLayer(cachedLayer);														//TODO: jt - no error handling here, what if code doesn't go in IF statemtn/
		    
		   on(cachedLayer, "error", lang.hitch(this, function(evt) {
		        if (evt.error.message === "Unable to add Cached Map Service.") {
		            this.nc4Notify.warn("Error during attempt to Base layer.");
		        } 
		    }));
		},
		/*
		_addCachedServiceFromMetaData: function(p_layerMetaData)		//this is the method from the data layer tree:
        {
			var p_layerDetails = p_layerMetaData;
			
        																				//this._showIcons(p_layerDetails.id);
        	if(p_layerDetails.parent == "customLayers")
        	{
        		//check if layer exist, 
                    var mapLyr = this.map.getLayer(p_layerDetails.id);
                    if(mapLyr == null)
                    {
                        var preDefinedParentId = p_layerDetails.id;
                        var customLayer = new ArcGISTiledMapServiceLayer(p_layerDetails.url, {		
                            id: p_layerDetails.id,
                            name: p_layerDetails.name,
                            title: p_layerDetails.name,
                            opacity: p_layerDetails.opacity > 0 ? p_layerDetails.opacity : this.appUtils.configGeneralSettings.defaultOpacity / 100,
                            refreshInterval: p_layerDetails.refresh > 0 ? p_layerDetails.refresh : this.appUtils.configGeneralSettings.defaultRefRate
                        });
                        customLayer.customLayerType = "arcgis_cached_service"; //todo may need to update this.
                        this.map.addLayer(customLayer);
                    }
        	}
        },*/
        
        _removeCachedService: function(p_layerDetails)
        {
        	var arrLyrsToRemove = [];
        	arrLyrsToRemove.push(p_layerDetails.id);
        	if(p_layerDetails.parent == "customLayers")
        	{
        		this._removeLayers(arrLyrsToRemove);
        	}
        	
        },
		
		_addCachedServiceNodeToLayerTree: function()
		{
		    this.appUtils.customLayerAdded(this.cachedServiceMetaData);
		}
		
	});
});
		