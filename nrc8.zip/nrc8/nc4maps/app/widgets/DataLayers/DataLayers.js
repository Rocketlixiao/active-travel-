define([
    "dojo/query",
    "dojo/_base/declare",
    //"app/widgets/Draw/DrawingLayer",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/on",
    "dojo/dom",
    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/dom-class",
    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/topic",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/text!./DataLayers.html",                                                                              //importing this html file as a text to pass into the require/define constructor
    //"dojo/text!./DataLayers.json",
    "dijit/TooltipDialog",
    "dijit/popup",
    "dijit/form/ValidationTextBox",
    "dijit/form/Button",
    "dijit/form/HorizontalSlider",
    "dijit/registry",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/TitlePane",
    "esri/SpatialReference",
    "esri/request",
    "esri/layers/FeatureLayer",
    "esri/InfoTemplate",
    "esri/layers/KMLLayer",
    "esri/layers/MapImage",
    "esri/layers/GraphicsLayer",
    //"esri/renderers/HeatmapRenderer",
    //"esri/layers/WMSLayer",
    //"app/widgets/DataLayers/WMSManager",
    "app/widgets/DataLayers/ArcGISMSmanager",
    "app/widgets/DataLayers/ArcGISMSCachedManager",
    "esri/geometry/Point",
    "esri/graphic",
    "esri/graphicsUtils",
    "esri/geometry/Extent",
    "esri/tasks/QueryTask",
    "esri/tasks/query",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/AlertBox/AlertBox",
    "app/widgets/LoadingShelter/LoadingShelter",
    "app/widgets/DataLayers/Clustering",
    //"app/widgets/DataList/DataList",
    //"app/widgets/DataOptions/DataOptions",
    "esri/layers/ArcGISTiledMapServiceLayer",
    "esri/config",
    "esri/tasks/ProjectParameters",
    "app/nc4modules/NC4GeometryService",
    "dojo/query"
],
    function (
        dojoQuery,
        declare,
        //DrawingLayer,
        html,
        lang,
        array,
        on,
        dom,
        aspect,
        domConstruct,
        domClass,
        Deferred,
        all,
        topic,
        sharedNls,
        template,
        //dataTreeDetail,
        TooltipDialog,
        Popup,
        ValidationTextBox,
        Button,
        HorizontalSlider,
        registry,
        _WidgetBase,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
        TitlePane,
        SpatialReference,
        esriRequest,
        FeatureLayer,
        InfoTemplate,
        KMLLayer,
        MapImage,
        GraphicsLayer,
        //HeatmapRenderer,
        //WMSLayer,
        //WMSManager,
        ArcGISMSmanager,
        ArcGISMSCachedManager,
        Point,
        Graphic,
        graphicsUtils,
        Extent,
        EsriQueryTask,
        EsriQuery,
        WidgetPanel,
        AlertBox,
        LoadingShelter,
        Clustering,
        //DataList,
        //DataOptions,
        ArcGISTiledMapServiceLayer,
        esriConfig,
        ProjectParameters,
        NC4GeometryService,
        query
    ) {
        return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {                                                               //_WidgetBase is the base class for all dijit widgets.
            name: "DataLayers",                                                                                         //_TemplateMixin - allows to pass in a template in order to create the dom
            baseClass: "widget-DataLayers",
            sharedNls: sharedNls,
            templateString: template,                                                                                   //passed in the html as the template for the widget
            isOpen: true,
            _arrClusterDetail: [],
            _arrLayerDetail: [],
            _isBasemapChanged: false,
            _saveElement: null,
            _opacitySpanSlider: null,
            _changedOpacityValue: null,
            _panel: null,
            _saveCount: null,
            _myTooltipDialog: null,
            _shelter: null,
            _nc4Notify: null,
            _gsvc: null,
            lastEditedOverlayId: null,
            //arrIntervalForClusters: [], placing in appUtils instead
            arrIntervalForOverlays: [],
            _widgetPosition: {
                right: 0,
                top: 41,
                height: 100 + "%"
            },

            /**
             * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
             * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
             */
            postCreate: function () {

                this.titlePaneDataLayers.startup();

                this._gsvc = new NC4GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL, this.appUtils);

                //james more error handling
                if (!this.appUtils.configGeneralSettings.defaultRefRate || this.appUtils.configGeneralSettings.defaultRefRate == null || this.appUtils.configGeneralSettings.defaultRefRate == "") {
                    this.appUtils.log.debug("initial/default universal layer refresh rate not yet set, setting to 100");
                    this.appUtils.configGeneralSettings.defaultRefRate = 0;
                }
                if (!this.appUtils.configGeneralSettings.defaultOpacity || this.appUtils.configGeneralSettings.defaultOpacity == null || this.appUtils.configGeneralSettings.defaultOpacity == "") {
                    this.appUtils.log.debug("initial/default universal layer opacity not yet set, setting to 100");
                    this.appUtils.configGeneralSettings.defaultOpacity = 100;
                }

                this._nc4Notify = this.appUtils.nc4Notify;
                //James TODO: opacity needs to be cleaned up.  Biz layers are returning opacity as # between 0 - 100 where as custom layers are returning # between 0 - 1 
                //( because other widget - addlayer.js, divides by 100 when adding)

                this.widgetIcon = html.create("div", {
                    "title": this.config.label,
                    "class": "widgetDataLayersIcon"
                }, null);
                this._placeWidgetContainer();
                this._shelter = new LoadingShelter({
                    hidden: false,
                    loadingText: sharedNls.LoadingShelter.lblLoading
                });
                this._shelter.placeAt(this.domNode);					//James - TODO: place this somewhere else (maybe top status bar?)

                this._alertBox = new AlertBox();
                this._attachWidgetRelatedEvents();
                this._layerData = [{									//this._layerData - seems like the a list of each layer tree node.
                    id: "datalayergroups",
                    name: "DataLayerGroups"
                }];
                this.Cluster = new Clustering({ appUtils: this.appUtils });
                this.appUtils.setClustering(this.Cluster);

                topic.subscribe("/checkbox/doubleclicked", lang.hitch(this, function (checkNode) {
                    this.map.infoWindow.hide();
                    this.appUtils.log.debug("/checkbox/clicked: checkNode: ", checkNode);
                    if (this.appUtils.iscreateOverlayMode && (checkNode[0].item.parent === "nc4maps_overlays" || checkNode[0].item.name === "Overlays")) {
                        this._nc4Notify.warn("Overlay create/edit mode is enabled.  Please disable mode in order to turn other drawing layers on.");
                        return;
                    }
                    var checkClassNode = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._checkBoxClicked(checkNode);
                    this._checkBoxClicked(checkNode);
                    if (this._shelter)
                        this._shelter.hide();

                }));

                topic.subscribe("/checkbox/clicked", lang.hitch(this, function (checkNode) {

                    this.appUtils.log.debug("/checkbox/clicked: checkNode: ", checkNode);
                    if (this.appUtils.iscreateOverlayMode && (checkNode[0].item.parent === "nc4maps_overlays" || checkNode[0].item.name === "Overlays")) {
                        this._nc4Notify.warn("Overlay create/edit mode is enabled.  Please disable mode in order to turn other drawing layers on.");
                        return;
                    }
                    var checkClassNode = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._checkBoxClicked(checkNode);       //james - seems like all it does is check the nodes...(no calls to layer services)
                    if (this._shelter)
                        this._shelter.hide();

                }));
                topic.subscribe("/cluster/clicked", lang.hitch(this, function (clusterNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._clusterClicked(clusterNode);
                    // topic.publish("nc4ClusterIcons");		JT dont want to put this here, only when a layer is for sure getting turned off
                }));
                topic.subscribe("/save/clicked", lang.hitch(this, function (saveNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(saveNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._saveClicked(saveNode);
                }));
                topic.subscribe("/OverlaySave/clicked", lang.hitch(this, function (saveNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(saveNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._saveCount = 0;
                    this._updateOverlayServices(saveNode);
                }));
                topic.subscribe("/cluster/HeatMaps", lang.hitch(this, function (clusterNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    var heatClassName = checkClassNode[0].labelNode.lastChild.className;
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    if (query(".selectedClusterHeatMaps").length == 0 || heatClassName == "selectedClusterHeatMaps") {
                        this._clusterHeatMaps(clusterNode);
                        // topic.publish("clearClusters");
                        // this.emit("load-data", null);
                        topic.publish("nc4ClusterIcons_RL");
                    }
                    else {
                        this._nc4Notify.error("Please select one heat map layer at a time.");
                    }
                }));
                topic.subscribe("/overlays/Edit", lang.hitch(this, function (clusterNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this.appUtils.currentOverlayEdit = clusterNode[0].item;
                    this._overlaysEdit(clusterNode);
                }));
                topic.subscribe("/cluster/ZoomTo", lang.hitch(this, function (clusterNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._clusterZoomTo(clusterNode);
                }));
                topic.subscribe("/cluster/settings", lang.hitch(this, function (clusterNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._clusterSettings(clusterNode);
                }));
                topic.subscribe("/delete/clicked", lang.hitch(this, function (deleteNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(deleteNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._deleteCustomLayer(deleteNode[0].item);
                }));
                topic.subscribe("/overlays/settings", lang.hitch(this, function (clusterNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._overlaysSettings(clusterNode);
                }));
                topic.subscribe("/customLayers/ZoomTo", lang.hitch(this, function (clusterNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._customLayersZoomTo(clusterNode);
                }));
                topic.subscribe("/overlays/ZoomTo", lang.hitch(this, function (clusterNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._overlaysZoomTo(clusterNode);
                }));
                topic.subscribe("/deleteOverlays/clicked", lang.hitch(this, function (deleteNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(deleteNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._deleteOverlaysLayer(deleteNode[0].item);
                }));
                topic.subscribe("/customLayers/settings", lang.hitch(this, function (clusterNode) {
                    var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var checkClassName = checkClassNode[0].labelNode.className;
                    var isItStrikedOut = checkClassName.indexOf("strikeout");
                    if (isItStrikedOut !== -1) {
                        return false;
                    }
                    this._customLayersSettings(clusterNode);
                }));
                topic.subscribe("checkParents", lang.hitch(this, function (Node) {
                    this.appUtils.log.debug("checkParents event published!");
                    this._checkParentNodes(Node[0], Node[1]);
                }));
                this._getDataTreeJSON();
                this._customLayerDeleteService = this.config.CustomLayerDeleteService;
                this._customLayerSaveService = this.config.CustomLayerSaveService;
                aspect.after(this.appUtils, "customLayerAdded", lang.hitch(this, function (layer) {              //attach add layer events to layers
                    this._dataLayerTreeStore.add(this.appUtils.customLayerCollection[0]);
                    this._doStrikeOutOperation();
                    this.appUtils.customLayerCollection = [];
                    // this.appUtils.refreshLegend(true);
                }));
                /*Below code for add custom base map and then pass map instance to all widgets*/
                if (this.appUtils.mapInstance) {
                    this.map = null;
                    this.map = this.appUtils.mapInstance;
                }
                /*This function will call after main function execution completes*/
                aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function () {
                    this.map = null;
                    this.map = this.appUtils.mapInstance;
                }));
                aspect.after(this.appUtils, "layerAddedOnBasemap", lang.hitch(this, function () {            //attach basemap gallery events to layer
                    //JT this is being called when wms sublayer is clicked..its attached to the update-end event ??
                    if (this.appUtils.boolBasemapChanged === true) {
                        this._doStrikeOutOperation();
                    }
                    // this.appUtils.refreshLegend(true);
                }));
                aspect.after(this.appUtils, "doneOverlayEditing", lang.hitch(this, function () {
                    this._overlaysDoneEditing();
                }));


            },
            //enalbe/disalbe navigation icon on newsfeed
            _enableDisableNavigation: function (checkNode, isChecked) {
                if (checkNode.url && checkNode.parent == "eteam" && globalConfig.isIncidentsLayer(checkNode.id.toLowerCase())) {

                    globalConfig.enableDisableNavigation(checkNode.id.toLowerCase(), isChecked);
                }
                else if (checkNode.id == "eteam") {
                    var childNodes = this._dataLayerTreeStore.query({
                        parent: checkNode.id
                    });

                    array.forEach(childNodes, lang.hitch(this, function (node, i) {
                        if (globalConfig.isIncidentsLayer(node.id.toLowerCase())){
                            globalConfig.enableDisableNavigation(node.id.toLowerCase(), isChecked);
                        }
                    }));
                }
            },
            /**
             * Function to execute checkbox clicked
             * @param {Object} checkNode - Object having detail of specific tree node, which is clicked.
             */
            _checkBoxClicked: function (checkNode) {

                if (checkNode[0].item.type) {
                    //if is a service with child nodes: (feature service/dynamic service/wms)
                    if (checkNode[0].item.type === "arcgis_map_service" || checkNode[0].item.type === "arcgis_dynamic_service" || checkNode[0].item.type === "wms"
                        || checkNode[0].item.type === "arcgis_cached_service") {
                        var objSave = dom.byId(checkNode[0].item.id + "_saveIcon");
                        var saveIcon = dom.byId(checkNode[0].item.id + "_saveRefreshLayer");
                        if (!objSave && !saveIcon) {
                            var childNode = this._dataLayerTreeStore.query({
                                parent: checkNode[0].item.id
                            });
                            if (childNode.length !== 0) {
                                /*if (this.config.CustomLayerSaveService) {
                                    var saveNode = html.create("div", {
                                        "id": checkNode[0].item.id + "_saveIcon"
                                    }, null);
                                    domClass.add(saveNode, "saveLayer");
                                    var treeNode = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                                    if (treeNode[0]) {
                                        domConstruct.place(saveNode, treeNode[0].labelNode, "last");
                                        on(saveNode, "click", lang.hitch(this, function(evt) {
                                            var checkClassNode = this._dataLayerTree.getNodesByItem(treeNode[0].item.id);
                                            var checkClassName = checkClassNode[0].labelNode.className;
                                            var isItStrikedOut = checkClassName.indexOf("strikeout");
                                            if (isItStrikedOut !== -1) {
                                                return false;
                                            }
                                            this._updateMapServer(treeNode);
                                        }));
                                    }
                                }*/
                            }
                        }
                        var parentNode = this._dataLayerTreeStore.query({
                            id: checkNode[0].item.parent
                        });
                        if (parentNode[0].type === "arcgis_map_service" || parentNode[0].type === "arcgis_dynamic_service" || parentNode[0].type === "wms") {
                            var objSaveNode = dom.byId(parentNode[0].id + "_saveIcon");
                            var saveIconNode = dom.byId(checkNode[0].item.id + "_saveRefreshLayer");
                            if (!objSaveNode && !saveIconNode) {
                                /*if (this.config.CustomLayerSaveService) {
                                    var savedNode = html.create("div", {
                                        "id": parentNode[0].id + "_saveIcon"
                                    }, null);
                                    domClass.add(savedNode, "saveLayer");
                                    var treeNodee = this._dataLayerTree.getNodesByItem(parentNode[0].id);
                                    if (treeNodee[0]) {
                                        domConstruct.place(savedNode, treeNodee[0].labelNode, "last");
                                        on(savedNode, "click", lang.hitch(this, function(evt) {
                                            var checkClassNode = this._dataLayerTree.getNodesByItem(treeNodee[0].item.id);
                                            var checkClassName = checkClassNode[0].labelNode.className;
                                            var isItStrikedOut = checkClassName.indexOf("strikeout");
                                            if (isItStrikedOut !== -1) {
                                                return false;
                                            }
                                            this._updateMapServer(treeNodee);
                                        }));
                                    }
                                }*/
                            }
                        }
                    }
                }
                var isChecked = false;
                this._shelter.show();
                if (checkNode[0].checkbox.className === "unchecked") {
                    domClass.remove(checkNode[0].checkbox, "unchecked");
                    domClass.add(checkNode[0].checkbox, "checked");
                    isChecked = true;
                } else if (checkNode[0].checkbox.className === "checked") {
                    domClass.remove(checkNode[0].checkbox, "checked");
                    domClass.add(checkNode[0].checkbox, "unchecked");
                    Popup.close(this._myTooltipDialog);
                    isChecked = false;
                } else {
                    domClass.remove(checkNode[0].checkbox, "partialChecked");
                    domClass.add(checkNode[0].checkbox, "checked");
                    isChecked = true;
                }

                //enalbe/disalbe navigation icon on newsfeed              
                this._enableDisableNavigation(checkNode[0].item, isChecked);
                this._checkHierarchicalNodes(checkNode[0].item, isChecked);

                if (checkNode[0].item.type === "featureService") { //06.05.2016 code may not be in use (arcgis_map_service is what we used to represetn a feature service)
                    checkNode[0].item.state = (checkNode[0].checkbox.className === "unchecked") ? 0 : 1;
                    this._appendSaveButtonToEtemLayers(checkNode);
                }

                this._updateindividualLayerServices(checkNode);

                //strikeouts should occur after this._updateinidividualLayerServices(checkNode); JT JAMES

                if (checkNode[0].item.type === "graphics") {
                    checkNode[0].item.state = (checkNode[0].checkbox.className === "unchecked") ? 0 : 1;
                    var objOverlay = dom.byId(checkNode[0].item.id + "_saveIcon");
                    if (objOverlay) {
                        domClass.remove(objOverlay, "saveRefreshLayerHide");
                        domClass.add(objOverlay, "saveLayer");
                    }
                }
                if (checkNode[0].item.type === "image") {
                    this._strikeOutOpereationOfImage(checkNode);
                }

                if (checkNode[0].item.type === "arcgis_cached_service")
                    this._performStrikeOutOnArcGISCachedService(checkNode[0].item);
            },

            /**
             * Function to add save button and update state of the custom layers.
             * @param {Object} checkNode - Object having detail of specific tree node, which is clicked.
             */
            _updateindividualLayerServices: function (checkNode) {
                if (checkNode[0].item.type) {
                    if (checkNode[0].item.type === "kml" || checkNode[0].item.type === "csv" ||
                        checkNode[0].item.type === "image" || checkNode[0].item.type === "georss" || checkNode[0].item.type === "arcgis_cached_service") {
                        var objSave = dom.byId(checkNode[0].item.id + "_saveIcon");
                        if (!objSave) {
                            checkNode[0].item.state = (checkNode[0].checkbox.className === "unchecked") ? 0 : 1;
                            var layerNode = this._dataLayerTreeStore.query({
                                id: checkNode[0].item.id
                            });
                            if (layerNode.length !== 0) {
                                /*if (this.config.CustomLayerSaveService) {
                                    var saveNodes = html.create("div", {
                                        "id": checkNode[0].item.id + "_saveIcon"
                                    }, null);
                                    domClass.add(saveNodes, "saveLayer");
                                    var treeNodes = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                                    if (treeNodes[0]) {
                                        domConstruct.place(saveNodes, treeNodes[0].labelNode, "last");
                                        on(saveNodes, "click", lang.hitch(this, function(evt) {
                                            var checkClassNode = this._dataLayerTree.getNodesByItem(treeNodes[0].item.id);
                                            var checkClassName = checkClassNode[0].labelNode.className;
                                            var isItStrikedOut = checkClassName.indexOf("strikeout");
                                            if (isItStrikedOut !== -1) {
                                                return false;
                                            }
                                            this._saveCount = 0;
                                            this._getSaveItems(evt, checkNode);
                                        }));
                                    }
                                }*/
                            }
                        }


                    }
                }
            },

            /**
             * Function to add save button and update state of the eteam layers.
             * @param {Object} checkNode - Object having detail of specific tree node, which is clicked.
             */
            _appendSaveButtonToEtemLayers: function (checkNode) {
                var objSave = dom.byId(checkNode[0].item.id + "_saveIcon");
                var saveIcon = dom.byId(checkNode[0].item.id + "_saveRefreshLayer");
                var treeNode = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                var saveNode;
                if (saveIcon) {
                    if (saveIcon.className === "saveRefreshLayer") {
                        saveNode = domConstruct.create("div", {
                            "id": checkNode[0].item.id + "saveRefreshLayerHide"
                        });
                        domClass.add(saveNode, "saveRefreshLayerHide");
                        domConstruct.place(saveNode, treeNode[0].labelNode.id);
                        return false;
                    }
                } else if (!objSave) {
                    /*if (this.config.CustomLayerSaveService) {
                        saveNode = html.create("div", {
                            "id": checkNode[0].item.id + "_saveIcon"
                        }, null);
                        domClass.add(saveNode, "saveLayer");
                        if (treeNode[0]) {
                            domConstruct.place(saveNode, treeNode[0].labelNode, "last");
                            on(saveNode, "click", lang.hitch(this, function(evt) {
                                var checkClassNode = this._dataLayerTree.getNodesByItem(treeNode[0].item.id);
                                var checkClassName = checkClassNode[0].labelNode.className;
                                var isItStrikedOut = checkClassName.indexOf("strikeout");
                                if (isItStrikedOut !== -1) {
                                    return false;
                                }
                                if (treeNode) {
                                    this._saveCount = 0;
                                    this._getBussinessSaveItems(evt, treeNode);
                                }
                            }));
                        }
                    }*/
                }
            },

            /**
             * Function to execute cluster clicked
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _clusterClicked: function (clusterNode) {

                if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                    this._nc4Notify.warn(sharedNls.DataLayer.turnOnLayer);
                    return false;
                }
                var isCluster = false;
                this._shelter.show();
                if (clusterNode[0].cluster.className === "decluster") {
                    domClass.remove(clusterNode[0].cluster, "decluster");
                    domClass.add(clusterNode[0].cluster, "cluster");
                    isCluster = true;
                } else if (clusterNode[0].cluster.className === "cluster") {
                    domClass.remove(clusterNode[0].cluster, "cluster");
                    domClass.add(clusterNode[0].cluster, "decluster");
                    isCluster = false;
                }
                var heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterHeatMapIcon");
                if (heatmapIcon.className === "selectedClusterHeatMaps") {
                    domClass.remove(heatmapIcon, "selectedClusterHeatMaps");
                    domClass.add(heatmapIcon, "clusterHeatMaps");
                }
                if (this.map.getLayer(clusterNode[0].item.id + "_heatlayer")) {
                    this.map.removeLayer(this.map.getLayer(clusterNode[0].item.id + "_heatlayer"));
                }
                var clusterDetail = [{
                    "clusterDetail": clusterNode[0].item,
                    "isClustered": isCluster
                }];
                var loadCluster = this._manageCluster(clusterDetail);                                   //james this seems to be the code that turns on biz layer
                loadCluster.then(lang.hitch(this, function () {
                    // this.appUtils.refreshLegend(true);
                    this._shelter.hide();
                }));
            },

            /**
             * Function to execute save clicked
             * @param {Object} saveNode - Object having detail of specific tree node, which is clicked.
             */
            _saveClicked: function (saveNode) {
                var layerType = null,
                    imageBounds = 0,
                    imageHeight = 0,
                    imageWidth = 0,
                    isCached = 0;
                if (saveNode[0].item.type === "wms") {
                    var wmsChildNodes = this.map.getLayer(saveNode[0].item.id + "_layer");
                    sublayers = wmsChildNodes.visibleLayers;
                }
                if (saveNode[0].item.type === "arcgis_map_service") {
                    layerType = "arcgis_map_service";
                    var objLayer = this.map.getLayer(saveNode[0].save.id);
                    if (!objLayer) {
                        var sublayers = [];
                        var childNode = this._dataLayerTreeStore.query({
                            parent: saveNode[0].item.id
                        });
                        for (var j = 0; j < childNode.length; j++) {
                            var objChild = this.map.getLayer(childNode[j].id + "_layer");
                            if (objChild) {
                                sublayers.push(childNode[j].name);
                            }
                        }
                    }
                } else if (saveNode[0].item.type === "arcgis_cached_service") {
                    layerType = "arcgis_cached_service";
                    isCached = 1;
                } else {
                    layerType = saveNode[0].item.type;
                }
                this._saveElement = null;
                this._saveElement = saveNode[0].save.id;
                if (saveNode[0].item.type === "image") {
                    //imageBounds = saveNode[0].item.saveBounds ;
                    imageBounds = saveNode[0].item.imgBounds.xmin.toFixed(3) + "," + saveNode[0].item.imgBounds.ymin.toFixed(3) + "," + saveNode[0].item.imgBounds.xmax.toFixed(3) + "," + saveNode[0].item.imgBounds.ymax.toFixed(3);

                    imageHeight = saveNode[0].item.imgHeight;
                    imageWidth = saveNode[0].item.imgWidth;
                }
                var jsonSave = [{
                    "layer_name": saveNode[0].item.name,
                    "layer_type": layerType,
                    "url": saveNode[0].item.url,
                    "opacity": saveNode[0].item.opacity,
                    "refresh": saveNode[0].item.refresh,
                    "sr": saveNode[0].item.sr,
                    "image_width": imageWidth.toString(),
                    "image_height": imageHeight.toString(),
                    "imageBounds": imageBounds.toString(),
                    "tileSizeH": "100",
                    "tileSizeW": "100",
                    "is_baseMap": "0",
                    "is_cached": isCached.toString(),
                    "tileFormat": "png",
                    "sub-layers": sublayers
                }];
                var objJson = JSON.stringify(jsonSave);
                console.info("wms json to save: ", jsonSave);
                esriRequest({
                    url: this.config.CustomLayerSaveService,
                    content: lang.mixin({
                        customLayers: objJson
                    }, null),
                    callbackParamName: "callback",
                    load: lang.hitch(this, function (response) {
                        if (response.results.length !== 0) {
                            this.appUtils.customLayerCount--;
                            this._nc4Notify.success(sharedNls.DataLayer.saveLayer);
                            domConstruct.destroy(this._saveElement);
                        }
                    }),
                    error: lang.hitch(this, function (err) {
                        this._nc4Notify.error(sharedNls.DataLayer.unableToSave);
                    })
                });
            },

            /**
             * Function to execute cluster heatmaps
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _clusterHeatMaps: function (clusterNode) {

                //this._shelter.show();
                //this._arrSelectedLayers = [];
                //var objLayer, heatmapIcon;
                //if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                //    heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterHeatMapIcon");
                //    if (heatmapIcon) {
                //        if (heatmapIcon.className === "clusterHeatMaps") {
                //            domClass.remove(heatmapIcon, "clusterHeatMaps");
                //            domClass.add(heatmapIcon, "selectedClusterHeatMaps");
                //        } else {
                //            domClass.remove(heatmapIcon, "selectedClusterHeatMaps");
                //            domClass.add(heatmapIcon, "clusterHeatMaps");
                //        }
                //    }
                //    this._shelter.hide();
                //}
                //heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterHeatMapIcon");
                //if (heatmapIcon) {
                //    var objTree;
                //    //Get all selected layer list
                //    objTree = this._dataLayerTreeStore.query({
                //        parent: clusterNode[0].item.id
                //    });
                //    if (objTree.length === 0) {
                //        objTree = this._dataLayerTreeStore.query({
                //            id: clusterNode[0].item.id
                //        });
                //    }
                //    if (heatmapIcon.className === "clusterHeatMaps") {
                //        array.forEach(objTree, lang.hitch(this, function (layer) {
                //            var objParent = this._dataLayerTreeStore.query({
                //                id: layer.id
                //            });
                //            if (objParent[0]) {
                //                array.forEach(objParent, lang.hitch(this, function (childLayer) {
                //                    var objLayer = this.map.getLayer(childLayer.id + "_cluster");
                //                    if (objLayer) {
                //                        domClass.remove(childLayer, "cluster");
                //                        domClass.add(childLayer, "decluster");
                //                        this._arrSelectedLayers.push(childLayer.id);
                //                    }
                //                }));

                //            } else {
                //                var objLayer = this.map.getLayer(layer.id + "_cluster");
                //                if (objLayer) {
                //                    domClass.remove(objLayer, "cluster");
                //                    domClass.add(objLayer, "decluster");
                //                    this._arrSelectedLayers.push(layer.id);
                //                }
                //            }
                //        }));
                //        if (this._arrSelectedLayers.length !== 0) {
                //            array.forEach(this._arrSelectedLayers, lang.hitch(this, function (id) {
                //                var layerId = id.replace("_cluster", "");
                //                var clusterNode = this._dataLayerTreeStore.query({
                //                    id: layerId
                //                });
                //                if (clusterNode[0]) {
                //                    var heatmapFeatureLayer = new FeatureLayer(clusterNode[0].url, {
                //                        outFields: ["*"],
                //                        mode: FeatureLayer.MODE_SNAPSHOT,
                //                        infoTemplate: new InfoTemplate("Attributes", clusterNode[0].popupInfo),
                //                        id: clusterNode[0].id + "_heatlayer",
                //                        name: clusterNode[0].name
                //                    });
                //                    var colors = clusterNode[0].heatRamp;
                //                    var heatmapRenderer = null;
                //                    if (colors) {
                //                        heatmapRenderer = new HeatmapRenderer({
                //                            colors: colors
                //                        });
                //                    } else {
                //                        heatmapRenderer = new HeatmapRenderer();
                //                    }
                //                    heatmapFeatureLayer.setRenderer(heatmapRenderer);
                //                    this.map.addLayer(heatmapFeatureLayer);
                //                    domClass.remove(heatmapIcon, "clusterHeatMaps");
                //                    domClass.add(heatmapIcon, "selectedClusterHeatMaps");
                //                    // this.appUtils.refreshLegend(true);

                //                    objLayer = this.map.getLayer(clusterNode[0].id + "_cluster");
                //                    if (objLayer) {
                //                        this.map.removeLayer(objLayer);
                //                    }
                //                    // this.appUtils.refreshLegend(true);
                //                }
                //            }));
                //            this._shelter.hide();
                //        }
                //    } else {
                //        array.forEach(objTree, lang.hitch(this, function (layer) {
                //            var objParent = this._dataLayerTreeStore.query({
                //                id: layer.id
                //            });
                //            if (objParent[0]) {
                //                array.forEach(objParent, lang.hitch(this, function (childLayer) {
                //                    var objLayer = this.map.getLayer(childLayer.id + "_heatlayer");
                //                    if (objLayer) {
                //                        this.map.removeLayer(objLayer);
                //                        domClass.remove(heatmapIcon, "selectedClusterHeatMaps");
                //                        domClass.add(heatmapIcon, "clusterHeatMaps");
                //                        this.setIntervalForClusters(this.map, childLayer);
                //                        // this.appUtils.refreshLegend(true);
                //                        this._shelter.hide();
                //                    }
                //                }));
                //            } else {
                //                var objLayer = this.map.getLayer(layer.id + "_heatlayer");
                //                if (objLayer) {
                //                    this.map.removeLayer(objLayer);
                //                }
                //            }
                //        }));
                //    }
                //}
            },

            _overlaysDoneEditing: function () {

                try {
                    var clusterNode = this._dataLayerTreeStore.query({
                        id: this.appUtils.editOverlayLayerId
                    });

                    var heatmapIcon = dom.byId(clusterNode[0].id + "_toggleOverlayEditIcon");
                    domClass.add(heatmapIcon, "overlayEdit");
                    domClass.remove(heatmapIcon, "selectedOverlayEdit");
                    if (dom.byId("editFeaturesMainContainer")) {
                        domConstruct.destroy("editFeaturesMainContainer");
                    }

                    this.appUtils.editOverlayLayerId = null;
                    this.appUtils.overlayLayers = [clusterNode[0]];
                    this.appUtils.createOverlayMode(false);
                }
                catch (error) {
                    //do nothing, we only want to run this when the user edit the graphics from the draw widget.
                    // we don't want this to run when saving opacity/state/refresh
                }
            },

            /**
             * Function to execute overlays edits
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _overlaysEdit: function (clusterNode) {

                if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                    this._nc4Notify.warn(sharedNls.DataLayer.turnOnLayer);
                    return false;
                }
                var heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleOverlayEditIcon");
                if (!this.appUtils.iscreateOverlayMode) {
                    if (heatmapIcon.className === "overlayEdit") {
                        domClass.remove(heatmapIcon, "overlayEdit");
                        domClass.add(heatmapIcon, "selectedOverlayEdit");
                        this.appUtils.editOverlayLayerId = clusterNode[0].item.id;
                        this.lastEditedOverlayId = clusterNode[0].item.id;
                        this.appUtils.createOverlayMode(true);
                        this.appUtils.openWidget("Draw");
                        this._nc4Notify.info("Please use drawing tools to edit the overlay layer");
                        //alert(this.appUtils.editOverlayLayerId);
                        var saveIcon = dom.byId(this.appUtils.editOverlayLayerId + "_saveIcon");
                        if (saveIcon.className === "saveRefreshLayerHide") {
                            domClass.remove(saveIcon, "saveRefreshLayerHide");
                            domClass.add(saveIcon, "saveLayer");
                        }
                        var objLayer = this.map.getLayer("Drawing");
                        if (objLayer) {
                            this.map.removeLayer(objLayer);
                        }

                        //iterate through OTHER overlay layers and turn them off
                        if (this.appUtils.overlayLayers.length) {
                            for (var j = 0; j < this.appUtils.overlayLayers.length; j++) {
                                if (this.appUtils.editOverlayLayerId !== this.appUtils.overlayLayers[j].id) {
                                    this.map.removeLayer(this.map.getLayer(this.appUtils.overlayLayers[j].id + "_layer"));
                                    var checkNode = dom.byId(this.appUtils.overlayLayers[j].id + "_checkBox");
                                    if (checkNode) {
                                        if (checkNode.className === "checked") {
                                            domClass.remove(checkNode, "checked");
                                            domClass.remove(checkNode, "partialChecked");
                                            domClass.add(checkNode, "unchecked");
                                        }
                                    }
                                }
                            }
                        }
                    }

                } else {
                    domClass.add(heatmapIcon, "overlayEdit");
                    domClass.remove(heatmapIcon, "selectedOverlayEdit");
                    if (dom.byId("editFeaturesMainContainer")) {
                        domConstruct.destroy("editFeaturesMainContainer");
                    }

                    this.appUtils.editOverlayLayerId = null;
                    this.appUtils.overlayLayers = [clusterNode[0].item];
                    this.appUtils.createOverlayMode(false);
                }
                //this.appUtils.editOverlayLayerId = clusterNode[0].item.id;
            },

            /**
             * Function to execute cluster zoomTo
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _clusterZoomTo: function (clusterNode) {

                this.appUtils.log.debug("_clusterZoomTo: clusterNode: ", clusterNode);
                var objLayer;
                if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                    this._nc4Notify.warn(sharedNls.DataLayer.turnOnLayer);
                    return false;
                }
                this._shelter.show();
                //var clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
                objLayer = this.map.getLayer(clusterNode[0].item.id + "_cluster");
                //zoomExtent = this.map.getLayer(objLayer.id);
                if (objLayer) {
                    var queryParam = new EsriQuery();
                    queryParam.where = "1=1";
                    queryParam.returnGeometry = true;
                    queryParam.outFields = ["*"];
                    var queryTask = new EsriQueryTask(objLayer.url);
                    queryTask.execute(queryParam, lang.hitch(this, function (response) {
                        if (response.features.length !== 0) {
                            var myFeatureExtent = graphicsUtils.graphicsExtent(response.features);
                            this.map.setExtent(myFeatureExtent.expand(2));
                        }
                        this._shelter.hide();
                    }), lang.hitch(this, function (error) {
                        this.log.error(error);
                        this._shelter.hide();

                    }));
                }
                this._shelter.hide();
            },

            /**
             * Function to execute cluster settings
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _clusterSettings: function (clusterNode) {
                if (this.customSettingsShown == true)
                    return;
                this.customSettingsShown = true;

                this._saveCount = 0;
                if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                    this._nc4Notify.warn(sharedNls.DataLayer.turnOnLayer);
                    this.customSettingsShown = false;
                    return false;
                }
                var heatmapIconInChild = dom.byId(clusterNode[0].item.id + "_toggleClusterHeatMapIcon");
                var heatmapIconInParent = dom.byId(clusterNode[0].item.parent + "_toggleClusterHeatMapIcon");
                if (heatmapIconInChild && heatmapIconInChild.className === "selectedClusterHeatMaps" ||
                    heatmapIconInParent && heatmapIconInParent.className === "selectedClusterHeatMaps") {
                    this._nc4Notify.error(sharedNls.DataLayer.notChangeOpacityRefresh);
                } else {
                    var domContentDynamic = domConstruct.create("div", {
                        "class": "MainContainerDiv"
                    }, null);

                    var allSubLayers = domConstruct.create("div", {
                        "id": "allClusterSubLayers"
                    }, domContentDynamic);

                    //***JT adding 'sub layer support for biz layers:  create html list and default checks
                    //***************************************************************//
                    if (clusterNode[0].item.subLayerson) //alSubLyrs will represent a list of availabe sub layers, provided from the layertree service
                    {
                        //need to store list of availabe layers in attributes
                        dojo.place("<br/><label>Layers: <br/></label>", allSubLayers, "first");

                        var objLayer = this.map.getLayer(clusterNode[0].item.id + "_cluster");
                        var allSubLyrs = clusterNode[0].item.subLayerson.split(",");
                        var visibleLayers = [];
                        if (clusterNode[0].item.visibleLayers) {
                            visibleLayers = clusterNode[0].item.visibleLayers || [];			//maintain visible layers
                        }
                        else {
                            //visibleLayers not defined, must be first load so turn everything on:
                            visibleLayers = allSubLyrs;
                        }


                        for (var i = 0; i < allSubLyrs.length; i++) {
                            var currSubLyr = allSubLyrs[i];
                            if (currSubLyr == "")
                                continue;
                            var checked = "";
                            if (visibleLayers.indexOf(currSubLyr) >= 0)
                                checked = "CHECKED";

                            dojo.place("<input type='checkbox' class='chkboxClusterSubLyrs' name='" + currSubLyr + "' id='" + currSubLyr + "'value='" + currSubLyr + "' " + checked + ">" + currSubLyr + "<br/>", allSubLayers, "after");

                        }
                        dojo.place("<br/>", allSubLayers, "after");

                    }
                    //******************END Sub layers html

                    var editPanelSpan = domConstruct.create("div", {
                        "class": "labelRefreshContainer"
                    }, domContentDynamic);
                    editPanelSpan.innerHTML = "Refresh Rate : ";
                    var editPanel = domConstruct.create("div", {
                        "class": "TextboxContainer"
                    }, domContentDynamic);
                    var editPanelTextbox = domConstruct.create("div", {}, editPanel);

                    var myTextBox = new ValidationTextBox({
                        name: "Title",
                        value: clusterNode[0].item.refresh > 0 ? clusterNode[0].item.refresh : this.appUtils.configGeneralSettings.defaultRefRate,      //TODO: James default refresh value
                        size: "15",
                        "regExp": "^[0-9]*$",
                        "invalidMessage": "Please enter valid number"
                    });

                    domConstruct.place(myTextBox.domNode, editPanelTextbox);
                    var opacitySpan = domConstruct.create("div", {
                        "class": "fillSliderOpacity"
                    }, domContentDynamic);

                    this._opacitySpanSlider = domConstruct.create("div", {
                        "id": "fillSliderValue"
                    }, opacitySpan);
                    this._opacitySpanSlider.innerHTML = "Opacity : " +
                        Math.round(clusterNode[0].item.opacity > 0 ? clusterNode[0].item.opacity : this.appUtils.configGeneralSettings.defaultOpacity) + "%";   //TODO: value for opacity
                    var domContentForSlider = domConstruct.create("div", {
                        "class": "fillOpacitySlider"
                    }, domContentDynamic);
                    var domContentForSliderright = domConstruct.create("div", {}, domContentForSlider);

                    var sliderForColor = new HorizontalSlider({
                        name: "slider",
                        minimum: 1,
                        maximum: 100,
                        value: Math.round(clusterNode[0].item.opacity > 0 ? clusterNode[0].item.opacity : this.appUtils.configGeneralSettings.defaultOpacity),
                        intermediateChanges: true,
                        onChange: lang.hitch(this, function (value) {
                            var currentOpacityValue,
                                objLayer,
                                opacityValue;
                            // this._getOpacityValue = Math.round(value);
                            this._changedOpacityValue = value;
                            opacityValue = this._changedOpacityValue;
                            this._opacitySpanSlider.innerHTML = "Opacity : " + Math.round(value) + " %";
                            
                            //clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
                            //if (clusterIcon.className === "cluster") {
                            objLayer = this.map.getLayer(clusterNode[0].item.id + "_cluster");
                            //} else {
                            //objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                            //}
                            currentOpacityValue = objLayer.opacity;
                            if (opacityValue) {
                                var setOpacityValue = opacityValue / 100;
                                objLayer.setOpacity(setOpacityValue);
                            }
                        })
                    });

                    domConstruct.place(sliderForColor.domNode, domContentForSliderright);
                    var btnSave = new Button({
                        label: "OK",
                        "class": "btnPopUp"
                    });
                    domConstruct.place(btnSave.domNode, domContentDynamic);
                    /*
                    var btnCancel = new Button({
                        label: "Cancel",
                        "class": "btnPopUp"
                    });
                    domConstruct.place(btnCancel.domNode, domContentDynamic);
                    
                    btnCancel.on("click", lang.hitch(this, function(event){
                        try
                        {
                            this._nc4Notify.hide(this._dataLayerSettingInfo);
                            Popup.close(this._myTooltipDialog);
                            this._dataLayerSettingInfo = null;
                        }catch(error){}
                    }));
                    */
                    btnSave.on("click", lang.hitch(this, function (event) {

                        //** adding sub layer support
                        //refresh new data from the server, respecting list of sub layers
                        //check sub lyrs
                        var objLayer = this.map.getLayer(clusterNode[0].item.id + "_cluster") || this.map.getLayer(clusterNode[0].item.id + "_heatlayer") || null;
                        if (objLayer == null) {
                            Popup.close(this._myTooltipDialog);
                            this._nc4Notify.hide(this._dataLayerSettingInfo);
                            this._dataLayerSettingInfo = null;
                        }
                        if (clusterNode[0].item.subLayerson) {
                            //iterate through each sublayer checkbox and add those that are checked, to an array, then set visible layers.
                            var newVisibleNodes = dojoQuery(".chkboxClusterSubLyrs:checked");
                            var newVisibleLayers = [];
                            for (var i = 0; i < newVisibleNodes.length; i++) {
                                newVisibleLayers.push(newVisibleNodes[i].id);
                            }
                            clusterNode[0].item.visibleLayers = newVisibleLayers;
                            objLayer._setVisibleLyrs(newVisibleLayers); //maintain visible layers
                            objLayer._filter();

                            //clusterNode[0].item["sub-layers"] = newVisibleLayers; 
                        }

                        //***end sub layers support

                        this.customSettingsShown = false;
                        var refreshRate,
                            opacityValue;
                        refreshRate = myTextBox.value;
                        opacityValue = this._changedOpacityValue;
                        if (opacityValue) {
                            clusterNode[0].item.opacity = opacityValue;
                        }
                        if (refreshRate) {
                            clusterNode[0].item.refresh = refreshRate;
                        }

                        if (!objLayer) {
                            this._nc4Notify.error(sharedNls.DataLayer.notAddedOnMap);
                            return false;
                        }
                        var currentRefreshValue = objLayer.refreshInterval;
                        if (currentRefreshValue !== refreshRate) {
                            this.setIntervalForClusters(this.map, clusterNode[0].item);
                        };
                        var currentOpacityValue = objLayer.opacity;
                        if (opacityValue) {
                            var setOpacityValue = opacityValue / 100;
                            objLayer.setOpacity(setOpacityValue);
                        }
                        objLayer.setRefreshInterval(refreshRate);
                        var parentNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                        var saveIcon = dom.byId(clusterNode[0].item.id + "_saveIcon");
                        if (saveIcon) {
                            var saveRefreshShow;
                            if (!dom.byId(clusterNode[0].item.id + "_saveRefreshLayer") || saveIcon.className === "saveLayer") {
                                saveRefreshShow = domConstruct.create("div", {
                                    "id": clusterNode[0].item.id + "_saveRefreshLayer"
                                });
                                domClass.add(saveRefreshShow, "saveRefreshLayerHide");
                            }
                        } else if (currentRefreshValue !== refreshRate || currentOpacityValue !== opacityValue) {
                            if (!dom.byId(clusterNode[0].item.id + "_saveIcon")) {
                                /*if (this.config.BussinessLayerUpdateService) {
                                    saveRefreshShow = domConstruct.create("div", {
                                        "id": clusterNode[0].item.id + "_saveIcon"
                                    });
                                    domClass.remove(saveRefreshShow, "saveRefreshLayerHide");
                                    domClass.add(saveRefreshShow, "saveRefreshLayer");
                                    domConstruct.place(saveRefreshShow, parentNode[0].labelNode.id);
                                    on(saveRefreshShow, "click", lang.hitch(this, function(evt) {
                                        this._getBussinessSaveItems(evt, clusterNode);
                                    }));
                                }*/
                            }
                        }
                        Popup.close(this._myTooltipDialog);
                        this.map.infoWindow.hide();
                        this._nc4Notify.hide(this._dataLayerSettingInfo);
                        this._dataLayerSettingInfo = null;
                    }));
                    var options = {
                        "showMethod": "slideDown",
                        "hideMethod": "slideUp",
                        "closeMethod": "slideUp",
                        "preventDuplicates": true,
                        "timeOut": 0,
                        "extendedTimeOut": 0,
                        "progressBar": false,
                        "onclick": null,
                        "positionClass": "toast-bottom-right",
                        "tapToDismiss": false
                    };
                    this._dataLayerSettingInfo = this._nc4Notify.message(domContentDynamic, options);
                }
            },

            /**
             * Function to execute customLayers zoomTo
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _customLayersZoomTo: function (clusterNode) {
                var layerImages,
                    objLayer,
                    zoomExtent;
                if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                    this._nc4Notify.warn(sharedNls.DataLayer.turnOnLayer);
                    return false;
                }
                objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                if (objLayer === undefined) {
                    this._nc4Notify.warn(sharedNls.DataLayer.extentNotFound);
                    return false;
                }
                if (objLayer.customLayerType === "kml") {
                    //zoomExtent = this.map.getLayer(objLayer.id + "_1");   //this implementation just wont work
                    //this._setZoomToExtentForCustomLayer(zoomExtent);
                    //below is more accurate for kml:
                    var layers = objLayer.getLayers();
                    var allGraphics = [];
                    for (var i = 0; i < layers.length; i++) {
                        var lyr = layers[i];
                        if (lyr.graphics && lyr.graphics.length > 0)
                            allGraphics = allGraphics.concat(lyr.graphics);
                    }

                    if (allGraphics.length > 0) {
                        var kmlExtent = graphicsUtils.graphicsExtent(allGraphics);

                        var layer = this.map.getLayer(this.map.layerIds[0]);
                        var baseMapExtent = layer.fullExtent;

                        if (baseMapExtent.contains(kmlExtent))
                            this.map.setExtent(kmlExtent);
                        else
                            this.map.setExtent(baseMapExtent);
                    }
                } else if (objLayer.customLayerType === "image") {
                    layerImages = objLayer.getImages();
                    (layerImages) ? this.map.setExtent(layerImages[0].extent) : this._nc4Notify.warn(sharedNls.DataLayer.extentNotFound); //jshint ignore:line
                } else {
                    this._setZoomToExtentForCustomLayer(objLayer);
                }
            },

            /**
             * Function to execute cluster settings
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _overlaysSettings: function (clusterNode) {

                //prevent content to show if other settings box is already displaying:
                if (this.customSettingsShown == true)
                    return;

                this.customSettingsShown = true;


                this._saveCount = 0;
                if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                    this._nc4Notify.warn(sharedNls.DataLayer.turnOnLayer);
                    this.customSettingsShown = false;
                    return false;
                }
                var domContentDynamic = domConstruct.create("div", {
                    "class": "MainContainerDiv"
                }, null);
                var editPanelSpan = domConstruct.create("div", {
                    "class": "labelRefreshContainer"
                }, domContentDynamic);
                editPanelSpan.innerHTML = "Refresh Rate : ";
                var editPanel = domConstruct.create("div", {
                    "class": "TextboxContainer"
                }, domContentDynamic);
                var editPanelTextbox = domConstruct.create("div", {}, editPanel);
                var myTextBox = new ValidationTextBox({
                    name: "Title",
                    value: clusterNode[0].item.refresh > 0 ? clusterNode[0].item.refresh : this.appUtils.configGeneralSettings.defaultRefRate,
                    size: "15",
                    "regExp": "^[0-9]*$",
                    "invalidMessage": "Please enter valid number"
                });
                domConstruct.place(myTextBox.domNode, editPanelTextbox);
                var opacitySpan = domConstruct.create("div", {
                    "class": "fillSliderOpacity"
                }, domContentDynamic);
                this._opacitySpanSlider = domConstruct.create("div", {
                    "id": "fillSliderValue"
                }, opacitySpan);
                this._opacitySpanSlider.innerHTML = "Opacity : " +
                    Math.round(clusterNode[0].item.opacity > 0 ? clusterNode[0].item.opacity : this.appUtils.configGeneralSettings.defaultOpacity) + "%";
                var domContentForSlider = domConstruct.create("div", {
                    "class": "fillOpacitySlider"
                }, domContentDynamic);
                var domContentForSliderright = domConstruct.create("div", {}, domContentForSlider);
                var sliderForColor = new HorizontalSlider({
                    name: "slider",
                    minimum: 1,
                    maximum: 100,
                    value: Math.round(clusterNode[0].item.opacity > 0 ? clusterNode[0].item.opacity : this.appUtils.configGeneralSettings.defaultOpacity),
                    intermediateChanges: true,
                    onChange: lang.hitch(this, function (value) {
                        var currentOpacityValue,
                            objLayer,
                            opacityValue;
                        // this._getOpacityValue = Math.round(value);
                        this._changedOpacityValue = value;
                        opacityValue = this._changedOpacityValue;
                        this._opacitySpanSlider.innerHTML = "Opacity : " + Math.round(value) + " %";
                        
                        objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                        if (objLayer) {
                            currentOpacityValue = objLayer.opacity;
                            if (opacityValue) {
                                var setOpacityValue = opacityValue / 100;
                                objLayer.setOpacity(setOpacityValue);
                            }
                        }
                    })
                });
                domConstruct.place(sliderForColor.domNode, domContentForSliderright);
                var btnSave = new Button({
                    label: "OK",
                    "class": "btnPopUp"
                });
                domConstruct.place(btnSave.domNode, domContentDynamic);
                btnSave.on("click", lang.hitch(this, function (event) {
                    this.customSettingsShown = false;
                    var objLayer,
                        refreshRate,
                        opacityValue;
                    refreshRate = myTextBox.value;
                    opacityValue = this._changedOpacityValue;
                    if (opacityValue) {
                        clusterNode[0].item.opacity = opacityValue;
                    }
                    if (refreshRate) {
                        clusterNode[0].item.refresh = refreshRate;
                    }
                    //        var clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterHeatMapIcon");
                    objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                    if (objLayer) {
                        var currentRefreshValue = objLayer.refreshInterval;
                        var currentOpacityValue = objLayer.opacity;
                        if (opacityValue) {
                            var setOpacityValue = opacityValue / 100;
                            objLayer.setOpacity(setOpacityValue);
                        }
                        objLayer.setRefreshInterval(refreshRate);
                    }
                    if (currentRefreshValue !== refreshRate) {
                        this.setIntervalForOverlays(clusterNode[0].item);
                    }
                    //  var parentNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    if (currentRefreshValue !== refreshRate || currentOpacityValue !== opacityValue) {
                        var saveIcon = dom.byId(clusterNode[0].item.id + "_saveIcon");
                        if (this.config.OverlayUpdateService) {
                            if (saveIcon.className === "saveRefreshLayerHide") {
                                domClass.remove(saveIcon, "saveRefreshLayerHide");
                                domClass.add(saveIcon, "saveLayer");
                            }
                        }
                    }
                    this._nc4Notify.hide(this._dataLayerSettingInfo);
                    this._dataLayerSettingInfo = null;
                }));

                var options = {
                    "showMethod": "slideDown",
                    "hideMethod": "slideUp",
                    "closeMethod": "slideUp",
                    "preventDuplicates": true,
                    "timeOut": 0,
                    "extendedTimeOut": 0,
                    "progressBar": false,
                    "onclick": null,
                    "positionClass": "toast-bottom-right",
                    "tapToDismiss": false
                };
                this._dataLayerSettingInfo = this._nc4Notify.message(domContentDynamic, options);
                //    }
            },

            /**
             * Function to update overly items.
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _updateOverlayServices: function (clusterNode) {
                var id = (this.appUtils.editOverlayLayerId) ? this.appUtils.editOverlayLayerId : clusterNode[0].item.id;
                //var dLayer = new DrawingLayer(this.map, this.appUtils, this._shelter, this.config, this._nc4Notify, null, null);
                clusterNode[0].item.fromWidget = "dataLayers";
                //dLayer.update(clusterNode[0].item, id);

                //TODO subscribe to event?
                var saveIcon = dom.byId(clusterNode[0].item.id + "_saveIcon");
                var heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleOverlayEditIcon");
                if (heatmapIcon.className === "selectedOverlayEdit") {
                    domClass.add(heatmapIcon, "overlayEdit");
                    domClass.remove(heatmapIcon, "selectedOverlayEdit");
                }
                if (saveIcon) {
                    domClass.remove(saveIcon, "saveLayer");
                    domClass.add(saveIcon, "saveRefreshLayerHide");
                }
            },

            /**
             * Function to execute overlays zoomTo.
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _overlaysZoomTo: function (clusterNode) {
                var objLayer,
                    zoomExtent;
                if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                    this._nc4Notify.warn(sharedNls.DataLayer.turnOnLayer);
                    return false;
                }
                objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                if (objLayer) {
                    zoomExtent = this.map.getLayer(objLayer.id);
                    var myFeatureExtent = graphicsUtils.graphicsExtent(zoomExtent.graphics);
                    this.map.setExtent(myFeatureExtent.expand(2));
                }
            },

            /**
             * Function to delete overlays layers.
             * @param {Object} layerIds - Parent id.
             */
            _deleteOverlaysLayer: function (layerIds) {
                if (layerIds.parent) {
                    if (layerIds.parent === "nc4maps_overlays") {
                        var deletePromtMessage = this._alertBox.confirm("Click OK to delete layer.");
                        deletePromtMessage.then(lang.hitch(this, function (res) {
                            esriRequest({
                                url: this.config.OverlayDeleteService,
                                content: lang.mixin({
                                    id: layerIds.id,
                                    f: "jsonp"
                                }, null),
                                callbackParamName: "callback",
                                load: lang.hitch(this, function () {
                                    if (this.map.getLayer(layerIds.id + "_layer")) {
                                        this.map.removeLayer(this.map.getLayer(layerIds.id + "_layer"));
                                    } else {

                                        var childNodes = this._dataLayerTreeStore.query({
                                            parent: layerIds.id
                                        });
                                        array.forEach(childNodes, lang.hitch(this, function (node) {
                                            if (node.url) {
                                                var childLayer = this.map.getLayer(node.id + "_layer");
                                                if (childLayer) {
                                                    this.map.removeLayer(childLayer);
                                                }
                                            }
                                        }));

                                    }
                                    this._nc4Notify.success("Layer deleted successfully");
                                    this.appUtils.createOverlayMode(false);
                                    this._dataLayerTreeStore.remove(layerIds.id);
                                }),
                                error: lang.hitch(this, function (err) {
                                    this._nc4Notify.error(err);
                                })
                            });
                        }));
                    }
                }
            },

            /**
             * Function to set zoom to extent of custom layers.
             * @param {Object} objLayer - layerObject.
             */
            _setZoomToExtentForCustomLayer: function (objLayer) {
                if (objLayer.fullExtent) {
                    this.map.setExtent(objLayer.fullExtent);
                } else if (objLayer.initialExtent) {
                    this.map.setExtent(objLayer.initialExtent);
                } else {
                    this._nc4Notify.warn(sharedNls.DataLayer.extentNotFound);
                }
            },

            /**
             * Function to execute customLayers settings
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */
            _customLayersSettings: function (clusterNode) {

                //prevent content to show if other settings box is already displaying:
                if (this.customSettingsShown == true)
                    return;

                this.customSettingsShown = true;

                this._saveCount = 0;
                if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                    this._nc4Notify.warn(sharedNls.DataLayer.turnOnLayer);
                    this.customSettingsShown = false;
                    return false;
                }
                var domContentDynamic = domConstruct.create("div", {
                    //"class": "MainContainer"
                }, null);

                //var refreshVisible = clusterNode[0].item.editRefreshDisabled ? 'none' : 'block';
                var refreshVisible = 'none';//hide refresh rate: in setting popup
                var editPanelSpan = domConstruct.create("div", {
                    "class": "labelRefreshContainer",
                    style: {
                        display: refreshVisible
                    }
                }, domContentDynamic);
                editPanelSpan.innerHTML = "Refresh Rate : ";
                var editPanel = domConstruct.create("div", {
                    "class": "TextboxContainer",
                    style: {
                        display: refreshVisible
                    }
                }, domContentDynamic);
                var editPanelTextbox = domConstruct.create("div", {}, editPanel);
                var myTextBox = new ValidationTextBox({
                    name: "Title",
                    value: clusterNode[0].item.refresh, //james - this has error handling in the addlayers widget
                    size: "15",
                    "regExp": "^[0-9]*$",
                    "invalidMessage": "Please enter valid number"
                });
                domConstruct.place(myTextBox.domNode, editPanelTextbox);
                var opacitySpan = domConstruct.create("div", {
                    "class": "fillSliderOpacity"
                }, domContentDynamic);
                this._opacitySpanSlider = domConstruct.create("div", {
                    "id": "fillSliderValue"
                }, opacitySpan);
                this._opacitySpanSlider.innerHTML = "Opacity : " +
                    Math.round(clusterNode[0].item.opacity * 100) + "%"; //james - opacity was divided by 100 in addlayers widget
                var domContentForSlider = domConstruct.create("div", {
                    "class": "fillOpacitySlider"
                }, domContentDynamic);
                var domContentForSliderright = domConstruct.create("div", {}, domContentForSlider);
                var sliderForColor = new HorizontalSlider({
                    name: "slider",
                    minimum: 1,
                    maximum: 100,
                    value: Math.round(clusterNode[0].item.opacity * 100),
                    intermediateChanges: true,
                    onChange: lang.hitch(this, function (value) {
                        var clusterIcon;
                        this._changedOpacityValue = value;
                        this._opacitySpanSlider.innerHTML = "Opacity : " + Math.round(value);
                        var opacityValue = this._changedOpacityValue;
                        clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
                        var objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");

                        /*support for arcgis_dynamic_service*/
                        if (objLayer == null)
                            objLayer = this.map.getLayer(clusterNode[0].item.id);

                        if (clusterNode[0].item.type === "arcgis_map_service" && (clusterNode[0].item.url.indexOf("MapServer/") === -1) && (clusterNode[0].item.url.indexOf("FeatureServer/") === -1)) {
                            //only for feature service: sub layers for feature service are actual individaul feature layer objects
                            var childNodes = this._dataLayerTreeStore.query({
                                parent: clusterNode[0].item.id
                            });
                            array.forEach(childNodes, lang.hitch(this, function (node) {
                                if (node.url) {
                                    var childLayer = this.map.getLayer(node.id + "_layer");
                                    if (childLayer) {
                                        if (opacityValue) {
                                            childLayer.setOpacity(opacityValue / 100);
                                        }
                                    }
                                }
                            }));
                        } else {
                            //|| clusterNode[0].item.type === "arcgis_dynamic_service") : since there is no 'child layer' object, dynamic service should be here:
                            if (!objLayer) {
                                this._shelter.hide();
                                return false;
                            }
                            //  var currentOpacityValue = objLayer.opacity;
                            if (opacityValue) {
                                var setOpacityValue = opacityValue / 100;
                                objLayer.setOpacity(setOpacityValue);
                            }
                        }
                    })
                });
                domConstruct.place(sliderForColor.domNode, domContentForSliderright);

                var allSubLayers = domConstruct.create("div", {
                    "id": "allSubLayers"
                }, domContentDynamic);


                if (clusterNode[0].item.allSubLyrs) {
                    dojo.place("<br/><label>Layers: <br/></label>", allSubLayers, "first");
                    var objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                    var visibleLayers = objLayer.visibleLayers || [];
                    for (var i = 0; i < clusterNode[0].item.allSubLyrs.length; i++) {
                        var currSubLyr = clusterNode[0].item.allSubLyrs[i].name;
                        var newCheckboxItem = "";

                        var checked = "";
                        if (visibleLayers.indexOf(currSubLyr) >= 0)
                            checked = "CHECKED";

                        dojo.place("<input type='checkbox' class='chkboxSubLyrs' name='" + currSubLyr + "' id='" + currSubLyr + "'value='" + currSubLyr + "' " + checked + ">" + currSubLyr + "<br/>", allSubLayers, "after");

                    }
                }


                // allSubLayers.innerHTML = clusterNode[0].item.allSubLyrs;

                var btnCustomLayerSave = new Button({
                    label: "OK",
                    "class": "btnPopUp"
                });
                domConstruct.place(btnCustomLayerSave.domNode, domContentDynamic);

                btnCustomLayerSave.on("click", lang.hitch(this, function (event) {
                    this.customSettingsShown = false;

                    var clusterIcon,
                        currentRefreshValue,
                        currentOpacityValue,
                        objLayer,
                        refreshRate,
                        opacityValue;

                    refreshRate = myTextBox.value;
                    opacityValue = this._changedOpacityValue;
                    if (opacityValue) {
                        clusterNode[0].item.opacity = opacityValue / 100;
                    }
                    if (refreshRate) {
                        clusterNode[0].item.refresh = refreshRate;
                    }
                    clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
                    objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                    if (objLayer == null)
                        objLayer = this.map.getLayer(clusterNode[0].item.id);   //some layers does not use _layer...eventually all will remove that

                    //canviz: add to prevent script error if some reason cause the layer failed to be add to map.
                    if (!objLayer) {
                        this._nc4Notify.hide(this._dataLayerSettingInfo);
                        console.log('layer "' + clusterNode[0].item.id + '(_layer)" was not found');
                        return;
                    }

                    //set opacity/refresh for child layers.  No need to do this for WMS since WMS is just one layer
                    //TODO look into doing the same for arcgis dynamic service that we are doing for WMS (really only one layer)
                    if ((clusterNode[0].item.type === "arcgis_map_service" || clusterNode[0].item.type === "arcgis_dynamic_service") && (clusterNode[0].item.url.indexOf("MapServer/") === -1) && (clusterNode[0].item.url.indexOf("FeatureServer/") === -1)) {
                        currentRefreshValue = objLayer.refreshInterval;
                        objLayer.setRefreshInterval(refreshRate);
                        var childNodes = this._dataLayerTreeStore.query({
                            parent: clusterNode[0].item.id
                        });
                        array.forEach(childNodes, lang.hitch(this, function (node) {
                            if (node.url) {
                                var childLayer = this.map.getLayer(node.id + "_layer");
                                if (childLayer) {
                                    if (opacityValue) {
                                        childLayer.setOpacity(opacityValue / 100);
                                    }
                                    childLayer.setRefreshInterval(refreshRate);
                                }
                            }
                        }));
                    } else {
                        if (!objLayer) {
                            this._nc4Notify.error(sharedNls.DataLayer.notAddedOnMap);
                            return false;
                        }
                        currentRefreshValue = objLayer.refreshInterval;
                        currentOpacityValue = objLayer.opacity;
                        if (opacityValue) {
                            var setOpacityValue = opacityValue / 100;
                            objLayer.setOpacity(setOpacityValue);
                        }
                        objLayer.setRefreshInterval(refreshRate);
                    }
                    var parentNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);

                    //add save icon to datalayer tree if differences occur
                    //TODO: seems like even if no differences, save icon still will appear.
                    var saveIcon = dom.byId(clusterNode[0].item.id + "_saveIcon");
                    if (!saveIcon) {
                        if (!dom.byId(clusterNode[0].item.id + "_saveRefreshLayer")) {

                            var saveRefreshHide = domConstruct.create("div", {
                                "id": clusterNode[0].item.id + "_saveRefreshLayer"
                            });
                            domClass.add(saveRefreshHide, "saveRefreshLayerHide");
                            domConstruct.place(saveRefreshHide, parentNode[0].labelNode.id);

                        }
                        if (currentRefreshValue !== refreshRate || currentOpacityValue !== opacityValue) {
                            /*var saveRefreshShow = dom.byId(clusterNode[0].item.id + "_saveRefreshLayer");
                            if (this.config.CustomLayerSaveService) {
                                domClass.remove(saveRefreshShow, "saveRefreshLayerHide");
                                domClass.add(saveRefreshShow, "saveRefreshLayer");
                                on(saveRefreshShow, "click", lang.hitch(this, function(evt) {
                                    this._getSaveItems(evt, clusterNode);
                                }));
                            }*/
                        }
                        this.appUtils.customLayerCount++;
                    }

                    //check sub lyrs
                    if (clusterNode[0].item.allSubLyrs) {
                        //iterate through each sublayer checkbox and add those that are checked, to an array, then set visible layers.
                        var newVisibleNodes = dojoQuery(".chkboxSubLyrs:checked");
                        var newVisibleLayers = [];
                        for (var i = 0; i < newVisibleNodes.length; i++) {
                            newVisibleLayers.push(newVisibleNodes[i].id);
                        }

                        objLayer.setVisibleLayers(newVisibleLayers);

                        ////this var gets used to keep track of what was last set to ON.  So when user turns off service and turns back on, we know what to set
                        //as the visible layer since we are destroying and re-creating the service.
                        clusterNode[0].item["sub-layers"] = newVisibleLayers;
                    }

                    this._nc4Notify.hide(this._dataLayerSettingInfo);
                    this._dataLayerSettingInfo = null;
                }));

                var options = {
                    "showMethod": "slideDown",
                    "hideMethod": "slideUp",
                    "closeMethod": "slideUp",
                    "preventDuplicates": true,
                    "timeOut": 0,
                    "extendedTimeOut": 0,
                    "progressBar": false,
                    "onclick": null,
                    "positionClass": "toast-bottom-right",
                    "tapToDismiss": false
                };
                this._dataLayerSettingInfo = this._nc4Notify.message(domContentDynamic, options);
            },

            /**
             * Function to add save button and update services with latest data of mapserver layer. (includes wms) //for wms.
             * @param {Object} saveNode - Object having detail of specific tree node, which is clicked.
             */
            _updateMapServer: function (saveNode) {
                this.appUtils.log.debug("datalayers: _updateMapServer, saveNode: ", saveNode);
                this.appUtils.log.debug("current map: ", this.map);
                if (saveNode[0].item.type === "arcgis_map_service" || saveNode[0].item.type === "arcgis_dynamic_service") {
                    var objLayer = this.map.getLayer(saveNode[0].item.id);
                    var sublayers = [];
                    if (objLayer) {
                        sublayers = objLayer.visibleLayers;

                    }
                }
                else if (saveNode[0].item.type === "wms") {
                    var sublayers = [];
                    var objLayer = this.map.getLayer(saveNode[0].item.id + "_layer");
                    if (objLayer) {
                        sublayers = objLayer.visibleLayers;
                    }
                }
                this.appUtils.log.debug("subLayers: ", sublayers);
                //else if wms, go straight to saving.  for wms
                var jsonSave = [{
                    "layer_name": saveNode[0].item.name,
                    "layer_type": saveNode[0].item.type,
                    "layer_id": saveNode[0].item.id,
                    "url": saveNode[0].item.url,
                    "opacity": saveNode[0].item.opacity,
                    "refresh": saveNode[0].item.refresh,
                    "sr": saveNode[0].item.sr,
                    "image_width": saveNode[0].item.imageWidth,
                    "image_height": saveNode[0].item.imageHeight,
                    "imageBounds": saveNode[0].item.imageBounds,
                    "tileSizeH": "100",
                    "tileSizeW": "100",
                    "is_baseMap": "0",
                    "is_cached": "0",
                    "tileFormat": "png",
                    "sub-layers": sublayers,
                    "state": saveNode[0].item.state
                }];
                var objJson = JSON.stringify(jsonSave);
                this._saveElement = null;
                this._saveElement = saveNode[0].item.id + "_saveIcon";
                esriRequest({
                    url: this.config.CustomLayerUpdateService,
                    content: lang.mixin({
                        customLayers: objJson
                    }, null),
                    callbackParamName: "callback",
                    load: lang.hitch(this, function (response) {
                        if (response.success === true) {
                            this._nc4Notify.success(sharedNls.DataLayer.saveLayer);
                            domConstruct.destroy(this._saveElement);
                        } else {
                            this._nc4Notify.error(sharedNls.DataLayer.unableToSave);
                            this._saveCount++;
                        }
                    }),
                    error: lang.hitch(this, function (err) {
                        this._nc4Notify.error(err);
                    })
                });
            },

            /**
             * Function to save and update the opacity of eteam layers.
             * @param {Object} evt - evt.
             * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
             */

            //TODO JT: Need to remove reference to 'eteam' and use more generic term like 'bizGroup'
            _getBussinessSaveItems: function (evt, clusterNode) {
                this._saveCount = 0;
                var jsonSave,
                    objJson,
                    reportType,
                    saveRefreshShow,
                    subReportType;
                if (clusterNode[0].item.parent === "eteam") {
                    reportType = clusterNode[0].item.name;
                    subReportType = "";
                } else {
                    reportType = clusterNode[0].item.parent;
                    subReportType = clusterNode[0].item.name;
                }
                jsonSave = {
                    "report_type": reportType,
                    "report_sub_type": subReportType,
                    "refresh": clusterNode[0].item.refresh,
                    "opacity": clusterNode[0].item.opacity,
                    "state": clusterNode[0].item.state
                };
                objJson = JSON.stringify(jsonSave);
                this._saveElement = null;
                this._saveElement = clusterNode[0].item.id + "_saveIcon";
                if (this._saveCount === 0) {
                    esriRequest({
                        url: this.config.BussinessLayerUpdateService,
                        content: lang.mixin({
                            reportLayer: objJson
                        }, null),
                        callbackParamName: "callback",
                        load: lang.hitch(this, function (response) {
                            if (response === true) {
                                if (this._saveCount === 0) {
                                    this._nc4Notify.success(sharedNls.DataLayer.saveLayer);
                                    domConstruct.destroy(this._saveElement);
                                    saveRefreshShow = dom.byId(clusterNode[0].item.id + "_saveRefreshLayer");
                                    if (saveRefreshShow) {
                                        domClass.remove(saveRefreshShow, "saveRefreshLayer");
                                        domClass.add(saveRefreshShow, "saveRefreshLayerHide");
                                    }
                                    this._saveCount++;
                                }
                            } else {
                                if (this._saveCount === 0) {
                                    this._nc4Notify.error(sharedNls.DataLayer.unableToSave);
                                    this._saveCount++;
                                }
                            }
                        }),
                        error: lang.hitch(this, function (err) {
                            this._nc4Notify.error(err);
                        })
                    });
                }
            },

            /**
             * Function to save and update the opacity of custom layers.
             * @param {Object} evt - evt.
             * @param {Object} saveNode - Object having detail of specific tree node, which is clicked.
             */
            _getSaveItems: function (evt, saveNode) {
                this._saveCount = 0;
                var layerType = null,
                    imageBounds = 0,
                    imageHeight = 0,
                    imageWidth = 0;
                if (saveNode[0].item.type === "wms") {
                    var wmsChildNodes = this.map.getLayer(saveNode[0].item.id + "_layer");
                    sublayers = wmsChildNodes.visibleLayers;
                }
                if (saveNode[0].item.type === "arcgis_map_service") {
                    layerType = "arcgis_map_service";
                    var objLayer = this.map.getLayer(saveNode[0].settings.id);
                    if (!objLayer) {
                        var sublayers = [];
                        var childNode = this._dataLayerTreeStore.query({
                            parent: saveNode[0].item.id
                        });
                        for (var j = 0; j < childNode.length; j++) {
                            var objChild = this.map.getLayer(childNode[j].id + "_layer");
                            if (objChild) {
                                sublayers.push(childNode[j].name);
                            }
                        }
                    }
                } else {
                    layerType = saveNode[0].item.type;
                }
                //this._saveElement = null;
                //this._saveElement = saveNode[0].settings.id;
                if (saveNode[0].item.type === "image") {
                    var saveBounds = saveNode[0].item.imgBounds.xmin.toFixed(3) + "," + saveNode[0].item.imgBounds.ymin.toFixed(3) + "," + saveNode[0].item.imgBounds.xmax.toFixed(3) + "," + saveNode[0].item.imgBounds.ymax.toFixed(3);
                    imageBounds = saveBounds;
                    imageHeight = saveNode[0].item.imgHeight;
                    imageWidth = saveNode[0].item.imgWidth;
                }
                var jsonSave = [{
                    "layer_name": saveNode[0].item.name,
                    "layer_type": saveNode[0].item.type,
                    "layer_id": saveNode[0].item.id,
                    "url": saveNode[0].item.url,
                    "opacity": saveNode[0].item.opacity,
                    "refresh": saveNode[0].item.refresh,
                    "sr": this.map.spatialReference.wkid.toString(),
                    "image_width": imageWidth.toString(),
                    "image_height": imageHeight.toString(),
                    "imageBounds": imageBounds.toString(),
                    "tileSizeH": "100",
                    "tileSizeW": "100",
                    "is_baseMap": "0",
                    "is_cached": "0",
                    "tileFormat": "png",
                    "state": saveNode[0].item.state
                }];
                if (sublayers) {
                    jsonSave[0]["sub-layers"] = sublayers;
                }
                var objJson = JSON.stringify(jsonSave);
                this._saveElement = saveNode[0].item.id + "_saveIcon";
                if (this._saveCount === 0) {
                    esriRequest({
                        url: this.config.CustomLayerUpdateService,
                        content: lang.mixin({
                            customLayers: objJson
                        }, null),
                        callbackParamName: "callback",
                        load: lang.hitch(this, function (response) {
                            if (response.success === true) {
                                if (this._saveCount === 0) {
                                    this._nc4Notify.success(sharedNls.DataLayer.saveLayer);
                                    var saveRefreshShow = dom.byId(saveNode[0].item.id + "_saveRefreshLayer");
                                    if (saveRefreshShow) {
                                        domClass.remove(saveRefreshShow, "saveRefreshLayer");
                                        domClass.add(saveRefreshShow, "saveRefreshLayerHide");
                                    }
                                    if (this._saveElement) {
                                        domConstruct.destroy(this._saveElement);
                                    }
                                    this.appUtils.customLayerCount--;
                                    this._saveCount++;
                                }
                            } else {
                                if (this._saveCount === 0) {
                                    this._nc4Notify.error(sharedNls.DataLayer.unableToSave);
                                    this._saveCount++;
                                }
                            }
                        }),
                        error: lang.hitch(this, function (err) {
                            this._nc4Notify.error(err);
                        })
                    });
                }
            },

            /**
             * Function to start strikeout operation.
             */
            _doStrikeOutOperation: function () {

                this._shelter.show();
                if (this._dataLayerTreeStore) {
                    this._performStrikeOutOperationOfLayerIds();                //from docs: this is for all layers except graphics and feature laeyrs
                    this._performStrikeOutOperationOfGraphicsLayerIds();        //TODO: this tackles csv and custom feature layers: from doc: this is for graphics and feature layers
                }
                this._shelter.hide();
            },

            /**
             * Function to perform strike out operation of KML, GeoRss and Cached layer's.
             * @param {array} kmlNode - Layer Node
             */
            _performStrikeOutOperationOfKmlGeoRssCachedLayers: function (kmlNode) {
                if (kmlNode[0].item.type === "kml") {
                    if (kmlNode[0].item.strike) {
                        if (kmlNode[0].item.strike === "Yes") {
                            html.addClass(kmlNode[0].labelNode, "strikeout");
                            this._hideIcons(kmlNode[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                            this._nc4Notify.warn("KML Layer is not compatible with current Base Map.");
                        } else {
                            html.removeClass(kmlNode[0].labelNode, "strikeout");
                            this._showIcons(kmlNode[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                        }
                    }
                }
                if (kmlNode[0].item.type === "georss") {
                    if (kmlNode[0].item.strike) {
                        if (kmlNode[0].item.strike === "Yes") {
                            html.addClass(kmlNode[0].labelNode, "strikeout");
                            this._hideIcons(kmlNode[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                            this._nc4Notify.warn("GeoRSS Layer is not compatible with current Base Map.");
                        } else {
                            html.removeClass(kmlNode[0].labelNode, "strikeout");
                            this._showIcons(kmlNode[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                        }
                    }
                }

                if (kmlNode[0].item.type === "arcgis_cached_service" || kmlNode[0].item.type === "Cached") {
                    if (kmlNode[0].item.strike) {
                        if (kmlNode[0].item.strike === "Yes") {
                            html.addClass(kmlNode[0].labelNode, "strikeout");
                            this._hideIcons(kmlNode[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                            this._nc4Notify.warn(sharedNls.DataLayer.notCompatible);
                        } else {
                            html.removeClass(kmlNode[0].labelNode, "strikeout");
                            this._showIcons(kmlNode[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                        }
                    }
                }
            },

            _performStrikeOutOnArcGISCachedService: function (p_node) {
                var p_layer = this.map.getLayer(p_node.id);
                if (p_layer == null)
                    return;
                var layerId = p_layer.id.replace("_layer", "");
                var layerNode = this._dataLayerTree.getNodesByItem(layerId);

                var nodeSR = new SpatialReference(p_node.sr);
                if (p_node.sr == this.map.spatialReference.wkid ||
                    (nodeSR._isWebMercator() && this.map.spatialReference._isWebMercator())) {
                    html.removeClass(layerNode[0].labelNode, "strikeout");
                    this._showIcons(layerNode[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                }
                else {
                    html.addClass(layerNode[0].labelNode, "strikeout");
                    this._hideIcons(layerNode[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                    this._nc4Notify.warn(sharedNls.DataLayer.notCompatible);
                }
            },

            /**
             * Function to perform strike out operation of WMS, Image and WMTS layer's.
             * @param {object} objWMS - object of wms layer.
             * @param {string} wmsLayer - Layer name.
             */
            //james - on basemap switch, this function is being called fdor custom image layer, despite the name!

            _performStrikeOutOperationOfWMSImageWMTSLayers: function (objWMS, wmsLayer) {
                //WMS TODO: we don't want to apply this to WMS anymore since there is no sub layers and wms MAY reproject w/o specifying 
                if (objWMS[0].item.type === "wms") {
                    if (this.appUtils.boolBasemapChanged) {
                        this._toggleWMSLayer(objWMS);
                    }
                    this.appUtils.boolBasemapChanged = false;
                }
                if (objWMS[0].item.type === "wmts") {
                    if (objWMS[0].item.strike) {
                        if (objWMS[0].item.strike === "Yes") {
                            html.addClass(objWMS[0].labelNode, "strikeout");
                            this._hideIcons(objWMS[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                            this._nc4Notify.warn("WMTS Layer is not compatible with current Base Map.");
                        } else {
                            html.removeClass(objWMS[0].labelNode, "strikeout");
                            this._showIcons(objWMS[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                        }
                    }
                }
                if (objWMS[0].item.type === "image") {
                    var basemap = this.map.getLayer(this.map.layerIds[0]);
                    var basemapSR = basemap.spatialReference.wkid;
                    if (basemapSR !== 102100 && basemapSR !== 4326) {
                        objWMS[0].item.strike = "Yes";
                        html.addClass(objWMS[0].labelNode, "strikeout");
                        this._hideIcons(objWMS[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                        this._nc4Notify.warn("Image Layer is not compatible with current Base Map.");
                    } else {
                        objWMS[0].item.strike = "No";
                        html.removeClass(objWMS[0].labelNode, "strikeout");
                        this._showIcons(objWMS[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }
            },

            /**
             * Function to perform strikeout operation of layerids.
             */
            _performStrikeOutOperationOfLayerIds: function () {
                var mapLayerIds = lang.clone(this.map.layerIds);
                if (mapLayerIds.length !== 0) {
                    array.forEach(mapLayerIds, lang.hitch(this, function (layer) {
                        var kml = layer.replace("_layer", "");
                        var kmlNode = this._dataLayerTree.getNodesByItem(kml);
                        if (kmlNode[0]) {
                            this._performStrikeOutOperationOfKmlGeoRssCachedLayers(kmlNode);
                        }
                        var wmsLayer = this.map.getLayer(layer);
                        var dupId = lang.clone(layer);
                        var id = dupId.replace("_layer", "");
                        var objWMS = this._dataLayerTree.getNodesByItem(id);
                        if (objWMS[0]) {
                            this._performStrikeOutOperationOfWMSImageWMTSLayers(objWMS, wmsLayer);
                        }
                    }));
                }
            },

            /**
             * Function to perform strike out operation of map server and it was added from data layer widget.
             * @param {string} name - Layer id
             */
            _performStrikeOutOperationOfMapserverFromDataLayer: function (name) {
                var msName = name.replace("_layer", "");
                var msNode = this._dataLayerTree.getNodesByItem(msName);
                if (msNode[0]) {
                    var replacedId, objNode;
                    if (msNode[0].item.strike) {
                        if (msNode[0].item.strike === "Yes") {
                            html.addClass(msNode[0].labelNode, "strikeout");
                            this._hideIcons(msNode[0].item.id);
                            replacedId = msNode[0].item.parent;
                            objNode = this._dataLayerTree.getNodesByItem(replacedId);
                            this._checkPrentStrikeOut(replacedId, objNode);
                            this.appUtils.boolBasemapChanged = false;
                        } else {
                            html.removeClass(msNode[0].labelNode, "strikeout");
                            this._showIcons(msNode[0].item.id);
                            replacedId = msNode[0].item.parent;
                            objNode = this._dataLayerTree.getNodesByItem(replacedId);
                            this._checkPrentStrikeOut(replacedId, objNode);
                            this.appUtils.boolBasemapChanged = false;
                        }
                    }
                }
            },

            /**
             * Function to perform strike out operation of map server and it was added from add layer widget.
             * @param {string} name - Layer id
             */
            _performStrikeOutOperationOfMapserverFromAddLayer: function (name) {
                var objNode,
                    replacedId;
                var mapServerId = name.replace("_layer", "");
                var mapServerNode = this._dataLayerTree.getNodesByItem(mapServerId);
                if (mapServerNode[0]) {
                    if (mapServerNode[0].item.strike) {
                        if (mapServerNode[0].item.strike === "Yes") {
                            html.addClass(mapServerNode[0].labelNode, "strikeout");
                            this._hideIcons(mapServerNode[0].item.id);
                            replacedId = mapServerNode[0].item.parent;
                            objNode = this._dataLayerTree.getNodesByItem(replacedId);
                            this._checkPrentStrikeOut(replacedId, objNode);
                            this.appUtils.boolBasemapChanged = false;
                        } else {
                            html.removeClass(mapServerNode[0].labelNode, "strikeout");
                            this._showIcons(mapServerNode[0].item.id);
                            replacedId = mapServerNode[0].item.parent;
                            objNode = this._dataLayerTree.getNodesByItem(replacedId);
                            this._checkPrentStrikeOut(replacedId, objNode);
                            this.appUtils.boolBasemapChanged = false;
                        }
                    }
                }
            },

            /**
             * Function to perform strike out operation of all feature layer's.
             * @param {string} name - Layer id
             * @param {object} objLayer - Layer Node
             */
            _performStrikeOutOperationOfFeatureLayers: function (layer, objLayer) {
                if (objLayer.type === "Feature Layer") {
                    var name = layer;
                    var mapServerFromAddlayer = name.indexOf("WebService");
                    if (mapServerFromAddlayer === -1) {
                        this._performStrikeOutOperationOfMapserverFromDataLayer(name);
                    } else {
                        this._performStrikeOutOperationOfMapserverFromAddLayer(name);
                    }
                }
            },

            /**
             * Function to perform strikeout operation of graphic layerIds.
             */
            _performStrikeOutOperationOfGraphicsLayerIds: function () {
                var mapGraphicsLayerIds = lang.clone(this.map.graphicsLayerIds);
                if (mapGraphicsLayerIds.length !== 0) {
                    array.forEach(mapGraphicsLayerIds, lang.hitch(this, function (layer) {
                        var objLayer = this.map.getLayer(layer);
                        if (objLayer.customLayerType === "csv") {
                            var id = objLayer.id;
                            var layerId = id.replace("_layer", "");
                            var csvNode = this._dataLayerTree.getNodesByItem(layerId);
                            if (csvNode[0].item.strike) {
                                if (csvNode[0].item.strike === "Yes") {
                                    html.addClass(csvNode[0].labelNode, "strikeout");
                                    this._hideIcons(csvNode[0].item.id);
                                    this.appUtils.boolBasemapChanged = false;
                                } else {
                                    html.removeClass(csvNode[0].labelNode, "strikeout");
                                    this._showIcons(csvNode[0].item.id);
                                    this.appUtils.boolBasemapChanged = false;
                                }
                            }
                        }
                        var childNodes = this._dataLayerTreeStore.query({
                            parent: "customLayers"
                        });
                        if (childNodes) {
                            this._performStrikeOutOperationOfFeatureLayers(layer, objLayer);
                        }
                    }));
                }
            },

            /**
             * Function to perform strikeout operation of parent node.
             * @param {Object} replacedId - Parent id
             * @param {Object} objNode - Parent Node
             */
            _checkPrentStrikeOut: function (replacedId, objNode) {
                //Check Parent node strike out.
                var count = null;
                count = 0;
                var childList = this._dataLayerTreeStore.query({
                    parent: replacedId
                });
                array.forEach(childList, lang.hitch(this, function (child) {
                    var objChild = this._dataLayerTree.getNodesByItem(child.id);
                    if (objChild[0].item.unSupportedLayer) {
                        html.addClass(objChild[0].labelNode, "strikeout");
                    }
                    if (objChild[0].item.strike === "Yes") {
                        html.addClass(objChild[0].labelNode, "strikeout");
                    }
                    var childClass = objChild[0].labelNode.className;
                    var value = childClass.indexOf("strikeout");
                    if (value !== -1) {
                        count++;
                    }
                }));
                if (count === 3) {
                    html.addClass(objNode[0].labelNode, "strikeout");
                    this._hideIcons(objNode[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                } else {
                    html.removeClass(objNode[0].labelNode, "strikeout");
                    this._showIcons(objNode[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                }
            },

            /**
             *  When layers are supported to current base map then display the (Delete,Save,Opacity,Cluster,Heat map)icons.
             * @param {string} id - layer id
             */
            _showIcons: function (id) {
                var deleteIcon = dom.byId(id + "_deleteIcon");
                if (deleteIcon) {
                    html.removeClass(deleteIcon, "hideIcon");
                    html.addClass(deleteIcon, "deleteLayer");
                }
                var zoomIcon = dom.byId(id + "_toggleZoomClusterIcon");
                if (zoomIcon) {
                    html.removeClass(zoomIcon, "hideIcon");
                    html.addClass(zoomIcon, "clusterZoomTo");
                }
                var settingIcon = dom.byId(id + "_toggleSettingClusterIcon");
                if (settingIcon) {
                    html.removeClass(settingIcon, "hideIcon");
                    html.addClass(settingIcon, "clusterSetting");
                }

                var node = this._dataLayerTreeStore.query({
                    id: id
                });
                console.info("node: ", node);

                var saveIcon = dom.byId(id + "_saveIcon");

                if (saveIcon && node[0].parent !== "nc4gisSamples" && (node[0].id != null && node[0].id.indexOf("nc4gisSamples") < 0)) {
                    html.removeClass(saveIcon, "hideIcon");
                    html.addClass(saveIcon, "saveLayer");
                }
            },

            /**
             *  When layers are not supported to current base map then hide the (Delete,Save,Opacity,Cluster,Heat map)icons.
             * @param {string} id - layer id
             */
            _hideIcons: function (id) {
                var deleteIcon = dom.byId(id + "_deleteIcon");
                if (deleteIcon) {
                    html.removeClass(deleteIcon, deleteIcon.className);
                    html.addClass(deleteIcon, "hideIcon");
                }
                var zoomIcon = dom.byId(id + "_toggleZoomClusterIcon");
                if (zoomIcon) {
                    html.removeClass(zoomIcon, zoomIcon.className);
                    html.addClass(zoomIcon, "hideIcon");
                }
                var settingIcon = dom.byId(id + "_toggleSettingClusterIcon");
                if (settingIcon) {
                    html.removeClass(settingIcon, settingIcon.className);
                    html.addClass(settingIcon, "hideIcon");
                }
                var saveIcon = dom.byId(id + "_saveIcon");
                if (saveIcon) {
                    html.removeClass(saveIcon, saveIcon.className);
                    html.addClass(saveIcon, "hideIcon");
                }
            },

            /**
             * Function to perform strikeout operation of csv layer.
             * @param {Object} csvNode - layer node
             */
            _checkCSVStrikeOutOperation: function (csvNode) {
                var csvLayer = this._dataLayerTree.getNodesByItem(csvNode.id);
                if (csvNode.strike === "Yes") {
                    html.addClass(csvLayer[0].labelNode, "strikeout");
                    this._hideIcons(csvNode.id);
                    this.appUtils.boolBasemapChanged = false;
                } else {
                    html.removeClass(csvLayer[0].labelNode, "strikeout");
                    this._showIcons(csvNode.id);
                    this.appUtils.boolBasemapChanged = false;
                }
            },

            /**
             * On selecting child node decide whether check, uncheck or gray out its parent node.
             * @param {Object} treeNode - Object having detail of specific tree node, which is clicked.
             * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
             */
            _checkHierarchicalNodes: function (treeNode, isChecked) {

                var arrDeferred = [];
                if (treeNode.type === "wms" && treeNode.parent === "customLayers" || treeNode.type === "arcgis_map_service" && treeNode.parent === "customLayers"
                    || treeNode.type === "arcgis_dynamic_service" && treeNode.parent === "customLayers") {
                    var layerName = treeNode.name;
                    var value = layerName.indexOf("_layer");
                    if (value === -1 || (treeNode.isSubLayer && treeNode.isSubLayer == false)) {
                        //if this is not a child / sub layer (in terms of the data layer tree)
                        this._checkChildNodes(treeNode, isChecked);
                        this._checkParentNodes(treeNode, isChecked);
                        if (treeNode.type === "wms")
                            this._toggleWMSLayer(treeNode, isChecked);
                        else //(treeNode.layerFromAddLayer) {
                            this._toggleLayerFromService(treeNode, isChecked);

                    }
                } else {
                    this._toggleLayerFromService(treeNode, isChecked);
                }
                if (this._arrClusterDetail.length) {
                    arrDeferred.push(this._manageCluster(this._arrClusterDetail));
                }
                this._arrClusterDetail = [];
                if (this._arrLayerDetail.length) {
                    arrDeferred.push(this._toggleLayer(this._arrLayerDetail));
                }
                this._arrLayerDetail = [];
                all(arrDeferred).then(lang.hitch(this, function () {
                    // this.appUtils.refreshLegend(true);
                    this._shelter.hide();
                }));
            },

            /**
             * On selecting node check parent and child nodes and perform toggle on/off operation.
             * @param {Object} treeNode - Object having detail of specific tree node, which is clicked.
             * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
             */
            _toggleLayerFromService: function (treeNode, isChecked) {
                if (treeNode.id) {
                    var layer = this._dataLayerTree.getNodesByItem(treeNode.id);
                    var className = layer[0].labelNode.className;
                    var removeLayerClass = className.indexOf("strikeout");
                    if (removeLayerClass !== -1) {
                        html.removeClass(layer[0].labelNode, "strikeout");
                        this._showIcons(layer[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }

                if (treeNode.url) {
                    //if a url exists, seems to be a child/leaf node
                    if (treeNode.geometryType) {
                        if (treeNode.geometryType === "esriGeometryPoint") {
                            var selectionChildNode = dom.byId(treeNode.id + "_toggleClusterHeatMapIcon");
                            var selectionNode = dom.byId(treeNode.parent + "_toggleClusterHeatMapIcon");
                            var clusterDetail = {
                                "clusterDetail": treeNode,
                                "isClustered": true
                            };
                            if (isChecked) {
                                if (selectionNode && selectionNode.className === "selectedClusterHeatMaps" || selectionChildNode && selectionChildNode.className === "selectedClusterHeatMaps") {
                                    this._arrLayerDetail.push({
                                        "LayerDetail": treeNode,
                                        "isChecked": isChecked,
                                        "isClustered": false
                                    });
                                } else {
                                    this._arrClusterDetail.push(clusterDetail);
                                }
                            } else {
                                if (selectionNode && selectionNode.className === "selectedClusterHeatMaps" || selectionChildNode && selectionChildNode.className === "selectedClusterHeatMaps") {
                                    this._arrLayerDetail.push({
                                        "LayerDetail": treeNode,
                                        "isChecked": isChecked,
                                        "isClustered": false
                                    });
                                } else {
                                    this._arrLayerDetail.push({
                                        "LayerDetail": treeNode,
                                        "isChecked": isChecked,
                                        "isClustered": true
                                    });
                                }
                            }

                        }
                        else {
                            //safely adding support for polygon feature service (in this case , coming from biz layer)
                            this._arrLayerDetail.push({
                                "LayerDetail": treeNode,
                                "isChecked": isChecked,
                                "mode": treeNode.mode || FeatureLayer.MODE_SNAPSHOT,
                                "isClustered": false        //if set to true, a clusteredfeaturelayer will be creatred instead
                            });
                        }
                    }
                    else {
                        this._arrLayerDetail.push({
                            "LayerDetail": treeNode,
                            "isChecked": isChecked,
                            "isClustered": false
                        });
                    }
                    this._checkParentNodes(treeNode, isChecked);
                }
                else {
                    //else seems to be a parent, so check its chld and its parent
                    this._checkChildNodes(treeNode, isChecked);
                    this._checkParentNodes(treeNode, isChecked);

                }
            },

            /**
             * On selecting node check parent and child nodes of wms layer and perform toggle on/off operation.
             * @param {Object} treeNode - Object having detail of specific tree node, which is clicked.
             * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
             */
            _toggleWMSLayer: function (treeNode, isChecked) { //for wms
                var layerId = treeNode.id;

                if (layerId == null) {
                    try {
                        layerId = treeNode[0].item.id;
                    } catch (error) { console.info("unknown layer id"); }
                }
                var value = layerId.indexOf("_sublayer");


                var wmsLayers = this.map.getLayer(treeNode.id + "_layer");
                if (wmsLayers) {
                    if (isChecked === true) {
                        if (treeNode.layerFromAddLayer && treeNode.layerFromAddLayer === true) {
                            //if just added to map from add layer, do nothing
                            treeNode.layerFromAddLayer = false;
                        }
                        else {
                            var lyrsToTurnOn = treeNode["sub-layers"] || [];
                            wmsLayers.setVisibleLayers(lyrsToTurnOn); //TODO, what to turn on here?
                        }

                    }
                    else {
                        var wmsLayer = this.map.getLayer(treeNode.id + "_layer");
                        if (wmsLayer != null) {
                            this.map.removeLayer(wmsLayer);
                        }
                    }
                }
                else {
                    //if wmslayer doesn't exist, and if it is checked to turn on, then add the layer
                    if (isChecked === true) {
                        this._wmsAddLayer(treeNode);
                    }
                    else {
                        //if wmslayer doesn't exist, and it is checked off ==> should not occur
                    }
                }
            },

            /**
             * On selecting child node decide whether check, uncheck or gray out its parent node.
             * @param {Object} Node - Object having detail of specific tree node.
             * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
             */
            _checkParentNodes: function (Node, isChecked) {

                this.appUtils.log.debug("_checkParentNdoes() : Node: ", Node);
                this.appUtils.log.debug("_checkParentNodes(): isChecked: ", isChecked);
                var checkNode,
                    childNodes,
                    childNodesCount,
                    nodesChecked = 0,
                    nodesUnchecked = 0,
                    parentNode = this._dataLayerTreeStore.query({
                        id: Node.parent
                    });
                if (parentNode.length) {
                    childNodes = this._dataLayerTreeStore.query({                                                           //query for all nodes whose parent matches the passed in parent node id
                        parent: parentNode[0].id
                    });
                    childNodesCount = childNodes.length;
                    array.forEach(childNodes, lang.hitch(this, function (node, i) {
                        var selectionNode = dom.byId(node.id + "_checkBox");
                        if (selectionNode) {
                            if (selectionNode.className === "unchecked") {
                                nodesUnchecked++;
                                //if (node.parent.toString() !== "customLayers" || node.parent.toString() !== "nc4maps_overlays") {
                                //    var heatmapIcon = dom.byId(node.id + "_toggleClusterHeatMapIcon");
                                //    if (heatmapIcon) {
                                //        domClass.remove(heatmapIcon, "selectedClusterHeatMaps");
                                //        domClass.add(heatmapIcon, "clusterHeatMaps");
                                //    }
                                //}
                            } else if (selectionNode.className === "checked") {
                                nodesChecked++;
                            }
                        }
                    }));
                    checkNode = dom.byId(parentNode[0].id + "_checkBox");
                    if (checkNode) {
                        if (childNodesCount === nodesChecked) { //if all nodes are checked, then check parent node
                            domClass.remove(checkNode, "unchecked");
                            domClass.remove(checkNode, "partialChecked");
                            domClass.add(checkNode, "checked");

                        } else if (childNodesCount === nodesUnchecked) {  //if all nodes unchecked, uncheck parent
                            domClass.remove(checkNode, "checked");
                            domClass.remove(checkNode, "partialChecked");
                            domClass.add(checkNode, "unchecked");
                        } else {
                            domClass.remove(checkNode, "checked");          //partial check
                            domClass.remove(checkNode, "unchecked");
                            domClass.add(checkNode, "partialChecked");
                        }
                    }
                    if (parentNode[0].parent) {
                        this._checkParentNodes(parentNode[0], isChecked);
                    }
                }
            },

            /**
             * Select children to add/remove layer from map.
             * @param {Object} Node - Object having detail of specific tree node.
             * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
             */
            _checkChildNodes: function (Node, isChecked) {
                var childNodes = this._dataLayerTreeStore.query({
                    parent: Node.id
                });

                array.forEach(childNodes, lang.hitch(this, function (node, i) {
                    var checkNode = dom.byId(node.id + "_checkBox"),
                        heatmapIcon, heatmapIconForChild;
                    if (checkNode) {
                        if (isChecked) {
                            domClass.remove(checkNode, "unchecked");
                            domClass.remove(checkNode, "partialChecked");
                            domClass.add(checkNode, "checked");
                        } else {
                            domClass.remove(checkNode, "checked");
                            domClass.remove(checkNode, "partialChecked");
                            domClass.add(checkNode, "unchecked");
                        }
                    }
                    if (node.layerFromAddLayer === true || node.parent.toString() === "customLayers" || node.parent.toString() === "nc4gisSamples"
                        || (node.id != null && node.id.indexOf("nc4gisSamples") >= 0) || node.parent.toString() === "nc4maps_overlays") {
                        if (node.type === "wms") {
                            this._toggleWMSLayer(node, isChecked);
                        }
                        else {
                            if (node.url) {
                                if (isChecked && !this.map.getLayer(node.id + "_layer")) {
                                    this._arrLayerDetail.push({
                                        "LayerDetail": node,
                                        "isChecked": isChecked,
                                        "isClustered": false
                                    });
                                } else if (!isChecked && this.map.getLayer(node.id + "_layer")) {
                                    this._arrLayerDetail.push({
                                        "LayerDetail": node,
                                        "isChecked": isChecked,
                                        "isClustered": false
                                    });
                                } else if (!isChecked) {
                                    this._arrLayerDetail.push({
                                        "LayerDetail": node,
                                        "isChecked": isChecked,
                                        "isClustered": false
                                    });
                                }
                            }
                        }

                    } else {
                        heatmapIcon = dom.byId(node.parent + "_toggleClusterHeatMapIcon");
                        heatmapIconForChild = dom.byId(node.id + "_toggleClusterHeatMapIcon");
                        //if (heatmapIcon) {
                        //    if (heatmapIcon.className === "selectedClusterHeatMaps") {
                        //        domClass.remove(heatmapIcon, "selectedClusterHeatMaps");
                        //        domClass.add(heatmapIcon, "clusterHeatMaps");
                        //    }
                        //}
                        var clusterDetail;
                        if (heatmapIcon) {
                            if (heatmapIcon.className === "selectedClusterHeatMaps") {
                                clusterDetail = {
                                    "clusterDetail": node,
                                    "isClustered": false
                                };
                            } else {
                                clusterDetail = {
                                    "clusterDetail": node,
                                    "isClustered": isChecked
                                };
                            }
                        } else {
                            if (heatmapIconForChild) {
                                if (heatmapIconForChild.className === "selectedClusterHeatMaps") {
                                    clusterDetail = {
                                        "clusterDetail": node,
                                        "isClustered": false
                                    };
                                } else {
                                    clusterDetail = {
                                        "clusterDetail": node,
                                        "isClustered": isChecked
                                    };
                                }
                            } else { //default: geofences is making it here on toggle of "layer" parent.  Will be supported as ClusterFeatureLayer in the future
                                clusterDetail = {
                                    "clusterDetail": node,
                                    "isClustered": isChecked
                                };
                            }
                        }
                        if (!isChecked) {
                            if (this.map.getLayer(node.id + "_layer")) {
                                this._arrLayerDetail.push({
                                    "LayerDetail": node,
                                    "isChecked": false,
                                    "isClustered": false
                                });
                            }
                            if (this.map.getLayer(node.id + "_cluster")) {
                                this._arrLayerDetail.push({
                                    "LayerDetail": node,
                                    "isChecked": false,
                                    "isClustered": true
                                });
                            }
                            if (this.map.getLayer(node.id + "_heatlayer")) {
                                this._arrLayerDetail.push({
                                    "LayerDetail": node,
                                    "isChecked": false,
                                    "isClustered": true
                                });
                            }
                            if (this.map.getLayer(node.id)) {
                                this._arrLayerDetail.push({
                                    "LayerDetail": node,
                                    "isChecked": false,
                                    "isClustered": true
                                });
                            }
                        } else {
                            if (isChecked && !this.map.getLayer(node.id + "_cluster")) {
                                this._arrClusterDetail.push(clusterDetail);		//geofences is being re-added as a cluster layer...
                            }
                        }
                    }
                    if (node.type !== "wms") //wms is handled 
                        this._checkChildNodes(node, isChecked);     // ?? huh
                    
                }));
            },

            /**
             * Decide to add/remove layer from map.
             * @param {Array} layersDetail - Array of objects having layer detail to decide add/remove them.
             * @returns {deferred.promise}
             */
            //JT: This is where datalayer on click eventually gets to:
            _toggleLayer: function (layersDetail) {
                var arrAddLayers = [],
                    arrRemoveLayers = [],
                    arrDeferred = [],
                    deferred = new Deferred();
                array.forEach(layersDetail, lang.hitch(this, function (layerDetail, i) {
                    var removeLayerID;
                    if (layerDetail.isChecked) {
                        //set the default value of customer layer to 0.5 when opacity is null
                        if (!layerDetail.LayerDetail.opacity || layerDetail.LayerDetail.opacity == null || layerDetail.LayerDetail.opacity * 1 <= 0) {
                            layerDetail.LayerDetail.opacity = 0.5;
                        }
                        
                        if (layerDetail.LayerDetail.type == "arcgis_dynamic_service") {
                            this._addDynService(layerDetail.LayerDetail);
                            return;
                        }
                        else if (layerDetail.LayerDetail.type == "arcgis_cached_service") {
                            //this._addCachedService(layerDetail.LayerDetail);
                            var cachedMgr = new ArcGISMSCachedManager(layerDetail.LayerDetail.name, this.appUtils, this.map, layerDetail.LayerDetail.url,
                                this._shelter, layerDetail.LayerDetail.id,
                                layerDetail.LayerDetail.opacity, layerDetail.LayerDetail.refresh);
                            cachedMgr._addCachedServiceToMap(sharedNls.DataLayer.notCompatible, layerDetail.LayerDetail.sr);
                            var cachedLyrNode = this._dataLayerTreeStore.query({
                                id: layerDetail.LayerDetail.id
                            });
                            this._performStrikeOutOnArcGISCachedService(cachedLyrNode[0]);
                            return;
                        }
                        else
                            arrAddLayers.push(layerDetail.LayerDetail);
                    } else {
                        if (layerDetail.LayerDetail.parent === "nc4maps_overlays") {
                            removeLayerID = layerDetail.LayerDetail.id + "_layer";
                        } else {

                            if (layerDetail.LayerDetail.type == "arcgis_dynamic_service") {
                                this._removeDynService(layerDetail.LayerDetail);
                                return;
                            }
                            else if (layerDetail.LayerDetail.type == "arcgis_cached_service") {
                                this._removeCachedService(layerDetail.LayerDetail);
                                return;
                            }
                            else if (layerDetail.isClustered) {
                                removeLayerID = layerDetail.LayerDetail.id + "_cluster";
                            } else {
                                removeLayerID = layerDetail.LayerDetail.id + "_heatlayer";  //JT: Custom layer is arriving here...ie sublayer of a dynamic map service
                            }
                        }
                        arrRemoveLayers.push(removeLayerID);
                    }
                }));
                if (arrAddLayers.length) {
                    arrDeferred.push(this._addLayers(arrAddLayers));
                }
                if (arrRemoveLayers.length) {
                    arrDeferred.push(this._removeLayers(arrRemoveLayers));
                }
                all(arrDeferred).then(lang.hitch(this, function (result) {
                    deferred.resolve(result);
                }));
                return deferred.promise;
            },

            _removeCachedService: function (p_layerDetails) {
                var arrLyrsToRemove = [];
                arrLyrsToRemove.push(p_layerDetails.id);
                if (p_layerDetails.parent == "customLayers") {
                    this._removeLayers(arrLyrsToRemove);
                }

            },

            /*
             * method to add dynamic service as a layer, to the map.  If the layer already exist, such as in the case of if you just added the layer, this method can 
             */
            _addDynService: function (p_layerDetails) {

                this._showIcons(p_layerDetails.id);
                if (p_layerDetails.parent == "customLayers") {
                    //check if layer exist, 
                    var mapLyr = this.map.getLayer(p_layerDetails.id);
                    if (mapLyr == null) {
                        //if the layer doesn't exist, create it.  
                        //also checks to see if there are any childs, if so, were the child added to the tree?  if not add them:
                        var childNodes = this._dataLayerTreeStore.query({
                            parent: p_layerDetails.id
                        });
                        var boolAddToTree = false;
                        var boolAddSubLyrsToMap = false;
                        var arrSubLyrIdsOn = p_layerDetails["sub-layers"] || [];    //if turning on layer from data layer tree, check if any sub-layer state was save

                        if (p_layerDetails.state && p_layerDetails.state == 3)
                            arrSubLyrIdsOn = ["_ALL_"];

                        var preDefinedParentId = p_layerDetails.id;
                        var boolUseDefaults = false;    //only using defaults defined in the service when initially adding form the add layer widget.

                        if (childNodes.length <= 0) {
                            //child nodes have never been added to the map or tree, attempt to add them:
                            boolAddToTree = true;
                            boolAddSubLyrsToMap = true;
                            boolUseDefaults = true;
                        }
                        var arcGisMSmgr = new ArcGISMSmanager(p_layerDetails.name, this.appUtils, this.map, p_layerDetails.url, p_layerDetails.id, this._shelter, arrSubLyrIdsOn, boolUseDefaults, { "opacity": p_layerDetails.opacity, "refresh": p_layerDetails.refresh, "popupCleanseAction": p_layerDetails.popupCleanse });
                        arcGisMSmgr._addDynamicMapServer3(preDefinedParentId, boolAddToTree, boolAddSubLyrsToMap);
                    }
                    //else do nothing.  since layer exist, data layer tree will take care of iterating through sub layers
                }
                else {
                    var dynService = this.map.getLayer(p_layerDetails.parent);

                    /*
                     * if parent layer doesn't exist, recreate it
                     * - no need to re-add to data layer tree
                     * - no need to re-add sub layers to data layer tree
                     * - just re-create, set parent visibility to -1, then pass in visible layer to the p_layerDetails here
                     */
                    if (dynService == null) {
                        //if layer doesn't exist, create and add it to map.  No need to add to tree since it is there already.  We're creating vs turning on since the
                        //      "remove" method actually destroys the layer every time.
                        var parentNode = this._dataLayerTreeStore.query({
                            id: p_layerDetails.parent
                        });

                        if (parentNode.length > 0) {
                            var node = parentNode[0];

                            var strLayrId = p_layerDetails.id.replace(p_layerDetails.parent + "_", "");
                            var layrId = parseInt(strLayrId);

                            var arrVisibleLyrs = [];
                            arrVisibleLyrs.push(layrId);
                            var arcGisMSmgr = new ArcGISMSmanager(node.name, this.appUtils, this.map, node.url, node.id, this._shelter, arrVisibleLyrs, false, { "opacity": node.opacity });
                            arcGisMSmgr._addDynamicMapServer3(node.id);
                            dynService = this.map.getLayer(node.id);
                        }
                        else {
                            this._nc4Notify.error("Unable to re-create Parent Layer at this time");
                        }
                    }
                    else {
                        //if layer does exist, include all sublyr ids to turn on
                        var arrVisibleLyrs = dynService.visibleLayers;
                        var strParentIndx = p_layerDetails.id.indexOf(p_layerDetails.parent + "_");
                        if (strParentIndx >= 0) {
                            var strLayrId = p_layerDetails.id.replace(p_layerDetails.parent + "_", "");
                            var layrId = parseInt(strLayrId);

                            if (arrVisibleLyrs.indexOf(layrId) < 0) {
                                if (arrVisibleLyrs.indexOf(-1) >= 0)   //if previously set to -1, replace
                                    arrVisibleLyrs = [];
                                arrVisibleLyrs.push(layrId);
                            }
                            dynService.setVisibleLayers(arrVisibleLyrs);
                        }
                    }
                }
            },

            /*
             * method to remove Arcgis Dynamic map service from map, or disable one of its sub layers
             */
            _removeDynService: function (p_layerDetails) {
                var arrLyrsToRemove = [];
                arrLyrsToRemove.push(p_layerDetails.id);
                if (p_layerDetails.parent == "customLayers") {
                    this._removeLayers(arrLyrsToRemove);
                }
                else if (this.map.getLayer(p_layerDetails.parent)) {
                    var dynamicSrv = this.map.getLayer(p_layerDetails.parent);
                    var arrLyrInfos = dynamicSrv.layerInfos;
                    var arrLyrs = dynamicSrv.visibleLayers;
                    var newVisibleLyrs = [];
                    for (var i = 0; i < arrLyrs.length; i++) {
                        var currVisibleLyrId = arrLyrs[i];
                        var currVisibleLyr = arrLyrInfos[currVisibleLyrId] || "";
                        var currLyrName = currVisibleLyr.name;
                        if (currLyrName && currLyrName != null && currLyrName != p_layerDetails.name) {
                            newVisibleLyrs.push(currVisibleLyrId);
                        }
                    }
                    if (newVisibleLyrs.length === 0) {
                        this.map.removeLayer(dynamicSrv);
                    }
                    else
                        dynamicSrv.setVisibleLayers(newVisibleLyrs);
                }

            },


            /**
             * Add layers to the map.
             * @param {Array} layerDetail - Array of objects having detail for feature layer.
             * @returns {deferredAll.promise}
             */

            //James - is this from add layer OR from layer clicked (already added layer ) OR both?...


            _addLayers: function (layerDetail) {

                var arrLayers = [];
                var deferredAll = new Deferred();
                var deferredLayerLoaded = new Deferred();
                var deferredLayerAdded = new Deferred();
                var deferredArray = [];
                var deferredAllArray = [];
                var template = new InfoTemplate("Attributes", layerDetail[0].popupInfo);
                this._shelter.show();
                var layMap = {
                    "dynamic": "esri/layers/ArcGISDynamicMapServiceLayer",                  //will be represented by "LayerClass" var below
                    "image": "esri/layers/MapImageLayer",
                    "feature": "esri/layers/FeatureLayer",
                    "georss": "esri/layers/GeoRSSLayer",
                    "csv": "esri/layers/CSVLayer",
                    "kml": "esri/layers/KMLLayer",
                    "webTiled": "esri/layers/WebTiledLayer",
                    "wms": "esri/layers/WMSLayer",
                    "wmts": "esri/layers/WMTSLayer",
                    "arcgis_map_service": "esri/layers/FeatureLayer",
                };
                this.own(on(this.map, "layers-add-result", lang.hitch(this, function (evt) {
                    var contentinfo,
                        i,
                        j,
                        temdata = "";
                    for (i = 0; i < evt.layers.length; i++) {
                        temdata = "";
                        if (evt.layers[i].layer.fields) {
                            for (j = 0; j < evt.layers[i].layer.fields.length; j++) {
                                temdata = temdata + " <div style='font-weight: bold;width:200px;word-break: normal;float: left;'>" + evt.layers[i].layer.fields[j].name + " </div> <div style='white-space: nowrap;line-height:5px'> ${" + evt.layers[i].layer.fields[j].name + "}</div><br/>";
                            }
                            contentinfo = new InfoTemplate();
                            contentinfo.setTitle("Attributes");
                            contentinfo.setContent("<div style='float:left'>" + temdata + "</div>");
                            //evt.layers[i].layer.setInfoTemplate(contentinfo);
                        }
                    }
                    deferredLayerLoaded.resolve(true);
                })));
                deferredAllArray.push(deferredLayerAdded.promise);
                array.forEach(layerDetail, lang.hitch(this, function (layer) {
                    var deferred = new Deferred();
                    if (!this.map.getLayer(layerDetail.id + "_layer")) {

                        if (layer.parent === "customLayers" || layer.parent === "nc4gisSamples" || (layer.id != null && layer.id.indexOf("nc4gisSamples") >= 0)) {
                            var maptype = layer.type;
                            require([layMap[maptype]], lang.hitch(this, function (LayerClass) {
                                var customLayer;

                                if (maptype !== "image") {
                                    if (layer.layerTitle) {
                                        this._featureCollection(layer);
                                    }
                                    /*wms now handled in wms manager*/
                                    if (maptype === "arcgis_map_service" && (layer.isCached === 0) && (layer.url.indexOf("MapServer/") === -1) && (layer.url.indexOf("FeatureServer/") === -1)) {
                                        //This should be fore feature services / layer only now
                                        var mapServerTreeNodeID = layer.id;
                                        var strURL = layer.url;
                                        var subLayers = layer["sub-layers"];
                                        childNodes = this._dataLayerTreeStore.query({
                                            parent: layer.id
                                        });

                                        childNodesCount = childNodes.length;
                                        strUrl = layer.url;
                                        strId = layer.id;
                                        strName = layer.name;
                                        opacity = layer.opacity > 0 ? layer.opacity : this.appUtils.configGeneralSettings.defaultOpacity;
                                        refreshInterval = layer.refresh;
                                        if (childNodesCount < 1) {
                                            esriConfig.defaults.io.alwaysUseProxy = true;
                                            esriRequest({
                                                url: layer.url,
                                                content: lang.mixin({
                                                    f: "json"
                                                }, null),
                                                callbackParamName: "callback",
                                                load: lang.hitch(this, function (response) {
                                                    esriConfig.defaults.io.alwaysUseProxy = false;
                                                    array.forEach(response.layers, lang.hitch(this, function (layer) {
                                                        this._addFeatureLayer(strURL + "/" + layer.id, mapServerTreeNodeID, layer.name, subLayers, opacity, refreshInterval);
                                                    }));
                                                    //james - opacity applied?
                                                }),
                                                error: lang.hitch(this, function (err) {
                                                    this._shelter.hide();
                                                    this._nc4Notify.error(err);
                                                })
                                            });

                                        } else {
                                            childNodes = this._dataLayerTreeStore.query({
                                                parent: layer.id
                                            });
                                            var isChecked = true;
                                            array.forEach(childNodes, lang.hitch(this, function (node, i) {
                                                if (node.url) {
                                                    if (isChecked && !this.map.getLayer(node.id + "_layer")) {
                                                        esriConfig.defaults.io.alwaysUseProxy = true;
                                                        var featurLayer = new FeatureLayer(node.url, {
                                                            outFields: ["*"],
                                                            id: node.id + "_layer",
                                                            name: node.name,
                                                            opacity: node.opacity && node.opacity > 0 ? node.opacity : this.appUtils.configGeneralSettings.defaultOpacity / 100   //james - add opacity?
                                                        });
                                                        featurLayer.customLayerType = maptype;
                                                        this.own(on(featurLayer, "mouse-over", lang.hitch(this, function (evt) {
                                                            this.map.setMapCursor("pointer");
                                                        })));
                                                        this.own(on(featurLayer, "mouse-out", lang.hitch(this, function (evt) {
                                                            this.map.setMapCursor("default");
                                                        })));
                                                        arrLayers.push(featurLayer);
                                                        esriConfig.defaults.io.alwaysUseProxy = false;
                                                        //this.map.addLayer(featurLayer);
                                                    }
                                                }
                                            }));
                                            this._shelter.hide();
                                            deferred.resolve(true);
                                        }
                                    } else {

                                        if (!layer.layerTitle) {
                                            if (layer.url.indexOf(location.hostname) >= 0)
                                                esriConfig.defaults.io.alwaysUseProxy = false;
                                            else
                                                esriConfig.defaults.io.alwaysUseProxy = true;

                                            //For kml layer, also, CSV layers go through this
                                            console.info("layer: ", layer);

                                            if (layer.type == "kml") //reprojection on data layer load, non on basemap switch or add layer yet
                                            {
                                                customLayer = new LayerClass(layer.url, {
                                                    outFields: ["*"],
                                                    id: layer.id + "_layer",
                                                    name: layer.name,
                                                    title: layer.name,
                                                    opacity: layer.opacity > 0 ? layer.opacity : this.appUtils.configGeneralSettings.defaultOpacity / 100,
                                                    outSR: this.map.spatialReference,
                                                    refreshInterval: layer.refresh > 0 ? layer.refresh : this.appUtils.configGeneralSettings.defaultRefRate
                                                });
                                                if (layer.popupCleanse)//set for layers when certain items want to be removed from the popup content box
                                                    customLayer.popupCleanseAction = layer.popupCleanse;
                                            }
                                            else if (layer.type == "georss") {
                                                customLayer = new LayerClass(layer.url, {
                                                    outSpatialReference: this.map.spatialReference,
                                                    id: layer.id + "_layer",
                                                    name: layer.name,
                                                    title: layer.name,
                                                    opacity: layer.opacity > 0 ? layer.opacity : this.appUtils.configGeneralSettings.defaultOpacity / 100,
                                                    refreshInterval: layer.refresh > 0 ? layer.refresh : this.appUtils.configGeneralSettings.defaultRefRate
                                                });
                                                if (layer.popupCleanse)//set for layers when certain items want to be removed from the popup content box
                                                    customLayer.popupCleanseAction = layer.popupCleanse;
                                            }
                                            else if (layer.type == "csv")    //reprojection on the fly supported, but POST to project geometry service currently broken
                                            {
                                                customLayer = new LayerClass(layer.url, {
                                                    outFields: ["*"],
                                                    id: layer.id + "_layer",
                                                    name: layer.name,
                                                    title: layer.name,
                                                    opacity: layer.opacity > 0 ? layer.opacity : this.appUtils.configGeneralSettings.defaultOpacity / 100,
                                                    refreshInterval: layer.refresh > 0 ? layer.refresh : this.appUtils.configGeneralSettings.defaultRefRate
                                                });
                                                if (layer.popupCleanse)//set for layers when certain items want to be removed from the popup content box
                                                    customLayer.popupCleanseAction = layer.popupCleanse;
                                            }
                                            else if (layer.type == "arcgis_map_service") //feature service
                                            {
                                                this.appUtils.log.debug("adding featurer service layer");
                                                customLayer = new LayerClass(layer.url, {
                                                    outFields: ["*"],
                                                    id: layer.id,
                                                    name: layer.name,
                                                    opacity: layer.opacity > 0 ? layer.opacity : this.appUtils.configGeneralSettings.defaultOpacity / 100,
                                                    refreshInterval: layer.refresh > 0 ? layer.refresh : this.appUtils.configGeneralSettings.defaultRefRate
                                                });
                                                if (layer.popupCleanse)//set for layers when certain items want to be removed from the popup content box
                                                    customLayer.popupCleanseAction = layer.popupCleanse;
                                            }
                                            else {
                                                console.error("non supported layer: ", layer);
                                            }

                                            customLayer.customLayerType = maptype;
                                            this.own(on(customLayer, "mouse-over", lang.hitch(this, function (evt) {
                                                this.map.setMapCursor("pointer");
                                            })));
                                            this.own(on(customLayer, "mouse-out", lang.hitch(this, function (evt) {
                                                this.map.setMapCursor("default");
                                            })));
                                            //}
                                            esriConfig.defaults.io.alwaysUseProxy = false;
                                            arrLayers.push(customLayer);
                                        }
                                    }
                                } else {
                                    //For image Layer (MapImageLayer) - no reprojection support here yet
                                    esriConfig.defaults.io.alwaysUseProxy = true;
                                    customLayer = new LayerClass({
                                        id: layer.id + "_layer",
                                        name: layer.name,
                                        opacity: layer.opacity && layer.opacity > 0 ? layer.opacity : this.appUtils.configGeneralSettings.defaultOpacity / 100,
                                        refreshInterval: layer.refresh && layer.refresh > 0 ? layer.refresh : this.appUtils.configGeneralSettings.defaultRefRate                //james - add opacity here?
                                    });
                                    var getMapImage = new MapImage({
                                        "extent": layer.imgBounds,
                                        "href": layer.url,
                                        "height": layer.imgHeight,
                                        "width": layer.imgWidth
                                    });
                                    customLayer.addImage(getMapImage);
                                    customLayer.customLayerType = maptype;
                                    esriConfig.defaults.io.alwaysUseProxy = false;
                                    arrLayers.push(customLayer);
                                }
                                if (customLayer) {
                                    this.own(on(customLayer, "mouse-over", lang.hitch(this, function (evt) {
                                        this.map.setMapCursor("pointer");
                                    })));
                                    this.own(on(customLayer, "mouse-out", lang.hitch(this, function (evt) {
                                        this.map.setMapCursor("default");
                                    })));
                                    arrLayers.push(customLayer);
                                    deferred.resolve(true);
                                }
                            }));
                        } else {
                            if (layer.type === "graphics") {
                                //re projection on the fly supported, current known bug with POST to Geometry Server Project (through the proxy)
                                //for overlay layers
                                this.setIntervalForOverlays(layer);
                                deferred.resolve(true);
                            } else { //geofence
                                //set use proxy to false
                                //for feature layers that are biz layer (we already checked for custom layers in the parent if statemetn)
                                esriConfig.defaults.io.alwaysUseProxy = false;
                                if (layer.url) {
                                    if (layer.layerFromAddLayer === true || layer.parent.toString() === "customLayers" || layer.parent.toString() === "nc4maps_overlays") {
                                        //JT geofence here
                                        //if added a layer from add layer widget and data layer widget not yet initiated, then you initiate the data layer widget, this will get called
                                        //from add layer, and not yet saved, opacity is between 0 and 1.

                                        //this also is called on datalayer radio button click...ie for an arcgis map service (dynamic) sub layer

                                        var featurLayer = new FeatureLayer(layer.url, {
                                            outFields: ["*"],
                                            infoTemplate: template,
                                            id: layer.id + "_layer",
                                            name: layer.name,
                                            "mode": treeNode.mode || FeatureLayer.MODE_SNAPSHOT,
                                            opacity: layer.opacity > 0 ? layer.opacity / 100 : this.appUtils.configGeneralSettings.defaultOpacity / 100,    //JT, i don't think we need to divide by 100
                                            refreshInterval: layer.refresh > 0 ? layer.refresh : this.appUtils.configGeneralSettings.defaultRefRate
                                        });
                                        featurLayer.customLayerType = maptype;
                                        this.own(on(featurLayer, "mouse-over", lang.hitch(this, function (evt) {
                                            this.map.setMapCursor("pointer");
                                        })));
                                        this.own(on(featurLayer, "mouse-out", lang.hitch(this, function (evt) {
                                            this.map.setMapCursor("default");
                                        })));
                                        arrLayers.push(featurLayer);
                                        deferred.resolve(true);
                                    } else {
                                        //JT: is this for biz layer?
                                        //var refreshInt = layer.refresh > 0 ? layer.refresh : this.appUtils.configGeneralSettings.defaultRefRate;
                                        //if (layer.isRefAllLyr && layer.isRefAllLyr == 0)
                                        //    refreshInt = layer.isRefAllLyr;
                                        //var featurLayerForHeat = new FeatureLayer(layer.url, {
                                        //    outFields: ["*"],
                                        //    infoTemplate: template,
                                        //    id: layer.id + "_heatlayer",
                                        //    mode: layer.mode || FeatureLayer.MODE_SNAPSHOT,
                                        //    name: layer.name,
                                        //    opacity: layer.opacity > 0 ? layer.opacity / 100 : this.appUtils.configGeneralSettings.defaultOpacity / 100, //james - this may be for heat only so doesn't apply
                                        //    refreshInterval: refreshInt
                                        //});

                                        //featurLayerForHeat.customLayerType = maptype;
                                        //var colors = layer.heatRamp;
                                        //var heatmapRenderer = null;
                                        //if (colors) {
                                        //    heatmapRenderer = new HeatmapRenderer({
                                        //        colors: colors
                                        //    });
                                        //} else {
                                        //    heatmapRenderer = new HeatmapRenderer();
                                        //}

                                        //if (layer.geometryType !== "esriGeometryPolygon")
                                        //    featurLayerForHeat.setRenderer(heatmapRenderer);
                                        //else
                                        //    featurLayerForHeat.geometryType = layer.geometryType;
                                        //this.own(on(featurLayerForHeat, "mouse-over", lang.hitch(this, function (evt) {
                                        //    this.map.setMapCursor("pointer");
                                        //})));
                                        //this.own(on(featurLayerForHeat, "mouse-out", lang.hitch(this, function (evt) {
                                        //    this.map.setMapCursor("default");
                                        //})));
                                        //arrLayers.push(featurLayerForHeat);
                                        //deferred.resolve(true);
                                        //if (this.appUtils.configGeneralSettings.layerCount) {
                                        //    this.own(on(featurLayerForHeat, "update-end", lang.hitch(this, function (evt) {
                                        //        var currNode = dom.byId(featurLayerForHeat.id.replace("_cluster", "").replace("_heatlayer", "") + "_checkBox").parentNode.parentNode.parentNode;
                                        //        var currLengths = query("#clusterLength", currNode);
                                        //        if (currLengths)
                                        //            domConstruct.destroy(currLengths[0]);
                                        //        var valueNode = domConstruct.create("span", { id: "clusterLength", value: featurLayerForHeat.graphics.length, innerHTML: " [" + featurLayerForHeat.graphics.length + "]" });
                                        //        domConstruct.place(valueNode, currNode, "last");
                                        //        if (layer.postCreate && layer.postCreate != null)
                                        //            eval(layer.postCreate);
                                        //    })));
                                        //}
                                    }
                                } else {
                                    deferred.resolve(true);
                                }
                            }
                        }
                        deferredArray.push(deferred.promise);
                    }
                }));
                all(deferredArray).then(lang.hitch(this, function (resultLayers) {
                    if (arrLayers.length == 1 && arrLayers[0].geometryType && arrLayers[0].geometryType == "esriGeometryPolygon")
                        this.map.addLayer(arrLayers[0], 0);
                    else
                        this.map.addLayers(arrLayers);
                    this._attachLayerEvents(arrLayers);
                    deferredLayerAdded.resolve(true);
                }));
                all(deferredAllArray).then(lang.hitch(this, function (resultLayers) {
                    deferredAll.resolve(true);
                    // topic.publish("nc4ClusterIcons");
                }));
                return deferredAll.promise;
            },

            /**
             * Function to perform load event operation of GeoRss and Kml layer's.
             * @param {evt} evt - event
             * @param {Array} layerNode - Layer Node
             */

            //james update this to use NC4 Geometry Service
            /* this may not be needed, seems like the code calls project?
            _performLoadEventOperationOfCSVLayer: function(evt, layerNode) {
                //james implementation
                this.appUtils.log.debug("_loadeventoperation on csv layer");
                var params = new ProjectParameters();
                params.geometries = graphicsUtils.getGeometries(evt.layer.graphics);
                params.outSR = this.map.spatialReference;
    
                this._gsvc.project(params, evt.layer, function(p_geometries){
                    for(var i = 0; i < p_geometries.length; i++)
                    {
                        this.graphics[i].setGeometry(p_geometries[i]);
                    }
                    this.redraw();
                }, function(){
                    this._nc4Notify.error("unable to update projection for csv layer");
                });
                //end james' version of implementation
            },
            */
            //this gets called only in data layer tree, may not need this since the layer's should reproj on the fly
            //kml and georss are simliar in that they both go through an arcgis utility, which automatically calls project if applicable
            _performLoadEventOperationOfGeoRssAndKmlLayers: function (evt, layerNode) {

                //james implementation
                /*
                var params = new ProjectParameters();
                params.geometries = graphicsUtils.getGeometries(graphicsLayer.graphics);
                params.outSR = this.map.spatialReference;
                */
                //end james' version of implementation

                var mapSR = this.map.spatialReference,
                    layerOutSR = evt.layer._outSR,
                    isValidSR;
                if (mapSR.wkid) {
                    isValidSR = mapSR._isWebMercator() && layerOutSR._isWebMercator() || mapSR.wkid === layerOutSR.wkid;
                } else if (mapSR.wkt) {
                    isValidSR = mapSR.wkt === layerOutSR.wkt;
                } else {
                    layerNode[0].item.strike = "Yes";
                    html.addClass(layerNode[0].labelNode, "strikeout");
                    this._hideIcons(layerNode[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                    this._shelter.hide();
                    return;
                }
                if (!isValidSR) {
                    if (mapSR._isWebMercator() && 4326 === layerOutSR.wkid) {
                        var x = 0; //jshint ignore:line
                    } else if (layerOutSR._isWebMercator() && 4326 === mapSR.wkid) {
                        var x = 0; //jshint ignore:line
                    } else {
                        layerNode[0].item.strike = "Yes";
                        html.addClass(layerNode[0].labelNode, "strikeout");
                        this._hideIcons(layerNode[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                        this._shelter.hide();
                        return;
                    }
                }
                layerNode[0].item.strike = "No";
                html.removeClass(layerNode[0].labelNode, "strikeout");
                this._showIcons(layerNode[0].item.id);
                this.appUtils.boolBasemapChanged = false;
                this._shelter.hide();
            },

            /**
             * Function to start load event operations.
             * @param {evt} evt - event
             */
            _performLoadEventOperations: function (evt) {
                var name = evt.target.id;
                var id = name.replace("_layer", "");
                var layerNode = this._dataLayerTree.getNodesByItem(id);
                if (layerNode[0].item.type === "georss") {//|| layerNode[0].item.type === "kml"  - james - this is not needed, kml will re-project on the fly
                    this._performLoadEventOperationOfGeoRssAndKmlLayers(evt, layerNode);
                }
                else if (layerNode[0].item.type === "csv") {
                    //not needed at this point, issue is with POST to goemetry server
                    //_performLoadEventOperationOfCSVLayer(evt, layerNode);
                }
                //For cached layer
                if (evt.target.customLayerType === "arcgis_cached_service") {
                    array.forEach(this.map.layerIds, lang.hitch(this, function (layer) {
                        var objLayer = this.map.getLayer(layer);
                        if (objLayer.customLayerType === "arcgis_cached_service") {
                            var cachedLayerVisible = objLayer.visibleAtMapScale;
                            if (cachedLayerVisible === true) {
                                layerNode[0].item.strike = "No";
                                html.removeClass(layerNode[0].labelNode, "strikeout");
                                this._showIcons(layerNode[0].item.id);
                                this.appUtils.boolBasemapChanged = false;
                                this._shelter.hide();
                            } else {
                                layerNode[0].item.strike = "Yes";
                                html.addClass(layerNode[0].labelNode, "strikeout");
                                this._hideIcons(layerNode[0].item.id);
                                this.appUtils.boolBasemapChanged = false;
                                this._shelter.hide();
                            }
                        }
                    }));
                }
                this._shelter.hide();
            },

            /**
             * Function to start error event operations.
             * @param {evt} evt - event
             */
            _performErrorEventOperations: function (evt) {

                //JT: TODO  check for response code...if 404, maybe a time out occurred?

                if (evt.error.message === "Unable to draw graphic (null): Unable to complete  operation." || evt.error.message === "Unable to draw graphic (null): Cannot read property '0' of null") {
                    var layerId = evt.target.id;
                    var replacedId = layerId.replace("_layer", "");
                    if (replacedId) {
                        var objNode = this._dataLayerTree.getNodesByItem(replacedId);
                    }
                    if (objNode[0]) {
                        if (objNode[0].item.type === "arcgis_map_service") {
                            html.addClass(objNode[0].labelNode, "strikeout");
                            this._hideIcons(objNode[0].item.id);
                            objNode[0].item.strike = "Yes";
                            this.appUtils.boolBasemapChanged = false;
                            var parentId = objNode[0].item.parent;
                            var objParent = this._dataLayerTree.getNodesByItem(parentId);
                            this._checkPrentStrikeOut(parentId, objParent);
                        }
                        if (objNode[0].item.type === "csv") {
                            objNode[0].item.strike = "Yes";
                            this._checkCSVStrikeOutOperation(objNode[0].item);
                        }
                        this._shelter.hide();
                    }
                } else {
                    this._shelter.hide();
                }
            },

            /**
             * Function to attach events to layer's.
             * @param {array} arrLayers - Layers list.
             */
            _attachLayerEvents: function (arrLayers) {
                array.forEach(arrLayers, lang.hitch(this, function (layer) {
                    this.own(on(layer, "load", lang.hitch(this, "_performLoadEventOperations")));
                    this.own(on(layer, "error", lang.hitch(this, "_performErrorEventOperations")));
                }));
            },

            /**
             * Function to add wms layers from clicking on radio button/checkbox in layer tree
             * @param {object} treenode - tree Node
             */
            _wmsAddLayer: function (treenode) {

                var parentTreeNode = this._dataLayerTree.getNodesByItem(treenode.id);
                var className = parentTreeNode[0].labelNode.className;
                var removeLayerClass = className.indexOf("strikeout");
                if (removeLayerClass !== -1) {
                    html.removeClass(parentTreeNode[0].labelNode, "strikeout");
                    this._showIcons(parentTreeNode[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                }

                var strUrl = treenode.url,
                    strId = treenode.id,
                    strName = treenode.name,
                    opacity = treenode.opacity,
                    refresh = treenode.refresh;
                var subLayers = treenode["sub-layers"];

                //JT: if there are no child nodes, this is the initial check, add WMS to map and sub layer to tree:
                //before ever adding any layer , check if it exists first:
                var layerExists = this.map.getLayer(strId + "_layer");
                if (layerExists == null)
                    layerExists = this.map.getLayer("WebMapService_" + strId + "_layer");
                if (layerExists == null) {
                    //var wmsMgr = new WMSManager(strName, this.appUtils, this.map, strUrl, subLayers);
                    //wmsMgr._addWebMapService(this._shelter, 1, strId, false, false, parentTreeNode[0].item);
                }
            },

            /**
             * This function to add feature layer.
             * @param {string} strUrl - Url for map server.
             * @param {string} parentID - parentID for map server.
             * @param {string} layerName - layerName for map server.
             * @param {string} subLayers - subLayers for map server.
             * @param {string} opacity - opacity for map server.
             * @param {string} refreshInterval - refreshInterval for map server.
             */
            //JT This is called on initial load of the data layer tree

            _addFeatureLayer: function (strUrl, parentID, layerName, subLayers, opacity, refreshInterval) {

                var featurLayer, state = 0;
                var layerID = layerName + "_" + parentID + "_layer";
                var treeNodeID = layerName + "_" + parentID;
                if (strUrl.indexOf(location.hostname) >= 0)
                    esriConfig.defaults.io.alwaysUseProxy = false;
                else
                    esriConfig.defaults.io.alwaysUseProxy = true;
                var name = (layerName) ? layerName : this._layerName;
                featurLayer = new FeatureLayer(strUrl, {
                    outFields: ["*"],
                    //infoTemplate: template,
                    id: layerID,
                    name: layerName,
                    opacity: opacity,
                    refreshInterval: refreshInterval
                });
                featurLayer.customLayerType = "arcgis_map_service";
                if (subLayers) {
                    for (var i = 0; i < subLayers.length; i++) {

                        if (subLayers[i].toLowerCase() === layerName.toLowerCase()) {
                            this.map.addLayer(featurLayer);
                            state = 1;
                        }
                    }
                }
                //             else {
                //                this.map.addLayer(featurLayer);
                //                state = 1;
                //            }
                var webMapServerDynamicLayer = {
                    "type": "arcgis_map_service",
                    "url": strUrl,
                    "opacity": opacity,
                    "refresh": refreshInterval,
                    "bbox": 0,
                    "id": treeNodeID,
                    "name": name,
                    "state": state,
                    "sr": 102100,
                    "basemap": 0,
                    "parent": parentID,
                    "layerFromAddLayer": true
                };
                this.appUtils.customLayerAdded(webMapServerDynamicLayer);
                this.own(on(featurLayer, "load", lang.hitch(this, function (evt) {
                    esriConfig.defaults.io.alwaysUseProxy = false;
                    this._shelter.hide();
                    this.map.setExtent(evt.layer.fullExtent);                   //TODO: james - check this, setting to fullextent?
                    featurLayer.on("mouse-over", lang.hitch(this, function () {
                        this.map.setMapCursor("pointer");
                    }));
                    featurLayer.on("mouse-out", lang.hitch(this, function () {
                        this.map.setMapCursor("default");
                    }));
                    var contentinfo = new InfoTemplate(),
                        temdata = "";
                    contentinfo.setTitle("Attributes");
                    for (var i = 0; i < evt.layer.fields.length; i++) {
                        //TODO - James - allow users to customize pop-up ? maybe allow admins to set pop-up columns?
                        temdata = temdata + "<div style='font-weight: bold;max-width:150px;width:125px;float: left;'>" + evt.layer.fields[i].name + " </div> <div style='white-space: nowrap;line-height:5px'> ${" + evt.layer.fields[i].name + "}</div><br/>";
                    }
                    contentinfo.setContent("<div style='float:left'>" + temdata + "</div>");
                    featurLayer.setInfoTemplate(contentinfo);
                })));
                this.own(on(featurLayer, "error", lang.hitch(this, function (evt) {
                    esriConfig.defaults.io.alwaysUseProxy = false;
                    if (evt.error.message === "Unable to draw graphic (null): Unable to complete  operation.") {
                        var name = evt.target.id;
                        //var childName = name.replace(evt.target.name + "_", "");
                        var id = name.replace("_layer", "");
                        var layerNode = this._dataLayerTree.getNodesByItem(id);
                        if (layerNode[0]) {
                            layerNode[0].item.strike = "Yes";
                            //this.appUtils.boolBasemapChanged = true;
                            this.appUtils.layerAddedOnBasemap(true);
                        }
                        this._shelter.hide();
                    } else {
                        this._shelter.hide();
                    }
                })));
            },

            /**
             * Function to add feature collection layer.
             * @param {Object} layer - layer object.
             */
            _featureCollection: function (layer) {
                var requestHandle = esriRequest({
                    url: layer.url,
                    callbackParamName: "jsoncallback"
                });
                requestHandle.then(lang.hitch(this, function (data) {
                    var featureCollection,
                        featureLayer;
                    featureCollection = {
                        "layerDefinition": data.layerDefinition,
                        "featureSet": {
                            "features": [],
                            "geometryType": "esriGeometryPoint"
                        }
                    };
                    featureLayer = new FeatureLayer(featureCollection, {
                        outFields: ["*"],
                        id: layer.id + "_layer",
                        name: layer.name,
                        opacity: layer.opacity > 0 ? layer.opacity / 100 : this.appUtils.configGeneralSettings.defaultOpacity / 100,
                        refreshInterval: layer.refresh > 0 ? layer.refresh : this.appUtils.configGeneralSettings.defaultRefRate
                    });
                    featureLayer.customLayerType = "feature_collection";
                    this.map.addLayers([featureLayer]);
                    this.own(on(featureLayer, "mouse-over", lang.hitch(this, function (evt) {
                        this.map.setMapCursor("pointer");
                    })));
                    this.own(on(featureLayer, "mouse-out", lang.hitch(this, function (evt) {
                        this.map.setMapCursor("default");
                    })));
                    //setTimeout: loading of layers sometimes take time, so wait for 500seconds.
                    setTimeout(lang.hitch(this, function () {
                        var extent,
                            featuresList = [],
                            unionExtent = null;
                        array.forEach(data.features, lang.hitch(this, function (item) {
                            var geometry = new Point(item.geometry.x, item.geometry.y, this.map.spatialReference),
                                graphic;
                            graphic = new Graphic(geometry);
                            graphic.setAttributes(item.attributes);
                            extent = new Extent(graphic.geometry.x - 1, graphic.geometry.y - 1, graphic.geometry.x + 1, graphic.geometry.y + 1, graphic.geometry.spatialReference);
                            if (unionExtent) {
                                unionExtent = unionExtent.union(extent);
                            } else {
                                unionExtent = new Extent(graphic.geometry.x - 1, graphic.geometry.y - 1, graphic.geometry.x + 1, graphic.geometry.y + 1, graphic.geometry.spatialReference);
                            }
                            featuresList.push(graphic);
                        }));
                        this.map.setExtent(unionExtent);
                        featureLayer.applyEdits(featuresList, null, null);
                        this._LayerId++;
                        this._shelter.hide();
                    }), 500);
                }), lang.hitch(this, function (error) {
                    this._shelter.hide();
                    this._nc4Notify.error(sharedNls.AddLayer.errorMessages.featureCollectionError + error);
                }));

            },

            /**
             * Function to delete custom layer.
             * @param {Object} layerIds - layer object.
             */
            _deleteCustomLayer: function (layerIds) {
                if (layerIds.parent) {
                    if (layerIds.parent === "customLayers") {
                        var deletePromtMessage = this._alertBox.confirm(sharedNls.DataLayer.conformToDelete);
                        deletePromtMessage.then(lang.hitch(this, function (res) {
                            esriRequest({
                                url: this.config.CustomLayerDeleteService,
                                content: lang.mixin({
                                    customLayerID: layerIds.id
                                }, null),
                                callbackParamName: "callback",
                                load: lang.hitch(this, function () {
                                    if (this.map.getLayer(layerIds.id + "_layer")) {
                                        this.map.removeLayer(this.map.getLayer(layerIds.id + "_layer"));
                                    } else if (this.map.getLayer(layerIds.id)) {
                                        this.map.removeLayer(this.map.getLayer(layerIds.id));
                                    }
                                    else {

                                        var childNodes = this._dataLayerTreeStore.query({
                                            parent: layerIds.id
                                        });
                                        array.forEach(childNodes, lang.hitch(this, function (node) {
                                            if (node.url) {
                                                var childLayer = this.map.getLayer(node.id + "_layer");
                                                if (childLayer) {
                                                    this.map.removeLayer(childLayer);
                                                }
                                            }
                                        }));

                                    }
                                    this._nc4Notify.success(sharedNls.DataLayer.deleteLayer);
                                    this._dataLayerTreeStore.remove(layerIds.id);
                                    var deleteLayerName = this.appUtils.customLayerName.indexOf(layerIds.name);
                                    if (deleteLayerName >= 0) {
                                        this.appUtils.customLayerName.splice(deleteLayerName, 1);
                                    }
                                    var deleteServiceLayerName = this.appUtils.customLayerServiceName.indexOf(layerIds.name);
                                    if (deleteServiceLayerName >= 0) {
                                        this.appUtils.customLayerServiceName.splice(deleteLayerName, 1);
                                    }
                                }),
                                error: lang.hitch(this, function (err) {
                                    this._nc4Notify.error(err);
                                })
                            });
                        }));
                    }
                }
            },

            /**
             * Function to execute the strikeout operation for image layer
             * @param {Object} checkNode - Object having detail of specific tree node, which is clicked.
             */
            _strikeOutOpereationOfImage: function (checkNode) {
                var basemap = this.map.getLayer(this.map.layerIds[0]);
                var basemapSR = basemap.spatialReference.wkid;
                if (basemapSR === 102100 && 4326) {
                    checkNode[0].item.strike = "No";
                } else {
                    checkNode[0].item.strike = "Yes";
                }
                if (checkNode[0].checkbox.className === "checked") {
                    if (checkNode[0].item.strike === "Yes") {
                        var imageLayerId = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                        html.addClass(imageLayerId[0].labelNode, "strikeout");
                        this._hideIcons(imageLayerId[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }
                if (checkNode[0].checkbox.className === "unchecked") {
                    if (checkNode[0].item.strike === "No") {
                        var layerClass = checkNode[0].checkbox.className;
                        var removeLayerClass = layerClass.indexOf("strikeout");
                        if (removeLayerClass !== -1) {
                            var imageId = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                            html.removeClass(imageId[0].labelNode, "strikeout");
                            this._showIcons(imageId[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                        }
                    }
                }
            },

            /**
             * Remove layers from the map
             * @param {Array} layerIds - Ids of layers to remove from map.
             * @returns {deferred.promise}
             */
            _removeLayers: function (layerIds) {
                var deferred = new Deferred();
                array.forEach(layerIds, lang.hitch(this, function (layer) {
                    var layerNode = this.map.getLayer(layer);

                    if (layerNode != null) {
                        try {
                            if (layerNode.currentExecute)
                                layerNode.currentExecute.cancel();
                            if (layerNode.currentExecuteSD)
                                layerNode.currentExecuteSD.cancel();
                        }
                        catch (error) { }
                    }
                    if (layerNode) {
                        var bool = false;
                        if (this.lastEditedOverlayId) {
                            bool = this.lastEditedOverlayId + "_layer" === layerNode.id ? true : false;
                            this.appUtils.editOverlayLayerId = null;
                        }
                        if (dom.byId("editFeaturesMainContainer") && bool) {
                            domConstruct.destroy("editFeaturesMainContainer");
                        }
                        this.map.removeLayer(layerNode);
                        this.map.infoWindow.hide();
                    } else {
                        var layerId = layer;
                        if (layerId.indexOf("_heatlayer") > 0) {                            //custom layer gets here ...ie dynamic map service sub lyr
                            layerId = layerId.replace("_heatlayer", "_layer");

                        } else if (layerId.indexOf("_cluster") > 0) {
                            layerId = layerId.replace("_cluster", "_heatlayer");

                        }
                        if (this.map.getLayer(layerId)) {
                            this.map.removeLayer(this.map.getLayer(layerId));
                        }
                    }
                    topic.publish("layer_removed", layer);
                }));
                deferred.resolve(true);
                topic.publish("nc4ClusterIcons_RL");
                // this.appUtils.refreshLegend(true);
                return deferred.promise;
            },

            /**
             * Function to Request the data layer tree service.
             */
            _getDataTreeJSON: function () {
                var deferredArray = [],
                    arrLayerList = [];

                if (this.config.LayerTreeService) {
                    arrLayerList.push(this.config.LayerTreeService);                //data layer tree datalayertree layertree
                }
                if (this.config.CustomLayerTreeService) { //randy added to remove other layers request
                    arrLayerList.push(this.config.CustomLayerTreeService);
                }
                array.forEach(arrLayerList, lang.hitch(this, function (url) {
                    var deferred = new Deferred();
                    esriRequest({
                        url: url,
                        content: lang.mixin({
                            f: "jsonp",
                            mode: this.appUtils.configGeneralSettings.mapMode || "standard"
                        }, null),
                        callbackParamName: "callback",
                        load: lang.hitch(this, function (response) {
                            deferred.resolve(response);                 //resolve: passes any results to the callback, 2nd argument is opt, is currently false (will not throw error if promise is fullfilled
                        }),
                        error: lang.hitch(this, function (err) {
                            deferred.resolve(false);
                        })
                    });
                    deferredArray.push(deferred.promise);
                }));
                all(deferredArray).then(lang.hitch(this, function (responseResults) {    //takes all promises, combine into one
                    this.appUtils.log.debug("responseResults: ", responseResults);
                    //responseResults contains DataLayerGroups JS Array (contains all data layer group, plus the layers that makes up the group / leaf nodes (which has the URL to 
                    //          feature service))
                    var count = 0;
                    var allFeatures = [];

                    //This is basically cloning the responseResults array into the allFeatures Array.
                    array.forEach(responseResults, lang.hitch(this, function (result) {
                        allFeatures = allFeatures.concat(result);
                    }));
                    this._processDataTreeJSON(allFeatures, count);
                }));
            },

            /**
             * Construct root node for data layer tree.
             * @param {Object} response - JSON object having detail for data layer tree.
             * @param {string} count - count value._processDataTreeJSON
             */
            _processDataTreeJSON: function (response, count) {
                globalConfig.allMapLayers = ['nc4CL'];//There is nc4CL cluster layer existing on the map when page is loading.
                for (var j = 0; j < response.length; j++) {
                    array.forEach(response[j].DataLayerGroups, lang.hitch(this, function (item, i) { //iterating through each data layer group (ie Eteam, custom layers, rc layers...etc)
                        //Randy:get all data layers for cluster on the map
                        if (item.id == "eteam") {
                            for (var m = 0; m < item.layers.length; m++) {
                                globalConfig.allMapLayers.push(item.layers[m].id + '_cluster');
                            }
                        }
                        else {//set custome layers opacity with 0.5 as default.
                            for (var n = 0; n < item.layers.length; n++) {
                                item.layers[n].opacity = 0.5;
                            }
                        }

                        this._layerData.push({                                                      //pushing root node into the _layerData array.
                            id: item.id,
                            name: item.name,
                            parent: "datalayergroups"
                        });
                        this._getDataLayerTreeItem(item, item.id);
                    }));
                }
                //if (this.appUtils.configGeneralSettings.dlOpt && this.appUtils.configGeneralSettings.dlOpt == 1) {
                //    //this.titlePaneDataOptions.startup();
                //    //var dOpt = new DataOptions(this.titlePaneDataOptions, this.map, this.appUtils.configGeneralSettings.dlOptHaloLyrs, this.appUtils.configGeneralSettings.showTravelerInfoLyr, this.appUtils.configGeneralSettings.acknowledgeProximityLyr, this._layerData);
                //}
                this._displayDataLayerTree(count);
            },

            /**
             * Construct child for data layer tree.
             * @param {Object} item - Object having detail of specific tree node.
             * @param {String} parentId - Parent node id of child node.
             */
            _getDataLayerTreeItem: function (item, parentId) {       //ie: item=eteam datalayer group obj, parentId = eteam



                if (item.groups.length) {                           //ie: if the datalayer group contains groups itself (subgroups - incident, site, etc..)
                    array.forEach(item.groups, lang.hitch(this, function (group, i) {
                        this._layerData.push({                      //push those group into the _layerData array as well.
                            "id": group.id,
                            "name": group.name,
                            "parent": parentId,
                            "heatMap": group.heatMap
                        });
                        if (group.layers.length !== 0) {

                            //TODO JT: load service details ahead of time for all in group
                            /*
                            if(group.isGroupService)
                            {
                                var url = group.groupServiceUrl;
                                this.cluster.addGroupService(url, group.id);
                            }
                            */
                            this._getDataLayerTreeItem(group, group.id);
                        }
                    }));
                }
                if (item.layers.length !== 0) {                     //if there exist layers directly under the datalayer group (call center, tips...)
                    array.forEach(item.layers, lang.hitch(this, function (layer, i) {
                        if (layer != null) {
                            layer.parent = parentId;
                            this._layerData.push(layer);                //push the actual layer object into the _layerData array as well.
                        }

                    }));
                }
            },

            /**
             * Construct and display data layer tree.
             * @param {string} count - count value.
             * @returns {treeNode}
             */
            _displayDataLayerTree: function (count) {

                var parentIds = [];
                var itemObjects = {};
                var myClassInstance = this;
                require([
                    "dojo/store/Memory",
                    "dojo/store/Observable",
                    "dijit/tree/ObjectStoreModel",
                    "dijit/Tree"
                ], lang.hitch(this, function (Memory, Observable, ObjectStoreModel, Tree) {
                    var arrayLayers = [],
                        arrStrikedLayers = [],
                        turnOnLayers = [],
                        _saveService = this.config.CustomLayerSaveService,
                        _deleteService = this.config.CustomLayerDeleteService,
                        _overlayDeleteService = this.config.OverlayDeleteService,
                        _overlayUpdateService = this.config.OverlayUpdateService;
                    if (this.appUtils.customLayerCollection) {
                        this._layerData = this._layerData.concat(this.appUtils.customLayerCollection);      //if there are custom layers, add to _layerData array as well
                    }
                    if (this.appUtils.mapServerLayers) {
                        this._layerData = this._layerData.concat(this.appUtils.mapServerLayers);            //James - these are arcgis map server layers, they are already added to custom layer list
                    }                                                                                                           //so not sure if we need to add thiem to mapServerLayers list (maybe for basemaps?)


                    //This store seems to be a client side implementation.  It is provided with the data as a JS object
                    this._dataLayerTreeStore = new Memory({
                        data: this._layerData,
                        getChildren: function (object) {                                                                         //james - the getChildren method returns all records w/ parent = to the passed in object
                            return this.query({                                                                                 //   getChildren only returns children directly below (no grandchildren)
                                parent: object.id
                            });
                        }
                    });
                    this._dataLayerTreeStore = new Observable(this._dataLayerTreeStore);                                        //adds notifications of data changes
                    this._dataLayerTreeModel = new ObjectStoreModel({                                                           //will connect dijit.Tree to a dojo.store 
                        store: this._dataLayerTreeStore,
                        query: {
                            id: "datalayergroups"
                        }
                    });

                    this._dataLayerTree = new Tree({
                        model: this._dataLayerTreeModel,
                        autoExpand: true,
                        showRoot: false,
                        id: "dataLayerTree",
                        _createTreeNode: function (args) {
                            var toggleDeleteNode,
                                toggleClusterHeatMaps,
                                toggleClusterSettingNode,
                                toggleClusterZoomNode,
                                saveNode,
                                treeNode,
                                treeNodeCheckBox;
                            treeNode = new Tree._TreeNode(args);
                            if (args.item.strike) {
                                html.addClass(treeNode.labelNode, "strikeout");
                                arrStrikedLayers.push(treeNode.item.id);
                                if (treeNode.item.type === "arcgis_map_service" || treeNode.item.type === "arcgis_dynamic_service" || treeNode.item.type === "wms") { //i think we want to add arcgis_dyanimc_service here
                                    arrayLayers.push(treeNode.item); //arrayLayers is used to strike out for parent layers (so should be fore feature services, wms, and arcgis dynamic layers
                                }
                            } else {
                                html.removeClass(treeNode.labelNode, "strikeout");
                            }
                            var currNodeId = args.item.id;
                            //if(args.item.parent)
                            //currNodeId = args.item.parent + currNodeId;
                            treeNodeCheckBox = html.create("div", {
                                "id": currNodeId + "_checkBox"
                            }, null);
                            if (treeNode.item.parent == "eteam" || treeNode.label == "ActivWeather and Fire Data") {
                                parentIds.push(currNodeId);
                            }
                            domClass.add(treeNodeCheckBox, (treeNode.item.state === 1) ? "checked" : "unchecked");              //james - determines on/off state of layer, checks the checkbox
                            domConstruct.place(treeNodeCheckBox, treeNode.labelNode, "first");
                            if (args.item.parent) {
                                if (args.item.parent === "eteam") {                                                             //TODO: this is critical, remove 'eteam'
                                    if (args.item.heatMap === 1) {                                                              //james - can turn off heat map here
                                        toggleClusterHeatMaps = html.create("div", {
                                            "id": currNodeId + "_toggleClusterHeatMapIcon",
                                            "title": "Create Heat Map For Layer"
                                        }, null);
                                        domClass.add(toggleClusterHeatMaps, "clusterHeatMaps");
                                        domConstruct.place(toggleClusterHeatMaps, treeNode.labelNode);
                                        on(toggleClusterHeatMaps, "click", function () {
                                            var treeNode = registry.getEnclosingWidget(this.parentNode);                        //registry - stores all widgets w/in page.  This returns closes widget to passed in dom node - parent node in this case
                                            topic.publish("/cluster/HeatMaps", [{                                               //fire event, "/cluster/HeatMaps" - which performs the heat map mode
                                                "clusterHeatMaps": this,
                                                "item": treeNode.item
                                            }]);
                                        });
                                    }
                                }
                            }
                            itemObjects[treeNode.item.id] = treeNode.item;
                            if (currNodeId == "eteam") {
                                var allLayers = this._itemNodesMap;
                                topic.subscribe("refreshLayer", lang.hitch(this, function (pLid, p_hideP) {

                                    var lyr = myClassInstance.map.getLayer(pLid);
                                    if (lyr._refreshGraphics)
                                        lyr._refreshGraphics(p_hideP);
                                    else {
                                        var plidKey = pLid.replace("_cluster", "").replace("_heatlayer", "")
                                        if (lyr != undefined) {
                                            topic.publish("/checkbox/doubleclicked", [{
                                                "checkbox": dom.byId(plidKey + "_checkBox"),
                                                "item": itemObjects[plidKey]
                                            }]);
                                        }
                                    }
                                }));
                                toggleRefreshAll = html.create("div", {
                                    "id": currNodeId + "_toggleRefreshAllIcon",
                                    "title": "Refresh All Layers"
                                }, null);
                                domClass.add(toggleRefreshAll, "refreshAll");
                                domConstruct.place(toggleRefreshAll, treeNode.labelNode);
                                on(toggleRefreshAll, "click", function () { //auto-refresh
                                    while (dom.byId("clusterLength"))
                                        domConstruct.destroy("clusterLength");
                                    for (var key in allLayers) {
                                        var clusterDetail = myClassInstance.map.getLayer(key + "_cluster");
                                        if (clusterDetail == undefined || clusterDetail == null) {
                                            clusterDetail = myClassInstance.map.getLayer(key + "_heatlayer");
                                        }
                                        if (clusterDetail != undefined) {
                                            if (clusterDetail._refreshGraphics)
                                                clusterDetail._refreshGraphics();
                                            else {
                                                topic.publish("/checkbox/doubleclicked", [{
                                                    "checkbox": dom.byId(key + "_checkBox"),
                                                    "item": itemObjects[key]
                                                }]);
                                            }

                                        }
                                    }
                                });
                            }
                            if (args.item.geometryType) {
                                if (args.item.geometryType === "esriGeometryPoint" || args.item.geometryType === "esriGeometryPolygon") {                                           //if the layer is a point layer, add the zoom to extent button
                                    if (myClassInstance.appUtils.configGeneralSettings.toggleZoomCluster) {
                                        toggleClusterZoomNode = html.create("div", {
                                            "id": currNodeId + "_toggleZoomClusterIcon",
                                            "title": "Zoom To Layer"
                                        }, null);
                                        domClass.add(toggleClusterZoomNode, "clusterZoomTo");
                                        domConstruct.place(toggleClusterZoomNode, treeNode.labelNode);
                                        on(toggleClusterZoomNode, "click", function () {
                                            var treeNode = registry.getEnclosingWidget(this.parentNode);
                                            topic.publish("/cluster/ZoomTo", [{                                                     //on click of the zoom to extent, fire event '/cluster/ZoomTo' event
                                                "clusterZoomTo": this,
                                                "item": treeNode.item,
                                                "title": "Zoom to Layer"
                                            }]);
                                        });
                                    }
                                    /*toggleClusterSettingNode = html.create("div", {
                                        "id": currNodeId + "_toggleSettingClusterIcon",
                                        "title": "Layer Settings"
                                    }, null);
                                    domClass.add(toggleClusterSettingNode, "clusterSetting");
                                    domConstruct.place(toggleClusterSettingNode, treeNode.labelNode, "last");
                                    on(toggleClusterSettingNode, "click", function() {                                          //add cluster button, register on click event
                                        var treeNode = registry.getEnclosingWidget(this.parentNode);
                                        topic.publish("/cluster/settings", [{
                                            "clusterSettings": this.parentNode,
                                            "item": treeNode.item
                                        }]);
                                    });*/
                                }
                            }
                            if (args.item.parent === "customLayers" || args.item.parent === "nc4gisSamples" || (currNodeId != null && currNodeId.indexOf("nc4gisSamples") >= 0)) {
                                if (!args.item.layerFromAddLayer) {                                                             //if saved custom layer, add delete button and register event
                                    /*if (_deleteService &&  args.item.parent !== "nc4gisSamples" && (currNodeId != null && currNodeId.indexOf("nc4gisSamples") < 0 ) ) {
                                        toggleDeleteNode = html.create("div", {
                                            "id": currNodeId + "_deleteIcon"
                                        }, null);
                                        domClass.add(toggleDeleteNode, "deleteLayer");
                                        domConstruct.place(toggleDeleteNode, treeNode.labelNode, "last");
                                        on(toggleDeleteNode, "click", function() {
                                            var treeNode = registry.getEnclosingWidget(this.parentNode);
                                            topic.publish("/delete/clicked", [{
                                                "delete": this,
                                                "item": treeNode.item
                                            }]);
                                        });
                                    }*/

                                    if (args.item.parent == "nc4gisSamples" && (currNodeId != null && currNodeId.indexOf("nc4gisSamples") < 0))
                                    { }
                                    else {
                                        if (myClassInstance.appUtils.configGeneralSettings.toggleZoomCluster) {
                                            toggleClusterZoomNode = html.create("div", {
                                                "id": currNodeId + "_toggleZoomClusterIcon",
                                                "title": "Zoom To Layer"
                                            }, null);
                                            domClass.add(toggleClusterZoomNode, "clusterZoomTo");
                                            domConstruct.place(toggleClusterZoomNode, treeNode.labelNode);
                                            on(toggleClusterZoomNode, "click", function () {
                                                var treeNode = registry.getEnclosingWidget(this.parentNode);
                                                topic.publish("/customLayers/ZoomTo", [{
                                                    "zoomTo": this,
                                                    "item": treeNode.item
                                                }]);
                                            });
                                        }

                                        toggleClusterSettingNode = html.create("div", {                                             //add cluster icon? I think this is disabled + why is the name 'toggleClusterSettingNode'
                                            "id": currNodeId + "_toggleSettingClusterIcon",
                                            "title": "Layer Settings"
                                        }, null);
                                        domClass.add(toggleClusterSettingNode, "clusterSetting");
                                        domConstruct.place(toggleClusterSettingNode, treeNode.labelNode, "last");
                                        on(toggleClusterSettingNode, "click", function () {
                                            var treeNode = registry.getEnclosingWidget(this.parentNode);
                                            topic.publish("/customLayers/settings", [{
                                                "settings": this.parentNode,
                                                "item": treeNode.item
                                            }]);
                                        });
                                    }

                                } else {
                                    /*if (_saveService && args.item.parent !== "nc4gisSamples"  && (currNodeId != null &&  currNodeId.indexOf("nc4gisSamples") < 0)) {
                                        saveNode = html.create("div", {
                                            "id": currNodeId + "_saveIcon"
                                        }, null);
                                        domClass.add(saveNode, "saveLayer");
                                        domConstruct.place(saveNode, treeNode.labelNode, "last");
                                        on(saveNode, "click", function() {
                                            var treeNode = registry.getEnclosingWidget(this.parentNode);
                                            topic.publish("/save/clicked", [{
                                                "save": this,
                                                "item": treeNode.item
                                            }]);
                                        });
                                    }
                                    if (_deleteService && args.item.parent !== "nc4gisSamples"  && (currNodeId != null && currNodeId.indexOf("nc4gisSamples") < 0)) {
                                        toggleDeleteNode = html.create("div", {
                                            "id": currNodeId + "_deleteIcon"
                                        }, null);
                                        domClass.add(toggleDeleteNode, "deleteLayer");
                                        domConstruct.place(toggleDeleteNode, treeNode.labelNode, "last");
                                        on(toggleDeleteNode, "click", function() {
                                            var treeNode = registry.getEnclosingWidget(this.parentNode);
                                            topic.publish("/delete/clicked", [{
                                                "delete": this,
                                                "item": treeNode.item
                                            }]);
                                        });
                                    }*/
                                    if (myClassInstance.appUtils.configGeneralSettings.toggleZoomCluster) {
                                        toggleClusterZoomNode = html.create("div", {
                                            "id": currNodeId + "_toggleZoomClusterIcon",
                                            "title": "Zoom To Layer"
                                        }, null);
                                        domClass.add(toggleClusterZoomNode, "clusterZoomTo");
                                        domConstruct.place(toggleClusterZoomNode, treeNode.labelNode);
                                        on(toggleClusterZoomNode, "click", function () {
                                            var treeNode = registry.getEnclosingWidget(this.parentNode);
                                            topic.publish("/customLayers/ZoomTo", [{
                                                "zoomTo": this,
                                                "item": treeNode.item
                                            }]);
                                        });
                                    }
                                    /*toggleClusterSettingNode = html.create("div", {
                                        "id": currNodeId + "_toggleSettingClusterIcon",
                                        "title": "Layer Settings"
                                    }, null);
                                    domClass.add(toggleClusterSettingNode, "clusterSetting");
                                    domConstruct.place(toggleClusterSettingNode, treeNode.labelNode, "last");
                                    on(toggleClusterSettingNode, "click", function() {
                                        var treeNode = registry.getEnclosingWidget(this.parentNode);
                                        topic.publish("/customLayers/settings", [{
                                            "settings": this.parentNode,
                                            "item": treeNode.item
                                        }]);
                                    });*/
                                }
                            } else if (args.item.parent === "nc4maps_overlays") {
                                if (_overlayUpdateService) {
                                    var toggleEditOverlays = html.create("div", {
                                        "id": currNodeId + "_toggleOverlayEditIcon"
                                    }, null);
                                    domClass.add(toggleEditOverlays, "overlayEdit");
                                    domConstruct.place(toggleEditOverlays, treeNode.labelNode);
                                    on(toggleEditOverlays, "click", function () {
                                        var treeNode = registry.getEnclosingWidget(this.parentNode);
                                        topic.publish("/overlays/Edit", [{
                                            "clusterOverlays": this,
                                            "item": treeNode.item
                                        }]);

                                    });
                                }
                                if (myClassInstance.appUtils.configGeneralSettings.toggleZoomCluster) {
                                    var toggleOverlaysZoomNode = html.create("div", {
                                        "id": currNodeId + "_toggleZoomClusterIcon",
                                        "title": "Zoom To Layer"
                                    }, null);
                                    domClass.add(toggleOverlaysZoomNode, "clusterZoomTo");
                                    domConstruct.place(toggleOverlaysZoomNode, treeNode.labelNode);
                                    on(toggleOverlaysZoomNode, "click", function () {
                                        var treeNode = registry.getEnclosingWidget(this.parentNode);
                                        topic.publish("/overlays/ZoomTo", [{
                                            "clusterZoomTo": this,
                                            "item": treeNode.item
                                        }]);
                                    });
                                }
                                var toggleOverlaysSettingNode = html.create("div", {
                                    "id": currNodeId + "_toggleoverlaySettingIcon"
                                }, null);
                                domClass.add(toggleOverlaysSettingNode, "overlaySetting");
                                domConstruct.place(toggleOverlaysSettingNode, treeNode.labelNode, "last");
                                on(toggleOverlaysSettingNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/overlays/settings", [{
                                        "overlaySetting": this.parentNode,
                                        "item": treeNode.item
                                    }]);
                                });
                                /*if (_overlayDeleteService) {
                                    var toggleOverlaysDeleteNode = html.create("div", {
                                        "id": currNodeId + "_deleteIcon"
                                    }, null);
                                    domClass.add(toggleOverlaysDeleteNode, "deleteLayer");
                                    domConstruct.place(toggleOverlaysDeleteNode, treeNode.labelNode, "last");
                                    on(toggleOverlaysDeleteNode, "click", function() {
                                        var treeNode = registry.getEnclosingWidget(this.parentNode);
                                        topic.publish("/deleteOverlays/clicked", [{
                                            "delete": this,
                                            "item": treeNode.item
                                        }]);
                                    });
                                }
                                if (_overlayUpdateService) {
                                    var toggleOverlaysSaveNode = html.create("div", {
                                        "id": currNodeId + "_saveIcon"
                                    }, null);
                                    domClass.add(toggleOverlaysSaveNode, "saveRefreshLayerHide");
                                    domConstruct.place(toggleOverlaysSaveNode, treeNode.labelNode, "last");
                                    on(toggleOverlaysSaveNode, "click", function() {
                                        var treeNode = registry.getEnclosingWidget(this.parentNode);
                                        topic.publish("/OverlaySave/clicked", [{
                                            "save": this,
                                            "item": treeNode.item
                                        }]);
                                    });
                                }*/
                            }
                            on(treeNodeCheckBox, "click", function () {
                                var treeNode = registry.getEnclosingWidget(this.parentNode);                                                            //on tree node (layer) onclick, fire event
                                topic.publish("/checkbox/clicked", [{
                                    "checkbox": this,
                                    "item": treeNode.item
                                }]);
                            });

                            if (treeNode.item.state === 1 || treeNode.item.state === 3) {
                                turnOnLayers.push(treeNode);
                                setTimeout(lang.hitch(this, function () {
                                    topic.publish("checkParents", [treeNode.item, true]);
                                }), 1000);
                            }
                            return treeNode;
                        }                                                                                                                               //END _createNode()
                    }, this._dataLayerTreeNode);                                                                                                                            //END Tree() constructor (for Data Layer Tree view)
                    this._dataLayerTree.startup();                                                                                          //startup() will display the widget
                    this._dataLayerTree.onLoadDeferred.then(lang.hitch(this, function () {
                        //if (this.appUtils.configGeneralSettings.rd && this.appUtils.configGeneralSettings.rd != null &&
                        //    this.appUtils.configGeneralSettings.rd.length > 0) {
                        //    this.titlePaneDataList.startup();
                        //    var dlist = new DataList(this.titlePaneDataList);
                        //}
                        //else {
                        //    try {
                        //        dijit.byId("titlePaneDataList").destroy();
                        //    }
                        //    catch (e) {
                        //        try {
                        //            dijit.byId("dijit_TitlePane_2").destroy();
                        //        }
                        //        catch (f) {
                        //            console.log("unable to remove recent data div");
                        //        }
                        //    }

                        //}

                        this._turnOnLayers(turnOnLayers);                                                                                   //turns on all layers that had state = 1.
                        //this._doStrikeOutOperation();                  
                        this._strikeOutForParentLayers(arrayLayers);
                        this._performStrikeOutOfLayerAddedFromAddlayer(arrStrikedLayers);
                        array.forEach(parentIds, lang.hitch(this, function (nodeId) {
                            this._dataLayerTree._collapseNode(this._dataLayerTree.getNodesByItem(nodeId)[0]);
                        }));
                        setTimeout(lang.hitch(this, function () {
                            this._dataLayerTree.set("path", ["datalayergroups", "eteam"]);                                                  //set path - needs the array of item Id's (necessary to expand the tree to the specific nodes and select those nodes
                            this.appUtils.customLayerCollection = [];                                                                       //      path-the path to expand to (may not be needed since no datalayergroup?)
                            //html.setStyle(this.hideNode, "display", "none");
                            html.setStyle(this.domNode, "overflow", "auto");
                            this._shelter.hide();
                        }), 1000);

                        //clapse all layers in mobile device
                        setTimeout(lang.hitch(this, function () {
                            if (globalConfig.isDockPopupMode) {
                                this._dataLayerTree.collapseAll();
                            }
                        }), 500);


                    }));


                }));
            },

            /**
             * Function to turn on the layer if layer state = 1.
             * @param {array} turnOnLayers - Array of layers.
             */
            _turnOnLayers: function (turnOnLayers) {

                array.forEach(turnOnLayers, lang.hitch(this, function (node) {
                    var layerNode = this._dataLayerTree.getNodesByItem(node.item.id);
                    //this._checkBoxClicked(layerNode);
                    this._checkHierarchicalNodes(layerNode[0].item, true);
                }));
            },

            /**
             * Function to perform strikeout operation of layers which are added from addlayer widget.
             * @param {array} arrLayers - Array of layers.
             */
            _performStrikeOutOfLayerAddedFromAddlayer: function (arrLayers) {
                array.forEach(arrLayers, lang.hitch(this, function (layerId) {
                    this._hideIcons(layerId);
                }));
            },

            /**
             * Function to execute strikeout for parent node while adding layer from addlayer
             * @param {array} arrayLayers - array contains layer list which are striked out.
             */
            _strikeOutForParentLayers: function (arrayLayers) {
                array.forEach(arrayLayers, lang.hitch(this, function (layerNode) {
                    var parentId = layerNode.parent;
                    var parentNode = this._dataLayerTree.getNodesByItem(parentId);
                    if (parentNode[0]) {
                        this._checkPrentStrikeOut(parentId, parentNode);
                    }
                }));
            },

            /**
             * Decide to show cluster layer or point layer.
             * @param {Array} clusterDetail - Array of objects having detail for clustering.
             * @returns {deferred.promise}
             */
            _manageCluster: function (clusterDetail) {

                this.appUtils.log.debug("_manageCluster(): clusterDetail ", clusterDetail);
                var arrAddLayers = [],
                    arrDeferred = [],
                    arrRemoveLayers = [],
                    deferred = new Deferred();
                for (var i = 0; i < clusterDetail.length; i++) {
                    //IF biz layer, nothing gets added to arrAddLayers, so _addLayers doesn't get called.
                    this.appUtils.log.debug("_manageCluster, entering for loop");
                    if (clusterDetail[i].isClustered) {
                        this.appUtils.log.debug("_manageCluster, curr clusterDetail: ", clusterDetail[i]);
                        if (this.map.getLayer(clusterDetail[i].clusterDetail.id + "_layer")) {
                            arrRemoveLayers.push(clusterDetail[i].clusterDetail.id + "_layer");
                        }
                        if (this.map.getLayer(clusterDetail[i].clusterDetail.id + "_cluster")) {
                            arrRemoveLayers.push(clusterDetail[i].clusterDetail.id + "_cluster");
                        }
                        if (this.map.getLayer(clusterDetail[i].clusterDetail.id + "_heatlayer")) {
                            arrRemoveLayers.push(clusterDetail[i].clusterDetail.id + "_heatlayer");
                        }

                        //since clusterFeatureLayer doesn't support polygons yet, dont use our current Cluster:
                        if (clusterDetail[i].clusterDetail.geometryType == "esriGeometryPolygon")
                            arrAddLayers.push(clusterDetail[i].clusterDetail);
                        else
                            arrDeferred.push(this.setIntervalForClusters(this.map, clusterDetail[i].clusterDetail));
                    } else {
                        arrAddLayers.push(clusterDetail[i].clusterDetail);
                        if (this.map.getLayer(clusterDetail[i].clusterDetail.id + "_cluster")) {
                            arrRemoveLayers.push(clusterDetail[i].clusterDetail.id + "_cluster");
                        }
                    }
                }
                if (arrAddLayers.length) {
                    arrDeferred.push(this._addLayers(arrAddLayers));
                }
                if (arrRemoveLayers.length) {
                    arrDeferred.push(this._removeLayers(arrRemoveLayers));
                }
                all(arrDeferred).then(lang.hitch(this, function (result) {
                    deferred.resolve(result);
                }));
                return deferred.promise;
            },

            /**
             * Display the widget panel.
             */
            show: function () {

                if (!this.isOpen) {

                    domClass.add(this.widgetIcon, "widgetIconFullOpacity");
                    this._panel.show();
                    this.isOpen = true;
                    this.appUtils.sidePanelOpen(this.isOpen);

                } else {
                    this.hide();
                }


            },

            /**
             * Hide the widget panel
             */
            hide: function () {

                this.isOpen = false;
                esriConfig.defaults.io.alwaysUseProxy = false;
                domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
                if (this._panel) {
                    this._panel.hide();
                    this.appUtils.sidePanelOpen(this.isOpen);
                }
                this.appUtils.getTreeNodeForBasemap(this._dataLayerTreeStore);
            },

            /**
             * Setting the widget panel position.
             */
            _placeWidgetContainer: function () {
                var widgetPanelPosition;
                if (this._widgetPosition) {
                    widgetPanelPosition = this._widgetPosition;
                } else {
                    widgetPanelPosition = {
                        right: 0,
                        top: 41,
                        height: 100 + "%"
                    };
                }
                this._panel = new WidgetPanel({
                    position: widgetPanelPosition,
                    id: "Panel_" + this.config.label
                });
                this._panel.startup();
                html.place(this.domNode, this._panel.widgetContainer);

            },

            /**
             * Attach widget related events
             */
            _attachWidgetRelatedEvents: function () {
                on(this.map, "click", lang.hitch(this, function () { this.hide() }));   //james
                on(window, "resize", lang.hitch(this, function () {
                    this._panel.resize();
                }));
            },
            setIntervalForOverlays: function (layer) {

                if (!this.map.getLayer(layer.id + "_layer")) {
                    this.addOverlayLayer(layer);
                }
                var myClassInstance = this;

                var refRateCleaned = 0;
                if (layer.refresh > 0)
                    refRateCleaned = layer.refresh * 60000;
                else {
                    if (this.appUtils.configGeneralSettings.defaultRefRate > 0)
                        refRateCleaned = this.appUtils.configGeneralSettings.defaultRefRate * 60000;
                    else
                        refRateCleaned = 9999 * 60000; //if 0, then set to large # since this is a custom implementation
                }
                var interval = setInterval(function () {
                    if (myClassInstance.map.getLayer(layer.id + "_layer")) {
                        myClassInstance.addOverlayLayer(layer);
                    }
                }, parseInt(refRateCleaned));  //james - overlay layer refresh applied
                var result = true;
                if (this.arrIntervalForOverlays.length > 0) {
                    for (var i = 0; i < this.arrIntervalForOverlays.length; i++) {
                        if (this.arrIntervalForOverlays[i].id === layer.id) {
                            clearInterval(this.arrIntervalForOverlays[i].interval);
                            this.arrIntervalForOverlays[i].interval = interval;
                            result = false;
                        }
                    }
                }
                if (result) {
                    var intervalValue = {
                        "id": layer.id,
                        "interval": interval
                    };
                    this.arrIntervalForOverlays.push(intervalValue);
                }

            },
            addOverlayLayer: function (layer) {
                if (this.map.getLayer(layer.id + "_layer")) {
                    this.map.removeLayer(this.map.getLayer(layer.id + "_layer"));
                }
                var graphicsLayer = new GraphicsLayer({
                    "id": layer.id + "_layer",
                    "addedType": "graphics",
                    "opacity": layer.opacity > 0 ? layer.opacity / 100 : this.appUtils.configGeneralSettings.defaultOpacity / 100,  //James - overlay layer opacity applied
                    infoTemplate: new InfoTemplate("Attributes", layer.popupContent)
                });
                graphicsLayer.overlayCustomLayerType = layer.name;
                graphicsLayer.layerFrom = "overlay";
                this.map.addLayer(graphicsLayer);
                this.appUtils.overlayLayersAdded(layer);
                graphicsLayer.enableMouseEvents();
                esriRequest({                               //james - request to grab the actual graphics that makes up the layer, then add it to the layer.
                    url: layer.url,
                    content: lang.mixin({
                        f: "jsonp"
                    }),
                    callbackParamName: "callback",
                    load: lang.hitch(this, function (response) {
                        this.appUtils.log.debug("overlay layer response: ", response);
                        if (response.graphics) {
                            var json = JSON.parse(response.graphics);
                            for (var i = 0; i < json.length; i++) {
                                var graphic = new Graphic(json[i]);
                                graphicsLayer.add(graphic);
                            }

                            var params = new ProjectParameters();
                            params.geometries = graphicsUtils.getGeometries(graphicsLayer.graphics);
                            params.outSR = this.map.spatialReference;

                            this._gsvc.project(params, graphicsLayer, function (p_geometries) {
                                for (var i = 0; i < p_geometries.length; i++) {
                                    this.graphics[i].setGeometry(p_geometries[i]);
                                }
                            }, function () {
                                this._nc4Notify.error("unable to update projection for: " + this.name);
                            });
                        }
                        this._shelter.hide();
                    }),
                    error: lang.hitch(this, function (err) {
                        this._shelter.hide();
                        this._nc4Notify.error(err);
                    })
                });
                graphicsLayer.on("mouse-over", lang.hitch(this, function () {
                    this.map.setMapCursor("pointer");
                }));
                graphicsLayer.on("mouse-out", lang.hitch(this, function () {
                    this.map.setMapCursor("default");
                }));
            },

            setIntervalForClusters: function (map, clusterDetail) {


                if (!this.map.getLayer(clusterDetail.id + "_cluster")) {
                    if (clusterDetail.opacity == 0)                                              //james - opacity will be 0 only if defaulted from server.  app allows you to set to as low as 0.1.  So default to default app value
                        clusterDetail.opacity = this.appUtils.configGeneralSettings.defaultOpacity;
                    this.Cluster.addClusters(this.map, clusterDetail);                          //james adding feature to cluster? - cluster layer opacity applied
                }
                //var myClassInstance = this;
                //var map = this.map;

                //var refRateCleaned = 0;
                //if (clusterDetail.refresh > 5)
                //    refRateCleaned = clusterDetail.refresh * 60000;
                //else {
                //    if (this.appUtils.configGeneralSettings.defaultRefRate > 5)
                //        refRateCleaned = this.appUtils.configGeneralSettings.defaultRefRate * 60000;
                //    else
                //        refRateCleaned = 5 * 60000; //if refresh rate is 0, set to large number here since this is custom implementation (not esri)
                //}

                //if (clusterDetail.isRefAllLyr && clusterDetail.isRefAllLyr == 1) {
                //    var interval = setInterval(function () {
                //        var lyr = myClassInstance.map.getLayer(clusterDetail.id + "_cluster");
                //        if (lyr != null) {      //jt: Todo: does it delete the old layer?
                //            if (lyr._refreshGraphics) {
                //                lyr._refreshGraphics();
                //            }
                //            else {
                //                myClassInstance.Cluster.addClusters(map, clusterDetail);
                //            }
                //        }

                //    }, parseInt(refRateCleaned));   //TODO - james: cluster layer refresh applied. 
                //}


                //var result = true;
                //if (this.appUtils.arrIntervalForClusters.length > 0) {
                //    for (var i = 0; i < this.appUtils.arrIntervalForClusters.length; i++) {
                //        if (this.appUtils.arrIntervalForClusters[i].id === clusterDetail.id) {
                //            clearInterval(this.appUtils.arrIntervalForClusters[i].interval);
                //            this.appUtils.arrIntervalForClusters[i].interval = interval;
                //            result = false;
                //        }
                //    }
                //}
                //if (result) {
                //    var intervalValue = {
                //        "id": clusterDetail.id,
                //        "refresh": refRateCleaned,                          //NOTE: layer itself does not have this attribute, so add a custom attribute:
                //        "interval": interval
                //    };
                //    this.appUtils.arrIntervalForClusters.push(intervalValue);
                //}
            }

        });
    });
