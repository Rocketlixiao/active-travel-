define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "esri/layers/ArcGISDynamicMapServiceLayer",
    "esri/urlUtils"
], function(declare, lang, ArcGISDynamicMapServiceLayer, urlUtils) {
	return declare([], {

		/*
		 * This is a class to encapsulate utility methods for an ArcGIS Dynamic Service
		 * 
		 */
		
		_layerName: "",
		appUtils: null,
		map: null,
		_url: "",
		_shelter: null,
		nc4Notify: null,
		LayerId: null,
		
		_visibleLyrIds: null,
		_useDefaultVisibilities: null,
		_serviceDetails: null,
		
		//provided URL to a map service
		constructor: function(p_serviceName, p_appUtils, p_map, p_url, p_layerIdCount, p_shelter, p_arrVisibleLyrIds, p_arrUseDefaultVisibilities, p_serviceDetails)
		{
			this.appUtils = p_appUtils;
			this._layerName = p_serviceName;
			this.map = p_map;
			this._url = p_url;
			this.nc4Notify = this.appUtils.nc4Notify;
			this.LayerId = p_layerIdCount;
			this._shelter = p_shelter;
			
			this._visibleLyrIds = p_arrVisibleLyrIds;
			this._useDefaultVisibilities = p_arrUseDefaultVisibilities;
			if(p_serviceDetails)
				this._serviceDetails = p_serviceDetails;
		},
		
		/*method to take care of turning on layers of the service
		 * p_subLayers: layerInfos from the actual ArcGISDynamicLayer from the JS API,
		 * p_parentLyr: actual parent layer object used to set visibility
		 * 
		 */
		_addSubLayersToMap3: function(p_subLayers, p_parentLyr)
		{
			if(p_subLayers == null)
				return;
			
			var visibleLayers = [];
			var addAll = false;
			if(this._visibleLyrIds != null && this._visibleLyrIds.length == 1 && this._visibleLyrIds[0] == "_ALL_")
                addAll = true;
            
			if(this._useDefaultVisibilities == true)
			{
				for(var i = 0; i < p_subLayers.length; i++)
				{
					var currSubLyr = p_subLayers[i];
					
					//if the sub layer has sub layers, skip it since it will be accounted for
					if(currSubLyr.subLayerIds && currSubLyr.subLayerIds.length > 0)
						continue;
					
					else if(currSubLyr.defaultVisibility && currSubLyr.defaultVisibility == true) //defaultVisibility from service's metadata
	                	visibleLayers.push(currSubLyr.id);
				}
			}
			else
				if(addAll == true)
				{
					for(var i = 0; i < p_subLayers.length; i++)
					{
						var currSubLyr = p_subLayers[i];
						
						//if the sub layer has sub layers, skip it since it will be accounted for
						if(currSubLyr.subLayerIds && currSubLyr.subLayerIds.length > 0)
							continue;
						
						visibleLayers.push(currSubLyr.id);
					}
					
				}
				else
					visibleLayers = this._visibleLyrIds;
			
			if(visibleLayers.length <= 0)
				visibleLayers.push(-1);
			
			p_parentLyr.setVisibleLayers(visibleLayers);
		},
		
		
		/*
		 * method to take care of adding sublayers of the dynamic service to the data layer widget (data layer widget subscribes to event appUtils.customLayerAdded)
		 * p_subLayers: list of sublayer ids to turn on
		 * p_parentId: actual parent layer id
		 */
		_addSubLayersInfoToTree: function(p_subLayers, p_parentId)
		{
			if(p_subLayers == null)
				return;
			
			for(var i = 0; i < p_subLayers.length; i++)
			{
				var currSubLyr = p_subLayers[i];
				
				//ignore sublayers of sublayers as an entry in the tree, since the sublayer's sublayers will appear later in the array
				if(currSubLyr.subLayerIds && currSubLyr.subLayerIds.length > 0)
					continue;
				
				var subLyrURL = this._url + "/" + currSubLyr.id;
				
	        	var defaultVisibility = false;
	        	if(this._useDefaultVisibilities && this._useDefaultVisibilities == true)
	        		defaultVisibility = this._useDefaultVisibilities;
	        	else if(this._visibleLyrIds && this._visibleLyrIds.length == 1 && this._visibleLyrIds[0] == "_ALL_")
	        		defaultVisibility = true; //turn on parent and all sub lyrs
	        	else if(this._visibleLyrIds && this._visibleLyrIds.length > 0)
	        	{
	        		var currId = currSubLyr.id;
	        		if(typeof currSubLyr.id == "number")
	        			currId = currId.toString()
	        		if(this._visibleLyrIds.indexOf(currId) >= 0)
	        			defaultVisibility = true;
                }
                //if current layer has defaultVisibility, set it with the variable defaultVisibility
                if (currSubLyr.defaultVisibility != undefined)
                {
                    currSubLyr.defaultVisibility = defaultVisibility;
                }
				this._addSubLayerMetaOnly(currSubLyr.name, currSubLyr.id, this.appUtils, this.map, subLyrURL, p_parentId, defaultVisibility);
			}
			
		},
		
		/*
		 * helper functo to add single sub layer to data layer widget
		 */
		_addSubLayerMetaOnly: function(p_subLayerName, p_layerIdCount, p_appUtils, p_map, p_url, p_parentId, p_defaultVisibility) {
	        this.treeNodeID = p_parentId + "_" + p_layerIdCount;
	        
	        var state=0;
	        if(this._serviceDetails != null && this._serviceDetails.state)
	        	state = this._serviceDetails.state || 0;
	        else if(p_defaultVisibility == true)
	        	state = 1;
	        else
	        	state = 0;
	        
	        var opacity = 1;
	        if(this._serviceDetails != null)
	        	opacity = this._serviceDetails.opacity || 1;
	        else
	        	opacity = this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1;

	        var refresh = 5;
	        if(this._serviceDetails != null)
	        	refresh = this._serviceDetails.refresh || 5;
	        else
	        	refresh = parseInt(this.appUtils.configGeneralSettings.defaultRefRate) || 5;
	        
	        var subLayerInfo = {
	                "type": "arcgis_dynamic_service",			//should we create a sub layer type?
	                "url": p_url,
	                "opacity": opacity,
	                "refresh": refresh || 0,
	                "bbox": 0,
	                "id": this.treeNodeID,
	                "name": p_subLayerName,
	                "state": state,
	                "sr": this.map.spatialReference.wkid,
	                "basemap": 0,
	                "parent": p_parentId,
	                "layerFromAddLayer": true,
	                "isSubLayer": true
	         };
	            
	         setTimeout(lang.hitch(this, function() {
	            this.appUtils.customLayerAdded(subLayerInfo);
	            this.appUtils.customLayerNameAdded(this._layerName);
	         }), 1000);
	    },
		
	    
	    /*
	     * function to add dynamic service as parent layer, to data layer tree only (does not add layer to map)
	     */
		_addDynamicServiceInfoToTree: function()
		{
			if (this._url.indexOf("MapServer") !== -1) {
                this.mapServerTreeNodeID = "arcgis_dynamic_service" + this._layerName;
                var webMapServerDynamicLayer = {
                    "id": this.mapServerTreeNodeID,											//type + given name
                    "name": this._layerName,
                    "state": 1,
                    "parent": "customLayers",
                    "layerFromAddLayer": true,
                    "type": "arcgis_dynamic_service",
                    "url": this._url,
                    "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,
                    "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0
                };
                
                this.appUtils.customLayerCount++;
                this.appUtils.customLayerAdded(webMapServerDynamicLayer);
                this.appUtils.customLayerNameAdded(this._layerName);
			}
		},
		
		/*
		 * function to add dynamic service as single layer onto the map
		 * p_mapServerTreeNodeId: id of this parent layer
		 * p_addSubLyrsToTree: boolean to specify if we need to add the sub layers to the data layer widget (it may have been added already)
		 * p_addSubLyrsToMap: boolean to specify if we need to add the sub layers to the map (it may have been added already)
		 */
		_addDynamicMapServer3: function(p_mapServerTreeNodeId, p_addSubLyrsToTree, p_addSubLyrsToMap) {
            if (this._url.indexOf("MapServer") >= 0) {
                this._count = 0;
                if (this._url.indexOf("MapServer/") !== -1) { //TODO: should probably check if there exist any thing after (in case user accidentally left '/' in.
                   /*           
                    var process = this._addFeatureLayer(strUrl, "customLayers", "", "arcgis_map_service"); //assuming feature layer, can't do this.
                    process.then(lang.hitch(this, function(evt) {
                        this._shelter.hide();
                    }));*/
                } 
                else if (this._url.indexOf("MapServer") !== -1) 
                {
                	urlUtils.addProxyRule({
                  	  urlPrefix: this._url,
                  	  proxyUrl: this.appUtils.configGeneralSettings.proxyPageURL //"/nc4maps/proxy.jsp"
                  	});
                    var layer = new ArcGISDynamicMapServiceLayer(this._url,{
                    	id: p_mapServerTreeNodeId || this.mapServerTreeNodeID
                    });
                     
                    //for dynamic services, let the sub layers determine what shows up initially.
                    var newVisibleLyrs = [];
                    
                    //if some visible lyr ids were initiallyu passed in, set it here, if not, set nothing
                    if(this._visibleLyrIds != null && this._visibleLyrIds.length > 0)
                    	layer.setVisibleLayers(this._visibleLyrIds);
                    else
                    {
                    	newVisibleLyrs.push(-1);
                        layer.setVisibleLayers(newVisibleLyrs);
                    }
                    layer.customLayerType = "arcgis_dynamic_service";
                    if(this._serviceDetails && this._serviceDetails.popupCleanseAction)
                    	layer.popupCleanseAction = this._serviceDetails.popupCleanseAction;
                    if(this._serviceDetails && this._serviceDetails.opacity)
                    	layer.setOpacity(this._serviceDetails.opacity);
                    if(this._serviceDetails && this._serviceDetails.refresh)
                    	layer.setRefreshInterval(this._serviceDetails.refresh);
                    this.map.addLayer(layer);
                    
                    try
                    {
                    	document.getElementById("Cached").disabled = false;
                        document.getElementById("Dynamic").disabled = false;
                    }
                    catch(error)
                    {//no need to do anything
                    }
                    
                    this.addSubLyrsToTree = p_addSubLyrsToTree;
                    this.addSubLyrsToMap = p_addSubLyrsToMap;
                    if( p_mapServerTreeNodeId != null )	
                    	this.mapServerTreeNodeID = p_mapServerTreeNodeId;
                    this.layer = layer;
                    
                    layer.on('load', lang.hitch(this, function(p_loadedLayer)
                    {
                        
                        var layerInfos = p_loadedLayer.layer.layerInfos;
                        if(this.addSubLyrsToTree && this.addSubLyrsToTree == true)
                        	this._addSubLayersInfoToTree(layerInfos, this.mapServerTreeNodeID)
                      
                        if(this.addSubLyrsToMap && this.addSubLyrsToMap == true)
                            this._addSubLayersToMap3(layerInfos, this.layer);
                                    
                        this._shelter.hide();
                    }));
                }
            } else {
                this._shelter.hide();
                this.nc4Notify.warn(sharedNls.AddLayer.errorMessages.invalidURLError);
            }
        }
	});
});