define([
    "dojo/_base/declare",
    "dojo/parser",
    "dojo/topic",
    "dojo/ready",
    "dojo/_base/array",
    "dojo/_base/Color",
    "dojo/dom-style",
    "dojo/query",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/Deferred",
    "esri/map",
    "esri/request",
    "esri/graphic",
    "esri/geometry/Extent",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/symbols/SimpleLineSymbol",
    "esri/symbols/SimpleFillSymbol",
    "esri/symbols/PictureMarkerSymbol",
    "esri/renderers/ClassBreaksRenderer",
    "esri/layers/GraphicsLayer",
    "esri/SpatialReference",
    "esri/dijit/PopupTemplate",
    "esri/geometry/Point",
    "esri/geometry/webMercatorUtils",
    "app/widgets/DataLayers/ClusterFeatureLayer",
    "app/widgets/Notifications/NC4Notification",
    "dijit/_Widget",
    "dijit/_WidgetBase",
    "dojo/dom",
    "dojo/dom-construct",
    "dojo/dom-attr",
    "lodash/lodash",
    "dojo/domReady!"
], function(declare,
    parser, topic, ready, arrayUtils, Color, domStyle, query, lang, on, Deferred,
    Map, esriRequest, Graphic, Extent,
    SimpleMarkerSymbol, SimpleLineSymbol, SimpleFillSymbol, PictureMarkerSymbol, ClassBreaksRenderer,
    GraphicsLayer, SpatialReference, PopupTemplate, Point, webMercatorUtils,
    ClusterFeatureLayer, NC4Notification, _Widget, _WidgetBase, dom, domConstruct, domAttr, _
) {

    return declare([_WidgetBase], {
    	_clusterDataLoading: [],
    	_dataLayerLoadingInfo: null,
    	_nc4Notify: null,
    	_cacheServiceDetails: [],
    	_dataLayerLoadingError: null,
    	/*
    	addGroupService: function(p_url, p_service)
    	{
    		
    	},*/
    	
        addClusters: function(map, resp) {
            var colorValues = []; // array to hold the RGBA values for symbol color
            colorValues.push(new Color([9, 34, 119, 0.25]));
            colorValues.push(new Color([56, 87, 55, 0.25]));
            colorValues.push(new Color([0, 184, 255, 0.25]));
            colorValues.push(new Color([60, 216, 118, 0.25]));
            colorValues.push(new Color([249, 60, 26, 0.25]));
            colorValues.push(new Color([60, 255, 0, 0.25]));
            colorValues.push(new Color([227, 0, 255, 0.25]));
            colorValues.push(new Color([0, 17, 255, 0.25]));
            var colorValuesBackground = []; // array to hold the background RGBA values for symbol color
            colorValuesBackground.push(new Color([9, 34, 119, 0.5]));
            colorValuesBackground.push(new Color([56, 87, 55, 0.5]));
            colorValuesBackground.push(new Color([0, 184, 255, 0.5]));
            colorValuesBackground.push(new Color([60, 216, 118, 0.5]));
            colorValuesBackground.push(new Color([249, 60, 26, 0.5]));
            colorValuesBackground.push(new Color([60, 255, 0, 0.5]));
            colorValuesBackground.push(new Color([227, 0, 255, 0.5]));
            colorValuesBackground.push(new Color([0, 17, 255, 0.5]));
            var intValue = this.getRandomInt(0, 7); //get random number between 0 to 7
            // Symbol for the cluster
            this._singleSym = this._singleSym ||
                new SimpleMarkerSymbol(
                    SimpleMarkerSymbol.STYLE_CIRCLE, 14,
                    new SimpleLineSymbol(
                        SimpleLineSymbol.STYLE_SOLID,
                        new Color([intValue, intValue, 0]), 2
                    ),
                    new Color([0, 191, 255, 0.75])
                );
            
            var gIds = "";
            this.gIdsKeepNew = [];
            if (map.getLayer(resp.id + "_cluster")) {
            	//must be a refresh, capture graphics ids and remove
            	var currLyr = map.getLayer(resp.id + "_cluster");
            	var gLen = currLyr.graphics.length;
            	var gIds = "";
            	for(var i =0; i< gLen; i++)
            	{
            		if(map.halo && map.halo == "click")
                	{
                		//keep array of items to keep highlighted
                		try{
                        	
                			var currObjtype = currLyr.graphics[i].attributes.objtype;
                			if(currObjtype != null && currObjtype.indexOf("highlight") >= 0)
                			{
                				this.gIdsKeepNew.push(currLyr.graphics[i].id);
                			}
                		}catch(error){log.error(error);}
                	}
            		gIds += currLyr.graphics[i].id;
            		if(i < gLen - 1)
            			gIds += ",";
            	}
                map.removeLayer(currLyr);
			}
            
            //potential clustering solution:
            // using current
            //  update this method to hold reference to one clusterfeaturelayer
            //  then add to the clusterfeaturelayer an array, that holds the URLs of all of its data source (layers)
            //	create a refresh function w/in clusterfeaturelayer that can be called from clustering
            //  update _onIdsReturned to query all uRLs in its datasource array
            //	update _onFeaturesReturned to concat all features from all datasources
            //  update pop-up function to iterate through all features in cluster layer.
            //	keep array of datasource/map of name of layer to datasource, to be used in intersect widget as well as legend widget
            //	no new layers will ever be created, just added to this one layer.
            //  may need to update other widgets
            
            
            //using old ol
            // always create separate layers.
            // create additional cluster layer.
            // add to cluster layer, hide from other layers
            // should not need to update other widgets.
            
            // create only one layer some how, similiar to first solution.
            // in _addLayers in data layer tree, never create a new layer.  Instead, request for data, put into graphcis layer
            // use cluster feature layer logic on graphics layer
            // this is going down the path of the firs option
            // generate cluster layer from feature service url.
            
            
            //cache Feature Layer endpoint
            
            
            if (resp.url) {
                
                var clusterLayer = new ClusterFeatureLayer({
                    "url": resp.url,
                    "distance": 100,
                    "service": resp.parent || "",
                    "isGroupService": resp.isGroupService || "",
                    "id": resp.id.indexOf("_cluster") >= 0 ? resp.id : resp.id + "_cluster",
                    "name": resp.name,
                    "labelColor": "#fff",
                    "resolution": map.extent.getWidth() / map.width,
                    "singleColor": "#888",
                    "zoomOnClick": false,
                    "useDefaultSymbol": true,
                    "popupInfo": resp.popupInfo,
                    "popupEndpoint": resp.popupEndpoint,
                    "spatialReference" : map.spatialReference,	//Done: JAMES NEED TO ADD SPATIAL REFERENCE HERE, THIS IS IMCOMPLETE, OR FIGURE OUT HOW TO GET IT IN THE CLUSTERFEATURELAYER>JS
                    "clientProjectOnly" : resp.clientProjectOnly || false,		//This is to turn off re-projection on the server if we know we are only converting from lat lon to web mercator
                    "appUtils" : this.appUtils,
                    "gIds": gIds,
                    "gIdsKeepNew": this.gIdsKeepNew,
                    "popW": resp.popW || 270,
                    "popH": resp.popH || 710,
                    "mode": resp.mode || "snapshot",
                    "cacheServiceDetails": this._cacheServiceDetails,
                    "visibleLyrs": resp.visibleLayers || resp.visibleLyrs || null,
                    "isPin": resp.isPin || 0
                    //"MODE_SNAPSHOT" : false
                });

                gIds="";
                //create renderer for the particular value
                var renderer = new ClassBreaksRenderer(this._singleSym, "clusterCount");
                var small = new SimpleMarkerSymbol("circle", 20,
                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, colorValues[intValue], 10),
                    colorValuesBackground[intValue]);
                var medium = new SimpleMarkerSymbol("circle", 30,
                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, colorValues[intValue], 10),
                    colorValuesBackground[intValue]);
                var large = new SimpleMarkerSymbol("circle", 50,
                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, colorValues[intValue], 10),
                    colorValuesBackground[intValue]);
                renderer.addBreak(2, 10, small);
                renderer.addBreak(10, 25, medium);
                renderer.addBreak(25, 2500000, large);
                clusterLayer.setRenderer(renderer);
                var deferred = new Deferred();
                
                this.own(on(clusterLayer, "details-loaded", lang.hitch(this, function(evt) {
                    deferred.resolve(evt);
                })));
                this.own(on(clusterLayer, "load-data", lang.hitch(this, function(evt) {
                	var options = {
                    		"showMethod": "slideDown",
                    		"hideMethod": "slideUp",
                    		"closeMethod": "slideUp",
                    		"preventDuplicates": true,
                    		"timeOut": 0,
                    		"extendedTimeOut": 0,
                    		"progressBar": true,
                    		"onclick": null,
                    		"positionClass":  "toast-bottom-right",
                    		"tapToDismiss": true
                    	};
                    	this._nc4Notify = new NC4Notification();	//all this is doing is updating the options
                    	if(this._clusterDataLoading.indexOf(clusterLayer.id) < 0)
                    		this._clusterDataLoading.push(clusterLayer.id);
                    	if(this._dataLayerLoadingInfo == null)
                    		this._dataLayerLoadingInfo = this._nc4Notify.info2(options, "info", "Data Layers", "<i>Loading Data</i>");
                })));
                
                this.own(on(clusterLayer, "load-done", lang.hitch(this, function(p_clusterLayrId) {
            		console.info("p_clusterLayrId: " , p_clusterLayrId);
            		
            		
        				var pos = arrayUtils.indexOf(this._clusterDataLoading, p_clusterLayrId);
        				if(pos >= 0)
        					this._clusterDataLoading.splice(pos, 1);
        				if(this._clusterDataLoading.length <= 0 )
        				{
        					if( this._dataLayerLoadingInfo != null )
        					{
        						this._nc4Notify.hide(this._dataLayerLoadingInfo);
        						this._dataLayerLoadingInfo = null;
                                if(query(".widget-Intersect").length > 0){
                                    require(["dijit/registry"], function(registry){
                                        var intersectWidget = registry.byId("app/widgets/Intersect/Intersect");
                                        intersectWidget._getLayersOnMap();
                                    });
                                }
                                if(!map.isDrillDown && map.infoWindow != null && map.infoWindow.features != null && map.infoWindow.features[0] != null && map.infoWindow.features[0].cluster)
                                    map.infoWindow.hide()
        					}
        					
        					topic.publish("nc4ClusterIcons", true);
        				}  
        				if( this._dataLayerLoadingError != null )
        				{
        					this._nc4Notify.hide(this._dataLayerLoadingError);
            				this._dataLayerLoadingError = null;
        					
        				}
                })));
                this.own(on(clusterLayer, "cluster-count", lang.hitch(this, function(p_Cluster) {           
                        var currNode = dom.byId(p_Cluster.lyrId.replace("_cluster", "").replace("_heatlayer", "") + "_checkBox");

                        if (currNode != null && !globalConfig.isFilterApplied && globalConfig.multipleFilters[0].IsCurrent)
	                    {
                        	try
                        	{
                        		currNode = currNode.parentNode.parentNode.parentNode;
    	                        var clusterLength = p_Cluster.clusterLength;
    	                        if(clusterLength == null || clusterLength == undefined)
                                    clusterLength = 0;
                                domConstruct.destroy("clusterLength_" + p_Cluster.lyrId);
                                var valueNode = domConstruct.create("span", { id: "clusterLength_" + p_Cluster.lyrId, value: clusterLength, innerHTML: " [" + clusterLength + "]" });
    	                        domConstruct.place(valueNode, currNode, "last");  
                        	}
                        	catch(error){}
                        }
                })));
                
                this.own(on(clusterLayer, "load-cancel", lang.hitch(this, function(p_clusterLayr) {
    				var pos = arrayUtils.indexOf(this._clusterDataLoading, p_clusterLayr.id);
    				if(pos >= 0)
    				{
    					this._clusterDataLoading.splice(pos, 1);
    				}
    				if(this._clusterDataLoading.length <= 0 && this._dataLayerLoadingInfo != null)
    				{
    					this._nc4Notify.hide(this._dataLayerLoadingInfo);
    					this._dataLayerLoadingInfo = null;
    				}
    		
            })));
                
                this.own(on(clusterLayer, "load-error", lang.hitch(this, function(p_clusterLayr) {
        				var pos = arrayUtils.indexOf(this._clusterDataLoading, p_clusterLayr.id);
        				if(pos >= 0)
        				{
        					this._clusterDataLoading.splice(pos, 1);
        					var lyrName = p_clusterLayr.name;
        					var lyrId = p_clusterLayr.id;
        					if(this._dataLayerLoadingError == null)
        						this._dataLayerLoadingError = this._nc4Notify.error("Error Loading Layer(s)");
        				}
        				if(this._clusterDataLoading.length <= 0 && this._dataLayerLoadingInfo != null)
        				{
        					this._nc4Notify.hide(this._dataLayerLoadingInfo);
        					this._dataLayerLoadingInfo = null;
        					topic.publish("nc4ClusterIcons", true);
        				}
        		
                })));
                
                
                clusterLayer.on("mouse-over", lang.hitch(this, function() {
                    map.setMapCursor("pointer");
                }));
                clusterLayer.on("mouse-out", lang.hitch(this, function() {
                    map.setMapCursor("default");
                }));
                clusterLayer.setOpacity(resp.opacity / 100); //apputils not defined, test this first
                map.addLayer(clusterLayer);
                // this.log.info("Clustered Layer added"+clusterLayer.id);
                // move the infoWindow to the selected feature 
                map.infoWindow.on("selection-change", this.getSelectedFeatureInfo);
                // close the info window when the map is clicked
                map.on("click", this.cleanUp);
                // close the info window when esc is pressed
                map.on("key-down", function(e) {
                    if (e.keyCode === 27) {
                        this.cleanUp();
                    }
                });
                return deferred.promise;
            }
        },

        /**
         * Moves the infoWindow to the selected feature
         */
        getSelectedFeatureInfo: function() {
            var featureExtent,
                graphic = this.map.infoWindow.getSelectedFeature();
            if (graphic) {
                this.map.infoWindow.show(graphic.geometry);
                if (graphic.geometry.type && graphic.geometry.type !== "point") {
                    featureExtent = graphic.geometry.getExtent();
                    //this.map.setExtent(featureExtent);//Commented this line to stop map from zoom-in to polygon feature.
                } else {
                    this.map.centerAt(graphic.geometry);
                }
            }
        },

        /**
         * Returns the random integer between min and max values
         */
        getRandomInt: function(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        },

        /**
         * Removes infoWindow and single graphics for the cluster
         */
        cleanUp: function() {
            for (var j = 0, jl = this.graphicsLayerIds.length; j < jl; j++) {
                if (this.graphicsLayerIds[j] != "esriGraphicLayer" && this.graphicsLayerIds[j] != "bingGraphicLayer" && this.graphicsLayerIds[j].indexOf("_cluster") != -1) {
                    var currentLayer = this.getLayer(this.graphicsLayerIds[j]);
                    if (currentLayer._singles.length > 0) {
                        this.infoWindow.hide();
                        this.infoWindow.clearFeatures();
                        arrayUtils.forEach(currentLayer._singles, function(g) {
                            currentLayer.remove(g);
                        }, currentLayer);
                        currentLayer._singles.length = 0;
                    }
                }
            }
        }
    });
});
