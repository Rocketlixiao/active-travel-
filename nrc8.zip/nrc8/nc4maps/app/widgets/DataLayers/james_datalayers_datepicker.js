define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/on",
    "dojo/dom",
    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/dom-class",
    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/topic",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/text!./DataLayers.html",
    "dojo/text!./DataLayers.json",
    "dijit/TooltipDialog",
    "dijit/popup",
    "dijit/form/ValidationTextBox",
    "dijit/form/Button",
    "dijit/form/HorizontalSlider",
    "dijit/registry",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "esri/request",
    "esri/layers/FeatureLayer",
    "esri/InfoTemplate",
    "esri/layers/KMLLayer",
    "esri/layers/MapImage",
    "esri/layers/GraphicsLayer",
    "esri/renderers/HeatmapRenderer",
    "esri/layers/WMSLayer",
    "esri/geometry/Point",
    "esri/graphic",
    "esri/graphicsUtils",
    "esri/geometry/Extent",
    "esri/tasks/QueryTask",
    "esri/tasks/query",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/AlertBox/AlertBox",
    "app/widgets/LoadingShelter/LoadingShelter",
    "app/widgets/DataLayers/Clustering",
    "esri/layers/ArcGISTiledMapServiceLayer"
], function (
    declare,
    html,
    lang,
    array,
    on,
    dom,
    aspect,
    domConstruct,
    domClass,
    Deferred,
    all,
    topic,
    sharedNls,
    template,
    dataTreeDetail,
    TooltipDialog,
    Popup,
    ValidationTextBox,
    Button,
    HorizontalSlider,
    registry,
    _WidgetBase,
    _TemplatedMixin,
    esriRequest,
    FeatureLayer,
    InfoTemplate,
    KMLLayer,
    MapImage,
    GraphicsLayer,
    HeatmapRenderer,
    WMSLayer,
    Point,
    Graphic,
    graphicsUtils,
    Extent,
    EsriQueryTask,
    EsriQuery,
    WidgetPanel,
    AlertBox,
    LoadingShelter,
    Clustering,
    ArcGISTiledMapServiceLayer
) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "DataLayers",
        baseClass: "widget-DataLayers",
        sharedNls: sharedNls,
        templateString: template,
        isOpen: false,
        _arrClusterDetail: [],
        _arrLayerDetail: [],
        _isBasemapChanged: false,
        _saveElement: null,
        _opacitySpanSlider: null,
        _changedOpacityValue: null,
        _panel: null,
        _saveCount: null,
        _myTooltipDialog: null,
        _shelter: null,
        lastEditedOverlayId: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },

        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
         */
        postCreate: function () {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetDataLayersIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
            this._alertBox = new AlertBox();
            this._attachWidgetRelatedEvents();
            this._layerData = [{
                id: "datalayergroups",
                name: "DataLayerGroups"
            }];
            this.Cluster = new Clustering();
            topic.subscribe("/checkbox/clicked", lang.hitch(this, function (checkNode) {
                if (this.appUtils.iscreateOverlayMode && (checkNode[0].item.parent === "nc4maps_overlays" || checkNode[0].item.name === "Overlays")) {
                    this._alertBox.prompt("Overlay create/edit mode is enabled.");
                    return;
                }
                var checkClassNode = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._checkBoxClicked(checkNode);
            }));
            topic.subscribe("/cluster/clicked", lang.hitch(this, function (clusterNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._clusterClicked(clusterNode);
            }));
            topic.subscribe("/save/clicked", lang.hitch(this, function (saveNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(saveNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._saveClicked(saveNode);
            }));
            topic.subscribe("/OverlaySave/clicked", lang.hitch(this, function (saveNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(saveNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._saveCount = 0;
                this._overlayUpdateItems(saveNode);
            }));
            topic.subscribe("/cluster/HeatMaps", lang.hitch(this, function (clusterNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._clusterHeatMaps(clusterNode);
            }));
            topic.subscribe("/overlays/Edit", lang.hitch(this, function (clusterNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._overlaysEdit(clusterNode);
            }));
            topic.subscribe("/cluster/ZoomTo", lang.hitch(this, function (clusterNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._clusterZoomTo(clusterNode);
            }));
            topic.subscribe("/cluster/settings", lang.hitch(this, function (clusterNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._clusterSettings(clusterNode);
            }));
            topic.subscribe("/delete/clicked", lang.hitch(this, function (deleteNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(deleteNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._deleteCustomLayer(deleteNode[0].item);
            }));
            topic.subscribe("/overlays/settings", lang.hitch(this, function (clusterNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._overlaysSettings(clusterNode);
            }));
            topic.subscribe("/customLayers/ZoomTo", lang.hitch(this, function (clusterNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._customLayersZoomTo(clusterNode);
            }));
            topic.subscribe("/overlays/ZoomTo", lang.hitch(this, function (clusterNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._overlaysZoomTo(clusterNode);
            }));
            topic.subscribe("/deleteOverlays/clicked", lang.hitch(this, function (deleteNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(deleteNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._deleteOverlaysLayer(deleteNode[0].item);
            }));
            topic.subscribe("/customLayers/settings", lang.hitch(this, function (clusterNode) {
                var checkClassNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var checkClassName = checkClassNode[0].labelNode.className;
                var isItStrikedOut = checkClassName.indexOf("strikeout");
                if (isItStrikedOut !== -1) {
                    return false;
                }
                this._customLayersSettings(clusterNode);
            }));
            topic.subscribe("checkParents", lang.hitch(this, function (Node) {
                this._checkParentNodes(Node[0], Node[1]);
            }));
            this._getDataTreeJSON();
            this._customLayerDeleteService = this.config.CustomLayerDeleteService;
            this._customLayerSaveService = this.config.CustomLayerSaveService;
            aspect.after(this.appUtils, "customLayerAdded", lang.hitch(this, function (layer) {
                this._dataLayerTreeStore.add(this.appUtils.customLayerCollection[0]);
                this._doStrikeOutOperation();
                this.appUtils.customLayerCollection = [];
                this.appUtils.refreshLegend(true);
            }));
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function () {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
            aspect.after(this.appUtils, "layerAddedOnBasemap", lang.hitch(this, function () {
                if (this.appUtils.boolBasemapChanged === true) {
                    this._doStrikeOutOperation();
                }
                this.appUtils.refreshLegend(true);
            }));
        },

        /**
         * Function to execute checkbox clicked
         * @param {Object} checkNode - Object having detail of specific tree node, which is clicked.
         */
        _checkBoxClicked: function (checkNode) {
            if (checkNode[0].item.type) {
                if (checkNode[0].item.type === "arcgis_map_service" || checkNode[0].item.type === "wms") {
                    var objSave = dom.byId(checkNode[0].item.id + "_saveIcon");
                    var saveIcon = dom.byId(checkNode[0].item.id + "_saveRefreshLayer");
                    if (!objSave && !saveIcon) {
                        var childNode = this._dataLayerTreeStore.query({
                            parent: checkNode[0].item.id
                        });
                        if (childNode.length !== 0) {
                            if (this.config.CustomLayerSaveService) {
                                var saveNode = html.create("div", {
                                    "id": checkNode[0].item.id + "_saveIcon"
                                }, null);
                                domClass.add(saveNode, "saveLayer");
                                var treeNode = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                                if (treeNode[0]) {
                                    domConstruct.place(saveNode, treeNode[0].labelNode, "last");
                                    on(saveNode, "click", lang.hitch(this, function (evt) {
                                        var checkClassNode = this._dataLayerTree.getNodesByItem(treeNode[0].item.id);
                                        var checkClassName = checkClassNode[0].labelNode.className;
                                        var isItStrikedOut = checkClassName.indexOf("strikeout");
                                        if (isItStrikedOut !== -1) {
                                            return false;
                                        }
                                        this._updateMapServer(treeNode);
                                    }));
                                }
                            }
                        }
                    }
                    var parentNode = this._dataLayerTreeStore.query({
                        id: checkNode[0].item.parent
                    });
                    if (parentNode[0].type === "arcgis_map_service" || parentNode[0].type === "wms") {
                        var objSaveNode = dom.byId(parentNode[0].id + "_saveIcon");
                        var saveIconNode = dom.byId(checkNode[0].item.id + "_saveRefreshLayer");
                        if (!objSaveNode && !saveIconNode) {
                            if (this.config.CustomLayerSaveService) {
                                var savedNode = html.create("div", {
                                    "id": parentNode[0].id + "_saveIcon"
                                }, null);
                                domClass.add(savedNode, "saveLayer");
                                var treeNodee = this._dataLayerTree.getNodesByItem(parentNode[0].id);
                                if (treeNodee[0]) {
                                    domConstruct.place(savedNode, treeNodee[0].labelNode, "last");
                                    on(savedNode, "click", lang.hitch(this, function (evt) {
                                        var checkClassNode = this._dataLayerTree.getNodesByItem(treeNodee[0].item.id);
                                        var checkClassName = checkClassNode[0].labelNode.className;
                                        var isItStrikedOut = checkClassName.indexOf("strikeout");
                                        if (isItStrikedOut !== -1) {
                                            return false;
                                        }
                                        this._updateMapServer(treeNodee);
                                    }));
                                }
                            }
                        }
                    }
                }
            }
            var clusterIcon, heatmapIcon,
                isChecked = false;
            this._shelter.show();
            if (checkNode[0].checkbox.className === "unchecked") {
                domClass.remove(checkNode[0].checkbox, "unchecked");
                domClass.add(checkNode[0].checkbox, "checked");
                isChecked = true;
            } else if (checkNode[0].checkbox.className === "checked") {
                domClass.remove(checkNode[0].checkbox, "checked");
                domClass.add(checkNode[0].checkbox, "unchecked");
                Popup.close(this._myTooltipDialog);
                isChecked = false;
            } else {
                domClass.remove(checkNode[0].checkbox, "partialChecked");
                domClass.add(checkNode[0].checkbox, "checked");
                isChecked = true;
            }
            clusterIcon = dom.byId(checkNode[0].item.id + "_toggleClusterIcon");
            heatmapIcon = dom.byId(checkNode[0].item.id + "_toggleClusterHeatMapIcon");
            if (clusterIcon) {
                if (!isChecked) {
                    domClass.remove(clusterIcon, "cluster");
                    domClass.add(clusterIcon, "decluster");
                } else {
                    domClass.remove(clusterIcon, "decluster");
                    domClass.add(clusterIcon, "cluster");
                }
                if (heatmapIcon.className === "selectedClusterHeatMaps") {
                    domClass.remove(heatmapIcon, "selectedClusterHeatMaps");
                    domClass.add(heatmapIcon, "clusterHeatMaps");
                }
            }
            this._checkHierarchicalNodes(checkNode[0].item, isChecked);
            if (checkNode[0].item.type === "featureService") {
                checkNode[0].item.state = (checkNode[0].checkbox.className === "unchecked") ? 0 : 1;
                this._appendSaveButtonToEtemLayers(checkNode);
            }
            this._updateindividualLayerServices(checkNode);
            if (checkNode[0].item.type === "image") {
                this._strikeOutOpereationOfImage(checkNode);
            }
            //            if (checkNode[0].item.type === "graphics") {
            //                checkNode[0].item.state = (checkNode[0].checkbox.className === "unchecked") ? 0 : 1;
            //                var objOverlay = dom.byId(checkNode[0].item.id + "_saveIcon");
            //                if (objOverlay) {
            //                    domClass.remove(objOverlay, "saveRefreshLayerHide");
            //                    domClass.add(objOverlay, "saveLayer");
            //                }
            //            }
        },

        /**
         * Function to add save button and update state of the custom layers.
         * @param {Object} checkNode - Object having detail of specific tree node, which is clicked.
         */
        _updateindividualLayerServices: function (checkNode) {
            if (checkNode[0].item.type) {
                if (checkNode[0].item.type === "kml" || checkNode[0].item.type === "csv" ||
                    checkNode[0].item.type === "image" || checkNode[0].item.type === "georss") {
                    var objSave = dom.byId(checkNode[0].item.id + "_saveIcon");
                    if (!objSave) {
                        checkNode[0].item.state = (checkNode[0].checkbox.className === "unchecked") ? 0 : 1;
                        var layerNode = this._dataLayerTreeStore.query({
                            id: checkNode[0].item.id
                        });
                        if (layerNode.length !== 0) {
                            if (this.config.CustomLayerSaveService) {
                                var saveNodes = html.create("div", {
                                    "id": checkNode[0].item.id + "_saveIcon"
                                }, null);
                                domClass.add(saveNodes, "saveLayer");
                                var treeNodes = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                                if (treeNodes[0]) {
                                    domConstruct.place(saveNodes, treeNodes[0].labelNode, "last");
                                    on(saveNodes, "click", lang.hitch(this, function (evt) {
                                        var checkClassNode = this._dataLayerTree.getNodesByItem(treeNodes[0].item.id);
                                        var checkClassName = checkClassNode[0].labelNode.className;
                                        var isItStrikedOut = checkClassName.indexOf("strikeout");
                                        if (isItStrikedOut !== -1) {
                                            return false;
                                        }
                                        this._saveCount = 0;
                                        this._getSaveItems(evt, checkNode);
                                    }));
                                }
                            }
                        }
                    }
                }
            }
        },

        /**
         * Function to add save button and update state of the eteam layers.
         * @param {Object} checkNode - Object having detail of specific tree node, which is clicked.
         */
        _appendSaveButtonToEtemLayers: function (checkNode) {
            var objSave = dom.byId(checkNode[0].item.id + "_saveIcon");
            var saveIcon = dom.byId(checkNode[0].item.id + "_saveRefreshLayer");
            var treeNode = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
            var saveNode;
            if (saveIcon) {
                if (saveIcon.className === "saveRefreshLayer") {
                    saveNode = domConstruct.create("div", {
                        "id": checkNode[0].item.id + "saveRefreshLayerHide"
                    });
                    domClass.add(saveNode, "saveRefreshLayerHide");
                    domConstruct.place(saveNode, treeNode[0].labelNode.id);
                    return false;
                }
            } else if (!objSave) {
                if (this.config.CustomLayerSaveService) {
                    saveNode = html.create("div", {
                        "id": checkNode[0].item.id + "_saveIcon"
                    }, null);
                    domClass.add(saveNode, "saveLayer");
                    if (treeNode[0]) {
                        domConstruct.place(saveNode, treeNode[0].labelNode, "last");
                        on(saveNode, "click", lang.hitch(this, function (evt) {
                            var checkClassNode = this._dataLayerTree.getNodesByItem(treeNode[0].item.id);
                            var checkClassName = checkClassNode[0].labelNode.className;
                            var isItStrikedOut = checkClassName.indexOf("strikeout");
                            if (isItStrikedOut !== -1) {
                                return false;
                            }
                            if (treeNode) {
                                this._saveCount = 0;
                                this._getBussinessSaveItems(evt, treeNode);
                            }
                        }));
                    }
                }
            }
        },

        /**
         * Function to execute cluster clicked
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _clusterClicked: function (clusterNode) {
            if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                this._alertBox.prompt(sharedNls.DataLayer.turnOnLayer);
                return false;
            }
            var isCluster = false;
            this._shelter.show();
            if (clusterNode[0].cluster.className === "decluster") {
                domClass.remove(clusterNode[0].cluster, "decluster");
                domClass.add(clusterNode[0].cluster, "cluster");
                isCluster = true;
            } else if (clusterNode[0].cluster.className === "cluster") {
                domClass.remove(clusterNode[0].cluster, "cluster");
                domClass.add(clusterNode[0].cluster, "decluster");
                isCluster = false;
            }
            var heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterHeatMapIcon");
            if (heatmapIcon.className === "selectedClusterHeatMaps") {
                domClass.remove(heatmapIcon, "selectedClusterHeatMaps");
                domClass.add(heatmapIcon, "clusterHeatMaps");
            }
            if (this.map.getLayer(clusterNode[0].item.id + "_heatlayer")) {
                this.map.removeLayer(this.map.getLayer(clusterNode[0].item.id + "_heatlayer"));
            }
            var clusterDetail = [{
                "clusterDetail": clusterNode[0].item,
                "isCluster": isCluster
            }];
            var loadCluster = this._manageCluster(clusterDetail);
            loadCluster.then(lang.hitch(this, function () {
                this.appUtils.refreshLegend(true);
                this._shelter.hide();
            }));
        },

        /**
         * Function to execute save clicked
         * @param {Object} saveNode - Object having detail of specific tree node, which is clicked.
         */
        _saveClicked: function (saveNode) {
            var layerType = null,
                imageBounds = 0,
                imageHeight = 0,
                imageWidth = 0,
                isCached = 0;
            if (saveNode[0].item.type === "wms") {
                var wmsChildNodes = this.map.getLayer(saveNode[0].item.id + "_layer");
                sublayers = wmsChildNodes.visibleLayers;
            }
            if (saveNode[0].item.type === "arcgis_map_service") {
                layerType = "arcgis_map_service";
                var objLayer = this.map.getLayer(saveNode[0].save.id);
                if (!objLayer) {
                    var sublayers = [];
                    var childNode = this._dataLayerTreeStore.query({
                        parent: saveNode[0].item.id
                    });
                    for (var j = 0; j < childNode.length; j++) {
                        var objChild = this.map.getLayer(childNode[j].id + "_layer");
                        if (objChild) {
                            sublayers.push(childNode[j].name);
                        }
                    }
                }
            } else if (saveNode[0].item.type === "Cached") {
                layerType = "arcgis_map_service";
                isCached = 1;
            } else {
                layerType = saveNode[0].item.type;
            }
            this._saveElement = null;
            this._saveElement = saveNode[0].save.id;
            if (saveNode[0].item.type === "image") {
                imageBounds = saveNode[0].item.saveBounds;
                imageHeight = saveNode[0].item.imgHeight;
                imageWidth = saveNode[0].item.imgWidth;
            }
            var jsonSave = [{
                "layer_name": saveNode[0].item.name,
                "layer_type": layerType,
                "url": saveNode[0].item.url,
                "opacity": saveNode[0].item.opacity,
                "refresh": saveNode[0].item.refresh,
                "sr": this.map.spatialReference.wkid.toString(),
                "image_width": imageWidth.toString(),
                "image_height": imageHeight.toString(),
                "imageBounds": imageBounds.toString(),
                "tileSizeH": "100",
                "tileSizeW": "100",
                "is_baseMap": "0",
                "is_cached": isCached.toString(),
                "tileFormat": "png",
                "sub-layers": sublayers
            }];
            var objJson = JSON.stringify(jsonSave);
            esriRequest({
                url: this.config.CustomLayerSaveService,
                content: lang.mixin({
                    customLayers: objJson
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, function (response) {
                    if (response.results.length !== 0) {
                        this.appUtils.customLayerCount--;
                        this._alertBox.success(sharedNls.DataLayer.saveLayer);
                        domConstruct.destroy(this._saveElement);
                    }
                }),
                error: lang.hitch(this, function (err) {
                    this._alertBox.error(sharedNls.DataLayer.unableToSave);
                })
            });
        },

        /**
         * Function to execute cluster heatmaps
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _clusterHeatMaps: function (clusterNode) {
            var objLayer;
            if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                this._alertBox.prompt(sharedNls.DataLayer.turnOnLayer);
                return false;
            }
            var clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
            var heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterHeatMapIcon");

            if (heatmapIcon.className === "clusterHeatMaps") {
                if (clusterIcon.className === "cluster") {
                    objLayer = this.map.getLayer(clusterNode[0].item.id + "_cluster");
                    if (objLayer) {
                        this.map.removeLayer(objLayer);
                        this.map.infoWindow.hide();
                    }
                    domClass.remove(clusterIcon, "cluster");
                    domClass.add(clusterIcon, "decluster");
                } else {
                    objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                    if (objLayer) {
                        this.map.removeLayer(objLayer);
                    }
                }
                var heatmapFeatureLayer = new FeatureLayer(clusterNode[0].item.url, {
                    outFields: ["*"],
                    mode: FeatureLayer.MODE_SNAPSHOT,
                    infoTemplate: new InfoTemplate("Attributes", clusterNode[0].item.popupInfo),
                    id: clusterNode[0].item.id + "_heatlayer",
                    name: clusterNode[0].item.name
                });
                var heatmapRenderer = new HeatmapRenderer();
                heatmapFeatureLayer.setRenderer(heatmapRenderer);
                this.map.addLayer(heatmapFeatureLayer);
                domClass.remove(heatmapIcon, "clusterHeatMaps");
                domClass.add(heatmapIcon, "selectedClusterHeatMaps");
                this.appUtils.refreshLegend(true);
            } else {
                objLayer = this.map.getLayer(clusterNode[0].item.id + "_heatlayer");
                if (objLayer) {
                    this.map.removeLayer(objLayer);
                }
                domClass.remove(heatmapIcon, "selectedClusterHeatMaps");
                domClass.add(heatmapIcon, "clusterHeatMaps");

                this.Cluster.addClusters(this.map, clusterNode[0].item);
                domClass.remove(clusterIcon, "decluster");
                domClass.add(clusterIcon, "cluster");
                this.appUtils.refreshLegend(true);
            }
        },

        /**
         * Function to execute overlays edits
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _overlaysEdit: function (clusterNode) {
            if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                this._alertBox.prompt(sharedNls.DataLayer.turnOnLayer);
                return false;
            }
            var heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleOverlayEditIcon");
            if (!this.appUtils.iscreateOverlayMode) {
                if (heatmapIcon.className === "overlayEdit") {
                    domClass.remove(heatmapIcon, "overlayEdit");
                    domClass.add(heatmapIcon, "selectedOverlayEdit");
                    this.appUtils.editOverlayLayerId = clusterNode[0].item.id;
                    this.lastEditedOverlayId = clusterNode[0].item.id;
                    this.appUtils.createOverlayMode(true);
                    this.appUtils.openWidget("Draw");
                    this._alertBox.prompt("Please use draw tool to edit the overlay");
                    //alert(this.appUtils.editOverlayLayerId);
                    var saveIcon = dom.byId(this.appUtils.editOverlayLayerId + "_saveIcon");
                    if (saveIcon.className === "saveRefreshLayerHide") {
                        domClass.remove(saveIcon, "saveRefreshLayerHide");
                        domClass.add(saveIcon, "saveLayer");
                    }
                    var objLayer = this.map.getLayer("Drawing");
                    if (objLayer) {
                        this.map.removeLayer(objLayer);
                    }

                    if (this.appUtils.overlayLayers.length) {
                        for (var j = 0; j < this.appUtils.overlayLayers.length; j++) {
                            if (this.appUtils.editOverlayLayerId !== this.appUtils.overlayLayers[j].id) {
                                this.map.removeLayer(this.map.getLayer(this.appUtils.overlayLayers[j].id + "_layer"));
                                var checkNode = dom.byId(this.appUtils.overlayLayers[j].id + "_checkBox");
                                if (checkNode) {
                                    if (checkNode.className === "checked") {
                                        domClass.remove(checkNode, "checked");
                                        domClass.remove(checkNode, "partialChecked");
                                        domClass.add(checkNode, "unchecked");
                                    }
                                }
                            }
                        }
                    }
                }

            } else {
                domClass.add(heatmapIcon, "overlayEdit");
                domClass.remove(heatmapIcon, "selectedOverlayEdit");
                this.appUtils.editOverlayLayerId = null;
                this.appUtils.overlayLayers = [clusterNode[0].item];
                this.appUtils.createOverlayMode(false);
            }
            //this.appUtils.editOverlayLayerId = clusterNode[0].item.id;
        },

        /**
         * Function to execute cluster zoomTo
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _clusterZoomTo: function (clusterNode) {
            var objLayer;
            if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                this._alertBox.prompt(sharedNls.DataLayer.turnOnLayer);
                return false;
            }
            this._shelter.show();
            var clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
            objLayer = (clusterIcon.className === "cluster") ? this.map.getLayer(clusterNode[0].item.id + "_cluster") : this.map.getLayer(clusterNode[0].item.id + "_layer");
            //zoomExtent = this.map.getLayer(objLayer.id);
            if (objLayer) {
                var queryParam = new EsriQuery();
                queryParam.where = "1=1";
                queryParam.returnGeometry = true;
                queryParam.outFields = ["*"];
                var queryTask = new EsriQueryTask(objLayer.url);
                queryTask.execute(queryParam, lang.hitch(this, function (response) {
                    if (response.features.length !== 0) {
                        var myFeatureExtent = graphicsUtils.graphicsExtent(response.features);
                        this.map.setExtent(myFeatureExtent.expand(2));
                    }
                    this._shelter.hide();
                }), lang.hitch(this, function (error) {
                    this.log.error(error);
                    this._shelter.hide();

                }));
            }
            this._shelter.hide();
        },

        /**
         * Function to execute cluster settings
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _clusterSettings: function (clusterNode) {
            this._saveCount = 0;
            if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                this._alertBox.prompt(sharedNls.DataLayer.turnOnLayer);
                return false;
            }
            var heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterHeatMapIcon");
            if (heatmapIcon.className === "selectedClusterHeatMaps") {
                this._alertBox.prompt(sharedNls.DataLayer.notChangeOpacityRefresh);
            } else {
                var domContentDynamic = domConstruct.create("div", {
                    "class": "MainContainerDiv"
                }, null);
                var editPanelSpan = domConstruct.create("div", {
                    "class": "labelRefreshContainer"
                }, domContentDynamic);
                editPanelSpan.innerHTML = "Refresh Rate : ";
                var editPanel = domConstruct.create("div", {
                    "class": "TextboxContainer"
                }, domContentDynamic);
                var editPanelTextbox = domConstruct.create("div", {}, editPanel);
                var myTextBox = new ValidationTextBox({
                    name: "Title",
                    value: clusterNode[0].item.refresh,
                    size: "15",
                    "regExp": "^[0-9]*$",
                    "invalidMessage": "Please enter valid number"
                });
                domConstruct.place(myTextBox.domNode, editPanelTextbox);
                var opacitySpan = domConstruct.create("div", {
                    "class": "fillSliderOpacity"
                }, domContentDynamic);
                this._opacitySpanSlider = domConstruct.create("div", {
                    "id": "fillSliderValue"
                }, opacitySpan);
                this._opacitySpanSlider.innerHTML = "Opacity : " + Math.round(clusterNode[0].item.opacity) + "%";
                var domContentForSlider = domConstruct.create("div", {
                    "class": "fillOpacitySlider"
                }, domContentDynamic);
                var domContentForSliderright = domConstruct.create("div", {}, domContentForSlider);
                var sliderForColor = new HorizontalSlider({
                    name: "slider",
                    minimum: 1,
                    maximum: 100,
                    value: clusterNode[0].item.opacity,
                    intermediateChanges: true,
                    onChange: lang.hitch(this, function (value) {
                        var currentOpacityValue,
                            clusterIcon,
                            objLayer,
                            opacityValue;
                        // this._getOpacityValue = Math.round(value);
                        this._changedOpacityValue = value;
                        opacityValue = this._changedOpacityValue;
                        this._opacitySpanSlider.innerHTML = "Opacity : " + Math.round(value) + " %";
                        clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
                        if (clusterIcon.className === "cluster") {
                            objLayer = this.map.getLayer(clusterNode[0].item.id + "_cluster");
                        } else {
                            objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                        }
                        currentOpacityValue = objLayer.opacity;
                        if (opacityValue) {
                            var setOpacityValue = opacityValue / 100;
                            objLayer.setOpacity(setOpacityValue);
                        }
                    })
                });
                domConstruct.place(sliderForColor.domNode, domContentForSliderright);
                
                 //James: creating datePicker label:
               // if(this.config.DateFilterService){
                	var startDateCalendar;
                    var endDateCalendar;
                    require(["dojo/parser", "dijit/form/DateTextBox"], function(parser, dateTextBox){
                    	 var datePickerStartTitle = domConstruct.create("div", {"class": "labelRefreshContainer"}, domContentDynamic, 4);
                    	 datePickerStartTitle.innerHTML = "Start Date: ";
                    	 var datePickerStartCal = domConstruct.create("div", {}, domContentDynamic,5);
                         startDateCalendar = new dateTextBox({name: "Start_Date",value: clusterNode[0].item.startDate}, "startDateCal");
                         domConstruct.place(startDateCalendar.domNode, datePickerStartCal);
                         
                    	 var datePickerEndTitle = domConstruct.create("div", {"class": "labelRefreshContainer"}, domContentDynamic, 6);
                    	 datePickerEndTitle.innerHTML = "End Date: ";
                    	 var datePickerEndCal = domConstruct.create("div", {}, domContentDynamic, 7);
                    	 endDateCalendar = new dateTextBox({name: "End_Date",value: clusterNode[0].item.endDate}, "endDateCal");  
                    	 domConstruct.place(endDateCalendar.domNode, datePickerEndCal);
                    });
                //}
                
                var btnSave = new Button({
                    label: "OK",
                    "class": "btnPopUp"
                }, domContentDynamic);
                domConstruct.place(btnSave.domNode, domContentDynamic, "last");
                btnSave.on("click", lang.hitch(this, function (event) {
                    var objLayer,
                        refreshRate,
                        opacityValue,
                        startDate,
                        endDate;
                    refreshRate = myTextBox.value;
                    opacityValue = this._changedOpacityValue;
                    startDate = startDateCalendar.get("value") || null;
                    endDate = endDateCalendar.get("value") || null;
                    clusterNode[0].item.opacity = opacityValue;
                    clusterNode[0].item.refresh = refreshRate;
                    clusterNode[0].item.startDate = startDate;
                    clusterNode[0].item.endDate = endDate;
                    var clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
                    if (clusterIcon.className === "cluster") {
                        objLayer = this.map.getLayer(clusterNode[0].item.id + "_cluster");
                    } else {
                        objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                    }
                    if (!objLayer) {
                        this._alertBox.prompt(sharedNls.DataLayer.notAddedOnMap);
                        return false;
                    }
                    var currentRefreshValue = objLayer.refreshInterval;
                    var currentOpacityValue = objLayer.opacity;
                    var currentStartDateValue = objLayer.startDate || "";
                    var currentEndDateValue = objLayer.endDate || "";
                    if (opacityValue) {
                        var setOpacityValue = opacityValue / 100;
                        objLayer.setOpacity(setOpacityValue);
                    }
                    objLayer.setRefreshInterval(refreshRate);
                    var parentNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                    var saveIcon = dom.byId(clusterNode[0].item.id + "_saveIcon");
                    if (saveIcon) {
                        var saveRefreshShow;
                        if (!dom.byId(clusterNode[0].item.id + "_saveRefreshLayer") || saveIcon.className === "saveLayer") {
                            saveRefreshShow = domConstruct.create("div", {
                                "id": clusterNode[0].item.id + "_saveRefreshLayer"
                            });
                            domClass.add(saveRefreshShow, "saveRefreshLayerHide");
                        }
                    } else if (currentRefreshValue !== refreshRate || currentOpacityValue !== opacityValue || currentStartDateValue !== startDate || currentEndDateValue !== endDate) {
                        if (!dom.byId(clusterNode[0].item.id + "_saveIcon")) {
                            if (this.config.BussinessLayerUpdateService) {
                                saveRefreshShow = domConstruct.create("div", {
                                    "id": clusterNode[0].item.id + "_saveIcon"
                                });
                                domClass.remove(saveRefreshShow, "saveRefreshLayerHide");
                                domClass.add(saveRefreshShow, "saveRefreshLayer");
                                domConstruct.place(saveRefreshShow, parentNode[0].labelNode.id);
                                on(saveRefreshShow, "click", lang.hitch(this, function (evt) {
                                    this._getBussinessSaveItems(evt, clusterNode);
                                }));
                            }
                        }
                    }
                    Popup.close(this._myTooltipDialog);
                }));
                this._myTooltipDialog = new TooltipDialog({
                    content: domContentDynamic
                });
                Popup.open({
                    popup: this._myTooltipDialog,
                    around: dom.byId(clusterNode[0].item.id + "_toggleSettingClusterIcon")
                });
            }
        },

        /**
         * Function to execute customLayers zoomTo
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _customLayersZoomTo: function (clusterNode) {
            var layerImages,
                objLayer,
                zoomExtent;
            if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                this._alertBox.prompt(sharedNls.DataLayer.turnOnLayer);
                return false;
            }
            objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
            if (objLayer === undefined) {
                this._alertBox.prompt(sharedNls.DataLayer.extentNotFound);
                return false;
            }
            if (objLayer.customLayerType === "kml") {
                zoomExtent = this.map.getLayer(objLayer.id + "_1");
                this._setZoomToExtentForCustomLayer(zoomExtent);
            } else if (objLayer.customLayerType === "image") {
                layerImages = objLayer.getImages();
                (layerImages) ? this.map.setExtent(layerImages[0].extent) : this._alertBox.prompt(sharedNls.DataLayer.extentNotFound); //jshint ignore:line
            } else {
                this._setZoomToExtentForCustomLayer(objLayer);
            }
        },

        /**
         * Function to execute cluster settings
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _overlaysSettings: function (clusterNode) {
            this._saveCount = 0;
            if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                this._alertBox.prompt(sharedNls.DataLayer.turnOnLayer);
                return false;
            }
            var domContentDynamic = domConstruct.create("div", {
                "class": "MainContainerDiv"
            }, null);
            var editPanelSpan = domConstruct.create("div", {
                "class": "labelRefreshContainer"
            }, domContentDynamic);
            editPanelSpan.innerHTML = "Refresh Rate : ";
            var editPanel = domConstruct.create("div", {
                "class": "TextboxContainer"
            }, domContentDynamic);
            var editPanelTextbox = domConstruct.create("div", {}, editPanel);
            var myTextBox = new ValidationTextBox({
                name: "Title",
                value: clusterNode[0].item.refresh,
                size: "15",
                "regExp": "^[0-9]*$",
                "invalidMessage": "Please enter valid number"
            });
            domConstruct.place(myTextBox.domNode, editPanelTextbox);
            var opacitySpan = domConstruct.create("div", {
                "class": "fillSliderOpacity"
            }, domContentDynamic);
            this._opacitySpanSlider = domConstruct.create("div", {
                "id": "fillSliderValue"
            }, opacitySpan);
            this._opacitySpanSlider.innerHTML = "Opacity : " + Math.round(clusterNode[0].item.opacity) + "%";
            var domContentForSlider = domConstruct.create("div", {
                "class": "fillOpacitySlider"
            }, domContentDynamic);
            var domContentForSliderright = domConstruct.create("div", {}, domContentForSlider);
            var sliderForColor = new HorizontalSlider({
                name: "slider",
                minimum: 1,
                maximum: 100,
                value: clusterNode[0].item.opacity,
                intermediateChanges: true,
                onChange: lang.hitch(this, function (value) {
                    var currentOpacityValue,
                        objLayer,
                        opacityValue;
                    // this._getOpacityValue = Math.round(value);
                    this._changedOpacityValue = value;
                    opacityValue = this._changedOpacityValue;
                    this._opacitySpanSlider.innerHTML = "Opacity : " + Math.round(value) + " %";
                    objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                    if (objLayer) {
                        currentOpacityValue = objLayer.opacity;
                        if (opacityValue) {
                            var setOpacityValue = opacityValue / 100;
                            objLayer.setOpacity(setOpacityValue);
                        }
                    }
                })
            });
            domConstruct.place(sliderForColor.domNode, domContentForSliderright);
            var btnSave = new Button({
                label: "OK",
                "class": "btnPopUp"
            }, domContentDynamic);
            domConstruct.place(btnSave.domNode, domContentDynamic);
            btnSave.on("click", lang.hitch(this, function (event) {
                var objLayer,
                    refreshRate,
                    opacityValue;
                refreshRate = myTextBox.value;
                opacityValue = this._changedOpacityValue;
                clusterNode[0].item.opacity = opacityValue;
                clusterNode[0].item.refresh = refreshRate;
                //        var clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterHeatMapIcon");
                objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                if (objLayer) {
                    var currentRefreshValue = objLayer.refreshInterval;
                    var currentOpacityValue = objLayer.opacity;
                    if (opacityValue) {
                        var setOpacityValue = opacityValue / 100;
                        objLayer.setOpacity(setOpacityValue);
                    }
                    objLayer.setRefreshInterval(refreshRate);
                }
                //  var parentNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                if (currentRefreshValue !== refreshRate || currentOpacityValue !== opacityValue) {
                    var saveIcon = dom.byId(clusterNode[0].item.id + "_saveIcon");
                    if (this.config.OverlayUpdateService) {
                        if (saveIcon.className === "saveRefreshLayerHide") {
                            domClass.remove(saveIcon, "saveRefreshLayerHide");
                            domClass.add(saveIcon, "saveLayer");
                        }
                    }
                }
                Popup.close(this._myTooltipDialog);
            }));
            this._myTooltipDialog = new TooltipDialog({
                content: domContentDynamic
            });
            Popup.open({
                popup: this._myTooltipDialog,
                around: dom.byId(clusterNode[0].item.id + "_toggleoverlaySettingIcon")
            });
            //    }
        },

        /**
         * Function to update overly items.
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _overlayUpdateItems: function (clusterNode) {
            if (this._saveCount === 0) {
                var objLayer,
                    objGraphics = {},
                    objFeaturecollection = [],
                    graphicsData,
                    id;
                id = (this.appUtils.editOverlayLayerId) ? this.appUtils.editOverlayLayerId : clusterNode[0].item.id;
                objLayer = this.map.getLayer(id + "_layer");
                if (objLayer) {
                    this._shelter.show();
                    for (var j = 0; j < objLayer.graphics.length; j++) {
                        objGraphics = {
                            "geometry": objLayer.graphics[j].toJson().geometry,
                            "symbol": objLayer.graphics[j].toJson().symbol,
                            "attributes": objLayer.graphics[j].toJson().attributes
                        };
                        objFeaturecollection.push(objGraphics);
                    }
                    graphicsData = JSON.stringify(objFeaturecollection);
                    esriRequest({
                        url: this.config.OverlayUpdateService,
                        content: lang.mixin({
                            f: "jsonp",
                            id: clusterNode[0].item.id,
                            name: clusterNode[0].item.name,
                            graphics: graphicsData,
                            wkid: 102100,
                            parent: "nc4maps_overlays",
                            opacity: clusterNode[0].item.opacity,
                            refresh: clusterNode[0].item.refresh,
                            state: clusterNode[0].item.state
                        }),
                        usePost: true,
                        //useProxy: false,
                        callbackParamName: "callback",
                        load: lang.hitch(this, function (response) {
                            if (response.success === true) {
                                this._alertBox.success("Layer saved Successfully");
                                this.appUtils.editOverlayLayerId = null;
                                //var saveRefreshShow = dom.byId(clusterNode[0].item.id + "_saveRefreshLayer");
                                var saveIcon = dom.byId(clusterNode[0].item.id + "_saveIcon");
                                var heatmapIcon = dom.byId(clusterNode[0].item.id + "_toggleOverlayEditIcon");
                                if (heatmapIcon.className === "selectedOverlayEdit") {
                                    domClass.add(heatmapIcon, "overlayEdit");
                                    domClass.remove(heatmapIcon, "selectedOverlayEdit");
                                }
                                if (saveIcon) {
                                    domClass.remove(saveIcon, "saveLayer");
                                    domClass.add(saveIcon, "saveRefreshLayerHide");
                                }
                                this.appUtils.createOverlayMode(false);
                                this._shelter.hide();
                            } else {
                                this._alertBox.error(sharedNls.DataLayer.unableToSave);
                                this._shelter.hide();
                            }
                        }),
                        error: lang.hitch(this, this._onErrordelete)
                    });
                }
                //                } else {
                //                    this._updateOverlayServices(clusterNode);
                //                }
            }
        },

        /**
         * Function to display the
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _onErrordelete: function (error) {
            this._shelter.hide();
            this._alertBox.error("Unable to save Overlay");
        },

        /**
         * Function to execute overlays zoomTo.
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _overlaysZoomTo: function (clusterNode) {
            var objLayer,
                zoomExtent;
            if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                this._alertBox.prompt(sharedNls.DataLayer.turnOnLayer);
                return false;
            }
            objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
            if (objLayer) {
                zoomExtent = this.map.getLayer(objLayer.id);
                var myFeatureExtent = graphicsUtils.graphicsExtent(zoomExtent.graphics);
                this.map.setExtent(myFeatureExtent.expand(2));
            }
        },

        /**
         * Function to delete overlays layers.
         * @param {Object} layerIds - Parent id.
         */
        _deleteOverlaysLayer: function (layerIds) {
            if (layerIds.parent) {
                if (layerIds.parent === "nc4maps_overlays") {
                    var deletePromtMessage = this._alertBox.confirm("Click OK to delete layer.");
                    deletePromtMessage.then(lang.hitch(this, function (res) {
                        esriRequest({
                            url: this.config.OverlayDeleteService,
                            content: lang.mixin({
                                id: layerIds.id,
                                f: "jsonp"
                            }, null),
                            callbackParamName: "callback",
                            load: lang.hitch(this, function () {
                                if (this.map.getLayer(layerIds.id + "_layer")) {
                                    this.map.removeLayer(this.map.getLayer(layerIds.id + "_layer"));
                                } else {

                                    var childNodes = this._dataLayerTreeStore.query({
                                        parent: layerIds.id
                                    });
                                    array.forEach(childNodes, lang.hitch(this, function (node) {
                                        if (node.url) {
                                            var childLayer = this.map.getLayer(node.id + "_layer");
                                            if (childLayer) {
                                                this.map.removeLayer(childLayer);
                                            }
                                        }
                                    }));

                                }
                                this._alertBox.success("Layer deleted successfully");
                                this.appUtils.createOverlayMode(false);
                                this._dataLayerTreeStore.remove(layerIds.id);
                            }),
                            error: lang.hitch(this, function (err) {
                                this._alertBox.error(err);
                            })
                        });
                    }));
                }
            }
        },

        /**
         * Function to set zoom to extent of custom layers.
         * @param {Object} objLayer - layerObject.
         */
        _setZoomToExtentForCustomLayer: function (objLayer) {
            if (objLayer.fullExtent) {
                this.map.setExtent(objLayer.fullExtent);
            } else if (objLayer.initialExtent) {
                this.map.setExtent(objLayer.initialExtent);
            } else {
                this._alertBox.prompt(sharedNls.DataLayer.extentNotFound);
            }
        },

        /**
         * Function to execute customLayers settings
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _customLayersSettings: function (clusterNode) {
            this._saveCount = 0;
            if (dom.byId(clusterNode[0].item.id + "_checkBox").className === "unchecked") {
                this._alertBox.prompt(sharedNls.DataLayer.turnOnLayer);
                return false;
            }
            var domContentDynamic = domConstruct.create("div", {
                "class": "MainContainerDiv"
            }, null);
            var editPanelSpan = domConstruct.create("div", {
                "class": "labelRefreshContainer"
            }, domContentDynamic);
            editPanelSpan.innerHTML = "Refresh Rate : ";
            var editPanel = domConstruct.create("div", {
                "class": "TextboxContainer"
            }, domContentDynamic);
            var editPanelTextbox = domConstruct.create("div", {}, editPanel);
            var myTextBox = new ValidationTextBox({
                name: "Title",
                value: clusterNode[0].item.refresh,
                size: "15",
                "regExp": "^[0-9]*$",
                "invalidMessage": "Please enter valid number"
            });
            domConstruct.place(myTextBox.domNode, editPanelTextbox);
            var opacitySpan = domConstruct.create("div", {
                "class": "fillSliderOpacity"
            }, domContentDynamic);
            this._opacitySpanSlider = domConstruct.create("div", {
                "id": "fillSliderValue"
            }, opacitySpan);
            this._opacitySpanSlider.innerHTML = "Opacity : " + Math.round(clusterNode[0].item.opacity) + "%";
            var domContentForSlider = domConstruct.create("div", {
                "class": "fillOpacitySlider"
            }, domContentDynamic);
            var domContentForSliderright = domConstruct.create("div", {}, domContentForSlider);
            var sliderForColor = new HorizontalSlider({
                name: "slider",
                minimum: 1,
                maximum: 100,
                value: clusterNode[0].item.opacity,
                intermediateChanges: true,
                onChange: lang.hitch(this, function (value) {
                    var clusterIcon;
                    this._changedOpacityValue = value;
                    this._opacitySpanSlider.innerHTML = "Opacity : " + Math.round(value) + " %";
                    var opacityValue = this._changedOpacityValue;
                    clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
                    var objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                    if (clusterNode[0].item.type === "arcgis_map_service" && (clusterNode[0].item.url.indexOf("MapServer/") === -1) && (clusterNode[0].item.url.indexOf("FeatureServer/") === -1)) {
                        var childNodes = this._dataLayerTreeStore.query({
                            parent: clusterNode[0].item.id
                        });
                        array.forEach(childNodes, lang.hitch(this, function (node) {
                            if (node.url) {
                                var childLayer = this.map.getLayer(node.id + "_layer");
                                if (childLayer) {
                                    if (opacityValue) {
                                        childLayer.setOpacity(opacityValue / 100);
                                    }
                                }
                            }
                        }));
                    } else {
                        if (!objLayer) {
                            this._shelter.hide();
                            return false;
                        }
                        //  var currentOpacityValue = objLayer.opacity;
                        if (opacityValue) {
                            var setOpacityValue = opacityValue / 100;
                            objLayer.setOpacity(setOpacityValue);
                        }
                    }
                })
            });
            domConstruct.place(sliderForColor.domNode, domContentForSliderright);
            var btnCustomLayerSave = new Button({
                label: "OK",
                "class": "btnPopUp"
            }, domContentDynamic);
            domConstruct.place(btnCustomLayerSave.domNode, domContentDynamic);
            btnCustomLayerSave.on("click", lang.hitch(this, function (event) {
                var clusterIcon,
                    currentRefreshValue,
                    currentOpacityValue,
                    objLayer,
                    refreshRate,
                    opacityValue;
                refreshRate = myTextBox.value;
                opacityValue = this._changedOpacityValue;
                clusterNode[0].item.opacity = opacityValue;
                clusterNode[0].item.refresh = refreshRate;
                clusterIcon = dom.byId(clusterNode[0].item.id + "_toggleClusterIcon");
                objLayer = this.map.getLayer(clusterNode[0].item.id + "_layer");
                if (clusterNode[0].item.type === "arcgis_map_service" && (clusterNode[0].item.url.indexOf("MapServer/") === -1) && (clusterNode[0].item.url.indexOf("FeatureServer/") === -1)) {
                    var childNodes = this._dataLayerTreeStore.query({
                        parent: clusterNode[0].item.id
                    });
                    array.forEach(childNodes, lang.hitch(this, function (node) {
                        if (node.url) {
                            var childLayer = this.map.getLayer(node.id + "_layer");
                            if (childLayer) {
                                if (opacityValue) {
                                    childLayer.setOpacity(opacityValue / 100);
                                }
                                childLayer.setRefreshInterval(refreshRate);
                            }
                        }
                    }));
                } else {
                    if (!objLayer) {
                        this._alertBox.prompt(sharedNls.DataLayer.notAddedOnMap);
                        return false;
                    }
                    currentRefreshValue = objLayer.refreshInterval;
                    currentOpacityValue = objLayer.opacity;
                    if (opacityValue) {
                        var setOpacityValue = opacityValue / 100;
                        objLayer.setOpacity(setOpacityValue);
                    }
                    objLayer.setRefreshInterval(refreshRate);
                }
                var parentNode = this._dataLayerTree.getNodesByItem(clusterNode[0].item.id);
                var saveIcon = dom.byId(clusterNode[0].item.id + "_saveIcon");
                if (!saveIcon) {
                    if (!dom.byId(clusterNode[0].item.id + "_saveRefreshLayer")) {

                        var saveRefreshHide = domConstruct.create("div", {
                            "id": clusterNode[0].item.id + "_saveRefreshLayer"
                        });
                        domClass.add(saveRefreshHide, "saveRefreshLayerHide");
                        domConstruct.place(saveRefreshHide, parentNode[0].labelNode.id);

                    }
                    if (currentRefreshValue !== refreshRate || currentOpacityValue !== opacityValue) {
                        var saveRefreshShow = dom.byId(clusterNode[0].item.id + "_saveRefreshLayer");
                        if (this.config.CustomLayerSaveService) {
                            domClass.remove(saveRefreshShow, "saveRefreshLayerHide");
                            domClass.add(saveRefreshShow, "saveRefreshLayer");
                            on(saveRefreshShow, "click", lang.hitch(this, function (evt) {
                                this._getSaveItems(evt, clusterNode);
                            }));
                        }
                    }
                    this.appUtils.customLayerCount++;
                }
                Popup.close(this._myTooltipDialog);
            }));
            this._myTooltipDialog = new TooltipDialog({
                content: domContentDynamic
            });
            Popup.open({
                popup: this._myTooltipDialog,
                around: dom.byId(clusterNode[0].item.id + "_toggleSettingClusterIcon")
            });
        },

        /**
         * Function to add save button and update services with latest data of mapserver layer.
         * @param {Object} saveNode - Object having detail of specific tree node, which is clicked.
         */
        _updateMapServer: function (saveNode) {
            if (saveNode[0].item.type === "arcgis_map_service") {
                var objLayer = this.map.getLayer(saveNode[0].item.id);
                if (!objLayer) {
                    var sublayers = [];
                    var childNode = this._dataLayerTreeStore.query({
                        parent: saveNode[0].item.id
                    });
                    for (var j = 0; j < childNode.length; j++) {
                        var objChild = this.map.getLayer(childNode[j].id + "_layer");
                        if (objChild) {
                            sublayers.push(childNode[j].name);
                        }
                    }
                }
            }
            var jsonSave = [{
                "layer_name": saveNode[0].item.name,
                "layer_type": saveNode[0].item.type,
                "layer_id": saveNode[0].item.id,
                "url": saveNode[0].item.url,
                "opacity": saveNode[0].item.opacity,
                "refresh": saveNode[0].item.refresh,
                "sr": this.map.spatialReference.wkid.toString(),
                "image_width": saveNode[0].item.imageWidth,
                "image_height": saveNode[0].item.imageHeight,
                "imageBounds": saveNode[0].item.imageBounds,
                "tileSizeH": "100",
                "tileSizeW": "100",
                "is_baseMap": "0",
                "is_cached": "0",
                "tileFormat": "png",
                "sub-layers": sublayers
            }];
            var objJson = JSON.stringify(jsonSave);
            this._saveElement = null;
            this._saveElement = saveNode[0].item.id + "_saveIcon";
            esriRequest({
                url: this.config.CustomLayerUpdateService,
                content: lang.mixin({
                    customLayers: objJson
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, function (response) {
                    if (response.success === true) {
                        this._alertBox.success(sharedNls.DataLayer.saveLayer);
                        domConstruct.destroy(this._saveElement);
                    } else {
                        this._alertBox.error(sharedNls.DataLayer.unableToSave);
                        this._saveCount++;
                    }
                }),
                error: lang.hitch(this, function (err) {
                    this._alertBox.error(err);
                })
            });
        },

        /**
         * Function to save and update the opacity of eteam layers.
         * @param {Object} evt - evt.
         * @param {Object} clusterNode - Object having detail of specific tree node, which is clicked.
         */
        _getBussinessSaveItems: function (evt, clusterNode) {
            this._saveCount = 0;
            var jsonSave,
                objJson,
                reportType,
                saveRefreshShow,
                subReportType;
            if (clusterNode[0].item.parent === "eteam") {
                reportType = clusterNode[0].item.name;
                subReportType = "";
            } else {
                reportType = clusterNode[0].item.parent;
                subReportType = clusterNode[0].item.name;
            }
            jsonSave = {
                "report_type": reportType,
                "report_sub_type": subReportType,
                "refresh": clusterNode[0].item.refresh,
                "opacity": clusterNode[0].item.opacity,
                "state": clusterNode[0].item.state
            };
            objJson = JSON.stringify(jsonSave);
            this._saveElement = null;
            this._saveElement = clusterNode[0].item.id + "_saveIcon";
            if (this._saveCount === 0) {
                esriRequest({
                    url: this.config.BussinessLayerUpdateService,
                    content: lang.mixin({
                        reportLayer: objJson
                    }, null),
                    callbackParamName: "callback",
                    load: lang.hitch(this, function (response) {
                        if (response === true) {
                            if (this._saveCount === 0) {
                                this._alertBox.success(sharedNls.DataLayer.saveLayer);
                                domConstruct.destroy(this._saveElement);
                                saveRefreshShow = dom.byId(clusterNode[0].item.id + "_saveRefreshLayer");
                                if (saveRefreshShow) {
                                    domClass.remove(saveRefreshShow, "saveRefreshLayer");
                                    domClass.add(saveRefreshShow, "saveRefreshLayerHide");
                                }
                                this._saveCount++;
                            }
                        } else {
                            if (this._saveCount === 0) {
                                this._alertBox.error(sharedNls.DataLayer.unableToSave);
                                this._saveCount++;
                            }
                        }
                    }),
                    error: lang.hitch(this, function (err) {
                        this._alertBox.error(err);
                    })
                });
            }
        },

        /**
         * Function to save and update the opacity of custom layers.
         * @param {Object} evt - evt.
         * @param {Object} saveNode - Object having detail of specific tree node, which is clicked.
         */
        _getSaveItems: function (evt, saveNode) {
            this._saveCount = 0;
            var layerType = null,
                imageBounds = 0,
                imageHeight = 0,
                imageWidth = 0;
            if (saveNode[0].item.type === "wms") {
                var wmsChildNodes = this.map.getLayer(saveNode[0].item.id + "_layer");
                sublayers = wmsChildNodes.visibleLayers;
            }
            if (saveNode[0].item.type === "arcgis_map_service") {
                layerType = "arcgis_map_service";
                var objLayer = this.map.getLayer(saveNode[0].settings.id);
                if (!objLayer) {
                    var sublayers = [];
                    var childNode = this._dataLayerTreeStore.query({
                        parent: saveNode[0].item.id
                    });
                    for (var j = 0; j < childNode.length; j++) {
                        var objChild = this.map.getLayer(childNode[j].id + "_layer");
                        if (objChild) {
                            sublayers.push(childNode[j].name);
                        }
                    }
                }
            } else {
                layerType = saveNode[0].item.type;
            }
            //this._saveElement = null;
            //this._saveElement = saveNode[0].settings.id;
            if (saveNode[0].item.type === "image") {
                var saveBounds = saveNode[0].item.imgBounds.xmin + "," + saveNode[0].item.imgBounds.ymin + "," + saveNode[0].item.imgBounds.xmax + "," + saveNode[0].item.imgBounds.ymax;
                imageBounds = saveBounds;
                imageHeight = saveNode[0].item.imgHeight;
                imageWidth = saveNode[0].item.imgWidth;
            }
            var jsonSave = [{
                "layer_name": saveNode[0].item.name,
                "layer_type": saveNode[0].item.type,
                "layer_id": saveNode[0].item.id,
                "url": saveNode[0].item.url,
                "opacity": saveNode[0].item.opacity,
                "refresh": saveNode[0].item.refresh,
                "sr": this.map.spatialReference.wkid.toString(),
                "image_width": imageWidth.toString(),
                "image_height": imageHeight.toString(),
                "imageBounds": imageBounds.toString(),
                "tileSizeH": "100",
                "tileSizeW": "100",
                "is_baseMap": "0",
                "is_cached": "0",
                "tileFormat": "png",
                "state": saveNode[0].item.state
            }];
            if (sublayers) {
                jsonSave[0]["sub-layers"] = sublayers;
            }
            var objJson = JSON.stringify(jsonSave);
            this._saveElement = saveNode[0].item.id + "_saveIcon";
            if (this._saveCount === 0) {
                esriRequest({
                    url: this.config.CustomLayerUpdateService,
                    content: lang.mixin({
                        customLayers: objJson
                    }, null),
                    callbackParamName: "callback",
                    load: lang.hitch(this, function (response) {
                        if (response.success === true) {
                            if (this._saveCount === 0) {
                                this._alertBox.success(sharedNls.DataLayer.saveLayer);
                                var saveRefreshShow = dom.byId(saveNode[0].item.id + "_saveRefreshLayer");
                                if (saveRefreshShow) {
                                    domClass.remove(saveRefreshShow, "saveRefreshLayer");
                                    domClass.add(saveRefreshShow, "saveRefreshLayerHide");
                                }
                                if (this._saveElement) {
                                    domConstruct.destroy(this._saveElement);
                                }
                                this.appUtils.customLayerCount--;
                                this._saveCount++;
                            }
                        } else {
                            if (this._saveCount === 0) {
                                this._alertBox.error(sharedNls.DataLayer.unableToSave);
                                this._saveCount++;
                            }
                        }
                    }),
                    error: lang.hitch(this, function (err) {
                        this._alertBox.error(err);
                    })
                });
            }
        },

        /**
         * Function to start strikeout operation.
         */
        _doStrikeOutOperation: function () {
            this._shelter.show();
            if (this._dataLayerTreeStore) {
                this._performStrikeOutOperationOfLayerIds();
                this._performStrikeOutOperationOfGraphicsLayerIds();
            }
            this._shelter.hide();
        },

        /**
         * Function to perform strike out operation of KML, GeoRss and Cached layer's.
         * @param {array} kmlNode - Layer Node
         */
        _performStrikeOutOperationOfKmlGeoRssCachedLayers: function (kmlNode) {
            if (kmlNode[0].item.type === "kml") {
                if (kmlNode[0].item.strike) {
                    if (kmlNode[0].item.strike === "Yes") {
                        html.addClass(kmlNode[0].labelNode, "strikeout");
                        this._hideIcons(kmlNode[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    } else {
                        html.removeClass(kmlNode[0].labelNode, "strikeout");
                        this._showIcons(kmlNode[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }
            }
            if (kmlNode[0].item.type === "georss") {
                if (kmlNode[0].item.strike) {
                    if (kmlNode[0].item.strike === "Yes") {
                        html.addClass(kmlNode[0].labelNode, "strikeout");
                        this._hideIcons(kmlNode[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    } else {
                        html.removeClass(kmlNode[0].labelNode, "strikeout");
                        this._showIcons(kmlNode[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }
            }
            if (kmlNode[0].item.type === "arcgis_map_service" || kmlNode[0].item.type === "Cached") {
                if (kmlNode[0].item.strike) {
                    if (kmlNode[0].item.strike === "Yes") {
                        html.addClass(kmlNode[0].labelNode, "strikeout");
                        this._hideIcons(kmlNode[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    } else {
                        html.removeClass(kmlNode[0].labelNode, "strikeout");
                        this._showIcons(kmlNode[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }
            }
        },

        /**
         * Function to perform strike out operation of WMS, Image and WMTS layer's.
         * @param {object} objWMS - object of wms layer.
         * @param {string} wmsLayer - Layer name.
         */
        _performStrikeOutOperationOfWMSImageWMTSLayers: function (objWMS, wmsLayer) {
            if (objWMS[0].item.type === "wms") {
                if (this.appUtils.boolBasemapChanged) {
                    this._enableStrikeOperationOfWMS(objWMS, wmsLayer);
                } else {
                    if (objWMS[0].item.strike) {
                        this._enableStrikeOperationOfWMS(objWMS, wmsLayer);
                    }
                }
            }
            if (objWMS[0].item.type === "wmts") {
                if (objWMS[0].item.strike) {
                    if (objWMS[0].item.strike === "Yes") {
                        html.addClass(objWMS[0].labelNode, "strikeout");
                        this._hideIcons(objWMS[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    } else {
                        html.removeClass(objWMS[0].labelNode, "strikeout");
                        this._showIcons(objWMS[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }
            }
            if (objWMS[0].item.type === "image") {
                var basemap = this.map.getLayer(this.map.layerIds[0]);
                var basemapSR = basemap.spatialReference.wkid;
                if (basemapSR !== 102100 && basemapSR !== 4326) {
                    objWMS[0].item.strike = "Yes";
                    html.addClass(objWMS[0].labelNode, "strikeout");
                    this._hideIcons(objWMS[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                } else {
                    objWMS[0].item.strike = "No";
                    html.removeClass(objWMS[0].labelNode, "strikeout");
                    this._showIcons(objWMS[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                }
            }
        },

        /**
         * Function to perform strikeout operation of layerids.
         */
        _performStrikeOutOperationOfLayerIds: function () {
            var mapLayerIds = lang.clone(this.map.layerIds);
            if (mapLayerIds.length !== 0) {
                array.forEach(mapLayerIds, lang.hitch(this, function (layer) {
                    var kml = layer.replace("_layer", "");
                    var kmlNode = this._dataLayerTree.getNodesByItem(kml);
                    if (kmlNode[0]) {
                        this._performStrikeOutOperationOfKmlGeoRssCachedLayers(kmlNode);
                    }
                    var wmsLayer = this.map.getLayer(layer);
                    var dupId = lang.clone(layer);
                    var id = dupId.replace("_layer", "");
                    var objWMS = this._dataLayerTree.getNodesByItem(id);
                    if (objWMS[0]) {
                        this._performStrikeOutOperationOfWMSImageWMTSLayers(objWMS, wmsLayer);
                    }
                }));
            }
        },

        /**
         * Function to perform strike out operation of map server and it was added from data layer widget.
         * @param {string} name - Layer id
         */
        _performStrikeOutOperationOfMapserverFromDataLayer: function (name) {
            var msName = name.replace("_layer", "");
            var msNode = this._dataLayerTree.getNodesByItem(msName);
            if (msNode[0]) {
                var replacedId, objNode;
                if (msNode[0].item.strike) {
                    if (msNode[0].item.strike === "Yes") {
                        html.addClass(msNode[0].labelNode, "strikeout");
                        this._hideIcons(msNode[0].item.id);
                        replacedId = msNode[0].item.parent;
                        objNode = this._dataLayerTree.getNodesByItem(replacedId);
                        this._checkPrentStrikeOut(replacedId, objNode);
                        this.appUtils.boolBasemapChanged = false;
                    } else {
                        html.removeClass(msNode[0].labelNode, "strikeout");
                        this._showIcons(msNode[0].item.id);
                        replacedId = msNode[0].item.parent;
                        objNode = this._dataLayerTree.getNodesByItem(replacedId);
                        this._checkPrentStrikeOut(replacedId, objNode);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }
            }
        },

        /**
         * Function to perform strike out operation of map server and it was added from add layer widget.
         * @param {string} name - Layer id
         */
        _performStrikeOutOperationOfMapserverFromAddLayer: function (name) {
            var objNode,
                replacedId;
            var mapServerId = name.replace("_layer", "");
            var mapServerNode = this._dataLayerTree.getNodesByItem(mapServerId);
            if (mapServerNode[0]) {
                if (mapServerNode[0].item.strike) {
                    if (mapServerNode[0].item.strike === "Yes") {
                        html.addClass(mapServerNode[0].labelNode, "strikeout");
                        this._hideIcons(mapServerNode[0].item.id);
                        replacedId = mapServerNode[0].item.parent;
                        objNode = this._dataLayerTree.getNodesByItem(replacedId);
                        this._checkPrentStrikeOut(replacedId, objNode);
                        this.appUtils.boolBasemapChanged = false;
                    } else {
                        html.removeClass(mapServerNode[0].labelNode, "strikeout");
                        this._showIcons(mapServerNode[0].item.id);
                        replacedId = mapServerNode[0].item.parent;
                        objNode = this._dataLayerTree.getNodesByItem(replacedId);
                        this._checkPrentStrikeOut(replacedId, objNode);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }
            }
        },

        /**
         * Function to perform strike out operation of all feature layer's.
         * @param {string} name - Layer id
         * @param {object} objLayer - Layer Node
         */
        _performStrikeOutOperationOfFeatureLayers: function (layer, objLayer) {
            if (objLayer.type === "Feature Layer") {
                var name = layer;
                var mapServerFromAddlayer = name.indexOf("WebService");
                if (mapServerFromAddlayer === -1) {
                    this._performStrikeOutOperationOfMapserverFromDataLayer(name);
                } else {
                    this._performStrikeOutOperationOfMapserverFromAddLayer(name);
                }
            }
        },

        /**
         * Function to perform strikeout operation of graphic layerIds.
         */
        _performStrikeOutOperationOfGraphicsLayerIds: function () {
            var mapGraphicsLayerIds = lang.clone(this.map.graphicsLayerIds);
            if (mapGraphicsLayerIds.length !== 0) {
                array.forEach(mapGraphicsLayerIds, lang.hitch(this, function (layer) {
                    var objLayer = this.map.getLayer(layer);
                    if (objLayer.customLayerType === "csv") {
                        var id = objLayer.id;
                        var layerId = id.replace("_layer", "");
                        var csvNode = this._dataLayerTree.getNodesByItem(layerId);
                        if (csvNode[0].item.strike) {
                            if (csvNode[0].item.strike === "Yes") {
                                html.addClass(csvNode[0].labelNode, "strikeout");
                                this._hideIcons(csvNode[0].item.id);
                                this.appUtils.boolBasemapChanged = false;
                            } else {
                                html.removeClass(csvNode[0].labelNode, "strikeout");
                                this._showIcons(csvNode[0].item.id);
                                this.appUtils.boolBasemapChanged = false;
                            }
                        }
                    }
                    var childNodes = this._dataLayerTreeStore.query({
                        parent: "customLayers"
                    });
                    if (childNodes) {
                        this._performStrikeOutOperationOfFeatureLayers(layer, objLayer);
                    }
                }));
            }
        },

        /**
         * Function to execute the strikeout operation for wms layer
         * @param {Object} objWMS - Object having detail of specific tree node, which is clicked.
         * @param {Object} wmsLayer - Object having detail of specific tree node, which is clicked.
         */
        _enableStrikeOperationOfWMS: function (objWMS, wmsLayer) {
            var replacedId, parentId, childrens, childWMS, objNode;
            if (objWMS[0].item.strike) {
                if (objWMS[0].item.strike === "Yes") {
                    parentId = objWMS[0].item.id;
                    childrens = this._dataLayerTreeStore.query({
                        parent: parentId
                    });
                    if (childrens.length > 0) {
                        for (var j = 0; j < wmsLayer.visibleLayers.length; j++) {
                            var index = j;
                            for (var i = 0; i < childrens.length; i++) {
                                if (index === childrens[i].index) {
                                    childWMS = this._dataLayerTree.getNodesByItem(childrens[i].id);
                                    if (childWMS[0]) {
                                        html.addClass(childWMS[0].labelNode, "strikeout");
                                        this._hideIcons(childWMS[0].item.id);
                                        this.appUtils.boolBasemapChanged = false;
                                    }
                                }
                            }
                        }
                        //Check wms parent strikeout operation
                        replacedId = parentId.replace("_layer", "");
                        objNode = this._dataLayerTree.getNodesByItem(replacedId);
                        this._checkPrentStrikeOut(replacedId, objNode);
                    }
                } else {
                    parentId = objWMS[0].item.id;
                    childrens = this._dataLayerTreeStore.query({
                        parent: parentId
                    });
                    if (childrens.length > 0) {
                        var k, l;
                        for (l = 0; l < wmsLayer.visibleLayers.length; l++) {
                            var indexValue = l;
                            for (k = 0; k < childrens.length; k++) {
                                if (indexValue === childrens[k].index) {
                                    childWMS = this._dataLayerTree.getNodesByItem(childrens[k].id);
                                    if (childWMS[0]) {
                                        html.removeClass(childWMS[0].labelNode, "strikeout");
                                        this._showIcons(childWMS[0].item.id);
                                        this.appUtils.boolBasemapChanged = false;
                                    }
                                }
                            }
                        }
                        //Check wms parent strikeout operation
                        replacedId = parentId.replace("_layer", "");
                        objNode = this._dataLayerTree.getNodesByItem(replacedId);
                        this._checkPrentStrikeOut(replacedId, objNode);
                    }
                }
            }
        },

        /**
         * Function to perform strikeout operation of parent node.
         * @param {Object} replacedId - Parent id
         * @param {Object} objNode - Parent Node
         */
        _checkPrentStrikeOut: function (replacedId, objNode) {
            //Check Parent node strike out.
            var count = null;
            count = 0;
            var childList = this._dataLayerTreeStore.query({
                parent: replacedId
            });
            array.forEach(childList, lang.hitch(this, function (child) {
                var objChild = this._dataLayerTree.getNodesByItem(child.id);
                if (objChild[0].item.unSupportedLayer) {
                    html.addClass(objChild[0].labelNode, "strikeout");
                }
                if (objChild[0].item.strike === "Yes") {
                    html.addClass(objChild[0].labelNode, "strikeout");
                }
                var childClass = objChild[0].labelNode.className;
                var value = childClass.indexOf("strikeout");
                if (value !== -1) {
                    count++;
                }
            }));
            if (count === 3) {
                html.addClass(objNode[0].labelNode, "strikeout");
                this._hideIcons(objNode[0].item.id);
                this.appUtils.boolBasemapChanged = false;
            } else {
                html.removeClass(objNode[0].labelNode, "strikeout");
                this._showIcons(objNode[0].item.id);
                this.appUtils.boolBasemapChanged = false;
            }
        },

        /**
         *  When layers are supported to current base map then display the (Delete,Save,Opacity,Cluster,Heat map)icons.
         * @param {string} id - layer id
         */
        _showIcons: function (id) {
            var deleteIcon = dom.byId(id + "_deleteIcon");
            if (deleteIcon) {
                html.removeClass(deleteIcon, "hideIcon");
                html.addClass(deleteIcon, "deleteLayer");
            }
            var zoomIcon = dom.byId(id + "_toggleZoomClusterIcon");
            if (zoomIcon) {
                html.removeClass(zoomIcon, "hideIcon");
                html.addClass(zoomIcon, "clusterZoomTo");
            }
            var settingIcon = dom.byId(id + "_toggleSettingClusterIcon");
            if (settingIcon) {
                html.removeClass(settingIcon, "hideIcon");
                html.addClass(settingIcon, "clusterSetting");
            }
            var saveIcon = dom.byId(id + "_saveIcon");
            if (saveIcon) {
                html.removeClass(saveIcon, "hideIcon");
                html.addClass(saveIcon, "saveLayer");
            }
        },

        /**
         *  When layers are not supported to current base map then hide the (Delete,Save,Opacity,Cluster,Heat map)icons.
         * @param {string} id - layer id
         */
        _hideIcons: function (id) {
            var deleteIcon = dom.byId(id + "_deleteIcon");
            if (deleteIcon) {
                html.removeClass(deleteIcon, deleteIcon.className);
                html.addClass(deleteIcon, "hideIcon");
            }
            var zoomIcon = dom.byId(id + "_toggleZoomClusterIcon");
            if (zoomIcon) {
                html.removeClass(zoomIcon, zoomIcon.className);
                html.addClass(zoomIcon, "hideIcon");
            }
            var settingIcon = dom.byId(id + "_toggleSettingClusterIcon");
            if (settingIcon) {
                html.removeClass(settingIcon, settingIcon.className);
                html.addClass(settingIcon, "hideIcon");
            }
            var saveIcon = dom.byId(id + "_saveIcon");
            if (saveIcon) {
                html.removeClass(saveIcon, saveIcon.className);
                html.addClass(saveIcon, "hideIcon");
            }
        },

        /**
         * Function to perform strikeout operation of csv layer.
         * @param {Object} csvNode - layer node
         */
        _checkCSVStrikeOutOperation: function (csvNode) {
            var csvLayer = this._dataLayerTree.getNodesByItem(csvNode.id);
            if (csvNode.strike === "Yes") {
                html.addClass(csvLayer[0].labelNode, "strikeout");
                this._hideIcons(csvNode.id);
                this.appUtils.boolBasemapChanged = false;
            } else {
                html.removeClass(csvLayer[0].labelNode, "strikeout");
                this._showIcons(csvNode.id);
                this.appUtils.boolBasemapChanged = false;
            }
        },

        /**
         * On selecting child node decide whether check, uncheck or gray out its parent node.
         * @param {Object} treeNode - Object having detail of specific tree node, which is clicked.
         * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
         */
        _checkHierarchicalNodes: function (treeNode, isChecked) {
            var arrDeferred = [];
            if (treeNode.type === "wms" && treeNode.parent === "customLayers" || treeNode.type === "arcgis_map_service" && treeNode.parent === "customLayers") {
                var layerName = treeNode.name;
                var value = layerName.indexOf("_layer");
                if (value === -1) {
                    this._checkChildNodes(treeNode, isChecked);
                    this._checkParentNodes(treeNode, isChecked);
                    if (treeNode.layerFromAddLayer) {
                        if (treeNode.type === "wms") {
                            this._toggleWMSLayer(treeNode, isChecked);
                        } else {
                            this._toggleLayerFromService(treeNode, isChecked);
                        }
                    } else {
                        if (treeNode.type === "wms") {
                            this._wmsAddLayer(treeNode);
                        } else {
                            this._toggleLayerFromService(treeNode, isChecked);
                        }
                    }
                }
            } else {
                this._toggleLayerFromService(treeNode, isChecked);
            }
            if (this._arrClusterDetail.length) {
                arrDeferred.push(this._manageCluster(this._arrClusterDetail));
            }
            this._arrClusterDetail = [];
            if (this._arrLayerDetail.length) {
                arrDeferred.push(this._toggleLayer(this._arrLayerDetail));
            }
            this._arrLayerDetail = [];
            all(arrDeferred).then(lang.hitch(this, function () {
                this.appUtils.refreshLegend(true);
                this._shelter.hide();
            }));
        },

        /**
         * On selecting node check parent and child nodes and perform toggle on/off operation.
         * @param {Object} treeNode - Object having detail of specific tree node, which is clicked.
         * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
         */
        _toggleLayerFromService: function (treeNode, isChecked) {
            if (treeNode.id) {
                var layer = this._dataLayerTree.getNodesByItem(treeNode.id);
                var className = layer[0].labelNode.className;
                var removeLayerClass = className.indexOf("strikeout");
                if (removeLayerClass !== -1) {
                    html.removeClass(layer[0].labelNode, "strikeout");
                    this._showIcons(layer[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                }
            }
            if (treeNode.url) {
                if (treeNode.geometryType) {
                    if (treeNode.geometryType === "esriGeometryPoint") {
                        var clusterDetail = {
                            "clusterDetail": treeNode,
                            "isCluster": isChecked
                        };
                        var selectionNode = dom.byId(treeNode.id + "_toggleClusterIcon");
                        if (selectionNode.className === "decluster" && this.map.getLayer(treeNode.id + "_layer")) {
                            this._arrLayerDetail.push({
                                "LayerDetail": treeNode,
                                "isChecked": false,
                                "isClustered": false
                            });
                        } else if (selectionNode.className === "decluster" && this.map.getLayer(treeNode.id + "_heatlayer")) {
                            this._arrLayerDetail.push({
                                "LayerDetail": treeNode,
                                "isChecked": false,
                                "isClustered": false
                            });
                        } else {
                            if (this.map.getLayer(treeNode.id + "_cluster")) {
                                this._arrLayerDetail.push({
                                    "LayerDetail": treeNode,
                                    "isChecked": false,
                                    "isClustered": true
                                });
                            } else {
                                this._arrClusterDetail.push(clusterDetail);
                            }
                        }
                    }
                } else {
                    this._arrLayerDetail.push({
                        "LayerDetail": treeNode,
                        "isChecked": isChecked,
                        "isClustered": false
                    });
                }
                this._checkParentNodes(treeNode, isChecked);
            } else {
                this._checkChildNodes(treeNode, isChecked);
                this._checkParentNodes(treeNode, isChecked);
                if (treeNode.layerFromAddLayer) {
                    if (treeNode.type === "wms") {
                        this._toggleWMSLayer(treeNode, isChecked);
                    }
                }
            }
        },

        /**
         * On selecting node check parent and child nodes of wms layer and perform toggle on/off operation.
         * @param {Object} treeNode - Object having detail of specific tree node, which is clicked.
         * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
         */
        _toggleWMSLayer: function (treeNode, isChecked) {
            var layerName = treeNode.name;
            var value = layerName.indexOf("_layer");
            if (value === -1) {
                var wmsLayers = this.map.getLayer(treeNode.id + "_layer");
                if (wmsLayers) {
                    var childNode = this._dataLayerTreeStore.query({
                        parent: treeNode.id
                    });
                    var seletedVisibleLayer = [];
                    array.forEach(childNode, lang.hitch(this, function (node, i) {
                        var selectionNode = dom.byId(node.id + "_checkBox");
                        if (selectionNode) {
                            if (selectionNode.className === "checked") {
                                seletedVisibleLayer.push(node.index);
                            }
                        }
                    }));
                    wmsLayers.setVisibleLayers(seletedVisibleLayer);
                }
            } else {
                var wmsLayer,
                    parentNode = this._dataLayerTreeStore.query({
                        id: treeNode.parent
                    });
                if (parentNode) {
                    wmsLayer = this.map.getLayer(parentNode[0].id + "_layer");
                    if (wmsLayer) {
                        if (parentNode.length) {
                            var childNodes = this._dataLayerTreeStore.query({
                                parent: parentNode[0].id
                            });
                            var seletedVisibleLayers = [];
                            array.forEach(childNodes, lang.hitch(this, function (node, i) {
                                var selectionNode = dom.byId(node.id + "_checkBox");
                                if (selectionNode) {
                                    if (selectionNode.className === "checked") {
                                        seletedVisibleLayers.push(node.index);
                                    }
                                }
                            }));
                            wmsLayer.setVisibleLayers(seletedVisibleLayers);
                        }
                    }
                }
            }
        },

        /**
         * On selecting child node decide whether check, uncheck or gray out its parent node.
         * @param {Object} Node - Object having detail of specific tree node.
         * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
         */
        _checkParentNodes: function (Node, isChecked) {
            var checkNode,
                childNodes,
                childNodesCount,
                nodesChecked = 0,
                nodesUnchecked = 0,
                parentNode = this._dataLayerTreeStore.query({
                    id: Node.parent
                });
            if (parentNode.length) {
                childNodes = this._dataLayerTreeStore.query({
                    parent: parentNode[0].id
                });
                childNodesCount = childNodes.length;
                array.forEach(childNodes, lang.hitch(this, function (node, i) {
                    var selectionNode = dom.byId(node.id + "_checkBox");
                    if (selectionNode) {
                        if (selectionNode.className === "unchecked") {
                            nodesUnchecked++;
                        } else if (selectionNode.className === "checked") {
                            nodesChecked++;
                        }
                    }
                }));
                checkNode = dom.byId(parentNode[0].id + "_checkBox");
                if (checkNode) {
                    if (childNodesCount === nodesChecked) {
                        domClass.remove(checkNode, "unchecked");
                        domClass.remove(checkNode, "partialChecked");
                        domClass.add(checkNode, "checked");

                    } else if (childNodesCount === nodesUnchecked) {
                        domClass.remove(checkNode, "checked");
                        domClass.remove(checkNode, "partialChecked");
                        domClass.add(checkNode, "unchecked");
                    } else {
                        domClass.remove(checkNode, "checked");
                        domClass.remove(checkNode, "unchecked");
                        domClass.add(checkNode, "partialChecked");
                    }
                }
                if (parentNode[0].parent) {
                    this._checkParentNodes(parentNode[0], isChecked);
                }
            }
        },

        /**
         * Select children to add/remove layer from map.
         * @param {Object} Node - Object having detail of specific tree node.
         * @param {Boolean} isChecked - Informs whether specific tree node is checked or not.
         */
        _checkChildNodes: function (Node, isChecked) {
            var childNodes = this._dataLayerTreeStore.query({
                parent: Node.id
            });
            array.forEach(childNodes, lang.hitch(this, function (node, i) {
                var checkNode = dom.byId(node.id + "_checkBox"),
                    clusterIcon, heatmapIcon;
                if (checkNode) {
                    if (isChecked) {
                        domClass.remove(checkNode, "unchecked");
                        domClass.remove(checkNode, "partialChecked");
                        domClass.add(checkNode, "checked");
                    } else {
                        domClass.remove(checkNode, "checked");
                        domClass.remove(checkNode, "partialChecked");
                        domClass.add(checkNode, "unchecked");
                    }
                }
                clusterIcon = dom.byId(node.id + "_toggleClusterIcon");
                heatmapIcon = dom.byId(node.id + "_toggleClusterHeatMapIcon");
                if (heatmapIcon) {
                    if (heatmapIcon.className === "selectedClusterHeatMaps") {
                        domClass.remove(heatmapIcon, "selectedClusterHeatMaps");
                        domClass.add(heatmapIcon, "clusterHeatMaps");
                    }
                }
                if (clusterIcon) {
                    if (!isChecked) {
                        domClass.remove(clusterIcon, "cluster");
                        domClass.add(clusterIcon, "decluster");
                    } else {
                        domClass.remove(clusterIcon, "decluster");
                        domClass.add(clusterIcon, "cluster");
                    }
                    var clusterDetail = {
                        "clusterDetail": node,
                        "isCluster": isChecked
                    };
                    if (!isChecked) {
                        if (this.map.getLayer(node.id + "_layer")) {
                            this._arrLayerDetail.push({
                                "LayerDetail": node,
                                "isChecked": false,
                                "isClustered": false
                            });
                        }
                        if (this.map.getLayer(node.id + "_cluster")) {
                            this._arrLayerDetail.push({
                                "LayerDetail": node,
                                "isChecked": false,
                                "isClustered": true
                            });
                        }
                        if (this.map.getLayer(node.id + "_heatlayer")) {
                            this._arrLayerDetail.push({
                                "LayerDetail": node,
                                "isChecked": false,
                                "isClustered": true
                            });
                        }
                    } else {
                        if (isChecked && !this.map.getLayer(node.id + "_cluster")) {
                            this._arrClusterDetail.push(clusterDetail);
                        }
                    }
                } else if (node.url) {
                    if (isChecked && !this.map.getLayer(node.id + "_layer")) {
                        this._arrLayerDetail.push({
                            "LayerDetail": node,
                            "isChecked": isChecked,
                            "isClustered": false
                        });
                    } else if (!isChecked && this.map.getLayer(node.id + "_layer")) {
                        this._arrLayerDetail.push({
                            "LayerDetail": node,
                            "isChecked": isChecked,
                            "isClustered": false
                        });
                    }
                }
                this._checkChildNodes(node, isChecked);
            }));
        },

        /**
         * Decide to add/remove layer from map.
         * @param {Array} layersDetail - Array of objects having layer detail to decide add/remove them.
         * @returns {deferred.promise}
         */
        _toggleLayer: function (layersDetail) {
            var arrAddLayers = [],
                arrRemoveLayers = [],
                arrDeferred = [],
                deferred = new Deferred();
            array.forEach(layersDetail, lang.hitch(this, function (layerDetail, i) {
                var removeLayerID;
                if (layerDetail.isChecked) {
                    arrAddLayers.push(layerDetail.LayerDetail);
                } else {
                    if (layerDetail.isClustered) {
                        removeLayerID = layerDetail.LayerDetail.id + "_cluster";
                    } else {
                        removeLayerID = layerDetail.LayerDetail.id + "_layer";
                    }
                    arrRemoveLayers.push(removeLayerID);
                }
            }));
            if (arrAddLayers.length) {
                arrDeferred.push(this._addLayers(arrAddLayers));
            }
            if (arrRemoveLayers.length) {
                arrDeferred.push(this._removeLayers(arrRemoveLayers));
            }
            all(arrDeferred).then(lang.hitch(this, function (result) {
                deferred.resolve(result);
            }));
            return deferred.promise;
        },

        /**
         * Add layers to the map.
         * @param {Array} layerDetail - Array of objects having detail for feature layer.
         * @returns {deferredAll.promise}
         */
        _addLayers: function (layerDetail) {
            var arrLayers = [];
            var deferredAll = new Deferred();
            var deferredLayerLoaded = new Deferred();
            var deferredLayerAdded = new Deferred();
            var deferredArray = [];
            var deferredAllArray = [];
            var template = new InfoTemplate("Attributes", layerDetail[0].popupInfo);
            this._shelter.show();
            var layMap = {
                "dynamic": "esri/layers/ArcGISDynamicMapServiceLayer",
                "image": "esri/layers/MapImageLayer",
                "feature": "esri/layers/FeatureLayer",
                "georss": "esri/layers/GeoRSSLayer",
                "csv": "esri/layers/CSVLayer",
                "kml": "esri/layers/KMLLayer",
                "webTiled": "esri/layers/WebTiledLayer",
                "wms": "esri/layers/WMSLayer",
                "wmts": "esri/layers/WMTSLayer",
                "arcgis_map_service": "esri/layers/FeatureLayer",
                "Cached": "esri/layers/ArcGISTiledMapServiceLayer"
            };
            this.own(on(this.map, "layers-add-result", lang.hitch(this, function (evt) {
                var contentinfo,
                    i,
                    j,
                    temdata = "";
                for (i = 0; i < evt.layers.length; i++) {
                    temdata = "";
                    if (evt.layers[i].layer.fields) {
                        for (j = 0; j < evt.layers[i].layer.fields.length; j++) {
                            temdata = temdata + " <div style='font-weight: bold;width:200px;word-break: normal;float: left;'>" + evt.layers[i].layer.fields[j].name + " </div> <div style='white-space: nowrap;line-height:5px'> ${" + evt.layers[i].layer.fields[j].name + "}</div><br/>";
                        }
                        contentinfo = new InfoTemplate();
                        contentinfo.setTitle("Attributes");
                        contentinfo.setContent("<div style='float:left'>" + temdata + "</div>");
                        //evt.layers[i].layer.setInfoTemplate(contentinfo);
                    }
                }
                deferredLayerLoaded.resolve(true);
            })));
            deferredAllArray.push(deferredLayerAdded.promise);
            array.forEach(layerDetail, lang.hitch(this, function (layer) {
                var deferred = new Deferred();
                if (!this.map.getLayer(layerDetail.id + "_layer")) {
                    if (layer.parent === "customLayers") {
                        var maptype = layer.type;
                        require([layMap[maptype]], lang.hitch(this, function (LayerClass) {
                            var customLayer;
                            if (maptype !== "image") {
                                if (layer.layerTitle) {
                                    this._featureCollection(layer);
                                }
                                if (maptype === "wms") {
                                    var childNodes = this._dataLayerTreeStore.query({
                                        parent: layer.id
                                    });
                                    var childNodesCount = childNodes.length;
                                    var strUrl = layer.url,
                                        strId = layer.id,
                                        strName = layer.name,
                                        opacity = layer.opacity,
                                        refreshInterval = layer.refresh;
                                    if (childNodesCount < 1) {
                                        var requestHandle = esriRequest({
                                            "url": strUrl + "?version=1.3.0&request=GetCapabilities&service=WMS",
                                            handleAs: "xml",
                                            useProxy: true
                                        });
                                        requestHandle.then(lang.hitch(this, function (response) {
                                            this.requestSucceeded(response, strUrl, strId, strName, opacity, refreshInterval);
                                        }), lang.hitch(this, this.requestFailed));
                                    } else {
                                        this._toggleWMSLayer(layer, true);
                                        this._shelter.hide();
                                    }
                                } else if (maptype === "arcgis_map_service" && (layer.isCached === 0) && (layer.url.indexOf("MapServer/") === -1) && (layer.url.indexOf("FeatureServer/") === -1)) {
                                    var mapServerTreeNodeID = layer.id;
                                    var strURL = layer.url;
                                    var subLayers = layer["sub-layers"];
                                    childNodes = this._dataLayerTreeStore.query({
                                        parent: layer.id
                                    });
                                    childNodesCount = childNodes.length;
                                    strUrl = layer.url;
                                    strId = layer.id;
                                    strName = layer.name;
                                    opacity = layer.opacity;
                                    refreshInterval = layer.refresh;
                                    if (childNodesCount < 1) {
                                        esriRequest({
                                            url: layer.url,
                                            content: lang.mixin({
                                                f: "json"
                                            }, null),
                                            callbackParamName: "callback",
                                            load: lang.hitch(this, function (response) {
                                                array.forEach(response.layers, lang.hitch(this, function (layer) {
                                                    this._addFeatureLayer(strURL + "/" + layer.id, mapServerTreeNodeID, layer.name, subLayers, opacity, refreshInterval);
                                                }));

                                            }),
                                            error: lang.hitch(this, function (err) {
                                                this._shelter.hide();
                                                this._alertBox.error(err);
                                            })
                                        });

                                    } else {
                                        childNodes = this._dataLayerTreeStore.query({
                                            parent: layer.id
                                        });
                                        var isChecked = true;
                                        array.forEach(childNodes, lang.hitch(this, function (node, i) {
                                            if (node.url) {
                                                if (isChecked && !this.map.getLayer(node.id + "_layer")) {
                                                    var featurLayer = new FeatureLayer(node.url, {
                                                        outFields: ["*"],
                                                        id: node.id + "_layer",
                                                        name: node.name
                                                    });
                                                    featurLayer.customLayerType = maptype;
                                                    this.own(on(featurLayer, "mouse-over", lang.hitch(this, function (evt) {
                                                        this.map.setMapCursor("pointer");
                                                    })));
                                                    this.own(on(featurLayer, "mouse-out", lang.hitch(this, function (evt) {
                                                        this.map.setMapCursor("default");
                                                    })));
                                                    arrLayers.push(featurLayer);
                                                    //this.map.addLayer(featurLayer);
                                                }
                                            }
                                        }));
                                        this._shelter.hide();
                                        deferred.resolve(true);
                                    }
                                } else {
                                    //For kml layer
                                    if (!layer.layerTitle) {
                                        if (layer.isCached === 1) {
                                            customLayer = new ArcGISTiledMapServiceLayer(layer.url, {
                                                id: layer.id + "_layer",
                                                name: layer.name,
                                                title: layer.name,
                                                opacity: layer.opacity / 100,
                                                refreshInterval: layer.refresh
                                            });
                                            customLayer.customLayerType = "cached";
                                        } else {
                                            customLayer = new LayerClass(layer.url, {
                                                outFields: ["*"],
                                                id: layer.id + "_layer",
                                                name: layer.name,
                                                title: layer.name,
                                                opacity: layer.opacity / 100,
                                                refreshInterval: layer.refresh
                                            });
                                            customLayer.customLayerType = maptype;
                                            this.own(on(customLayer, "mouse-over", lang.hitch(this, function (evt) {
                                                this.map.setMapCursor("pointer");
                                            })));
                                            this.own(on(customLayer, "mouse-out", lang.hitch(this, function (evt) {
                                                this.map.setMapCursor("default");
                                            })));
                                        }
                                        arrLayers.push(customLayer);
                                    }
                                }
                            } else {
                                //For image Layer
                                customLayer = new LayerClass({
                                    id: layer.id + "_layer",
                                    name: layer.name
                                });
                                var getMapImage = new MapImage({
                                    "extent": layer.imgBounds,
                                    "href": layer.url,
                                    "height": layer.imgHeight,
                                    "width": layer.imgWidth
                                });
                                customLayer.addImage(getMapImage);
                                customLayer.customLayerType = maptype;
                                arrLayers.push(customLayer);
                            }
                            if (customLayer) {
                                this.own(on(customLayer, "mouse-over", lang.hitch(this, function (evt) {
                                    this.map.setMapCursor("pointer");
                                })));
                                this.own(on(customLayer, "mouse-out", lang.hitch(this, function (evt) {
                                    this.map.setMapCursor("default");
                                })));
                                arrLayers.push(customLayer);
                                deferred.resolve(true);
                            }
                        }));
                    } else {
                        if (layer.type === "graphics") {
                            if (!this.map.getLayer(layer.id + "_layer")) {
                                var graphicsLayer = new GraphicsLayer({
                                    "id": layer.id + "_layer",
                                    "addedType": "graphics",
                                    infoTemplate: new InfoTemplate("Attributes", layer.popupContent)
                                });
                                graphicsLayer.overlayCustomLayerType = layer.name;
                                graphicsLayer.layerFrom = "overlay";
                                this.map.addLayer(graphicsLayer);
                                this.appUtils.overlayLayersAdded(layer);
                                graphicsLayer.enableMouseEvents();
                                esriRequest({
                                    url: layer.url,
                                    content: lang.mixin({
                                        f: "jsonp"
                                    }),
                                    callbackParamName: "callback",
                                    load: lang.hitch(this, function (response) {
                                        var json = JSON.parse(response.graphics);
                                        for (var i = 0; i < json.length; i++) {
                                            var graphic = new Graphic(json[i]);
                                            graphicsLayer.add(graphic);
                                        }
                                        this._shelter.hide();
                                    }),
                                    error: lang.hitch(this, function (err) {
                                        this._shelter.hide();
                                        this._alertBox.error(err);
                                    })
                                });
                                graphicsLayer.on("mouse-over", lang.hitch(this, function () {
                                    this.map.setMapCursor("pointer");
                                }));
                                graphicsLayer.on("mouse-out", lang.hitch(this, function () {
                                    this.map.setMapCursor("default");
                                }));
                            }
                            deferred.resolve(true);
                        } else {
                            var featurLayer = new FeatureLayer(layer.url, {
                                outFields: ["*"],
                                infoTemplate: template,
                                id: layer.id + "_layer",
                                name: layer.name,
                                opacity: layer.opacity / 100,
                                refreshInterval: layer.refresh
                            });
                            featurLayer.customLayerType = maptype;
                            this.own(on(featurLayer, "mouse-over", lang.hitch(this, function (evt) {
                                this.map.setMapCursor("pointer");
                            })));
                            this.own(on(featurLayer, "mouse-out", lang.hitch(this, function (evt) {
                                this.map.setMapCursor("default");
                            })));
                            arrLayers.push(featurLayer);
                            deferred.resolve(true);
                        }
                    }
                    deferredArray.push(deferred.promise);
                }
            }));
            all(deferredArray).then(lang.hitch(this, function (resultLayers) {
                this.map.addLayers(arrLayers);
                this._attachLayerEvents(arrLayers);
                deferredLayerAdded.resolve(true);
            }));
            all(deferredAllArray).then(lang.hitch(this, function (resultLayers) {
                deferredAll.resolve(true);
            }));
            return deferredAll.promise;
        },

        /**
         * Function to perform load event operation of GeoRss and Kml layer's.
         * @param {evt} evt - event
         * @param {Array} layerNode - Layer Node
         */
        _performLoadEventOperationOfGeoRssAndKmlLayers: function (evt, layerNode) {
            var mapSR = this.map.spatialReference,
                layerOutSR = evt.layer._outSR,
                isValidSR;
            if (mapSR.wkid) {
                isValidSR = mapSR._isWebMercator() && layerOutSR._isWebMercator() || mapSR.wkid === layerOutSR.wkid;
            } else if (mapSR.wkt) {
                isValidSR = mapSR.wkt === layerOutSR.wkt;
            } else {
                layerNode[0].item.strike = "Yes";
                html.addClass(layerNode[0].labelNode, "strikeout");
                this._hideIcons(layerNode[0].item.id);
                this.appUtils.boolBasemapChanged = false;
                this._shelter.hide();
                return;
            }
            if (!isValidSR) {
                if (mapSR._isWebMercator() && 4326 === layerOutSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else if (layerOutSR._isWebMercator() && 4326 === mapSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else {
                    layerNode[0].item.strike = "Yes";
                    html.addClass(layerNode[0].labelNode, "strikeout");
                    this._hideIcons(layerNode[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                    this._shelter.hide();
                    return;
                }
            }
            layerNode[0].item.strike = "No";
            html.removeClass(layerNode[0].labelNode, "strikeout");
            this._showIcons(layerNode[0].item.id);
            this.appUtils.boolBasemapChanged = false;
            this._shelter.hide();
        },

        /**
         * Function to start load event operations.
         * @param {evt} evt - event
         */
        _performLoadEventOperations: function (evt) {
            var name = evt.target.id;
            var id = name.replace("_layer", "");
            var layerNode = this._dataLayerTree.getNodesByItem(id);
            if (layerNode[0].item.type === "georss" || layerNode[0].item.type === "kml") {
                this._performLoadEventOperationOfGeoRssAndKmlLayers(evt, layerNode);
            }
            //For cached layer
            if (evt.target.customLayerType === "cached" || evt.target.customLayerType === "Cached") {
                array.forEach(this.map.layerIds, lang.hitch(this, function (layer) {
                    var objLayer = this.map.getLayer(layer);
                    if (objLayer.customLayerType === "cached" || objLayer.customLayerType === "Cached") {
                        var cachedLayerVisible = objLayer.visibleAtMapScale;
                        if (cachedLayerVisible === true) {
                            layerNode[0].item.strike = "No";
                            html.removeClass(layerNode[0].labelNode, "strikeout");
                            this._showIcons(layerNode[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                            this._shelter.hide();
                        } else {
                            layerNode[0].item.strike = "Yes";
                            html.addClass(layerNode[0].labelNode, "strikeout");
                            this._hideIcons(layerNode[0].item.id);
                            this.appUtils.boolBasemapChanged = false;
                            this._shelter.hide();
                        }
                    }
                }));
            }
            this._shelter.hide();
        },

        /**
         * Function to start error event operations.
         * @param {evt} evt - event
         */
        _performErrorEventOperations: function (evt) {
            if (evt.error.message === "Unable to draw graphic (null): Unable to complete  operation." || evt.error.message === "Unable to draw graphic (null): Cannot read property '0' of null") {
                var layerId = evt.target.id;
                var replacedId = layerId.replace("_layer", "");
                if (replacedId) {
                    var objNode = this._dataLayerTree.getNodesByItem(replacedId);
                }
                if (objNode[0]) {
                    if (objNode[0].item.type === "arcgis_map_service") {
                        html.addClass(objNode[0].labelNode, "strikeout");
                        this._hideIcons(objNode[0].item.id);
                        objNode[0].item.strike = "Yes";
                        this.appUtils.boolBasemapChanged = false;
                        var parentId = objNode[0].item.parent;
                        var objParent = this._dataLayerTree.getNodesByItem(parentId);
                        this._checkPrentStrikeOut(parentId, objParent);
                    }
                    if (objNode[0].item.type === "csv") {
                        objNode[0].item.strike = "Yes";
                        this._checkCSVStrikeOutOperation(objNode[0].item);
                    }
                    this._shelter.hide();
                }
            } else {
                this._shelter.hide();
            }
        },

        /**
         * Function to attach events to layer's.
         * @param {array} arrLayers - Layers list.
         */
        _attachLayerEvents: function (arrLayers) {
            array.forEach(arrLayers, lang.hitch(this, function (layer) {
                this.own(on(layer, "load", lang.hitch(this, "_performLoadEventOperations")));
                this.own(on(layer, "error", lang.hitch(this, "_performErrorEventOperations")));
            }));
        },

        /**
         * Function to add wms layers
         * @param {object} treenode - tree Node
         */
        _wmsAddLayer: function (treenode) {
            var childNodes = this._dataLayerTreeStore.query({
                parent: treenode.id
            });
            var parentTreeNode = this._dataLayerTree.getNodesByItem(treenode.id);
            var className = parentTreeNode[0].labelNode.className;
            var removeLayerClass = className.indexOf("strikeout");
            if (removeLayerClass !== -1) {
                html.removeClass(parentTreeNode[0].labelNode, "strikeout");
                this._showIcons(parentTreeNode[0].item.id);
                this.appUtils.boolBasemapChanged = false;
            }
            if (childNodes) {
                array.forEach(childNodes, lang.hitch(this, function (layer) {
                    var objLayer = this._dataLayerTree.getNodesByItem(layer.id);
                    var className = objLayer[0].labelNode.className;
                    var removeLayerClass = className.indexOf("strikeout");
                    if (removeLayerClass !== -1) {
                        html.removeClass(objLayer[0].labelNode, "strikeout");
                        this._showIcons(objLayer[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }));
            }
            var childNodesCount = childNodes.length;
            var strUrl = treenode.url,
                strId = treenode.id,
                strName = treenode.name,
                opacity = treenode.opacity,
                refresh = treenode.refresh;
            var subLayers = treenode["sub-layers"];
            if (childNodesCount < 1) {
                var requestHandle = esriRequest({
                    "url": strUrl + "?version=1.3.0&request=GetCapabilities&service=WMS",
                    handleAs: "xml",
                    useProxy: true
                });
                requestHandle.then(lang.hitch(this, function (response) {
                    this.requestSucceeded(response, strUrl, strId, strName, subLayers, opacity, refresh);
                }), lang.hitch(this, this.requestFailed));
            } else {
                this._toggleWMSLayer(treenode, true);
                this._shelter.hide();
            }
        },

        /**
         * This function to add feature layer.
         * @param {string} strUrl - Url for map server.
         * @param {string} parentID - parentID for map server.
         * @param {string} layerName - layerName for map server.
         * @param {string} subLayers - subLayers for map server.
         * @param {string} opacity - opacity for map server.
         * @param {string} refreshInterval - refreshInterval for map server.
         */
        _addFeatureLayer: function (strUrl, parentID, layerName, subLayers, opacity, refreshInterval) {
            var featurLayer, state = 0;
            var layerID = layerName + "_" + parentID + "_layer";
            var treeNodeID = layerName + "_" + parentID;

            var name = (layerName) ? layerName : this._layerName;
            featurLayer = new FeatureLayer(strUrl, {
                outFields: ["*"],
                //infoTemplate: template,
                id: layerID,
                name: layerName,
                opacity: opacity / 100,
                refreshInterval: refreshInterval
            });
            featurLayer.customLayerType = "arcgis_map_service";
            if (subLayers) {
                for (var i = 0; i < subLayers.length; i++) {

                    if (subLayers[i].toLowerCase() === layerName.toLowerCase()) {
                        this.map.addLayer(featurLayer);
                        state = 1;
                    }
                }
            }
            //             else {
            //                this.map.addLayer(featurLayer);
            //                state = 1;
            //            }
            var webMapServerDynamicLayer = {
                "type": "arcgis_map_service",
                "url": strUrl,
                "opacity": opacity,
                "refresh": refreshInterval,
                "bbox": 0,
                "id": treeNodeID,
                "name": name,
                "state": state,
                "sr": 102100,
                "basemap": 0,
                "parent": parentID,
                "layerFromAddLayer": true
            };
            this.appUtils.customLayerAdded(webMapServerDynamicLayer);
            this.own(on(featurLayer, "load", lang.hitch(this, function (evt) {
                this._shelter.hide();
                this.map.setExtent(evt.layer.fullExtent);
                featurLayer.on("mouse-over", lang.hitch(this, function () {
                    this.map.setMapCursor("pointer");
                }));
                featurLayer.on("mouse-out", lang.hitch(this, function () {
                    this.map.setMapCursor("default");
                }));
                var contentinfo = new InfoTemplate(),
                    temdata = "";
                contentinfo.setTitle("Attributes");
                for (var i = 0; i < evt.layer.fields.length; i++) {
                    temdata = temdata + "<div style='font-weight: bold;max-width:150px;width:125px;float: left;'>" + evt.layer.fields[i].name + " </div> <div style='white-space: nowrap;line-height:5px'> ${" + evt.layer.fields[i].name + "}</div><br/>";
                }
                contentinfo.setContent("<div style='float:left'>" + temdata + "</div>");
                featurLayer.setInfoTemplate(contentinfo);
            })));
            this.own(on(featurLayer, "error", lang.hitch(this, function (evt) {
                if (evt.error.message === "Unable to draw graphic (null): Unable to complete  operation.") {
                    var name = evt.target.id;
                    //var childName = name.replace(evt.target.name + "_", "");
                    var id = name.replace("_layer", "");
                    var layerNode = this._dataLayerTree.getNodesByItem(id);
                    if (layerNode[0]) {
                        layerNode[0].item.strike = "Yes";
                        //this.appUtils.boolBasemapChanged = true;
                        this.appUtils.layerAddedOnBasemap(true);
                    }
                    this._shelter.hide();
                } else {
                    this._shelter.hide();
                }
            })));
        },

        /**
         * This function to add and display the results of  WMS layer.
         * @param {string} strUrl - Url for map server.
         * @param {string} parentID - parentID for map server.
         * @param {string} layerName - layerName for map server.
         * @param {string} subLayers - subLayers for map server.
         * @param {string} opacity - opacity for map server.
         * @param {string} refreshInterval - refreshInterval for map server.
         */
        requestSucceeded: function (response, strUrl, strId, strName, subLayers, opacity, refreshInterval) {
            var x = this.xmlToJson(response);
            var parentId = strId,
                _LayerId = 1;
            var visibleLayers = [];
            for (var i = 0; i < x.WMS_Capabilities.Capability.Layer.Layer.length; i++) {
                var state = 0;
                if (subLayers) {
                    for (var j = 0; j < subLayers.length; j++) {
                        if (subLayers[j].toLowerCase() === i.toString()) {
                            visibleLayers.push(i);
                            state = 1;
                        }
                    }
                }
                this._addWMSSubLayers("", parentId, strName + "_layer" + "_" + i, i, state);
                _LayerId++;
            }
            var wmsLayer = new WMSLayer(strUrl, {
                format: "png",
                visibleLayers: visibleLayers,
                id: parentId + "_layer",
                name: strName,
                opacity: opacity / 100,
                refreshInterval: refreshInterval
            });
            wmsLayer.customLayerType = "wms";
            this.map.addLayer(wmsLayer);
            this.own(on(wmsLayer, "load", lang.hitch(this, function (evt) {
                this.map.setExtent(evt.layer.fullExtent);
                this._LayerId++;
                this._shelter.hide();
            })));
            this.own(on(wmsLayer, "error", lang.hitch(this, function (evt) {
                var message = evt.error.message;
                var notValid = message.indexOf("Unable to load image");
                if (notValid !== -1) {
                    var id = evt.target.id;
                    this._wmsStrikeOutFromErrorReport(wmsLayer, id);
                } else {
                    this._shelter.hide();
                }
            })));
        },

        /**
         * Function to perform strikeout operation of wms layer.
         * @param {Object} wmsLayer - Child Nodes
         * @param {Object} id - Parent id
         */
        _wmsStrikeOutFromErrorReport: function (wmsLayer, id) {
            var layerId = id;
            var objNode;
            var replacedId = layerId.replace("_layer", "");
            if (replacedId) {
                objNode = this._dataLayerTree.getNodesByItem(replacedId);
                if (wmsLayer.visibleLayers !== 0) {
                    var childrens = this._dataLayerTreeStore.query({
                        parent: replacedId
                    });
                    for (var j = 0; j < wmsLayer.visibleLayers.length; j++) {
                        var index = j;
                        for (var i = 0; i < childrens.length; i++) {
                            if (index === childrens[i].index) {
                                var childWMS = this._dataLayerTree.getNodesByItem(childrens[i].id);
                                if (childWMS[0]) {
                                    childWMS[0].strike = "Yes";
                                    html.addClass(childWMS[0].labelNode, "strikeout");
                                    this._hideIcons(childWMS[0].item.id);
                                    this.appUtils.boolBasemapChanged = false;
                                }
                            }
                        }
                    }
                    //Check wms parent strikeout operation
                    objNode = this._dataLayerTree.getNodesByItem(replacedId);
                    this._checkPrentStrikeOut(replacedId, objNode);
                }
            }
        },

        /**
         * Function to display the error results of wms layers.
         * @param {Object} error - Child Nodes
         */
        requestFailed: function (error, io) {
            this._alertBox.error(error);
        },

        /**
         * Function to add wms and sub layers.
         * @param {string} strUrl - Url for map server.
         * @param {string} parentID - parentID for map server.
         * @param {string} layerName - layerName for map server.
         * @param {string} index - index for map server.
         * @param {string} state - state for map server.
         */
        _addWMSSubLayers: function (strUrl, parentID, layerName, index, state) {
            var treeNodeID = layerName + "_" + index;
            var name = (layerName) ? layerName : this._layerName;
            var webMapServerDynamicLayer = {
                "type": "wms",
                "url": strUrl,
                "opacity": 100.0,
                "refresh": 20,
                "bbox": 0,
                "id": treeNodeID,
                "name": name,
                "state": state,
                "sr": 102100,
                "basemap": 0,
                "parent": parentID,
                "layerFromAddLayer": true,
                "index": index
            };
            this.appUtils.customLayerAdded(webMapServerDynamicLayer);
        },

        /**
         * Function to build data in json format.
         * @param {Object} xml - data.
         * @returns {obj}
         */
        xmlToJson: function (xml) {
            // Create the return object
            var obj = {};
            if (xml.nodeType == 1) { // element
                // do attributes
                if (xml.attributes.length > 0) {
                    obj["@attributes"] = {};
                    for (var j = 0; j < xml.attributes.length; j++) {
                        var attribute = xml.attributes.item(j);
                        obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
                    }
                }
            } else if (xml.nodeType == 3) { // text
                obj = xml.nodeValue;
            }
            // do children
            if (xml.hasChildNodes()) {
                for (var i = 0; i < xml.childNodes.length; i++) {
                    var item = xml.childNodes.item(i);
                    var nodeName = item.nodeName;
                    if (typeof (obj[nodeName]) == "undefined") {
                        obj[nodeName] = this.xmlToJson(item);
                    } else {
                        if (typeof (obj[nodeName].push) == "undefined") {
                            var old = obj[nodeName];
                            obj[nodeName] = [];
                            obj[nodeName].push(old);
                        }
                        obj[nodeName].push(this.xmlToJson(item));
                    }
                }
            }
            return obj;
        },

        /**
         * Function to add feature collection layer.
         * @param {Object} layer - layer object.
         */
        _featureCollection: function (layer) {
            var requestHandle = esriRequest({
                url: layer.url,
                callbackParamName: "jsoncallback"
            });
            requestHandle.then(lang.hitch(this, function (data) {
                var featureCollection,
                    featureLayer;
                featureCollection = {
                    "layerDefinition": data.layerDefinition,
                    "featureSet": {
                        "features": [],
                        "geometryType": "esriGeometryPoint"
                    }
                };
                featureLayer = new FeatureLayer(featureCollection, {
                    outFields: ["*"],
                    id: layer.id + "_layer",
                    name: layer.name,
                    opacity: layer.opacity,
                    refreshInterval: layer.refresh
                });
                featureLayer.customLayerType = "feature_collection";
                this.map.addLayers([featureLayer]);
                this.own(on(featureLayer, "mouse-over", lang.hitch(this, function (evt) {
                    this.map.setMapCursor("pointer");
                })));
                this.own(on(featureLayer, "mouse-out", lang.hitch(this, function (evt) {
                    this.map.setMapCursor("default");
                })));
                //setTimeout: loading of layers sometimes take time, so wait for 500seconds.
                setTimeout(lang.hitch(this, function () {
                    var extent,
                        featuresList = [],
                        unionExtent = null;
                    array.forEach(data.features, lang.hitch(this, function (item) {
                        var geometry = new Point(item.geometry.x, item.geometry.y, this.map.spatialReference),
                            graphic;
                        graphic = new Graphic(geometry);
                        graphic.setAttributes(item.attributes);
                        extent = new Extent(graphic.geometry.x - 1, graphic.geometry.y - 1, graphic.geometry.x + 1, graphic.geometry.y + 1, graphic.geometry.spatialReference);
                        if (unionExtent) {
                            unionExtent = unionExtent.union(extent);
                        } else {
                            unionExtent = new Extent(graphic.geometry.x - 1, graphic.geometry.y - 1, graphic.geometry.x + 1, graphic.geometry.y + 1, graphic.geometry.spatialReference);
                        }
                        featuresList.push(graphic);
                    }));
                    this.map.setExtent(unionExtent);
                    featureLayer.applyEdits(featuresList, null, null);
                    this._LayerId++;
                    this._shelter.hide();
                }), 500);
            }), lang.hitch(this, function (error) {
                this._shelter.hide();
                this._alertBox.error(sharedNls.AddLayer.errorMessages.featureCollectionError + error);
            }));

        },

        /**
         * Function to delete custom layer.
         * @param {Object} layerIds - layer object.
         */
        _deleteCustomLayer: function (layerIds) {
            if (layerIds.parent) {
                if (layerIds.parent === "customLayers") {
                    var deletePromtMessage = this._alertBox.confirm(sharedNls.DataLayer.conformToDelete);
                    deletePromtMessage.then(lang.hitch(this, function (res) {
                        esriRequest({
                            url: this.config.CustomLayerDeleteService,
                            content: lang.mixin({
                                customLayerID: layerIds.id
                            }, null),
                            callbackParamName: "callback",
                            load: lang.hitch(this, function () {
                                if (this.map.getLayer(layerIds.id + "_layer")) {
                                    this.map.removeLayer(this.map.getLayer(layerIds.id + "_layer"));
                                } else {

                                    var childNodes = this._dataLayerTreeStore.query({
                                        parent: layerIds.id
                                    });
                                    array.forEach(childNodes, lang.hitch(this, function (node) {
                                        if (node.url) {
                                            var childLayer = this.map.getLayer(node.id + "_layer");
                                            if (childLayer) {
                                                this.map.removeLayer(childLayer);
                                            }
                                        }
                                    }));

                                }
                                this._alertBox.success(sharedNls.DataLayer.deleteLayer);
                                this._dataLayerTreeStore.remove(layerIds.id);
                                var deleteLayerName = this.appUtils.customLayerName.indexOf(layerIds.name);
                                if (deleteLayerName >= 0) {
                                    this.appUtils.customLayerName.splice(deleteLayerName, 1);
                                }
                                var deleteServiceLayerName = this.appUtils.customLayerServiceName.indexOf(layerIds.name);
                                if (deleteServiceLayerName >= 0) {
                                    this.appUtils.customLayerServiceName.splice(deleteLayerName, 1);
                                }
                            }),
                            error: lang.hitch(this, function (err) {
                                this._alertBox.error(err);
                            })
                        });
                    }));
                }
            }
        },

        /**
         * Function to execute the strikeout operation for image layer
         * @param {Object} checkNode - Object having detail of specific tree node, which is clicked.
         */
        _strikeOutOpereationOfImage: function (checkNode) {
            var basemap = this.map.getLayer(this.map.layerIds[0]);
            var basemapSR = basemap.spatialReference.wkid;
            if (basemapSR === 102100 && 4326) {
                checkNode[0].item.strike = "No";
            } else {
                checkNode[0].item.strike = "Yes";
            }
            if (checkNode[0].checkbox.className === "checked") {
                if (checkNode[0].item.strike === "Yes") {
                    var imageLayerId = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                    html.addClass(imageLayerId[0].labelNode, "strikeout");
                    this._hideIcons(imageLayerId[0].item.id);
                    this.appUtils.boolBasemapChanged = false;
                }
            }
            if (checkNode[0].checkbox.className === "unchecked") {
                if (checkNode[0].item.strike === "No") {
                    var layerClass = checkNode[0].checkbox.className;
                    var removeLayerClass = layerClass.indexOf("strikeout");
                    if (removeLayerClass !== -1) {
                        var imageId = this._dataLayerTree.getNodesByItem(checkNode[0].item.id);
                        html.removeClass(imageId[0].labelNode, "strikeout");
                        this._showIcons(imageId[0].item.id);
                        this.appUtils.boolBasemapChanged = false;
                    }
                }
            }
        },

        /**
         * Remove layers from the map
         * @param {Array} layerIds - Ids of layers to remove from map.
         * @returns {deferred.promise}
         */
        _removeLayers: function (layerIds) {
            var deferred = new Deferred();
            array.forEach(layerIds, lang.hitch(this, function (layer) {
                var layerNode = this.map.getLayer(layer);
                var bool = false;
                if (this.lastEditedOverlayId) {
                    bool = this.lastEditedOverlayId + "_layer" === layerNode.id ? true : false;
                }
                if (dom.byId("editFeaturesMainContainer") && bool) {
                    domConstruct.destroy("editFeaturesMainContainer");
                }
                if (layerNode) {
                    this.map.removeLayer(layerNode);
                    this.map.infoWindow.hide();
                } else {
                    var layerId = layer;
                    if (layerId.indexOf("_layer") > 0) {
                        layerId = layerId.replace("_layer", "_heatlayer");

                    } else if (layerId.indexOf("_cluster") > 0) {
                        layerId = layerId.replace("_cluster", "_heatlayer");

                    }
                    if (this.map.getLayer(layerId)) {
                        this.map.removeLayer(this.map.getLayer(layerId));
                    }
                }
            }));
            deferred.resolve(true);
            this.appUtils.refreshLegend(true);
            return deferred.promise;
        },

        /**
         * Function to Request the data layer tree service.
         */
        _getDataTreeJSON: function () {
            var deferredArray = [],
                arrLayerList = [];
            if (this.config.LayerTreeService) {
                arrLayerList.push(this.config.LayerTreeService);
            }
            if (this.config.CustomLayerTreeService) {
                arrLayerList.push(this.config.CustomLayerTreeService);
            }
            array.forEach(arrLayerList, lang.hitch(this, function (url) {
                var deferred = new Deferred();
                esriRequest({
                    url: url,
                    content: lang.mixin({
                        f: "json"
                    }, null),
                    callbackParamName: "callback",
                    load: lang.hitch(this, function (response) {
                        deferred.resolve(response);
                    }),
                    error: lang.hitch(this, function (err) {
                        deferred.resolve(false);
                    })
                });
                deferredArray.push(deferred.promise);
            }));
            all(deferredArray).then(lang.hitch(this, function (responseResults) {
                var count = 0;
                var allFeatures = [];
                array.forEach(responseResults, lang.hitch(this, function (result) {
                    allFeatures = allFeatures.concat(result);
                }));
                this._processDataTreeJSON(allFeatures, count);
            }));
        },

        /**
         * Construct root node for data layer tree.
         * @param {Object} response - JSON object having detail for data layer tree.
         * @param {string} count - count value.
         */
        _processDataTreeJSON: function (response, count) {
            for (var j = 0; j < response.length; j++) {
                array.forEach(response[j].DataLayerGroups, lang.hitch(this, function (item, i) {
                    this._layerData.push({
                        id: item.id,
                        name: item.name,
                        parent: "datalayergroups"
                    });
                    this._getDataLayerTreeItem(item, item.id);
                }));
            }
            this._displayDataLayerTree(count);
        },

        /**
         * Construct child for data layer tree.
         * @param {Object} item - Object having detail of specific tree node.
         * @param {String} parentId - Parent node id of child node.
         */
        _getDataLayerTreeItem: function (item, parentId) {
            if (item.groups.length) {
                array.forEach(item.groups, lang.hitch(this, function (group, i) {
                    this._layerData.push({
                        "id": group.id,
                        "name": group.name,
                        "parent": parentId
                    });
                    if (group.layers.length !== 0) {
                        this._getDataLayerTreeItem(group, group.id);
                    }
                }));
            }
            if (item.layers.length !== 0) {
                array.forEach(item.layers, lang.hitch(this, function (layer, i) {
                    layer.parent = parentId;
                    this._layerData.push(layer);
                }));
            }
        },

        /**
         * Construct and display data layer tree.
         * @param {string} count - count value.
         * @returns {treeNode}
         */
        _displayDataLayerTree: function (count) {
            require([
                "dojo/store/Memory",
                "dojo/store/Observable",
                "dijit/tree/ObjectStoreModel",
                "dijit/Tree"
            ], lang.hitch(this, function (Memory, Observable, ObjectStoreModel, Tree) {
                var arrayLayers = [],
                    arrLayers = [],
                    turnOnLayers = [],
                    _saveService = this.config.CustomLayerSaveService,
                    _deleteService = this.config.CustomLayerDeleteService,
                    _overlayDeleteService = this.config.OverlayDeleteService,
                    _overlayUpdateService = this.config.OverlayUpdateService;
                if (this.appUtils.customLayerCollection) {
                    this._layerData = this._layerData.concat(this.appUtils.customLayerCollection);
                }
                if (this.appUtils.mapServerLayers) {
                    this._layerData = this._layerData.concat(this.appUtils.mapServerLayers);
                }
                this._dataLayerTreeStore = new Memory({
                    data: this._layerData,
                    getChildren: function (object) {
                        return this.query({
                            parent: object.id
                        });
                    }
                });
                this._dataLayerTreeStore = new Observable(this._dataLayerTreeStore);
                this._dataLayerTreeModel = new ObjectStoreModel({
                    store: this._dataLayerTreeStore,
                    query: {
                        id: "datalayergroups"
                    }
                });
                this._dataLayerTree = new Tree({
                    model: this._dataLayerTreeModel,
                    autoExpand: true,
                    id: "dataLayerTree",
                    _createTreeNode: function (args) {
                        var toggleClusterNode,
                            toggleDeleteNode,
                            toggleClusterHeatMaps,
                            toggleClusterSettingNode,
                            toggleClusterZoomNode,
                            saveNode,
                            treeNode,
                            treeNodeCheckBox;
                        treeNode = new Tree._TreeNode(args);
                        if (args.item.strike) {
                            html.addClass(treeNode.labelNode, "strikeout");
                            arrLayers.push(treeNode.item.id);
                            if (treeNode.item.type === "arcgis_map_service" || treeNode.item.type === "wms") {
                                arrayLayers.push(treeNode.item);
                            }
                        } else {
                            html.removeClass(treeNode.labelNode, "strikeout");
                        }
                        treeNodeCheckBox = html.create("div", {
                            "id": args.item.id + "_checkBox"
                        }, null);
                        //domClass.add(treeNodeCheckBox, "unchecked");
                        domClass.add(treeNodeCheckBox, (treeNode.item.state === 1) ? "checked" : "unchecked");
                        domConstruct.place(treeNodeCheckBox, treeNode.labelNode, "first");
                        if (args.item.geometryType) {
                            if (args.item.geometryType === "esriGeometryPoint") {
                                toggleClusterNode = html.create("div", {
                                    "id": args.item.id + "_toggleClusterIcon"
                                }, null);
                                domClass.add(toggleClusterNode, (treeNode.item.state === 1) ? "cluster" : "decluster");
                                domConstruct.place(toggleClusterNode, treeNode.labelNode, "last");
                                on(toggleClusterNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/cluster/clicked", [{
                                        "cluster": this,
                                        "item": treeNode.item
                                    }]);
                                });
                                toggleClusterHeatMaps = html.create("div", {
                                    "id": args.item.id + "_toggleClusterHeatMapIcon"
                                }, null);
                                domClass.add(toggleClusterHeatMaps, "clusterHeatMaps");
                                domConstruct.place(toggleClusterHeatMaps, treeNode.labelNode);
                                on(toggleClusterHeatMaps, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/cluster/HeatMaps", [{
                                        "clusterHeatMaps": this,
                                        "item": treeNode.item
                                    }]);
                                });
                                toggleClusterZoomNode = html.create("div", {
                                    "id": args.item.id + "_toggleZoomClusterIcon"
                                }, null);
                                domClass.add(toggleClusterZoomNode, "clusterZoomTo");
                                domConstruct.place(toggleClusterZoomNode, treeNode.labelNode);
                                on(toggleClusterZoomNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/cluster/ZoomTo", [{
                                        "clusterZoomTo": this,
                                        "item": treeNode.item
                                    }]);
                                });
                                toggleClusterSettingNode = html.create("div", {
                                    "id": args.item.id + "_toggleSettingClusterIcon"
                                }, null);
                                domClass.add(toggleClusterSettingNode, "clusterSetting");
                                domConstruct.place(toggleClusterSettingNode, treeNode.labelNode, "last");
                                on(toggleClusterSettingNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/cluster/settings", [{
                                        "clusterSettings": this.parentNode,
                                        "item": treeNode.item
                                    }]);
                                });
                            }
                        }
                        if (args.item.parent === "customLayers") {
                            if (!args.item.layerFromAddLayer) {
                                if (_deleteService) {
                                    toggleDeleteNode = html.create("div", {
                                        "id": args.item.id + "_deleteIcon"
                                    }, null);
                                    domClass.add(toggleDeleteNode, "deleteLayer");
                                    domConstruct.place(toggleDeleteNode, treeNode.labelNode, "last");
                                    on(toggleDeleteNode, "click", function () {
                                        var treeNode = registry.getEnclosingWidget(this.parentNode);
                                        topic.publish("/delete/clicked", [{
                                            "delete": this,
                                            "item": treeNode.item
                                        }]);
                                    });
                                }
                                toggleClusterZoomNode = html.create("div", {
                                    "id": args.item.id + "_toggleZoomClusterIcon"
                                }, null);
                                domClass.add(toggleClusterZoomNode, "clusterZoomTo");
                                domConstruct.place(toggleClusterZoomNode, treeNode.labelNode);
                                on(toggleClusterZoomNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/customLayers/ZoomTo", [{
                                        "zoomTo": this,
                                        "item": treeNode.item
                                    }]);
                                });

                                toggleClusterSettingNode = html.create("div", {
                                    "id": args.item.id + "_toggleSettingClusterIcon"
                                }, null);
                                domClass.add(toggleClusterSettingNode, "clusterSetting");
                                domConstruct.place(toggleClusterSettingNode, treeNode.labelNode, "last");
                                on(toggleClusterSettingNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/customLayers/settings", [{
                                        "settings": this.parentNode,
                                        "item": treeNode.item
                                    }]);
                                });
                            } else {
                                if (_saveService) {
                                    saveNode = html.create("div", {
                                        "id": args.item.id + "_saveIcon"
                                    }, null);
                                    domClass.add(saveNode, "saveLayer");
                                    domConstruct.place(saveNode, treeNode.labelNode, "last");
                                    on(saveNode, "click", function () {
                                        var treeNode = registry.getEnclosingWidget(this.parentNode);
                                        topic.publish("/save/clicked", [{
                                            "save": this,
                                            "item": treeNode.item
                                        }]);
                                    });
                                }
                                if (_deleteService) {
                                    toggleDeleteNode = html.create("div", {
                                        "id": args.item.id + "_deleteIcon"
                                    }, null);
                                    domClass.add(toggleDeleteNode, "deleteLayer");
                                    domConstruct.place(toggleDeleteNode, treeNode.labelNode, "last");
                                    on(toggleDeleteNode, "click", function () {
                                        var treeNode = registry.getEnclosingWidget(this.parentNode);
                                        topic.publish("/delete/clicked", [{
                                            "delete": this,
                                            "item": treeNode.item
                                        }]);
                                    });
                                }
                                toggleClusterZoomNode = html.create("div", {
                                    "id": args.item.id + "_toggleZoomClusterIcon"
                                }, null);
                                domClass.add(toggleClusterZoomNode, "clusterZoomTo");
                                domConstruct.place(toggleClusterZoomNode, treeNode.labelNode);
                                on(toggleClusterZoomNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/customLayers/ZoomTo", [{
                                        "zoomTo": this,
                                        "item": treeNode.item
                                    }]);
                                });
                                toggleClusterSettingNode = html.create("div", {
                                    "id": args.item.id + "_toggleSettingClusterIcon"
                                }, null);
                                domClass.add(toggleClusterSettingNode, "clusterSetting");
                                domConstruct.place(toggleClusterSettingNode, treeNode.labelNode, "last");
                                on(toggleClusterSettingNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/customLayers/settings", [{
                                        "settings": this.parentNode,
                                        "item": treeNode.item
                                    }]);
                                });
                            }
                        } else if (args.item.parent === "nc4maps_overlays") {
                            if (_overlayUpdateService) {
                                var toggleEditOverlays = html.create("div", {
                                    "id": args.item.id + "_toggleOverlayEditIcon"
                                }, null);
                                domClass.add(toggleEditOverlays, "overlayEdit");
                                domConstruct.place(toggleEditOverlays, treeNode.labelNode);
                                on(toggleEditOverlays, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/overlays/Edit", [{
                                        "clusterOverlays": this,
                                        "item": treeNode.item
                                    }]);

                                });
                            }
                            var toggleOverlaysZoomNode = html.create("div", {
                                "id": args.item.id + "_toggleZoomClusterIcon"
                            }, null);
                            domClass.add(toggleOverlaysZoomNode, "clusterZoomTo");
                            domConstruct.place(toggleOverlaysZoomNode, treeNode.labelNode);
                            on(toggleOverlaysZoomNode, "click", function () {
                                var treeNode = registry.getEnclosingWidget(this.parentNode);
                                topic.publish("/overlays/ZoomTo", [{
                                    "clusterZoomTo": this,
                                    "item": treeNode.item
                                }]);
                            });
                            var toggleOverlaysSettingNode = html.create("div", {
                                "id": args.item.id + "_toggleoverlaySettingIcon"
                            }, null);
                            domClass.add(toggleOverlaysSettingNode, "overlaySetting");
                            domConstruct.place(toggleOverlaysSettingNode, treeNode.labelNode, "last");
                            on(toggleOverlaysSettingNode, "click", function () {
                                var treeNode = registry.getEnclosingWidget(this.parentNode);
                                topic.publish("/overlays/settings", [{
                                    "overlaySetting": this.parentNode,
                                    "item": treeNode.item
                                }]);
                            });
                            if (_overlayDeleteService) {
                                var toggleOverlaysDeleteNode = html.create("div", {
                                    "id": args.item.id + "_deleteIcon"
                                }, null);
                                domClass.add(toggleOverlaysDeleteNode, "deleteLayer");
                                domConstruct.place(toggleOverlaysDeleteNode, treeNode.labelNode, "last");
                                on(toggleOverlaysDeleteNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/deleteOverlays/clicked", [{
                                        "delete": this,
                                        "item": treeNode.item
                                    }]);
                                });
                            }
                            if (_overlayUpdateService) {
                                var toggleOverlaysSaveNode = html.create("div", {
                                    "id": args.item.id + "_saveIcon"
                                }, null);
                                domClass.add(toggleOverlaysSaveNode, "saveRefreshLayerHide");
                                domConstruct.place(toggleOverlaysSaveNode, treeNode.labelNode, "last");
                                on(toggleOverlaysSaveNode, "click", function () {
                                    var treeNode = registry.getEnclosingWidget(this.parentNode);
                                    topic.publish("/OverlaySave/clicked", [{
                                        "save": this,
                                        "item": treeNode.item
                                    }]);
                                });
                            }
                        }
                        on(treeNodeCheckBox, "click", function () {
                            var treeNode = registry.getEnclosingWidget(this.parentNode);
                            topic.publish("/checkbox/clicked", [{
                                "checkbox": this,
                                "item": treeNode.item
                            }]);
                        });
                        if (treeNode.item.state === 1) {
                            turnOnLayers.push(treeNode);
                            setTimeout(lang.hitch(this, function () {
                                topic.publish("checkParents", [treeNode.item, true]);
                            }), 1000);
                        }
                        return treeNode;
                    }
                }, this._dataLayerTreeNode);
                this._dataLayerTree.startup();
                this._dataLayerTree.onLoadDeferred.then(lang.hitch(this, function () {
                    this._turnOnLayers(turnOnLayers);
                    this._checkWmsStrikeOut();
                    this._strikeOutForParentLayers(arrayLayers);
                    this._performStrikeOutOfLayerAddedFromAddlayer(arrLayers);
                    this._dataLayerTree.collapseAll();
                    setTimeout(lang.hitch(this, function () {
                        this._dataLayerTree.set("path", ["datalayergroups", "eteam"]);
                        this.appUtils.customLayerCollection = [];
                        html.setStyle(this.hideNode, "display", "none");
                        html.setStyle(this.domNode, "overflow", "auto");
                        this._shelter.hide();
                    }), 1000);
                }));
            }));
        },

        /**
         * Function to turn on the layer if layer state = 1.
         * @param {array} turnOnLayers - Array of layers.
         */
        _turnOnLayers: function (turnOnLayers) {
            array.forEach(turnOnLayers, lang.hitch(this, function (node) {
                var layerNode = this._dataLayerTree.getNodesByItem(node.item.id);
                //this._checkBoxClicked(layerNode);
                this._checkHierarchicalNodes(layerNode[0].item, true);
            }));
        },

        /**
         * Function to perform strikeout operation of layers which are added from addlayer widget.
         * @param {array} arrLayers - Array of layers.
         */
        _performStrikeOutOfLayerAddedFromAddlayer: function (arrLayers) {
            array.forEach(arrLayers, lang.hitch(this, function (layerId) {
                this._hideIcons(layerId);
            }));
        },

        /**
         * Function to execute strikeout for parent node while adding layer from addlayer
         * @param {array} arrayLayers - array contains layer list which are striked out.
         */
        _strikeOutForParentLayers: function (arrayLayers) {
            array.forEach(arrayLayers, lang.hitch(this, function (layerNode) {
                var parentId = layerNode.parent;
                var parentNode = this._dataLayerTree.getNodesByItem(parentId);
                if (parentNode[0]) {
                    this._checkPrentStrikeOut(parentId, parentNode);
                }
            }));
        },

        /**
         * Function to execute strikeout of wms layer.
         */
        _checkWmsStrikeOut: function () {
            var childNodes = this._dataLayerTreeStore.query({
                parent: "customLayers"
            });
            array.forEach(childNodes, lang.hitch(this, function (childLayer) {
                if (childLayer.type === "wms") {
                    if (childLayer.strike === "Yes") {
                        var wmsLayer = this.map.getLayer(childLayer.id + "_layer");
                        var objWMS = this._dataLayerTree.getNodesByItem(childLayer.id);
                        if (objWMS[0]) {
                            if (objWMS[0].item.type === "wms") {
                                this._enableStrikeOperationOfWMS(objWMS, wmsLayer);
                            }
                        }
                    }
                }
            }));
        },

        /**
         * Decide to show cluster layer or point layer.
         * @param {Array} clusterDetail - Array of objects having detail for clustering.
         * @returns {deferred.promise}
         */
        _manageCluster: function (clusterDetail) {
            var arrAddLayers = [],
                arrDeferred = [],
                arrRemoveLayers = [],
                deferred = new Deferred();
            for (var i = 0; i < clusterDetail.length; i++) {
                if (clusterDetail[i].isCluster) {
                    if (this.map.getLayer(clusterDetail[i].clusterDetail.id + "_layer")) {
                        arrRemoveLayers.push(clusterDetail[i].clusterDetail.id + "_layer");
                    }
                    if (this.map.getLayer(clusterDetail[i].clusterDetail.id + "_heatlayer")) {
                        arrRemoveLayers.push(clusterDetail[i].clusterDetail.id + "_layer");
                    }
                    arrDeferred.push(this.Cluster.addClusters(this.map, clusterDetail[i].clusterDetail));
                } else {
                    arrAddLayers.push(clusterDetail[i].clusterDetail);
                    if (this.map.getLayer(clusterDetail[i].clusterDetail.id + "_cluster")) {
                        arrRemoveLayers.push(clusterDetail[i].clusterDetail.id + "_cluster");
                    }
                }
            }
            if (arrAddLayers.length) {
                arrDeferred.push(this._addLayers(arrAddLayers));
            }
            if (arrRemoveLayers.length) {
                arrDeferred.push(this._removeLayers(arrRemoveLayers));
            }
            all(arrDeferred).then(lang.hitch(this, function (result) {
                deferred.resolve(result);
            }));
            return deferred.promise;
        },

        /**
         * Display the widget panel.
         */
        show: function () {
            if (!this.isOpen) {
                domClass.add(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                this.appUtils.sidePanelOpen(this.isOpen);
            } else {
                this.hide();
            }
        },

        /**
         * Hide the widget panel
         */
        hide: function () {
            this.isOpen = false;
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
            }
            this.appUtils.getTreeNodeForBasemap(this._dataLayerTreeStore);
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function () {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Attach widget related events
         */
        _attachWidgetRelatedEvents: function () {
            on(window, "resize", lang.hitch(this, function () {
                this._panel.resize();
            }));
        }
    });
});
