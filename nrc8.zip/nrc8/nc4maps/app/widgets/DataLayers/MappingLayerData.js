define([
  "dojo/_base/declare",
  "dojo/parser",
  "dojo/ready",
  "dojo/_base/array",
  "esri/SpatialReference",
  "esri/geometry/Point",
  "esri/geometry/webMercatorUtils",
  "esri/InfoTemplate",
  "dojo/aspect",
  "dojo/_base/lang"

], function (declare,
  parser, ready, arrayUtils, SpatialReference, Point, webMercatorUtils, InfoTemplate, aspect, lang
) {

    return declare([], {
      constructor: function () {
        this.cluserIndex = 0;

        this.infoTemplateIncident = '<div  class="infowindow-content risk-${severity}">';
        this.infoTemplateIncident += '<div class="icons">';
        this.infoTemplateIncident += ' <a  class="icon color-${severity}"   ><i class="nc4-icon-${category}"></i></a>';
        this.infoTemplateIncident += '</div>'
        this.infoTemplateIncident += '<div class="content-wrap">';
        this.infoTemplateIncident += '<div class="title"> ${gist} </div>';
        this.infoTemplateIncident += '</div>';
        this.infoTemplateIncident += '</div>';
        this.infoTemplateIncident += '<div class="infowindow-additional">';
        this.infoTemplateIncident += '<div class="additional-detail">${detail}</div>';
        this.infoTemplateIncident += '<a href="${url}" target="${target}" class="additional-link">VIEW DETAILS<i class="fa fa-chevron-right"></i></a>';
        this.infoTemplateIncident += '<a href="#" class="additional-links"></a>';
        this.infoTemplateIncident += '</div>';

        this.infoTemplateLocation = '<div  class="infowindow-location risk-${severity}">';
        this.infoTemplateLocation += '<div  class="infowindow-location-title">';
        this.infoTemplateLocation += '<img src="' + CDN.root +'/nc4mapMainStyle/images/alert-warning.png"></img>';
        this.infoTemplateLocation += '<span>INCIDENT PROXIMITY WARNING</span>';
        this.infoTemplateLocation += '</div>';
        this.infoTemplateLocation += '<div  class="infowindow-location-content">';
        this.infoTemplateLocation += '<div class="icons">';
        this.infoTemplateLocation += ' <a  class="icon color-${severity}"><i class="nc4-icon-${category}"></i></a>';
        this.infoTemplateLocation += '</div>'
        this.infoTemplateLocation += '<div class="content-wrap">';
        this.infoTemplateLocation += '<div class="title"> ${gist} </div>';
        this.infoTemplateLocation += '</div>';
        this.infoTemplateLocation += '</div>';
        this.infoTemplateLocation += '<div class="infowindow-location-button"><span class="acknowledge" onclick="globalConfig._requestAcknowledgeRestApi(\'${id}\')">ACKNOWLEDGE</span><span class="cancel" onclick="globalConfig._requestCancelRestApi(\'${id}\')">CANCEL</span></div>';
        this.infoTemplateLocation += '<div class="infowindow-location-additional">';
        this.infoTemplateLocation += '<a href="${url}" target="${target}" class="additional-link"><span>VIEW DETAILS</span><img src="' + CDN.root +'/nc4mapMainStyle/images/right-arrow.png"></img></a>';
        this.infoTemplateLocation += '<a href="#" class="additional-links"></a>';
        this.infoTemplateLocation += '</div>';
        this.infoTemplateLocation += '</div>';

        this.infoTemplateLocationNoProximity = '<div  class="infowindow-location risk-${severity}">';
        this.infoTemplateLocationNoProximity += '<div  class="infowindow-location-content">';
        this.infoTemplateLocationNoProximity += '<div class="icons">';
        this.infoTemplateLocationNoProximity += ' <a  class="icon color-${severity}"><i class="nc4-icon-${category}"></i></a>';
        this.infoTemplateLocationNoProximity += '</div>'
        this.infoTemplateLocationNoProximity += '<div class="content-wrap">';
        this.infoTemplateLocationNoProximity += '<div class="title"> ${gist} </div>';
        this.infoTemplateLocationNoProximity += '</div>';
        this.infoTemplateLocationNoProximity += '</div>';
        this.infoTemplateLocationNoProximity += '<div class="infowindow-location-additional">';
        this.infoTemplateLocationNoProximity += '<a href="${url}" target="${target}" class="additional-link"><span>VIEW DETAILS</span><img src="' + CDN.root +'/nc4mapMainStyle/images/right-arrow.png"></img></a>';
        this.infoTemplateLocationNoProximity += '<a href="#" class="additional-links"></a>';
        this.infoTemplateLocationNoProximity += '</div>';
        this.infoTemplateLocationNoProximity += '</div>';
      },
      getIncidentsByLayerId: function (layerId) {
        var arrIncidents = [];
        if (globalConfig.allFilteredIncidentItems.length > 0) {
          for (var i = 0; i < globalConfig.allFilteredIncidentItems.length; i++) {
            var inc = globalConfig.allFilteredIncidentItems[i];
            if ((layerId == '_nimc_adv_cluster' && inc.source == 'NIMC' && inc.category == 'advisory')
              || (layerId == '_nimc__cluster' && inc.source == 'NIMC' && inc.category != 'advisory')
              || (layerId == '_nimc_gfp_cluster' && inc.source == 'GFP')
              || (layerId == '_nimc_ab_cluster' && inc.source == 'AB')
              || (layerId == '_nimc_seb_cluster' && inc.source == 'SEB')
              || (layerId == '_nimc_sr_cluster' && inc.source == 'SR')
              || (layerId.toLowerCase() == '_isa_cybertech_india_cluster' && inc.source == 'Cybertech India')) {
              arrIncidents.push(inc);
            }
          }
        }

        return arrIncidents;
      },
      //mapping data schema
      mappingResults: function (data, layerId, type) {

        var mappingData = data;
        if (type == 'render') {
          if (layerId.indexOf('_nimc_') >= 0 || layerId.toLowerCase().indexOf('_isa_cybertech_india') >= 0) {
            mappingData = this._mappingIncidentsGraphicRenderObjects(data);
          }
          else if (layerId.indexOf('_fac_') >= 0) {
            mappingData = this._mappingLocationsGraphicRenderObjects(data);

          }
        }
        else if (type == 'points') {
          if (layerId.indexOf('_nimc_') >= 0 || layerId.toLowerCase().indexOf('_isa_cybertech_india') >= 0) {
            mappingData = this._mappingIncidentsGraphicPoints(data);
          }
          else if (layerId.indexOf('_fac_') >= 0) {
            mappingData = this._mappingLocationsGraphicPoints(data);
          }
        }

        return mappingData;
      },
      _mappingIncidentsGraphicRenderObjects: function (data) {

        var result = {};

        result.id = "nimcinc";
        result.name = "nimcinc";
        result.type = "Feature Layer";
        result.description = "nimcinc - nimcinc";
        result.copyrightText = "";
        result.geometryType = "esriGeometryPoint";
        result.minScale = 0;
        result.maxScale = 0;
        result.extent = {
          "xmin": -8478000.0,
          "ymin": 5014590.0,
          "xmax": -8099500.0,
          "ymax": 5245000.0,
          "spatialReference": { "wkid": 102100 }
        };

        var render = new Object();
        render.type = "uniqueValue";
        render.field1 = "incidentid";
        render.field2 = "severity";
        render.field3 = "channel";
        render.fieldDelimiter = ",";
        render.fieldDelimiter = {
          "type": "esriPMS",
          "url": "/nc4maps_resources/icons/blank_unknown",
          "contentType": "image/png",
          "width": 17.5,
          "height": 17.5,
          "angle": 0.0,
          "xoffset": 0.0,
          "yoffset": 0.0
        };

        render.defaultLabel = "Default Icon";
        render.uniqueValueInfos = [];

        if (data.length > 0) {
          for (var i = 0; i < data.length; i++) {
            var res = new Object();
            var item = data[i];
            res.value = item.id + ',' + this.getSeverity(item.risk) + ',' + item.source;
            res.label = item.text;
            res.description = 'description';
            var iconPath = globalConfig.getIncidentIconsBySeverityCategory(item.risk, item.category);
            var pinWidth = globalConfig.getPinWidthHeight(iconPath).width;
            var pinHeight = globalConfig.getPinWidthHeight(iconPath).height;
            res.symbol = {
              "type": "esriPMS",
              "url": iconPath,
              "contentType": "image/png",
              "width": pinWidth,
              "height": pinHeight,
              "angle": 0.0,
              "xoffset": 0.0,
              "yoffset": pinHeight / 2
            }

            render.uniqueValueInfos.push(res);
          }
        }

        result.drawingInfo = {
          "labelingInfo": "Drawing Info. for nimcinc",
          "renderer": render,
          "transparency": 0
        };

        result.hasAttachments = false;
        result.htmlPopupType = "esriServerHTMLPopupTypeAsHTMLText";
        result.capabilities = "Query";
        result.fields = [
          {
            "name": "incactivityid",
            "type": "esriFieldTypeOID",
            "alias": "Incident Activity ID",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "channel",
            "type": "esriFieldTypeString",
            "alias": "Channel",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "sensitivity",
            "type": "esriFieldTypeString",
            "alias": "Sensitivty",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "category",
            "type": "esriFieldTypeString",
            "alias": "Category",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "city",
            "type": "esriFieldTypeString",
            "alias": "City",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "updateddate",
            "type": "esriFieldTypeString",
            "alias": "Updated Date",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "inctype",
            "type": "esriFieldTypeString",
            "alias": "Type",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "dateoccurred",
            "type": "esriFieldTypeString",
            "alias": "Date Occurred",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "nc4editable",
            "type": "esriFieldTypeString",
            "alias": "Editable",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "stateprovince",
            "type": "esriFieldTypeString",
            "alias": "State or Province",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "gist",
            "type": "esriFieldTypeString",
            "alias": "GIST",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "animationOrHighlightSuffix",
            "type": "esriFieldTypeString",
            "alias": "animationOrHighlightSuffix",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "incidentid",
            "type": "esriFieldTypeString",
            "alias": "Incident ID",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "infosource",
            "type": "esriFieldTypeString",
            "alias": "Info Source",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "description",
            "type": "esriFieldTypeString",
            "alias": "Description",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "severity",
            "type": "esriFieldTypeString",
            "alias": "Severity",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "country",
            "type": "esriFieldTypeString",
            "alias": "Country",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "latitude",
            "type": "esriFieldTypeString",
            "alias": "Latitude",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "longitude",
            "type": "esriFieldTypeString",
            "alias": "Longitude",
            "editable": false,
            "length": 100,
            "isRequired": true
          }
        ];
        result.objectIdField = "incactivityid";

        return result;

      },
      _mappingLocationsGraphicRenderObjects: function (data) {

        var result = {};

        result.id = "location";
        result.name = "location";
        result.type = "Feature Layer";
        result.description = "location - location";
        result.copyrightText = "";
        result.geometryType = "esriGeometryPoint";
        result.minScale = 0;
        result.maxScale = 0;
        result.extent = {
          "xmin": -8478000.0,
          "ymin": 5014590.0,
          "xmax": -8099500.0,
          "ymax": 5245000.0,
          "spatialReference": { "wkid": 102100 }
        };

        var render = new Object();
        render.type = "uniqueValue";
        render.field1 = "facilityid";
        render.field2 = "type";
        render.field3 = "currentstatus";
        render.fieldDelimiter = ",";
        render.defaultLabel = "Default Icon";
        render.uniqueValueInfos = [];


        if (data != null && data.features.length > 0) {
          for (var i = 0; i < data.features.length; i++) {
            var res = new Object();
            var att = data.features[i].attributes;
            res.value = att.facilityid + ',' + att.type + ',' + att.currentstatus;
            res.label = att.facilityname;
            res.description = 'description';

            //add attributes for pupup template
            att.datatype = 'location';
            att.category = 'location';
            att.severity = globalConfig.getAssetProximityStatus(att.facilityid).toLowerCase();
            att.gist = this.getAssetGist(att);
            att.id = att.facilityid;
            var detail = this.getAssetDetail(att.description, att.facilityid);
            att.url = detail.link;
            att.target = detail.linkTarget;
            //end add attributes
            att.objtype = globalConfig.getLegacyProximitiesById(att.facilityid);

            var iconPath = globalConfig.getAssetIconPathBySeverity(att.severity, att.objtype);
            var pinWidth = globalConfig.getPinWidthHeight(iconPath).width;
            var pinHeight = globalConfig.getPinWidthHeight(iconPath).height;
            res.symbol = {
              "type": "esriPMS",
              "url": iconPath,
              "contentType": att.objtype == 'impacted' ? "image/gif" : "image/png",
              "width": pinWidth,
              "height": pinHeight,
              "angle": 0.0,
              "xoffset": 0.0,
              "yoffset": pinHeight / 2
            }

            render.uniqueValueInfos.push(res);
          }
        }

        result.drawingInfo = {
          "labelingInfo": "Drawing Info. for location",
          "renderer": render,
          "transparency": 0
        };

        result.hasAttachments = false;
        result.htmlPopupType = "esriServerHTMLPopupTypeAsHTMLText";
        result.capabilities = "Query";
        result.fields = [
          {
            "name": "currentstatus",
            "type": "esriFieldTypeString",
            "alias": "Current Status",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "updateddate",
            "type": "esriFieldTypeString",
            "alias": "Updated Date",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "facilitytype",
            "type": "esriFieldTypeString",
            "alias": "Facility Type",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "city",
            "type": "esriFieldTypeString",
            "alias": "City",
            "editable": false,
            "length": 100,
            "isRequired": false
          },
          {
            "name": "description",
            "type": "esriFieldTypeString",
            "alias": "Description",
            "editable": false,
            "length": 100,
            "isRequired": false
          },
          {
            "name": "latitude",
            "type": "esriFieldTypeString",
            "alias": "Latitude",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "longitude",
            "type": "esriFieldTypeString",
            "alias": "Longitude",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "country",
            "type": "esriFieldTypeString",
            "alias": "Country",
            "editable": false,
            "length": 100,
            "isRequired": false
          },
          {
            "name": "contactemail",
            "type": "esriFieldTypeString",
            "alias": "Contact Email",
            "editable": false,
            "length": 100,
            "isRequired": false
          },
          {
            "name": "stateprovince",
            "type": "esriFieldTypeString",
            "alias": "State/Province",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "street",
            "type": "esriFieldTypeString",
            "alias": "Street",
            "editable": false,
            "length": 100,
            "isRequired": false
          },
          {
            "name": "postal",
            "type": "esriFieldTypeString",
            "alias": "Postal",
            "editable": false,
            "length": 100,
            "isRequired": false
          },
          {
            "name": "facilityname",
            "type": "esriFieldTypeString",
            "alias": "Facility Name",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "facilityid",
            "type": "esriFieldTypeOID",
            "alias": "Facility ID",
            "editable": false,
            "length": 100,
            "isRequired": true
          },
          {
            "name": "district",
            "type": "esriFieldTypeString",
            "alias": "District",
            "editable": false,
            "length": 100,
            "isRequired": false
          }
        ];
        result.objectIdField = "facilityid";

        return result;

      },
      _mappingIncidentsGraphicPoints: function (data) {

        var result = {};

        result.spatialReference = { "wkid": 102100 };
        result.nativeSR = { "wkid": 4326 };

        result.features = [];

        if (data.length > 0) {
          for (var i = 0; i < data.length; i++) {
            var item = data[i]
            var feature = new Object();
            var webMercator = this.getwebMercatorlanlog(item.longitude, item.latitude);
            var detail = this.getIncidentDetail(item);

            feature.attributes = {
              "datatype": "incident",
              "country": item.country,
              "city": item.city,
              "dateoccurred": item.date,
              "latitude": item.latitude,
              "channel": item.source,
              "clusterTitle": item.name,
              "type": item.risk,
              "inctype": item.info_event,
              "nc4editable": "1",
              "incactivityid": item.id,
              "incidentid": item.id,
              "key": item.id,
              "longitude": item.longitude,
              "severity": this.getSeverity(item.risk),
              "clusterpriority": "0",
              "infosource": item.source,
              "objtype": "null",
              "stateprovince": "",
              "gist": this.getIncidentGist(item),
              "detail": detail.description,
              "url": detail.link,
              "target": detail.linkTarget,
              "drillDownText": "View Details",
              "updateddate": item.date,
              "_category": item.category,
              "category": item.category,
              "objtypeO": "null"
            };

            feature.geometry = {
              "x": webMercator.x,
              "y": webMercator.y,
              "SpatialReference": { "wkid": 102100 }
            };

            feature.id = item.id;

            result.features.push(feature);
          }
        }

        result.objectIdFieldName = "incidentid";
        result._geometryServiceUrl = "http://tasks.arcgisonline.com/ArcGIS/rest/services/Geometry/GeometryServer";
        result.layerSize = result.features.length;
        result.ts = 0;
        result.geometryType = "esriGeometryPoint";
        result.fields = [
          {
            "name": "incactivityid",
            "type": "esriFieldTypeOID",
            "alias": "Incident Activity ID",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "channel",
            "type": "esriFieldTypeString",
            "alias": "Channel",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "sensitivity",
            "type": "esriFieldTypeString",
            "alias": "Sensitivty",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "category",
            "type": "esriFieldTypeString",
            "alias": "Category",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "city",
            "type": "esriFieldTypeString",
            "alias": "City",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "updateddate",
            "type": "esriFieldTypeString",
            "alias": "Updated Date",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "inctype",
            "type": "esriFieldTypeString",
            "alias": "Type",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "dateoccurred",
            "type": "esriFieldTypeString",
            "alias": "Date Occurred",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "nc4editable",
            "type": "esriFieldTypeString",
            "alias": "Editable",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "stateprovince",
            "type": "esriFieldTypeString",
            "alias": "State or Province",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "gist",
            "type": "esriFieldTypeString",
            "alias": "GIST",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "animationOrHighlightSuffix",
            "type": "esriFieldTypeString",
            "alias": "animationOrHighlightSuffix",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "incidentid",
            "type": "esriFieldTypeString",
            "alias": "Incident ID",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "infosource",
            "type": "esriFieldTypeString",
            "alias": "Info Source",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "description",
            "type": "esriFieldTypeString",
            "alias": "Description",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "severity",
            "type": "esriFieldTypeString",
            "alias": "Severity",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "country",
            "type": "esriFieldTypeString",
            "alias": "Country",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "latitude",
            "type": "esriFieldTypeString",
            "alias": "Latitude",
            "length": 100,
            "isRequired": true
          },
          {
            "name": "longitude",
            "type": "esriFieldTypeString",
            "alias": "Longitude",
            "length": 100,
            "isRequired": true
          }
        ];
        result.objectIdField = "incactivityid";

        return result;

      },
      _mappingLocationsGraphicPoints: function (data) {

        if (data != null && data.features.length > 0) {
          for (var i = 0; i < data.features.length; i++) {

            var att = data.features[i].attributes;

            //add attributes for pupup template
            att.datatype = 'location';
            att.category = 'location';
            att.severity = globalConfig.getAssetProximityStatus(att.facilityid).toLowerCase();
            att.gist = this.getAssetGist(att);
            att.id = att.facilityid;
            var detail = this.getAssetDetail(att.description, att.facilityid);
            att.url = detail.link;
            att.target = detail.linkTarget;
            //end add attributes
            att.objtype = globalConfig.getLegacyProximitiesById(att.facilityid);

          }
        }

        return data;
      },
      //common
      truncate: function (text, len) {
        if (!text) {
          return '';
        }

        if (text.length > len) {
          var regex = new RegExp('^([\\s\\S]{1,' + len + '})(\\s[\\s\\S]*|$)', 'gi');
          return text.replace(regex, '$1...');
        }
        return text;
      },
      valueToLower: function (str) {
        if (str != null && typeof (str) != 'undefined') {
          return str.toLowerCase();
        }
        else {
          return '';
        }
      },
      //incident           
      getIncidentGist: function (item) {

        var gist = item.name + '</br>'
          + item.address
          + '</br><span class="date">'
          + item.date
          + '</span>';

        return gist;
      },
      getIncidentDetail: function (item) {
        var detail = new Object();
        detail.description = '';
        detail.link = '';
        detail.linkTarget = '_self';

        if (item.source == 'SEB' || item.source == 'SR' || item.source == 'CR' || item.source == 'CRR') {
          if (item.resourceURI != null && typeof (item.resourceURI) != 'undefined' && item.resourceURI != '') {
            detail.link = item.resourceURI;
            detail.linkTarget = '_blank';
          }
          else {
            detail.link = '#/content/' + item.id;
          }
        }
        else {
          detail.link = '#/content/' + item.id;
          detail.description = item.text;
        }
        return detail;
      },
      getwebMercatorlanlog: function (longitude, latitude) {
        var wgs = new SpatialReference({
          "wkid": 102100
        });
        var latlng = new Point(parseFloat(longitude), parseFloat(latitude), wgs);
        var webMercator = webMercatorUtils.geographicToWebMercator(latlng);
        var oClusterPoint = new Object();
        oClusterPoint.x = webMercator.x;
        oClusterPoint.y = webMercator.y;

        return oClusterPoint;
      },
      getSeverity: function (severity) {
        var s = severity;
        if (severity == undefined) {
          s = 'unknown';
        }

        return s.toLowerCase();
      },
      //assets            
      getAssetGist: function (att) {
        var gist = att.type
          + '</br>'
          + att.facilityname
          + '</br>'
          + att.street
          + '</br>'
          + att.city
          + ', '
          + att.stateprovince
          + ' '
          + att.zip
          + '</br>'
          + att.country;

        return gist;
      },
      getAssetDetail: function (description, id) {
        var detail = new Object();
        detail.description = this.truncate(description, 65);
        detail.link = '#/assets/' + id;
        detail.linkTarget = '_self';

        return detail;
      },
      //create popup
      createClusterTemplate: function (cluster) {

        var index = this.cluserIndex++,
          incidentsHtml = '',
          assetsHtml = '',
          incidentsCount = 0,
          assetsCount = 0,
          assetsIdsForDetail = '',
          toLower = this.valueToLower,
          capitalize = globalConfig.filter_capitalize;

        if (Array.isArray(cluster)) {
          var incidents = [];
          var assets = [];
          cluster.forEach(function (c) {

            //incidents
            if (c.attributes.datatype === 'incident') {
              incidentsCount += c.attributes.clusterCount || 0;
              incidents.push({
                severity: toLower(c.attributes.severity),
                sortKey: globalConfig.severityFactory.getKeyByValue(c.attributes.severity) || 0,
                detailURL: c.attributes.url,
                title: capitalize(c.attributes.category) + ' | ' + c.attributes.inctype,
                id: c.attributes.incidentid,
                datatype: c.attributes.datatype,
                latitude: c.attributes.latitude,
                longitude: c.attributes.longitude
              });
            }
            //locations
            else {
              var signleAssestClusterCount = c.attributes.c ? c.attributes.c * 1 : c.attributes.clusterCount;
              assetsCount += signleAssestClusterCount || 0;
              if (signleAssestClusterCount < 2) {
                var status = globalConfig.getAssetProximityStatus(c.attributes.facilityid);
                assets.push({
                  status: status,
                  sortKey: globalConfig.severityFactory.getKeyByValue(status) || 0,
                  detailURL: c.attributes.url,
                  title: c.attributes.facilitytype + ' | ' + c.attributes.facilityname,
                  id: c.id,
                  datatype: c.attributes.datatype,
                  latitude: c.attributes.latitude,
                  longitude: c.attributes.longitude
                });
              }
              else {
                //multiple assets will be retrieved while expand assets in popups.
                assetsIdsForDetail += c.attributes.clusteredIds + ',';
              }
            }
          });

          incidents.sort(function (a, b) { return b.sortKey - a.sortKey; });
          var title = '';
          incidents.forEach(function (c) {
            incidentsHtml += '<div class="col col-md-12 col-sm-12 col-xs-12 item risk-' + toLower(c.severity) + '">';
            incidentsHtml += '<a href="' + c.detailURL + '" class="title">' + c.title + '</a><a class="paper-airplane" onclick="javascript:globalConfig.launchIncidentLocationFromPopup(\'' + c.datatype + '\',\'' + c.id + '\',' + c.latitude + ',' + c.longitude + ');"><i class="nc4-icon-map-marker"></i></a>';
            incidentsHtml += '</div>';
          });
          assets.sort(function (a, b) { return b.sortKey - a.sortKey; });
          assets.forEach(function (c) {
            assetsHtml += '<div class="col col-md-12 col-sm-12 col-xs-12 item risk-' + toLower(c.status) + '" severity="' + c.sortKey + '">';
            assetsHtml += '<a href="' + c.detailURL + '" class="title">' + c.title + '</a><a class="paper-airplane" onclick="javascript:globalConfig.launchIncidentLocationFromPopup(\'' + c.datatype + '\',\'' + c.id + '\',' + c.latitude + ',' + c.longitude + ');"><i class="nc4-icon-map-marker"></i></a>';
            assetsHtml += '</div>';
          });
        }
        if (incidentsCount) {
          incidentsHtml =
            '<div class="panel panel-default" >' +
            '<div class="panel-heading" role="tab">' +
            '<button class="collapse-head" type="button" data-toggle="collapse" data-parent="accordion" data-target="#collapse_incident_' + index + '" aria-expanded="false" aria-controls="collapse_incident_' + index + '">' +
            'incidents (' + incidentsCount + ')' +
            '</button>' +
            '</div>' +
            '<div id="collapse_incident_' + index + '" class="panel-collapse collapse in" role="tabpanel">' +
            '<div class="panel-body style-6">' +
            incidentsHtml +
            '</div>' +
            '</div>' +
            '</div >';
        }
        if (assetsCount) {
          assetsHtml =
            '<div class="panel panel-default">' +
            '<div class="panel-heading" role="tab">' +
            '<button class="collapse-head show-assets" type="button" data-toggle="collapse" data-parent="accordion" data-target="#collapse_asset_' + index + '" onclick="require([\'dojo/topic\'], function(topic){topic.publish(\'loadAssetsDetail\', \'#collapse_asset_' + index + ' .panel-body\', \'' + assetsIdsForDetail + '\');})" aria-expanded="false" aria-controls="collapse_asset_' + index + '">' +
            'assets (' + assetsCount + ')' +
            '</button>' +
            '</div>' +
            '<div id="collapse_asset_' + index + '" class="panel-collapse collapse" role="tabpanel">' +
            '<div class="panel-body style-6">' +
            assetsHtml +
            '</div>' +
            '</div>' +
            '</div>';
        }

        return '<div class="panel-group" id="accordion_' + index + '" role="tablist" aria-multiselectable="true">' + incidentsHtml + assetsHtml + '</div>';
      },
      createSingleTemplate: function (layerId, attr) {
        var contentinfo = null;
        if (layerId.indexOf('_nimc_') >= 0 || layerId.toLowerCase().indexOf('_isa_cybertech_india') >= 0) {
          contentinfo = new InfoTemplate('incident', this.infoTemplateIncident);
        }
        else if (layerId.indexOf('_fac_') >= 0) {
          if (attr.objtype == 'impacted' && globalConfig.settingsData.IsORGAdmin) {
            contentinfo = new InfoTemplate('flashingLocation', this.infoTemplateLocation);
          }
          else {
            contentinfo = new InfoTemplate('location', this.infoTemplateLocationNoProximity);
          }
        }

        return contentinfo;
      }
    });
  });
