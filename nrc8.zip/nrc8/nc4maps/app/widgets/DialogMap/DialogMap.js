
define([
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/dom",
        "dojo/dom-style",
        "dojo/dom-construct",
        "esri/graphicsUtils",
        "esri/map",
        "esri/graphic", 
        "esri/geometry/Extent",
        "esri/virtualearth/VETiledLayer",
], function(declare, lang, DOM, domStyle, domConstruct, graphicsUtils, Map, Graphic, Extent, VETiledLayer
){
	
	return declare([],{			//constructor? or postcreate? _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin

		appUtils: null,
		
		constructor: function(p_options, p_appUtils)
		{
			this.appUtils = p_appUtils;
			domConstruct.empty(p_options.div);
			this.createMap(DOM.byId(p_options.div), p_options.graphic, p_options.markers);
		},
		 	
		createMap: function (p_node, p_graphic, p_markers) {
		        var map = new Map(p_node);
		         
		        //TODO make this configurable:
		        var basemapLayer = new VETiledLayer({
                    bingMapsKey: this.appUtils.configGeneralSettings.bingAccessKey,
                    mapStyle: VETiledLayer.MAP_STYLE_AERIAL_WITH_LABELS
                });
		        
		        map.addLayer(basemapLayer);
		        /*
		        dojo.connect(map, "onLoad", function() {
		          dojo.connect(map, "onMouseOver", map, "reposition");
		          
		          map.infoWindow.setTitle("Location");
		          map.infoWindow.resize(200, 100);
		        });*/
		        var scopeObj = {
		        	map: map,
		        	graphic: p_graphic,
		        	markers: p_markers
		        };
		        map.on("load", lang.hitch(scopeObj,function(){
		        	this.map.graphics.add(new Graphic(this.graphic.geometry, this.graphic.symbol)); //must clone
					
		        	var graphicExtent = graphicsUtils.graphicsExtent([this.graphic]);
		        	
		        	if(this.markers != null && this.markers.length > 0)
		        	{
		        		for(var i = 0; i< this.markers.length; i++)
		        		{
		        			this.map.graphics.add(this.markers[i]);
		        		}
		        	}
		        	
		        	var contentPaneNode = dojo.query(".contentPane")[0];
		            domStyle.set(contentPaneNode, "max-height", "none"); //remove any max height setting

		        	if(this.graphic.geometry.type == "point")
		        		this.map.centerAndZoom(this.graphic.geometry, this.map.getMaxZoom() - 2);
		        	else
		        		this.map.setExtent(graphicExtent);
		        //	this.map.centerAndZoom(this.graphic.geometry, this.map.getMaxZoom() - 2);
		        }));
		      },
		      
		 addPoints: function(p_graphics)
		 {
			 
		 }
		
		
	});
})


	
