define([
    "dojo/_base/declare",
    "dojo/query",
    "dojo/on",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dijit/_WidgetBase"
], function(declare, query, on, html, lang, domStyle, _WidgetBase) {
    return declare([_WidgetBase], {

        postCreate: function() {
            this.inherited(arguments);
            var zoomOut = query(".esriSimpleSliderDecrementButton");
            if (zoomOut.length > 0) {
                /**
                 * Create and place 'Help' button widget to show help page.
                 */
                this.help = html.create("div", {
                    "title": this.config.label,
                    "class": "widget-Help"
                }, null);
                html.place(this.help, zoomOut[0], "after");
                if(this.config.left)
                	domStyle.set(this.help, "left", this.config.left);
                if(this.config.top)
                	domStyle.set(this.help, "top", this.config.top);
                this.own(on(this.help, "click", lang.hitch(this, function() {
                    this._showHelpPage();
                })));
            }
        },

        /**
         * Show help page
         */
        _showHelpPage: function() {
        	window.open(this.config.helpContents);
        }
    });
});
