/* the constructor should take a param, with the name of a div to embed this in */
/*Data layer should have Features whose attributes contains a "key" attribute*/
/*attribute severity param is needed for datalist selection*/
define([
        "dojo/_base/declare",
        "dojo/topic",
        "dojo/on",
        "dojo/_base/lang",
        "dojo/dom",
        "dojo/dom-construct",
        "dojo/dom-class",
        "dojo/dom-attr",
        "dojo/store/Memory", 
        "dijit/form/ComboBox",
        "dojo/query",
        
        "dijit/form/Select",
        "esri/InfoTemplate"
], function(declare, topic, on, lang, dom, domConstruct, domClass, domAttr, Memory, ComboBox, query, Select, InfoTemplate){
	
	return declare([],{			//constructor? or postcreate? _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin
		
		dlOptions: null,
		dl: null,
		dataMem: null,
		changeEvent: null,
		arrItems: null,
		arrItemsIndRem: null,
		arrOptions: null,
		isFirstTime: null,
		
		constructor: function(p_DAP)
		{
			this.dlOptions = domConstruct.create("div", {}, null);
			new Select({id: "recentDataSel"}).placeAt(this.dlOptions).startup();
	    	dijit.byId('recentDataSel').addOption({value: "all", label: "All", selected: false});
	        this.dl = domConstruct.create("div", {}, null);
	        
	        p_DAP.containerNode.appendChild(this.dlOptions);
            p_DAP.containerNode.appendChild(this.dl);
            this.arrItems = [];
            this.arrItemsIndRem = [];
            this.arrOptions = {};
            this.isFirstTime = true;
            this.activate();
		},
	
		activate: function()
		{
			topic.subscribe("ncRdOpt", lang.hitch(this, function(p_newOpt){
				if(this.changeEvent == null)
				{
					var select = dijit.byId('recentDataSel');

				    select.on('change', function(evt) {
				    	var node = dijit.byId('recentDataSel')
				    	var lyrId = node.value;
				    	if(lyrId == "all")
				    	{
				    		query("tr", "recentList").style("display", "block");
					    	var shownList = query("tr", "recentList");
					    	shownList.removeClass("bgOdd");
					    	shownList.removeClass("bgEven");
							for (var i=0;i<shownList.length;i++){
							    if ((i+2)%2==0) {
							        dojo.addClass(shownList[i], "bgOdd");
							    }
							    else {
							        dojo.addClass(shownList[i], "bgEven");
							    }
							}
				    	}
				    	else
				    	{
					    	query("tr", "recentList").style("display", "none");
					    	query("."+lyrId, "recentList").style("display", "block");
					    	var shownList = query("."+lyrId);
					    	shownList.removeClass("bgOdd");
					    	shownList.removeClass("bgEven");
							for (var i=0;i<shownList.length;i++){
							    if ((i+2)%2==0) {
							        dojo.addClass(shownList[i], "bgOdd");
							    }
							    else {
							        dojo.addClass(shownList[i], "bgEven");
							    }
							}


				    		
				    	}

				    });
				    this.changeEvent = true;
				}
				
				if(p_newOpt != null)
				{
					for(var potentialNewOpt in p_newOpt){
				        	if(!this.arrOptions.hasOwnProperty(potentialNewOpt)){
				        		this.arrOptions[potentialNewOpt] = p_newOpt[potentialNewOpt];
					        }
				        
				    }
					if(Object.keys(this.arrOptions).length !== 0){
						dijit.byId('recentDataSel').removeOption(dijit.byId('recentDataSel').getOptions());
						dijit.byId('recentDataSel').addOption({value: "all", label: "All", selected: false});
					}
					for (var property in this.arrOptions) {
					    // if (p_newOpt.hasOwnProperty(property)) {
					    dijit.byId('recentDataSel').addOption({value: property, label: this.arrOptions[property], selected: false});
					    // }
					}
					/*
					 * on change:
					 * query(".someClassName").style("visibility", "hidden");
 						
					 */
				}
			}));
			
			
			
			//option2 = { value: "o2", label: "option 2", selected: true };
			topic.subscribe("nc4newdata", lang.hitch(this, function(p_newData){
				

				/*
		        if(query('.recentList').length > 0 && p_newData.length != 0){
		        	domConstruct.destroy("recentList");
		        }*/
				
				//for now, just empty and repopulate
				var newTable = dom.byId("recentList");
				if(newTable == null)
				{
					var newTable = domConstruct.create("table", {"class": "recentList", "id": "recentList"}, null);
				}
				else
					this.isFirstTime = false;


				if(p_newData != null && p_newData.length > 0)
				{
					//check if filter is all
					
					///TODO: What if we removal all graphics everytime?
					//OR would have to add nother attribute "KEY" to use for comoparison
					
					for(var i = 0; i < p_newData.length; i ++)
					{
						var currGraphic = p_newData[i];
						try{
							this.remove(currGraphic.attributes.key);
						}
						catch(error){}
						this.arrItems.push(currGraphic);
					}
					
					this.arrItems.sort(function(a, b) {
					    //return parseFloat(b.attributes.incactivityid) - parseFloat(a.attributes.incactivityid);
						return parseFloat(b.id) - parseFloat(a.id);
					});
					
					for(var j = 0; j < this.arrItems.length; j ++)
					{
						var currGraphic = this.arrItems[j];
						var currAttr = currGraphic.attributes;
						
						dojo.destroy(currGraphic.attributes.key);
						var addListItem = this.checkDataList(currGraphic.id, p_newData, j);
						if(addListItem){
						
							var newDiv = domConstruct.toDom("<tr id='"+currGraphic.attributes.key+"' class = '" + currGraphic._layer.id + "'><td><img id='"+currGraphic.attributes.key+"IMG'  src='"+currGraphic.symbol.url+"' /></td><td><b>"+currAttr.category+"</b>: "
									+ currAttr.inctype
									+"<br/>"+currAttr.city+"," + currAttr.stateprovince + " " + currAttr.country
									+"<br/>updated:<b>"+currAttr.updateddate+"</b><br/></td></tr>");
							domConstruct.place(newDiv, newTable);
							on(newDiv, "click", lang.hitch(currGraphic, function(){
								console.log("currGraphic: " , this);
								try
								{
									if(this._layer.visibleLyrs == null || this._layer.visibleLyrs.indexOf(this.attributes.severity.toLowerCase()) >= 0){
										//layer severity levels needed for above conditional
										//showpopup
										var map = this._layer._map;
										//map.infoWindow.hide();
				    					var newContent = null;
				    					if(this.attributes && this.attributes.objtype == "cluster")
				    						newContent = new InfoTemplate(this._layer.name,this.attributes.name +"<br/><br/>" + this.attributes.discription);
				    					else if(this.infoTemplate)
				    						newContent = this.infoTemplate;
				    					else if(this._layer.popupInfo)
				    						newContent = new InfoTemplate(this._layer.name, this._layer.popupInfo);
				    					else if(this._layer.infoTemplate)
				    						newContent = this._layer.infoTemplate;
				    					else
				    						newContent = "";
				    					this.setInfoTemplate(newContent);
				    					if(map != null && map.infoWindow != null){
											map.infoWindow.setFeatures([this]);
											try
											{
												if(this.geometry.x != null && this.geometry.y !=null )
												{
													var deferred = map.centerAt(this.geometry);//, map.getMaxZoom() - 1
							    					
													deferred.then(lang.hitch(this, function(value){
							    						map.infoWindow.show(this.geometry);
							    					}));
												}
												else
												{
													console.error("issue with item's geometry");
													require(["app/widgets/Notifications/NC4Notification"], function(nc4notify){
														new nc4notify().error("Unable to locate item on the map.")
													})
													
												}
												
											}catch(e)
											{
												console.error("issue with item's geometry: ", e);
												require(["app/widgets/Notifications/NC4Notification"], function(nc4notify){
													new nc4notify().error("Unable to locate item on the map.")
												})
											}
										}
										else{
											require(["app/widgets/Notifications/NC4Notification"], function(nc4notify){
												new nc4notify().error("The map layer containing this item is turned off.<br />** Please enable the map layer with the check boxes in the layer's settings. **")
											})
										}
									}
									else{
										require(["app/widgets/Notifications/NC4Notification"], function(nc4notify){
											new nc4notify().error("The map layer containing this item is turned off.<br />** Please enable the map layer with the check boxes in the layer's settings. **")
										})	
									}
									
								}
								catch(error)
								{
									console.error(error);
									//do nothing for now
								}
							}));
						}
						
					}
					for (var i = this.arrItemsIndRem.length; i > 0; i --) {
						this.arrItems.splice(this.arrItemsIndRem[i-1], 1);
					};
					this.arrItemsIndRem = [];
					
					//if filter is not all, need if statement to check layer of each data
					if(this.isFirstTime == true)
						domConstruct.place(newTable, this.dl);
				}
				
			}));
			
			topic.subscribe("dlUpdateItem", lang.hitch(this, function(p_graphic){
				this.updateG(p_graphic);
			}));
		},
		
		remove: function(p_graphicId)
		{
			//remove all data for a given layer id
			for(var i = 0; i<this.arrItems.length; i++)
			{
				var currGraphic = this.arrItems[i];
				if(currGraphic.attributes.key == p_graphicId)
				{
					this.arrItems.splice(i, 1); //costly
					break;
				}
			}
			
		
			
		},
		
		updateG: function(p_graphic)
		{
			try
			{
				var node = dom.byId(p_graphic.attributes.key + "IMG");
				domAttr.set(node, "src", p_graphic.symbol.url);
			}
			catch(error){}
		},
		checkDataList: function(p_graphicId, p_newData, index)
		{
			//remove all data for a given layer id
			for(var i = 0; i<p_newData.length; i++)
			{
				var currGraphic = p_newData[i];
				if(currGraphic.id == p_graphicId)
				{
					return true;
				}
			}
			this.arrItemsIndRem.push(index)
			return false;
			
		
			
		}
		/*
		addItems: function(p_newData)
		{
			this.dataMem = new Memory({});
			if(p_newData != null && p_newData.length > 0)
			{
				//check if filter is all
				for(var i = 0; i < p_newData.length; i ++)
				{
					var currGraphic = p_newData[i];
					this.remove(currGraphic.id);
					var currAttr = currGraphic.attributes;
					this.dataMem.put({id: currGraphic.id, lyr: currGraphic._layer.id })
				}
			}
		}
		*/
	});
	
});