/* this returns 'declare()' function, so its returning a constructor 
 * this inherits from '_WidgetBase' as well as from '_TemplateMixin' 
 * 
 */
define([
    "dojo/_base/declare",
    "dojo/dom-construct",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dojo/on",
    "dojo/_base/lang",
    "dojo/text!./MapTemplate.html",
    "dojo/aspect",
    "esri/map",
    "esri/geometry/Extent",
    "esri/tasks/GeometryService",
    "esri/SpatialReference",
    "esri/layers/ArcGISTiledMapServiceLayer",
    "esri/layers/ArcGISDynamicMapServiceLayer",
    "esri/dijit/Scalebar",
    "lodash/lodash",
    "dojo/_base/array",
    "esri/geometry/webMercatorUtils",
    "esri/tasks/ProjectParameters",
    "esri/virtualearth/VETiledLayer",
    "app/nc4custom/PopupExtended",
    "app/widgets/DataLayers/ArcGISMSCachedManager",
    "esri/geometry/Point",
    "dojo/dom",
    "esri/request",
    "dojo/query",
    "dojo/when"
], function(declare, domConstruct, _WidgetBase, _TemplatedMixin, on, lang, template, aspect, Map, Extent, GeometryService, SpatialReference, ArcGISTiledMapServiceLayer, 
		ArcGISDynamicMapServiceLayer, Scalebar, _, array, webMercatorUtils, ProjectParameters, VETiledLayer, PopupExtended, ArcGISMSCachedManager, Point, dom, esriRequest, query, when) {
    return declare([_WidgetBase, _TemplatedMixin], {		/*_ underscore implies that it is a base class (not directly usable) */
        templateString: template,
        scalebar: null,

        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Call another function to initialize map.
         */
        postCreate: function() {
            this.inherited(arguments);		//this is like super() (calls the parent postCreate()) - arguments seem to be empty
            this._initializeMap();
            this._scaleBar();
            this._nc4Notify = this.appUtils.nc4Notify;
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() { //this.appUtils.updateMapInstance() is called, then lang.hitch...is called
                this.scalebar.destroy();
                this.map = null;
                this.map = this.appUtils.mapInstance;	//this.map now refers to the map created in this._initializeMap()
                this.map.autoResize = true;
                this._scaleBar();
                this.map.enableKeyboardNavigation();
                
                this._extendPopup();
            }));
            
        },
        
        _extendPopup: function()
        {
          var mapInstance = this.map;
          var rd = this.config.generalSettings.rd
          this.map.isDrillDown = false;
        	var extendedPopup = new PopupExtended({
        	    extended: {
        	        themeClass: "light",
        	        draggable: false,
        	        defaultWidth: 250,
        	        customtitle: this.config.generalSettings.customtitle, 
        	        ct_attr_key: this.config.generalSettings.ct_attr_key,
                    actions: [{
                        text: "", className: "action zoomTo DrillDown", title: "Drill Down",
                        click: function (feature) {
                            mapInstance.isDrillDown = true;
                            var point = feature.geometry;
                            var currentZoom = mapInstance.getZoom();
                            var rdLength = rd.length;
                            if(rdLength <= 0 || point.type == "polygon"){
                                if(point.type == "polygon")
                                  mapInstance.setExtent(point.getExtent());
                                else
                                  mapInstance.centerAndZoom(new Point(point.x, point.y, new SpatialReference(point.spatialReference)), currentZoom + 3);
                            }
                            else{
                                var zoomINC = mapInstance.centerAndZoom(new Point(point.x, point.y, new SpatialReference(point.spatialReference)), mapInstance.getMaxZoom() - 1);
                                while(rdLength--){
                                  if(feature._layer.layerId && feature._layer.layerId.indexOf(rd[rdLength])!=-1){
                                    console.log(feature._layer.url + "/"+feature.attributes.incidentid+"/htmlPopup?d=1");
                                    var request = esriRequest({
                                            url: feature._layer.url + "/"+feature.attributes.incidentid+"/htmlPopup?d=1",
                                            content: lang.mixin({
                                                f: "jsonp"
                                            }, null),
                                            callbackParamName: "callback",
                                            load: lang.hitch(this, function (response) {
                                                require(["app/widgets/DrillDown/DrillDown"], function(DrillDown){
                                                    var DrillDown = new DrillDown({
                                                        returnZoom: currentZoom,
                                                        mapInstance: mapInstance
                                                    });
                                                    DrillDown._loadDrillDownInfo(response.content);
                                                });
                                                mapInstance.isDrillDown = false;
                                            }),
                                            error: lang.hitch(this, function (response) {
                                                console.log(response);
                                                mapInstance.isDrillDown = false;
                                            })
                                           })
                                    function syncProcess(){
                                        mapInstance.infoWindow.show(mapInstance.infoWindow.features[0].geometry);
                                        query(".zoomTo")[1].classList.add("hidden");
                                        query(".return")[0].classList.remove("hidden");
                                    }
                                    aspect.after(zoomINC, syncProcess());
                                  }
                                  else if(dom.byId("mainDrillDown")){
                                      dojo.destroy("mainDrillDown");
                                      mapInstance.isDrillDown = false;
                                  }
                                  else{
                                      mapInstance.isDrillDown = false;
                                  }
                              }                          
                            }
                        }
                    },{
                        text: "Return", className: "hidden return", title: "Return",
                        click: function (feature) {
                            var point = feature.geometry;
                            var DrillDown = dom.byId("mainDrillDown");
                            mapInstance.centerAndZoom(new Point(point.x, point.y, new SpatialReference(point.spatialReference)), parseInt(DrillDown != null ? DrillDown.getAttribute("returnZoom") : 2));
                            try{
                                dojo.destroy("mainDrillDown");
                                query(".return")[0].classList.add("hidden");
                                query(".zoomTo")[1].classList.remove("hidden");
                                mapInstance.isDrillDown = false;
                            }catch(error)
                            {
                            	console.info("attempted to destroy drill down: ", error);
                            }
                        }
                    }],
        	        hideOnOffClick: true,
        	        multiple: false,
        	        smallStyleWidthBreak: 1,
        	    },
        	    highlight: true,
        	    pagingControls: false,
        	    pagingInfo: false,
        	    titleInBody: true
        	}, domConstruct.create("div"));
        	
        	//set the map to use the exteneded popup
        	extendedPopup.setMap(this.map); 
        	this.map.infoWindow = extendedPopup;
        },

        /**
         * Initializes the map with configured extent, spatial reference and default basemap.
         */
        _initializeMap: function() {
        	
            /*
             * var extentInitial = this._getDefaultExtent(this.appUtils.configGeneralSettings.defaultExtent, this.appUtils.configGeneralSettings.defaultExtentSpatialRef);
            this.appUtils.configGeneralSettings.initialBookmark = extentInitial.id;

			this.map = new Map(this.mapNode, {
				extent: extentInitial
			});       
			*/
			this.map = new Map(this.mapNode);
      		this.map.wrapAround180 = false;
			
            this.appUtils.mapNode = this.mapNode;
            
            //ET-23 attempt to add lock pop-up functionality here
            /*
             * actions: [{
        	            //text: "Default action", className: "defaultAction", title: "Default action added in extendedPopup properties.",
        	            //click: function (feature) { alert("clicked feature - " + feature.attributes); }
        	        }],
             */
            this._extendPopup();
            
           
        },

        /**
         * Function to create scale bar on map.
         */
        _scaleBar: function() {
            this.scalebar = new Scalebar({
                map: this.map,
                scalebarStyle: "line",
                scalebarUnit: "dual",
                attachTo: "bottom-left"
            });
        },

        /**
         * Returns default extent configured in the configuration file. This function will return USA extent
         * in following scenarios:
         * * Extent is not configured.
         * * Extent is not configured properly.
         * * Spatial reference is not configured.
         * @param {string} defaultExtent - Map extent.
         * @param {string} defaultExtentSpatialRef - Spatial reference of the extent.
         * @returns {object} initialExtent - Map default extent and spatial reference.
         */
        _getDefaultExtent: function(defaultExtent, defaultExtentSpatialRef) {
            var initialExtent, extent, maxExtent;
            var id= "";
            
            if(this.appUtils.configGeneralSettings.defaultBookmarkExtent && this.appUtils.configGeneralSettings.defaultBookmarkExtent != null
            		&& this.appUtils.configGeneralSettings.defaultBookmarkExtent.split(",").length == 4 && this.appUtils.configGeneralSettings.defaultBookmarkSr && this.appUtils.configGeneralSettings.maxMapExtent && this.appUtils.configGeneralSettings.maxMapExtent.split(",").length == 4)
            {
            	//check db value or customer set bookmark:
            	
				extent = this.appUtils.configGeneralSettings.defaultBookmarkExtent.split(",");
        		maxExtent = this.appUtils.configGeneralSettings.maxMapExtent.split(",");
				defaultExtentSpatialRef = this.appUtils.configGeneralSettings.defaultBookmarkSr;
				id = this.appUtils.configGeneralSettings.defaultBookmark;
			}	
/*          commenting out.  leaving blank will automatically zoom to initial extent of the base map.  
 * 			else if (defaultExtent && (defaultExtent.split(",").length == 4) && defaultExtentSpatialRef) 
            {
            		//TODO: james this should set the extent to the current base map's initial extent.
            		extent = defaultExtent.split(",");
            } 
 */           else 
            {
	 			return "";
	 			/*
            	 //check default from configs (taking wild guess) - TODO: use the spatial extent ref to get default
            	if (defaultExtent && (defaultExtent.split(",").length == 4) && defaultExtentSpatialRef) 
            	{
            		extent = defaultExtent.split(",");
            	}
            	else
            	{
            		 this.appUtils.log.info("Default extent is undefined or not configured properly. Setting extent to USA.");
                     extent = "-14803100.645816434,3095975.801835673,-8120669.885014963,6241512.3898264095".split(",");
                     defaultExtentSpatialRef = 102100;
            	}*/
            }
            
            //TODO: James - really need to check here if initial extent is not out of range for the initial/full extent of the default basemap.
            //			if it is out of range, then just use the initial / full extent of the default basemap.
            
            initialExtent = new Extent({
                "xmin": parseFloat(extent[0]),
                "ymin": parseFloat(extent[1]),
                "xmax": parseFloat(extent[2]),
                "ymax": parseFloat(extent[3]),
                "spatialReference": {
                    "wkid": parseInt(defaultExtentSpatialRef, 10)
                }
            });
            maxExtent = new Extent({
                "xmin": parseFloat(maxExtent[0]),
                "ymin": parseFloat(maxExtent[1]),
                "xmax": parseFloat(maxExtent[2]),
                "ymax": parseFloat(maxExtent[3]),
                "spatialReference": {
                    "wkid": parseInt(defaultExtentSpatialRef, 10)
                }
            });
            initialExtent.id = id;
            on(this.map, "extent-change", lang.hitch(this, function(evt) {
              var extent = this.map.extent.getCenter();  
              if(maxExtent.contains(extent)){}  
              else{this.map.setExtent(initialExtent)}
             }));
            return initialExtent;
        },

        /**
         * Filter out default basemap from the basemaps array
         * @param {array} basemaps - Array of basemaps ex: [{"url":"", "isDefault":true}]
         * @returns {object} basemap - default basemap
         */
        _getDefaultBasemap: function(basemaps) {
            var basemap;
            
            
            try {
            	//check if database default was received :
            	 if( this.appUtils.configGeneralSettings.defaultBaseMap && this.appUtils.configGeneralSettings.defaultBaseMap != "" 
            			 && this.appUtils.configGeneralSettings.defaultBaseMapName && this.appUtils.configGeneralSettings.defaultBaseMapName != "" 
            			 && this.appUtils.configGeneralSettings.defaultBaseMapUrl && this.appUtils.configGeneralSettings.defaultBaseMapUrl != "")
                 {
            	    
                 	basemap = {
                 			"url": this.appUtils.configGeneralSettings.defaultBaseMapUrl,
                 			"isDefault": true,
                 			"name": this.appUtils.configGeneralSettings.defaultBaseMapName,
                 			"id": this.appUtils.configGeneralSettings.defaultBaseMap,
                 			"isCached" : this.appUtils.configGeneralSettings.defaultBaseMapCached || 0	//default to dynamic
                 	};
                 }
            	 else if(this.appUtils.configGeneralSettings.defaultBaseMap && this.appUtils.configGeneralSettings.defaultBaseMap != "")
            	 {
            		//if a basemap from the online esri/bing basemap gallery was chosen, only id was saved and is pulled from db:
            		var isFound = false; 
            		for(var i = 0; i<basemaps.length; i++)
            		{
            			 var basemap = basemaps[i];
            			 if( basemap.id && (basemap.id.toLowerCase() == this.appUtils.configGeneralSettings.defaultBaseMap.toLowerCase()) )
                         {
            				 this.appUtils.configGeneralSettings.defaultBaseMapUrl = basemap.url;
                          	this.appUtils.configGeneralSettings.defaultBaseMapName = basemap.name;
                          	this.appUtils.configGeneralSettings.defaultBaseMap = basemap.id;
                        	isFound = true;
                          	return basemap;
                        	 //break; ?
                         }
            		}
            		 /*
            		 array.forEach(basemaps, lang.hitch( this, function(basemap) {
                        
                     }));*/
            		 //TODO: James : Need error handling here
            		if(!isFound)
            		{
            			basemap = _.find(basemaps, function(basemap) {
                            return basemap.isDefault;
                        });
            		}
            		
                	
            	 }
                 else
                 {
                	 this.appUtils.log.debug("no basemap from db, using basemap form online");
                 	 basemap = _.find(basemaps, function(basemap) {
                          return basemap.isDefault;
                      });
                 
                 }
            } 
           catch (error) {
                this.appUtils.log.info("Unable to find the default basemap. Setting Road as default basemap.");
                console.error("error: " , error);
                basemap = {
                    "url": "http://services.arcgisonline.com/arcgis/rest/services/World_Street_Map/MapServer",
                    "isDefault": true
                };
            }
            return basemap;
        },

        /**
         * separate function to set extent.  Allows us to decide whether initial SR is from basemap or from bookmark.  
         * 
         */
        
        //change name to setInitialExtent
        //This is possible for future use, currently not in use as of 12/22/2015
        setExtent: function(p_defaultSR) {
        	var extentInitial = this._getDefaultExtent(this.appUtils.configGeneralSettings.defaultExtent, this.appUtils.configGeneralSettings.defaultExtentSpatialRef);
        	this.appUtils.log.debug("extentInitial: " , extentInitial);
        	
        	if(extentInitial == null || extentInitial == "")	//just use initial extent
        		return;
        	
        	this.appUtils.configGeneralSettings.initialBookmark = extentInitial.id;
        	var defaultSR = new SpatialReference(p_defaultSR);
        	//checkSR:
        	if(extentInitial.spatialReference.wkid == defaultSR.wkid)
        		this.map.setExtent(extentInitial);
        	else
        	{
        		this.appUtils.log.debug("extent of initial bookmark differs in SR from map...converting");
        		//convert first.
        		//borrowed from main.js - showLocation code.  This needs to be extracted into its own util calss
        		var sr = extentInitial.spatialReference;
        		var currSR = defaultSR; //this.map.spatialReference;
        		
        		if(sr.wkid == "4326")
                 {
                 	if(currSR.wkid == "102100" || currSR.wkid == "102113" || currSR.wkid == "3857" || currSR.wkid == "3785")
                 	{
                 		//lat lon to web mercator
                     	var projectedExtent = webMercatorUtils.geographicToWebMercator(extentInitial);
                     	this.map.setExtent( projectedExtent );
                 	}
                 	else
                 	{
                 		var params = new ProjectParameters();
                          params.geometries = [extentInitial];
                          params.outSR = new SpatialReference(currSR.wkid);
                 		//callsite
                         var gsvc = new GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL);
                         gsvc.project(params, lang.hitch(this, function(geometries) {
                            this.map.setExtent( geometries );
                            //or return new Extent(geometries);
                            
                         }), lang.hitch(this, function(error) {
                        	 this._nc4Notify.error("unable to show location due to failed coordinate conversion");			//add status area is better TODO
                         }));
                 		
                 	}
                 	
                 }
                 //else if web mercator
                 else if(sr.wkid == "102100" || sr.wkid == "102113" || sr.wkid == "3857" || sr.wkid == "3785")
                 {
                 	//if web mercator to lat lon
                 	if(currSR.wkid == "4326")
                 	{
                 		var geographicExtent = webMercatorUtils.webMercatorToGeographic(extentInitial);
                 		return geographicExtent;
                 	}
                 	else
                 	{
                 		//request sr is webmercator and current map sr is a custom SR (non lat lon / web mercator)
                 		var params = new ProjectParameters();
                         params.geometries = [extentInitial];
                         params.outSR = new SpatialReference(currSR.wkid);
                		//callsite
                        var gsvc = new GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL);
                        gsvc.project(params, lang.hitch(this, function(geometries) {
                           this.map.setExtent( geometries );
                        }), lang.hitch(this, function(error) {
                        	this._nc4Notify.error("unable to show location due to failed coordinate conversion");
                        }));
                 	}
                 }
                 else 
                 {
                 	//passed in coords is custom SR, and curr SR is not a custom SR, so need geom service to convert
                 	var params = new ProjectParameters();
                     params.geometries = [extentInitial];
                     params.outSR = new SpatialReference(currSR.wkid);
            		//callsite
                    var gsvc = new GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL);
                    gsvc.project(params, lang.hitch(this, function(geometries) {
                       this.map.setExtent( geometries ); 

                    }), lang.hitch(this, function(error) {
                    	this._nc4Notify.error("unable to show location due to failed coordinate conversion");
                    }));
                 }
             	
                 
        	}
        },
        
        /**
         * Adds the basemap layer to map and attach map-on-load event.
         */
        /*james: need to take into consideration saved basemap from database 
         * either a default basemap from the db OR we select from the list of hardcoded maps from the prop file.
         * */
        addBaseMapLayer: function() {
            var basemap = this._getDefaultBasemap(this.appUtils.configGeneralSettings.basemaps);
            this.appUtils.log.debug("defaultBasemap: " , basemap);
            if (basemap.url) {
            	var basemapLayer;
            	
            	if(basemap.type && basemap.type.toLowerCase().indexOf('bing') >= 0)
            	{
            		//IF Bing basemap from the online gallery:
            		 var type = basemap.type;
            		 switch (type) {
                     case "BingMapsRoad":
                    	 var basemapLayer = new VETiledLayer({
                             bingMapsKey: this.appUtils.configGeneralSettings.bingAccessKey,
                             mapStyle: VETiledLayer.MAP_STYLE_ROAD
                         });
                    	 break;
                     case "BingMapsAerial":
                    	 var basemapLayer = new VETiledLayer({
                             bingMapsKey: this.appUtils.configGeneralSettings.bingAccessKey,
                             mapStyle: VETiledLayer.MAP_STYLE_AERIAL
                         });
                    	 break;
                     case "BingMapsHybrid":
                    	 var basemapLayer = new VETiledLayer({
                             bingMapsKey: this.appUtils.configGeneralSettings.bingAccessKey,
                             mapStyle: VETiledLayer.MAP_STYLE_AERIAL_WITH_LABELS
                         });
                    	 break;
                 }
            		
            	}
            	else
            	{
            		//ESRI Base Maps (only other type that can be base map is ESRI Map Service
            	
            		if(typeof(basemap.isCached) != 'undefined' && basemap.isCached > 0)
    				{
            			//if is cached //serviceName, p_appUtils, p_map, p_url, p_shelter, p_id, p_opacity, p_refres
            			this.appUtils.log.info("creating cache map service for: " + basemap.url);
            			
            			var arcgisCachedMgr = new ArcGISMSCachedManager("defaultBasemap", this.appUtils, this.map, basemap.url, null, null, 100, 0);
            			arcgisCachedMgr._addCachedServiceAsBaseMap();
            			
    				}
                	
                	else
                	{
                		//if is not cached
                		this.appUtils.log.info("create dynamic map service for: " + basemap.url);
                		 var basemapLayer = new ArcGISDynamicMapServiceLayer(basemap.url, {
                             id: "defaultBasemap",
                             visible: true
                         });
                	}
            	}
				
                this.map.addLayer(basemapLayer);
            } else {
                this.appUtils.log.error("Basemap url is empty.");
            }
            on(this.map, "load", lang.hitch(this, function() {
                this.appUtils.log.info("Map Loaded");
                this.map.autoResize = true;
                this.map.enableKeyboardNavigation();
                if(this.mode != "showLocation")
                	this.setExtent(this.map.spatialReference.wkid);
               	

            }));
        }

    });
});
