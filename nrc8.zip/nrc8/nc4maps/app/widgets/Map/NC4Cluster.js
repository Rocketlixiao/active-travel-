/*code adapted from ESA's nc4gis map and file nc4Cluster.js, clusterPriority: each graphic should have this attribute if sorting matters */

define([
    "dojo/_base/declare",
    "dojo/aspect",
    "dojo/on",
    "dojo/topic",
    "dojo/_base/lang",
    "dojo/_base/Color",
    "dojo/dom-construct",
    "dojo/dom-style",
    "jqueryplugins/toastr2_1_2/toastr",
    "jqueryplugins/jsRender/jsRenderer",
    "esri/request",
    "esri/layers/GraphicsLayer",
    "esri/graphic",
    "esri/InfoTemplate",
    "esri/geometry/Point",
    "esri/geometry/Polyline",
    "esri/graphicsUtils",
    "esri/SpatialReference",
    "esri/symbols/PictureMarkerSymbol",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/symbols/SimpleLineSymbol",
    "esri/symbols/SimpleFillSymbol",
    "esri/renderers/ClassBreaksRenderer",
    "app/nc4modules/NC4Utils",
    "esri/geometry/screenUtils",
    "app/widgets/DataLayers/MappingLayerData",
    "dojo/_base/event",
    "dojo/query"
], function (declare, aspect, on, topic, lang, Color, domConstruct, domStyle, toastr, jsRenderer, esriRequest, GraphicsLayer, Graphic, InfoTemplate,
    Point, Polyline, graphicsUtils, SpatialReference, PictureMarkerSymbol, SimpleMarkerSymbol, SimpleLineSymbol, SimpleFillSymbol,
    ClassBreaksRenderer, NC4Utils, screenUtils, MappingLayerData, event, query) {

        return declare([], {			//constructor? or postcreate? _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin

            /**
             * APIProperty: distance
             * {Integer} Pixel distance between features that should be considered a
             *     single cluster.  Default is 20 pixels.
             */
            distance: 74,
            tightD: 74,

            /**
             * APIProperty: threshold
             * {Integer} Optional threshold below which original features will be
             *     added to the layer instead of clusters.  For example, a threshold
             *     of 3 would mean that any time there are 2 or fewer features in
             *     a cluster, those features will be added directly to the layer instead
             *     of a cluster representing those features.  Default is null (which is
             *     equivalent to 1 - meaning that clusters may contain just one feature).
             */
            threshold: 2,

            /**
             * Property: resolution
             * {Float} The resolution (map units per pixel) of the current cluster set.
             */
            resolution: null,

            hideClusteredIcons: true,

            map: null,
            nc4ClusterLayer: null,
            id: null,
            plusIcon: null,
            plusIconPin: null,
            pinHeight: 47,
            pinWidth: 20,
            /**
             * Constructor: OpenLayers.Strategy.Cluster
             * Create a new clustering strategy.
             *
             * Parameters:
             * options - {Object} Optional object whose properties will be set on the
             *     instance.
             */

            constructor: function (p_options) {

                //if creating object at a later time, and want to use the current settings
                //if(p_useCurrentState)
                //return;
                //toastr.$ = $;            
                this.setDefaults(p_options);
                this.nc4Utils = new NC4Utils();
                this.mappingLayerData = new MappingLayerData();
                this.maxMapZoom = this.map.getMaxZoom() || 19;
            },

            defaultInfoTemplate:
            "<div  class='infowindow-content '>"
            + "<div class='content-wrap'>"
            + "<div class='title'>${name}</div>"
            + "</div>"
            + "</div>"
            + "<div class='infowindow-additional no-padding'>"
            + "<div class='additional-detail'>${description} </div>"
            + "</div>",

            setDefaults: function (p_options) {
                this.map = p_options.map;
                this.appUtils = p_options.appUtils;
                this.plusIcon = "nc4maps/app/images/cluster_30_TR_plus.gif";
                this.plusIconPin = "nc4maps/app/images/cluster_3047_TR_plus.gif";
                this.nc4ClusterLayer = new GraphicsLayer({
                    refreshInteval: 0	//dependent on layers that makes up the cluster.
                    //styling: true  // TODO: come back to this to see what it is all about
                    , infoTemplate: new InfoTemplate("&nbsp;", this.defaultInfoTemplate)
                });
                /*
                            var _singleSym = new SimpleMarkerSymbol( SimpleMarkerSymbol.STYLE_CIRCLE, 19, new SimpleLineSymbol
                                    (SimpleLineSymbol.STYLE_SOLID,new Color([0, 191, 255, 0.75]), 2),
                                    new Color([0, 191, 255, 0.75])
                            );
                        	
                             var renderer = new ClassBreaksRenderer(_singleSym, "count");
                             var small = new SimpleMarkerSymbol("circle", 20,
                                 new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([0, 191, 255, 0.75]), 10),
                                 new Color([0, 191, 255, 0.75]));
                             var medium = new SimpleMarkerSymbol("circle", 30,
                                 new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([0, 191, 255, 0.75]), 10),
                                 new Color([0, 191, 255, 0.75]));
                             var large = new SimpleMarkerSymbol("circle", 50,
                                 new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([0, 191, 255, 0.75]), 10),
                                 new Color([0, 191, 255, 0.75]));
                             renderer.addBreak(2, 10, small);
                             renderer.addBreak(10, 25, medium);
                             renderer.addBreak(25, 2500000, large);
                             this.nc4ClusterLayer.setRenderer(renderer);
                            */

                this.nc4ClusterLayer.id = "nc4CL";
                this.map.addLayer(this.nc4ClusterLayer);			//TODO: add function to always update index to highest number ? so clusters can always be on top?



                //add event for on update to map instance:
                aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function () {
                    this.map = null;
                    this.map = this.appUtils.mapInstance;
                    this.map.addLayer(this.nc4ClusterLayer);
                    this.deactivate();
                    this.activate();
                    // this.cluster(); the update end should trigger to cluster
                }));
                //		layers.addLayerToVectorClickHoverControl( ClusterManager.layer );

                // turn on
                this.activate();
            },


            /**
             * APIMethod: activate
             * Activate the strategy.  Register any listeners, do appropriate setup.
             *
             * Returns:
             * {Boolean} The strategy was successfully activated.
             */
            activate: function () {
                this.previousExtent = this.map.extent;
                this.nc4ClusterLayer.on("mouse-over", lang.hitch(this, function () {
                    this.map.setMapCursor("pointer");
                }));
                this.nc4ClusterLayer.on("mouse-out", lang.hitch(this, function () {
                    this.map.setMapCursor("default");
                }));
                this.nc4ClusterLayer.on("mouse-down", lang.hitch(this, function (evt) {
                    console.info(evt);

                    var templateReset = new InfoTemplate("&nbsp;", this.defaultInfoTemplate);
                    evt.graphic.setInfoTemplate(templateReset);
                }));
                this.nc4ClusterLayer.on("click", lang.hitch(this, function (evt) {
                    if (this.map.getZoom() < this.maxMapZoom && evt.graphic.cluster.length > 0) {
                        var clusterCount = 0;
                        for (var i = 0; i < evt.graphic.cluster.length; i++) {
                            var cluster = evt.graphic.cluster[i];
                            clusterCount += cluster.attributes.c ? cluster.attributes.c * 1 : cluster.attributes.clusterCount;
                        }
                        if (clusterCount > 10) {
                            this.map.centerAndZoom(evt.graphic.geometry, this.map.getZoom() + 1);
                            event.stop(evt);
                        }
                        else if (globalConfig.isDockPopupMode) {
                            var geometry = evt.graphic.geometry, map = this.map;
                            setTimeout(function () {
                                map.centerAt(geometry);
                            }, 100);
                        }
                    }
                }));
                //this is getting called BEFORE layers fully load
                on(this.map, "zoom-end", lang.hitch(this, function (evt) {
                    this.cluster(evt);
                    //TODO: recent inc: also refresh layer list
                }));


                this.thX = 100;
                this.thY = 100;
                this.currDiffX = 0;
                this.currDiffY = 0;
                on(this.map, "extent-change", lang.hitch(this, function (evt) {


                    if (evt.delta && evt.delta != null) {
                        this.currDiffX += evt.delta.x;
                        this.currDiffY += evt.delta.y;
                        globalConfig.paperAirplane.nc4bboxCount = 0;
                        if (evt.levelChange == true || Math.abs(this.currDiffX) >= this.thX || Math.abs(this.currDiffY) >= this.thY) //( Math.abs(evt.delta.x) > 50 || Math.abs(evt.delta.y) > 50) )
                        {
                            this.currDiffX = 0;
                            this.currDiffY = 0;
                            var ids = this.map.graphicsLayerIds;

                            this.map.infoWindow.hide();
                            for (var i = 0; i < ids.length; i++) {
                                var currLyr = this.map.getLayer(ids[i]);

                                if (currLyr.mode && currLyr.mode == "nc4bbox") {
                                    if (!this.map.isDrillDown && this.map.infoWindow.features && this.map.infoWindow.features[0].cluster)
                                        this.map.infoWindow.hide();
                                    currLyr._refreshGraphicsBbox();
                                    globalConfig.paperAirplane.nc4bboxCount++;
                                }
                            }
                            //TODO: recent inc: also refresh layer list


                        }

                        if (globalConfig.paperAirplane.nc4bboxCount == 0) {
                            globalConfig.paperAirplane.showInforWindow();
                        }
                    }


                }));

                this.subscription = topic.subscribe("nc4ClusterIcons", lang.hitch(this, function (evt) {
                    this.cluster(evt, "nc4newdata");
                    //this event differs from onzoom/zoomend/update-end accounts for those nc4ClusterIcons_RL

                }));
                this.subscription = topic.subscribe("nc4ClusterIcons_RL", lang.hitch(this, function (evt) {
                    this.cluster(evt);
                    //this event differs from onzoom/zoomend/update-end accounts for those nc4ClusterIcons_RL

                }));

                this.subscripCgC = topic.subscribe("cgC", lang.hitch(this, function (p_gId) { //TODO: pass in id of cluster layer , so we don't have to do for loop
                    var graphics = this.nc4ClusterLayer.graphics;	//grab each cluster
                    var l = graphics.length;
                    for (var i = 0; i < l; i++) {
                        var currCluster = graphics[i].cluster;
                        var currCL = currCluster.length;
                        for (var j = 0; j < currCL; j++) {
                            try {
                                var currG = currCluster[j];		//go trhough each graphic to figure out which was clicked
                                if (currG.id == p_gId) {
                                    //this.map.infoWindow.hide();
                                    var newContent = null;

                                    //always check server side cluster first, its popup is stored in the desc attribute
                                    if (currG.attributes && currG.attributes.objtype && (currG.attributes.objtype.indexOf("cluster") >= 0)) {
                                        var templatePath = currG.attributes.popPath;
                                        var objScore = {
                                            currG: currG,
                                            map: this.map
                                        };
                                        require([templatePath], lang.hitch(objScore, function (TemplateMaker) {
                                            var currG = objScore.currG;
                                            var map = objScore.map;

                                            var tm = new TemplateMaker();
                                            var template = new InfoTemplate("&nbsp;", tm.createClusterListTemplate("cgC_server", currG));
                                            currG.setInfoTemplate(template);

                                            map.infoWindow.setFeatures([currG]);
                                            map.infoWindow.show(currG.geometry);

                                        }));
                                        return;

                                    }
                                    else if (currG._layer.popupEndpoint && currG._layer.popupEndpoint == true) 					//if graphic contains htmlPopupendpoint
                                    {
                                        this.loadHtmlPopup(currG._layer.url, currG.id, currG);
                                        return;
                                    }
                                    else if (currG.infoTemplate) 																//if regular graphic and has infotemplate already
                                        newContent = currG.infoTemplate;
                                    else if (currG._layer.popupInfo)																//regular graphic, check layer's popup template passed from nc4
                                        newContent = new InfoTemplate(currG._layer.name, currG._layer.popupInfo);
                                    else if (currG._layer.infoTemplate)															//regular graphic, check layer's default template
                                        newContent = currG._layer.infoTemplate;
                                    else
                                        newContent = "";

                                    if (this.map.halo && this.map.halo == "click") {
                                        try {
                                            var currObjtype = currG.attributes.objtype;
                                            if (currObjtype != null && currObjtype.indexOf("highlight") >= 0) {
                                                currG.attributes.objtype = currG.attributes.objtypeO;

                                                var sym = currG._layer._defaultRenderer.getSymbol(currG);			//how to update symbol
                                                currG.setSymbol(sym);
                                                //update cluster popup (list of items) with new icon)
                                                graphics[i].attributes["description"] = this.createPopup(graphics[i]);
                                            }
                                        } catch (error) { log.error(error); }
                                    }

                                    currG.setInfoTemplate(newContent);
                                    this.map.infoWindow.setFeatures([currG]);

                                    this.map.infoWindow.show(currG.geometry);
                                    return;
                                }
                            }
                            catch (e)
                            { }
                        }

                    }
                }));

                //required, set graphic variable before using template to create data list:
                topic.subscribe("createDataList", lang.hitch(this, function (p_strListOfGIds, p_strListOfLyrIds, p_nodeToAdd, p_getTemplateFxn, p_optIdAttr) {
                    var list = eval(p_strListOfGIds);
                    var lyrList = eval(p_strListOfLyrIds);
                    for (var i = 0; i < list.length; i++) {
                        //find the graphic:
                        var graphic = null;
                        for (var k = 0; k < lyrList.length; k++) {
                            graphic = this.getGraphicFromLayerPrefixes(lyrList[k], list[i], p_optIdAttr);
                            if (graphic != null)
                                break;
                        }
                        if (graphic != null) {
                            var tmpl = $.templates(p_getTemplateFxn);
                            var params = {
                                graphic: graphic,
                                symbol: graphic.symbol.url,
                                type: graphic.attributes.inctype,
                                city: graphic.attributes.city,
                                sp: graphic.attributes.stateprovince
                            }
                            var html = tmpl.render(params);
                            /*
                            str = "";
                            str += "<tr onclick='topic.publish(\"focusOnGraphic\", " + graphic + ")'>";
                                str += "<td valign='middle' align='center'>";
                                    str += "<img  style=\"max-width: 22px;\" src=\"" + graphic.symbol.url + "\" />";
                                str += "</td>";
                                str+= "<td valign='top'>";
                                    str += graphic.attributes.type + ", " + graphic.attributes.city + ", "  + graphic.attributes.stateprovince + ""; //TODO solution specific templat, need to change
                                str += "</td></tr>";*/
                            //var template = eval(p_template);

                            var c = {
                                html: html
                                , p_nodeToAdd: p_nodeToAdd
                            };
                            setTimeout(lang.hitch(c, function () {
                                try {
                                    domConstruct.place(this.html, this.p_nodeToAdd, "after");
                                }
                                catch (error) {
                                    console.error("error: ", error);
                                }
                            }), 600);


                        }
                    }
                }));

                topic.subscribe("addGraphicDialogMap", lang.hitch(this, function (p_options) {
                    try {
                        require(["app/widgets/DialogMap/DialogMap", "esri/geometry/Point", "esri/graphic", "esri/SpatialReference", "esri/symbols/SimpleMarkerSymbol"], lang.hitch(this, function (DialogMap, Point, Graphic, SpatialReference, SimpleMarkerSymbol) {
                            var graphic = this.getGraphicFromLayer(p_options.lId + "_cluster", p_options.fId);
                            if (graphic == null) //as in the case of a server side cluster (the graphic may be clustered)
                            {
                                var symbol = this.getSymbolFromLayer(p_options.lId + "_cluster", p_options.fId)

                                //create a graphic
                                var newpt = new Point(p_options.lon, p_options.lat, new SpatialReference(p_options.wkid));
                                graphic = new Graphic(newpt, symbol);
                            }
                            p_options.graphic = graphic;
                            var contexto = {
                                p_options: p_options,
                                appUtils: this.appUtils
                            };
                            //hack - "show" event not working for popup
                            setTimeout(lang.hitch(contexto, function () {
                                var dMap = new DialogMap(p_options, this.appUtils);
                            }), 600);
                        }));
                    } catch (e) {
                        console.error(e);
                    }
                }));

                topic.subscribe("addGraphicTracksDialogMap", lang.hitch(this, function (p_options) {
                    try {
                        require(["app/widgets/DialogMap/DialogMap"], lang.hitch(this, function (DialogMap) {
                            var graphic = this.getGraphicFromLayer(p_options.lId + "_cluster", p_options.fId);
                            //var symbol = graphic.symbol; //use this as the symbol for the lines

                            var tracksSR = new SpatialReference({ wkid: p_options.sr });
                            var geometry = new Polyline(tracksSR);
                            var tracks = p_options.tracks;
                            //geometry.addPath(JSON.stringify(p_options.tracks));
                            geometry.addPath(tracks);
                            var newgraphic = new Graphic(geometry,
                                new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                    new Color([255, 0, 0, .90]), 2));

                            p_options.graphic = newgraphic;

                            if (p_options.points != null && p_options.points.length > 0) {
                                var markers = [];
                                for (var i = 0; i < p_options.points.length; i++) {
                                    var currPt = p_options.points[i];
                                    var newPtGraphic = new Graphic(currPt, graphic.symbol);
                                    markers.push(newPtGraphic);
                                }
                                p_options.markers = markers;

                            }

                            var dMap = new DialogMap(p_options, this.appUtils);
                        }));
                    } catch (e) {
                        console.error(e);
                    }
                }));

                topic.subscribe("hideShowDivs", function (p_listH, p_listS) {
                    require(["dojo/dom-style"], function (domStyle) {
                        for (var i = 0; i < p_listH.length; i++) {
                            try { domStyle.set(p_listH[i], "display", "none"); } catch (e) { console.info("hideShowDivs", e) }
                        }
                        for (var j = 0; j < p_listH.length; j++) {
                            try { domStyle.set(p_listS[j], "display", "block"); } catch (e) { console.info("hideShowDivs", e) }
                        }
                    });
                });

                topic.subscribe("focusOnGraphic", lang.hitch(this, function (p_graphic) {

                    //The map layer containing this item is turned off.
                    //** Please enable the map layer with the check boxse in the menu. **
                }));

                this.subscripCgC_server = topic.subscribe("cgC_server", lang.hitch(this, function (p_fId, p_sId, p_lId) {
                    var layerUrl = "../nc4maps/rest/services/" + p_sId + "/featureServer/" + p_lId;
                    var graphic = this.getGraphicFromLayer(p_lId, p_fId); //will only exist for top item of server side cluster (others are an illusion)
                    this.loadHtmlPopup(layerUrl, p_fId, graphic);

                }));

                this.subsripLoadPop = topic.subscribe("loadHtmlPopup", lang.hitch(this, function (p_graphic) {
                    this.loadHtmlPopup(p_graphic._layer.url, p_graphic.id, p_graphic);
                }));

                topic.subscribe("loadAssetsDetail", lang.hitch(this, function (selector, ids) {
                    var self = this;
                    if (ids) {
                        var assetsRequest = this.loadAssetsDetail(ids);
                        assetsRequest.then(function (response) {
                            if (response && response.features) {
                                var html = $ui(selector).html();

                                response.features.forEach(function (a) {
                                    var status = globalConfig.getAssetProximityStatus(a.attributes.facilityid);
                                    var title = a.attributes.facilitytype + ' | ' + a.attributes.facilityname;
                                    html += '<div class="col col-md-12 col-sm-12 col-xs-12 item risk-' + self.toLower(status) + '" severity="' + (globalConfig.severityFactory.getKeyByValue(status) || 0) + '">';
                                    html += '<a href="#/assets/' + a.attributes.facilityid + '" class="title">' + title + '</a><a class="paper-airplane" onclick="javascript:globalConfig.launchIncidentLocationFromPopup(\'location\',\'' + a.attributes.facilityid + '\',' + a.attributes.latitude * 1 + ',' + a.attributes.longitude * 1 + ');"><i class="nc4-icon-map-marker"></i></a>';
                                    html += '</div>';
                                });

                                if (html) {
                                    var items = $ui(html)
                                    items.sort(function (a, b) {
                                        var indexA = parseInt($(a).attr('severity'));
                                        var indexB = parseInt($(b).attr('severity'));

                                        return indexB - indexA;
                                    });
                                    $ui(selector).empty().append(items);
                                }
                            }
                        }, function (err) { console.log(err); });
                    }
                }));
                topic.subscribe("popup-shown", lang.hitch(this, function (option) {
                    var btn = query('button.show-assets', option.domNode);
                    if (btn.length) {
                        btn[0].click();
                    }
                    //add scroll event for panel body
                    var divPanelBody = query('div.panel-body', option.domNode);
                    if (divPanelBody.length) {
                        for (var i = 0; i < divPanelBody.length; i++) {
                            globalConfig.touchScroll(divPanelBody[i]);
                        }
                    }
                }));
            },

            //called on single graphic, called on single graphic w/in client side cluster
            loadHtmlPopup: function (p_lyrUrl, p_fId, p_graphic) {

                if (p_graphic && p_graphic.attributes.objtype)
                    contentObj = { f: "json", objtype: p_graphic.attributes.objtype }
                else
                    contentObj = { f: "json" } //(item from a server side cluster)

                var contextObj = {
                    currG: p_graphic,
                    map: this.map
                };
                esriRequest({
                    url: p_lyrUrl + "/" + p_fId + "/htmlPopup",
                    content: lang.mixin(contentObj, null),
                    load: lang.hitch(contextObj, function (response) {
                        var currG = contextObj.currG;
                        if (currG == null)
                            currG = contextObj.map.infoWindow.getSelectedFeature(); //when clicking on an item from server side cluster

                        if (response.featureCoords) {
                            currG.geometry.x = response.featureCoords.x
                            currG.geometry.y = response.featureCoords.y
                        }

                        currG.setInfoTemplate(new InfoTemplate(response));
                        contextObj.map.infoWindow.setFeatures([currG]);
                        contextObj.map.infoWindow.show(currG.geometry); //currG.geom is required for single item w/in client cluster

                        if (response.jsClientAction)
                            eval(response.jsClientAction);

                        //if new attributes were received, try to update currG with the new attributes - N/A for IE 8 mode
                        if (response.jsAttrUpdate && response.jsAttrUpdate != null) {
                            var newAttrObj = response.jsAttrUpdate;
                            for (var att in newAttrObj) {
                                if (newAttrObj.hasOwnProperty(att))
                                    currG.attributes[att] = newAttrObj[att];
                            }
                            currG.setSymbol(currG._layer._getRenderedSymbol(currG));
                        }
                    }),
                    error: lang.hitch(this, function (response) {
                    })
                });
            },
            loadAssetsDetail: function (ids) {
                return esriRequest({
                    url: '/nc4maps/rest/services/location/FeatureServer/locationaz/query?f=json&where=1=1&outSR=102100&outFields=city,street,postal,country,description,lastupdateddate,contactemail,region,showonmap&cluster=false&showonmap=all&lids=' + ids,
                    handleAs: 'json'
                });
            },
            /**
             * APIMethod: deactivate
             * Deactivate the strategy.  Unregister any listeners, do appropriate
             *     tear-down.
             *
             * Returns:
             * {Boolean} The strategy was successfully deactivated.
             */
            deactivate: function () {
                try {
                    this.nc4ClusterLayer.clear();

                    this.subscription.remove();
                    this.subscripCgC.remove();
                    this.isClustering = false;

                }
                catch (error) {
                    console.log("unable to deactivate fully: error: ", error);
                }

            },

            //jt : currently not in use
            getSize: function (feature) {
                var bScale = false; // setting

                if (bScale) {
                    return Math.max(40,
                        Math.min(25,
                            20 + Math.round(feature.attributes.count * 1.125)))
                }
                else {
                    return 30;
                }
            },

            //main method
            cluster: function (event, p_nc4event) {
                if (this.isClustering) {
                    return;
                    /*
                    if(this.timeoutId)
                    {
                        console.log("Clustering - busy AND there's already timeout");
                        // so there's no need to set another timer
                        //this.timeoutId = setTimeout( lang.hitch(this, function(){this.cluster()}), 50);//ClusterManager.cluster , 50 );
                        return;
                    }*/
                }

                var bDoCluster = true;

                if (this.threshold < 1) {
                    // console.log("Cluster - EXIT.  threshold = ", ClusterManager.threshold);
                    bDoCluster = false;
                }
                //JT Ignore this for now, TODO: optimize later.
                /*
                else if( event && event.layer)
                {
                    var layer = event.layer;
    
                    if( layer.id == this.id)
                    {
                        // console.log("Cluster - EXIT.  event caused by cluster layer itself");
                        bDoCluster = false;
                    }
                    else if( ! layer.features || layer.features.length == 0 )
                    {
                        // console.log("Cluster - EXIT.  Layer has no features.");
                        bDoCluster = false;
                    }
                }
                */
                if (!bDoCluster) {
                    console.log("not clustering, threshold is less than 1");
                    return;
                }
                /* if it is clustering, lets not set a timeout for now...this can affect performance JT
                            if( ClusterManager.isClustering )
                            {
                                if(ClusterManager.timeoutId)
                                {
                                    console.log("Clustering - busy AND there's already timeout");
                                    // so there's no need to set another timer
                                    return;
                                }
                
                                console.log("Cluster - BUSY! set timeout");
                                ClusterManager.timeoutId = setTimeout( ClusterManager.cluster , 50 );
                            }
                            else
                            {*/
                // console.log("Cluster - run it");
                //ClusterManager.timeoutId = null;

                this.isClustering = true;
                // ClusterManager._cluster();
                this._cluster(event, p_nc4event);

            },

            /**
             * Method: cluster
             * Cluster features based on some threshold distance.
             *
             * Parameters:
             * event - {Object} The event received when cluster is called as a
             *     result of a moveend event.
             */
            _cluster: function (p_event, p_nc4event) {
                this.nc4ClusterLayer.clear();
                console.info("event passed into cluster(): ", p_event);
                try {
                    // if(console.time){ console.time("cluster"); }
                    //TODO JT: most optimized place to add to recent incident list?

                    // this.map.infoWindow.hide();

                    this.resolution = this.map.extent.getWidth() / this.map.width;
                    var clusters = [];


                    // loop all map layers, check for features
                    // join all features into single array
                    var gIds = this.map.graphicsLayerIds;
                    //var theLayers = this.map.layers;
                    var lenLayers = gIds.length;
                    var allGraphics = [];



                    // forloop to gather all the data
                    for (var iOverLayers = lenLayers - 1; iOverLayers >= 0; iOverLayers--) {
                        var layer = this.map.getLayer(gIds[iOverLayers]);

                        //layer = theLayers[ iOverLayers -1 ]; randy added: only keep locations and incidents layer left.
                        if (layer == null || (layer.id && layer.id == "nc4CL") || (layer.id.indexOf('_fac_') == -1) && layer.id.indexOf('_nimc_') == -1 && layer.id.indexOf('_isa_') == -1)
                            continue;
                        var currFeatures = layer.graphics || layer.items;
                        if (currFeatures == null || currFeatures.length == 0)
                        { continue; }

                        // we found a good layer that has features and could be possibly clustered
                        var graphics = currFeatures || [];
                        allGraphics = allGraphics.concat(graphics);
                    }

                    // run clustering on full array of features
                    var clustered;
                    var iAllFoundFeatures = allGraphics.length;

                    var newRecentData = [];
                    var rdOpt = {};
                    var arrIncludedLyrs = []; //config.generalsettings.rlyrs
                    var arrRd = this.appUtils.configGeneralSettings.rd || []; //get array of prefixes for recent data layers

                    for (var iOverFeatures = 0; iOverFeatures < iAllFoundFeatures; ++iOverFeatures) {
                        var currGraphic = allGraphics[iOverFeatures];

                        if (p_nc4event == "nc4newdata") {
                            //grab array of layer IDs that should be included in recent inc

                            //       	if(arrIncludedLyrs.contains[currGraphic._layer.id])              TODO: JT ADD this check in later
                            var cgLyr = currGraphic._layer;
                            for (var i = 0; i < arrRd.length; i++) {
                                if (cgLyr.id.indexOf(arrRd[i]) >= 0) {
                                    newRecentData.push(currGraphic);

                                    if (rdOpt[cgLyr.id] == null) {
                                        rdOpt[cgLyr.id] = cgLyr.name || "";
                                    }
                                    break;
                                }
                            }
                        }

                        //this check shouldn't apply to recent data list, since we want all data to be shown and respect its own filter
                        if (currGraphic.attributes.turnedOff && currGraphic.attributes.turnedOff == 1)
                            continue;
                        // TODO clean up cluster priority

                        if (currGraphic.attributes != undefined && currGraphic.attributes.clusterpriority != undefined)
                            currGraphic.clusterPriority = currGraphic.attributes.clusterpriority;
                        else
                            currGraphic.clusterPriority = 0;
                        if (currGraphic.id == null)
                            currGraphic.id = new Date().getTime() + Math.random();

                        // we only cluster points.  everything else (ie polygons) is left as drawn on the map
                        if (currGraphic.geometry && currGraphic.geometry.type == "point") {
                            clustered = false;

                            var closestCluster = null;
                            //var closestClusterPinCase = null;

                            var currDForZ = this.getClusterDistForZoom();

                            var closestDistance = currDForZ;
                            //var closestDistancePinCase = this.pinHeight;

                            for (var iOverClusters = 0; iOverClusters < clusters.length; ++iOverClusters) {
                                var currCluster = clusters[iOverClusters];
                                var dToCluster = (this.getDistance(currCluster, currGraphic));

                                //check if w/in current distance threshold for zoom
                                if (dToCluster <= currDForZ) {
                                    //now check if graphic has a shorter to any other cluster objects.
                                    if (dToCluster <= closestDistance) {
                                        closestDistance = dToCluster;
                                        closestCluster = currCluster;
                                    }
                                }
                                //JT-experiment with special case for pin icons: allow for item to be clusted if it is w/in 47px north of cluster
                                /*
                                else if( dToCluster <= this.pinHeight 
                                            && this.isNorthOfCluster(currCluster, currGraphic)
                                            && this.getLonDistancePx(currCluster, currGraphic) <= this.pinWidth)
                                {
                                    closestDistancePinCase = dToCluster;
                                    closestClusterPinCase = currCluster;
                                	
                                }
                                */
                            } // end for() over clusters
                            if (closestCluster != null) {
                                this.addToCluster(closestCluster, currGraphic); //adding reference
                                clustered = true;
                            }
                            /*
                            else if(closestClusterPinCase != null)
                            {
                                this.addToCluster(closestClusterPinCase, currGraphic); //adding reference
                                clustered = true;
                            }*/

                            if (!clustered) {
                                //when current graphic is location cluster, hidden the graphic. Otherwise, display graphic
                                if (currGraphic.attributes.datatype == 'location' && currGraphic.attributes.c != undefined && currGraphic.attributes.c * 1 > 1) {
                                    this.hideFeature(currGraphic);
                                }
                                else {
                                    this.showFeature(currGraphic);
                                }
                                clusters.push(this.createCluster(currGraphic));
                            }
                            else {
                                this.hideFeature(currGraphic);	//JT: graphic is clustered, so hide from its native layer
                            }

                        } // end if feature.geometry

                    } // end for() over features
                    if (newRecentData != null && newRecentData.length > 0)
                        topic.publish("nc4newdata", newRecentData);
                    if (rdOpt != null && rdOpt.length > 0)
                        topic.publish("ncRdOpt", rdOpt);

                    if (clusters.length > 0) {
                        if (this.threshold > 1) {
                            //sort clusters by the highest severity of its items to order rendered graphics.
                            clusters.forEach(function (c) {
                                c.cluster.forEach(function (i) {
                                    var s = globalConfig.severityFactory.getKeyByValue(i.attributes.severity || '') || 0;
                                    c.attributes.severity = c.attributes.severity > s ? c.attributes.severity : s;
                                })
                            });
                            clusters.sort(function (a, b) { return a.attributes.severity - b.attributes.severity });

                            //var clone = clusters.slice();
                            //clusters = [];

                            //iterating through each cluster.  TODO: Since this is another for loop, might want to add this logic into the clustering for loop
                            var candidate = null;
                            for (var iOverClustersClone = 0, len = clusters.length; iOverClustersClone < len; ++iOverClustersClone) {
                                candidate = clusters[iOverClustersClone];

                                //set up info template
                                if (candidate.attributes.count >= this.threshold) {
                                    // iterate through all features in the cluster to setup
                                    // the cluster name and description

                                    var f, desc;


                                    var bHideSingleClusterFeature = true; // setting

                                    var mostImportantFeature = null;

                                    // have to sort them before we generate the click title
                                    var previousTopFeature = candidate.cluster[0];
                                    try {
                                        candidate.cluster.sort(function (a, b) {
                                            var bInt = parseInt(b.attributes.clusterpriority) || 0;
                                            var aInt = parseInt(a.attributes.clusterpriority) || 0;
                                            return bInt - aInt;
                                        });
                                    }
                                    catch (e) {
                                        console.log("error with sorting cluster: ", e)
                                    }

                                    var desc = this.createPopup(candidate);
                                    var title = 'MORE INFORMATION';
                                    candidate.attributes["name"] = title;
                                    candidate.attributes["description"] = desc;
                                    var isPinCluster = this.updateClusterMainFeature(candidate, previousTopFeature);

                                    if (candidate.cluster.length > 1 || (candidate.cluster.length == 1 && candidate.attributes.count != undefined && candidate.attributes.count > 1)) {
                                        /*
                                        if(isPinCluster == true)
                                        {
                                            for(var x = 0; x < clusters.length; x++)
                                            {
                                                var currSing = clusters[x];
                                                
                                                var dFrmClusToSingItem = this.getDistance(candidate, currSing);
                                                if( dFrmClusToSingItem <= this.pinHeight 
                                                               && this.isNorthOfCluster(candidate, currSing)
                                                               && this.getLonDistancePx(candidate, currSing) <= this.pinWidth)
                                                       {
                                                         this.addToCluster(candidate, currSing);
                                                         clusters.splice(iOverClustersClone)
                                                         iOverClustersClone--;
                                                       }
                                            }
                                                                                
                                       }*/
                                        //JT if top icon is pin, loop through all pin clusters, for each, loop through all single items left, and see if those
                                        //single items fall w/in 47 px top of the icon?

                                        this.nc4ClusterLayer.add(candidate);
                                    }
                                }
                            }

                            clusters = [];
                            clusters = null;
                        }
                    }
                    if (!this.map.isDrillDown && this.map.infoWindow.features && this.map.infoWindow.features[0].cluster) {
                        this.map.infoWindow.hide();
                    }
                    //Randy: notice the loader timer interval that cluster for all layers are done
                    //when length=1, that means all of layers have been cluster completely
                    if (globalConfig.allMapLayers != undefined && globalConfig.allMapLayers.length == 1) {
                        globalConfig.isClusterComplete = true;
                    }

                    //Randy:show popup untill all of ncebbox are loaded completed.
                    if (globalConfig.paperAirplane.nc4bboxCount == 1) {
                        globalConfig.paperAirplane.showInforWindow();
                        globalConfig.paperAirplane.nc4bboxCount = 0;
                    }
                    else if (globalConfig.paperAirplane.nc4bboxCount > 0) {
                        globalConfig.paperAirplane.nc4bboxCount--;
                    }
                    //if(console.time){ console.timeEnd("cluster"); }
                    // ClusterManager.getClusterStats();
                }
                catch (e) {
                    console.log(e);
                }
                finally {
                    this.isClustering = false;
                }
                this.map.reorderLayer(this.nc4ClusterLayer, this.map.graphicsLayerIds.length);
            },

            createPopup: function (p_cluster) {
                return this.mappingLayerData.createClusterTemplate(p_cluster.cluster);
            },

            hideFeature: function (p_graphic) {
                p_graphic.hide();
                /*
                if( !ClusterManager.hideClusteredIcons )
                {
                    if(feature && feature.style && feature.style.display == "none" )
                    {
                        ClusterManager.showFeature (feature);
                    }
    
                    return;
    
                }
    
                if(feature && feature.style && feature.style.display == "none" )
                {
                    // do nothing, it's already hidden
                }
                else
                {
                    feature.origStyle = feature.style;
    
                    // if( ! feature.style )
                    {
                        feature.style = {};
                    }
    
                    feature.style.display = "none";
                    feature.layer.drawFeature(feature);
                }*/
            },

            showFeature: function (p_graphic) {

                p_graphic.show();
                /*
                if(feature && feature.style && feature.style.display == "none" )
                {
                    feature.style = feature.origStyle;
    
                    feature.origStyle = null;
    
                    feature.layer.drawFeature(feature,  feature.style || "default" );
                }*/
            },

            getClusterStats: function () {
                var theLayers = ClusterManager.map.layers;
                var lenLayers = theLayers.length;

                var iLayers = lenLayers;
                var iFeatureLayers = 0;
                var iAllFeatures = 0;
                var iShownFeatures = 0;
                var iHiddenFeatures = 0;

                var layer;
                var allfeatures = [];

                // forloop to gather all the data
                for (var iOverLayers = 0; iOverLayers < lenLayers; iOverLayers++) {
                    layer = theLayers[iOverLayers];

                    if (layer.isBaseLayer || !layer.visibility)
                    { continue; }


                    if (layer.CLASS_NAME == "OpenLayers.Layer.Vector.RootContainer")
                    { continue; }

                    /*
                    if(layer.id == ClusterManager.layer.id)
                    {
                        continue;
                    }
                    */

                    if (!layer.features)
                    { continue; }

                    iFeatureLayers++;

                    // we found a good layer that has features and could be possibly clustered
                    allfeatures = allfeatures.concat(layer.features);
                }

                // run clustering on full array of features
                iAllFeatures = allfeatures.length;

                for (var iOverFeatures = 0; iOverFeatures < iAllFeatures; ++iOverFeatures) {
                    feature = allfeatures[iOverFeatures];

                    if (feature && feature.style && feature.style.display == "none") {
                        iHiddenFeatures++;
                    }
                } // end for() over features

                iShownFeatures = iAllFeatures - iHiddenFeatures;

                var strResult = "Layers: " + iLayers + " (" + iFeatureLayers + " w/features).  Features: " + iAllFeatures + " (" + iShownFeatures + ", " + iHiddenFeatures + ", " + Math.round((iAllFeatures > 0 ? iHiddenFeatures / iAllFeatures : 0) * 100) + "%) (shown, hidden, %hidden)";
                console.log(strResult);

                return;
            },

            moveClusterLayerToTop: function () {
                // guarantee layer stays on top
                ClusterManager.map.setLayerZIndex(ClusterManager.layer, ClusterManager.map.getNumLayers());
            },

            getDistance: function (p_cluster, p_graphic) {
                var cc = p_cluster.geometry;
                //var cc = graphicsUtils.graphicsExtent(p_cluster.geometry).getCenter();
                var fc = p_graphic.geometry;
                var distance =
                    Math.sqrt(
                        Math.pow((cc.y - fc.y), 2) + Math.pow((cc.x - fc.x), 2)
                    ) / this.resolution
                    ;
                return distance; //(distance <= this.distance);
            },

            getClusterDistForZoom: function () {
                var cz = this.map.getZoom();
                if (cz <= 1)
                    return 38;
                else if (cz <= 2)
                    return 32;
                else if (cz <= 4)
                    return 33;
                else if (cz <= 6)
                    return 40;
                else if (cz <= 7)
                    return 54;
                else if (cz <= 9)
                    return 42;
                else
                    return 40;
            },

            isNorthOfCluster: function (p_cluster, p_graphic) {
                //what if we test for if distance is greater than this.distance, but less that this.pinIconSize(47), and direction is north?

                var cc = p_cluster.geometry;
                var fc = p_graphic.geometry;

                if (fc.y > cc.y)
                    return true;

            },

            getLonDistancePx: function (p_cluster, p_graphic) {
                var clusterPx = screenUtils.toScreenGeometry(this.map.extent, this.map.width, this.map.height, p_cluster.geometry);
                var graphicPx = screenUtils.toScreenGeometry(this.map.extent, this.map.width, this.map.height, p_graphic.geometry);

                var xdiff = Math.abs(clusterPx.x - graphicPx.x);
                return xdiff;
            },

            /**
             * Method: addToCluster
             * Add a feature to a cluster.
             *
             * Parameters:
             * cluster - {<OpenLayers.Feature.Vector>} A cluster.
             * feature - {<OpenLayers.Feature.Vector>} A feature.
             */
            addToCluster: function (p_cluster, p_graphic) {
                p_cluster.cluster.push(p_graphic);
                p_cluster.attributes.count += (p_graphic.attributes.datatype == 'location' && p_graphic.attributes.c != undefined) ? p_graphic.attributes.c * 1 : 1;
            },

            /**
             * Method: createCluster
             * Given a graphic, create a cluster
             *
             * Parameters:
             * Esri Graphic
             *
             * Returns:
             * Cluster object, based on the geometry of the passed in ESRI Graphic, that contains the ESRI Graphic
             */
            createCluster: function (p_graphic) //p_graphic.symbol.height /width
            {
                var center = p_graphic.geometry;
                //calculate offset from size
                var symbol = p_graphic.symbol;
                //var offsets = this.getOffsetFromSize(symbol.width, symbol.height );
                var sr = center.spatialReference.wkid;
                var newPms = symbol;
                // newPms.setOffset(offsets.xoffset,offsets.yoffset);
                //make sure get correct cluster count for location graphic
                var cou = (p_graphic.attributes.datatype == 'location' && p_graphic.attributes.c != undefined) ? p_graphic.attributes.c * 1 : 1;
                var newCluster = new Graphic(
                    new Point(center.x, center.y, new SpatialReference(sr)),
                    newPms,//p_graphic.symbol,
                    { count: cou },	//attributes
                    new InfoTemplate("&nbsp;", this.defaultInfoTemplate)
                );
                /*
                var cluster = new OpenLayers.Feature.Vector(
                    new OpenLayers.Geometry.Point(center.lon, center.lat),
                    {count: 1}
                );*/

                //neew cluster object created, its first item will be the graphic used to create it:
                newCluster.cluster = [p_graphic];

                return newCluster;
            },

            createClusterSymbol: function (cluster) {
                var length = width = height = 25,
                    data = this.createSymbolData(cluster),
                    symbol = new PictureMarkerSymbol({ 'width': width, 'height': height }),
                    total = 0;

                if (d3) {
                    data.forEach(function (d) { total += d.value; });
                    var color = d3.scale.ordinal()
                        .range(data.map(function (i) { return i.color; })),
                        arc = d3.svg.arc()
                            .outerRadius(length / 2)
                            .innerRadius(length / 2 - 5),
                        pie = d3.layout.pie()
                            .sort(null)
                            .value(function (d) { return d.value; });

                    var svg = '<svg width="' + width + '" height="' + height + '" viewBox="0 0 ' + width + ' ' + height + '" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">';
                    svg += '<circle fill="white" cx="' + length / 2 + '" cy="' + length / 2 + '" r="' + length / 2 + '"></circle>';
                    svg += '<g transform="translate(' + length / 2 + ',' + length / 2 + ')">';
                    data.forEach(function (d, i) {
                        svg += '<path d="' + arc(pie(data)[i]) + '" fill="' + color(i) + '"></path>'
                    });
                    svg += '</g>'
                    svg += '<text x="' + length / 2 + '" y="' + (length / 2 + 3) + '" text-anchor="middle" font-size="8" font-family="Verdana" fill="black">' + total + '</text>';
                    svg += '</svg > ';

                    var dataURL = "data:image/svg+xml;base64," + globalConfig.Base64.encode(svg);
                    symbol.setUrl(dataURL);
                }
                return symbol;
            },

            createSymbolData: function (cluster) {
                var assetsCount = extreme = severe = moderate = minor = unknown = 0;
                cluster.forEach(function (g) {
                    if (g.attributes.datatype == 'incident') {
                        switch (g.attributes.severity) {
                          case globalConfig.SEVERITY_VALUE_EXTREME:
                                extreme++;
                                break;
                          case globalConfig.SEVERITY_VALUE_SEVERE:
                                severe++;
                                break;
                          case globalConfig.SEVERITY_VALUE_MODERATE:
                                moderate++;
                                break;
                          case globalConfig.SEVERITY_VALUE_MINOR:
                                minor++;
                                break;
                            default:
                                unknown++;
                                break;
                        }
                    }
                    else {
                        assetsCount += g.attributes.c ? g.attributes.c * 1 : g.attributes.clusterCount;
                    }
                });
                return [
                  { label: globalConfig.SEVERITY_VALUE_EXTREME, color: globalConfig.SEVERITY_COLOR_EXTREME, value: extreme },
                  { label: globalConfig.SEVERITY_VALUE_SEVERE, color: globalConfig.SEVERITY_COLOR_SEVERE, value: severe },
                  { label: globalConfig.SEVERITY_VALUE_MODERATE, color: globalConfig.SEVERITY_COLOR_MODERATE, value: moderate },
                  { label: globalConfig.SEVERITY_VALUE_MINOR, color: globalConfig.SEVERITY_COLOR_MINOR, value: minor },
                    { label: 'Unkown', color: 'grey', value: unknown },
                  { label: 'Assets', color: globalConfig.SEVERITY_COLOR_RING_LOCATION, value: assetsCount }
                ];
            },

            updateClusterMainFeature: function (p_cluster, p_previousTopGraphic) {
                //replace p_cluster's, which is a graphic object,   point and symbol
                var isPin = false;
                mostImportantFeature = p_cluster.cluster[0];

                var newPoint = new Point(mostImportantFeature.geometry.x, mostImportantFeature.geometry.y, new SpatialReference(mostImportantFeature.geometry.spatialReference.wkid));

                p_cluster.symbol = this.createClusterSymbol(p_cluster.cluster);
                if (mostImportantFeature._layer._isPin && mostImportantFeature._layer._isPin == 1) {
                    isPin = true;
                }

                //if (p_previousTopGraphic.id != mostImportantFeature.id)
                p_previousTopGraphic.hide();

                p_cluster.geometry = newPoint;
                //this.showFeature(mostImportantFeature);	//JT Most important icon on top
                return isPin;
            },

            getOffsetFromSize: function (p_w, p_h) {
                try {
                    var intMicrosoftDefaultImageSize = 26; // default MS icon image is 26x26 pixels
                    var intOffsetLeft = Math.round(p_w / 2); // - (intMicrosoftDefaultImageSize / 2 * -1);
                    var intOffsetTop = Math.round(p_h / 2);// - (intMicrosoftDefaultImageSize / 2 * -1);

                    var offsets = { xoffset: intOffsetLeft, yoffset: intOffsetTop };

                    return offsets;
                }
                catch (e) {
                    console.log("error getting offset for cluster icon: ", e);
                    return { xoffset: 10, yoffset: 10 };
                }
            },

            getGraphicFromLayer: function (p_layerId, p_graphicId) {
                var lyr = this.map.getLayer(p_layerId);
                if (lyr != null) {
                    var graphics = lyr.graphics;
                    for (var i = 0; i < graphics.length; i++) {
                        if (graphics[i].id == p_graphicId)
                            return graphics[i];
                    }
                    return null;
                }
                else return null;
            },

            //TODO: all this does is use the 1st graphic from the same layer...worst case scenario! so need to update this
            getSymbolFromLayer: function (p_layerId, p_graphicId) {
                var lyr = this.map.getLayer(p_layerId);
                if (lyr != null) {
                    var graphics = lyr.graphics;
                    return graphics[0].symbol;
                }
                else return null;
            },

            getGraphicFromLayerPrefixes: function (p_layerPrefix, p_graphicId, p_optIdAttr) {

                var graphicsLayerIds = this.map.graphicsLayerIds
                for (var m = 0; m < graphicsLayerIds.length; m++)			//TODO make this reusable function
                {
                    var currMapLyrId = graphicsLayerIds[m];
                    if (currMapLyrId.indexOf(p_layerPrefix) >= 0) {
                        var currLyr = this.map.getLayer(currMapLyrId);
                        var graphics = currLyr.graphics;
                        for (var i = 0; i < graphics.length; i++) {
                            if (p_optIdAttr && p_optIdAttr != null) {
                                if (graphics[i].attributes[p_optIdAttr] == p_graphicId)
                                    return graphics[i];
                            }
                            else
                                if (graphics[i].attributes.incidentid == p_graphicId)
                                    return graphics[i];
                        }


                    }
                }
                return null;
            },

            /* not in use
            getFeatureByLayerAndId: function(p_shapeId, p_layerId)
            {
                var layer = this.map.getLayer( p_layerId );
                var feature = layer.getFeatureById( p_shapeId );
                return feature;
            },
            */
            toLower: function (str) {
                if (typeof str === 'string') {
                    return str.toLowerCase();
                }
                return str;
            }
        });
    });
