/*
 * Identify task for ArcGIS Map Service
 * - if on, need to check other floating widgets and turn them off
 * - give notification if other floating widgets were turned off
 * 
 */
define([
	"dojo/aspect",
    "dojo/_base/declare",
    "dojo/query",
    "dojo/on",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dijit/_WidgetBase",
    "dojo/dom-class",
    "esri/tasks/IdentifyParameters",
    "esri/tasks/IdentifyTask",
    "esri/InfoTemplate",
    "dojo/_base/array",
    "dojo/promise/all",
    "dijit/registry"
], function(aspect, declare, query, on, html, lang, _WidgetBase, domClass, IdentifyParameters, IdentifyTask, InfoTemplate, array, all,registry) {
    return declare([_WidgetBase], {
    	id: "Identify",		//ID Causing issue on basmap switch
    	name: "Identify",
    	_state: false, //default to not locked
		_identify: null,
    currLayer: null,
		
        postCreate: function() {
            this.inherited(arguments);
            this._nc4Notify = this.appUtils.nc4Notify;
                /**
                 * Create and place 'Identify' button widget to activate/deactivate
                 */
            this._identify = html.create("div", {
                "title": this.config.label,
                "class": "widget-identify"
            }, null);
            
            on(this._identify, "click", lang.hitch(this, function(){
            	this._showHideWidget();
            }));
            
            var zoomOut = query(".esriSimpleSliderDecrementButton");
            html.place(this._identify, zoomOut[0], "after");
			if (zoomOut.length > 0) {
                
			}
			else
			{
				//TODO place somewhere else
			}
			
       },
        
        _showHideWidget: function() {
            if (!this._state) {
                domClass.add(this._identify, "widgetIconFullOpacity");
                this._state=true;
                //activate identify on click
                this._nc4Notify.info("'Identify' Tool Enabled for ArcGIS Dynamic Services");
                this.map.infoWindow.identify = true;
                this._identifyOn();
                
                this._disableConflictingWidgets();
            } else {
                domClass.remove(this._identify, "widgetIconFullOpacity");
                this._state=false;
                this.map.infoWindow.identify = false;
                // this.map.infoWindow.multiple = false;
                //de-activate identify on click
                this._identifyOff();
            }
        },
        
        _disableConflictingWidgets: function() {
        	var widgetRevGeocode = registry.byId("ReverseGeocode");
        	if( widgetRevGeocode._isGeocoderActive)
        	{
        		this._nc4Notify.warn("Disabling 'Show Address' Tool.")
        		widgetRevGeocode._showHideWidget();
        	}
        },
        
        _identifyOn: function() {
            this.identifyEvent = this.map.on("click", lang.hitch(this, function(event){
            	this._identifyFeatures(event);
            }));
          },
          
        _identifyOff: function() {
        	if(this.identifyEvent)
        		this.identifyEvent.remove();
        	this.map.infoWindow.clearFeatures();
        },
        
         _identifyFeatures: function(event)
         {
           if(this != null && this.map != null && this.map.infoWindow != null && this.map.infoWindow.features == null){
          	 this.map.infoWindow.clearFeatures();
          	 var geom = event.mapPoint;
                var layers = array.map(this.map.layerIds, lang.hitch(this, function (layerId) {
                    var currLayer = this.map.getLayer(layerId);
                    if (currLayer.tileInfo == null){
                      this.currLayer = currLayer;
                  	  return currLayer;
                    }
                }));
                
                /*
                var bmlayers = array.map(this.map.basemapLayerIds, lang.hitch(this, function (layerId) {
                  return this.map.getLayer(layerId);
                }));
                 */
                
                var tasks = array.map(layers, lang.hitch(this, function (layer) {
                    if(layer != null)
                  	  return new IdentifyTask(layer.url);
                }));

                var LyrNames = array.map(layers, lang.hitch(this, function (layer) {
                    if(layer != null)
                  	  return layer.name;
                }));

                var LyrIds = array.map(layers, lang.hitch(this, function (layer) {
                    if(layer != null)
                  	  return layer.id;
                }));

                var params = this._createIdentifyParams(layers, geom);

                var promises = [];

                for (var i = 0; i < tasks.length; i++) {
              	if(tasks[i] == null)
              		continue;
                  if(params[i].layerIds && params[i].layerIds.length > 0){
                  	tasks[i]._url.path = "proxy.jsp?" + tasks[i]._url.path + "?1=1";		//JT: This is hackish, but only way to allow https eteam to identify http service
                  	promises.push(tasks[i].execute(params[i]));
                  }
                }
                var iPromises = new all(promises);

                iPromises.then(lang.hitch(this, function (r) {
              	  //after all is completed, show pop-ups
              	  var results = [];
                    	r = array.filter(r, function (result) {
                      return r[0];
                    });
                    
                    for (var i = 0; i < r.length; i++) {
                      results = results.concat(r[i]);
                    }
                    
                    if(results.length > 0)
                    {
                  	//now go through each in the results array:
                        this.finalFeatures = [];
                        
                  	   results = array.filter(results, lang.hitch(this, function (identifyResult, index) {
     	               	 //for each identify ressult, add layername to feature's attribute, then add feature to overall array
     	               	   var currFeature = identifyResult.feature;
     	               	
     	               	   currFeature.layerName = identifyResult.layerName;
     	               	   currFeature.layerId = identifyResult.layerId;
     	               	   
	     	               	var pt = "<div  class='infowindow-content '>";
		     	   			pt += "<div class='content-wrap'>";
		     	   				pt += "<div class='title'>" + currFeature.layerName + "</div>";
		     	   					pt += "</div>";
		     	   				pt += "</div>";
		     	   				pt += "<div class='infowindow-additional'>";
		     	   					pt += "<div class='additional-detail'>";
		     	   					if(currFeature.attributes != null)
		     	   					{
		     	   						for(var key in currFeature.attributes)
		     	   						{
		     	   							pt+="<b>" + key + ":</b> " + currFeature.attributes[key] + "<br/>";
		     	   						}
		     	   					}
		     	   					pt += "</div>";
		     	   				pt+="</div>";

                        if(this.currLayer.popupCleanseAction){//for external layers that only create popups through the identify tool(arcgis_dynamic_service), this is where you can remove popup text or html
                            pt = pt.replace(this.currLayer.popupCleanseAction, '');
                        }
     	   				
     	               	   currFeature.setInfoTemplate( new InfoTemplate("&nbsp;", pt) );
     	               	   this.finalFeatures.push(currFeature);
     	               	   
  	   	               	
                       }));
                  	 if(this.map.infoWindow.features != null)
                  		 this.finalFeatures = this.finalFeatures.concat(this.map.infoWindow.features)
                  	 this.map.infoWindow.setFeatures(this.finalFeatures);
  						this.map.infoWindow.highlight = true; //still not highlighting
  					 this.map.infoWindow.select(0);
  					 this.map.infoWindow.show(event.mapPoint, {closestFirst: true});
                    }
                    else
                    {
                  	  this._nc4Notify.warn("No Features Identified from ArcGIS Dynamic Services.");
                      if (this.map.infoWindow.hideOnOffClick) {
                          for (var i = 0, len = this.map.infoWindow.openPopups.length; i < len; i++) {
                              this.map.infoWindow.openPopups[i].hide();
                              i--;
                              len--;
                          }
                          return;
                      }
                    }
               
                }), lang.hitch(this, function (err){
                  console.info(err);
                }));
              }
            },
            
           
           
           _createIdentifyParams: function (layers, geom) {
              var identifyParamsList = [];
              array.forEach(layers, lang.hitch(this, function (layer) {
            	  if(layer != null)
            	{
            		  var identifyParams = new IdentifyParameters();
                      identifyParams.width = this.map.width;
                      identifyParams.height = this.map.height;
                      identifyParams.geometry = geom;
                      identifyParams.tolerance = 10;
                      identifyParams.mapExtent = this.map.extent;
                      identifyParams.returnGeometry = true;

                    var visLayers = layer.visibleLayers;
                    if (visLayers && visLayers !== -1) {
                      var subLayers = visLayers;
                      if(subLayers.indexOf(-1) !== -1){
                        subLayers.splice(subLayers.indexOf(-1), 1);
                      }
                      identifyParams.layerIds = this._removeGroupLayers(subLayers, layer);
                    } else {
                      identifyParams.layerIds = [];
                    }
                    identifyParamsList.push(identifyParams);
            	}
            	  else
            		{
            		  //need to push null so that number 
            		  identifyParamsList.push(null);
            		}  
            	 
              }));
              return identifyParamsList;
            },
            
           _removeGroupLayers: function(subLayers, layer) {
                var newSubLayers = [];
                for (var i = 0; i < subLayers.length; i++) {
                  if (layer.layerInfos[subLayers[i]] && layer.layerInfos[subLayers[i]].subLayerIds === null){
                    newSubLayers.push(subLayers[i]);
                  }
                }
                return newSubLayers;
            }

    });
});