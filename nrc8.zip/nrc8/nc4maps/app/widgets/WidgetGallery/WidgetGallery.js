define([
    "dojo/_base/declare",
    "dojo/dom",
    "dojo/_base/html",
    "dijit/registry",
    "dojo/on",
    "dojo/topic",
    "dojo/dom-class",
    "dojo/query",
    "dojo/_base/lang",
    "app/widgets/WidgetGallery/ViewStack",
    "dojo/text!./WidgetGalleryTemplate.html",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin"
], function(
    declare,
    dom,
    html,
    registry,
    on,
    topic,
    domClass,
    query,
    lang,
    ViewStack,
    template,
    _WidgetBase,
    _TemplatedMixin,
    _WidgetsInTemplateMixin
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        baseClass: "widget-Gallery",
        templateString: template,
        _margin: 4,
        _nodeWidth: null,
        _nodes: [],
        _pages: [],
        _viewStack: null,
        _items: [],
        _count: 0,
        _closeNode: null,
        _moreIconPaneCoverNode: null,

        /**
         * Creates widget icon and attach widget related events like resize and click.
         */
        postCreate: function() {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetWidgetGalleryIcon"
            }, null);
            on(window, "resize", lang.hitch(this, function() {
                html.setStyle(this.domNode, this._getPositionStyle(this._getMorePanelSize()));
                this._resize();
            }));
            this.own(on(this.widgetIcon, "click", lang.hitch(this, function() {
                this.show();
            })));
        },

        /**
         * Hides the widget's UI.
         */
        hide: function() {
            html.setStyle(this._moreIconPaneCoverNode, "display", "none");
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
        },

        /**
         * Shows the widget's UI.
         */
        show: function() {
            if (!this._moreIconPaneCoverNode) {
                this._createCoverNode();
            }
            html.setStyle(this._moreIconPaneCoverNode, "display", "block");
            domClass.add(this.widgetIcon, "widgetIconFullOpacity");
            this._closeOtherWidgets();
            html.empty(this.pagesNode);
            html.empty(this.pointsNode);
            if (this._closeNode) {
                html.destroy(this._closeNode);
            }
            if (this._viewStack) {
                this._viewStack.destroyRecursive(true);
            }
            this._nodes = [];
            this._pages = [];
            this._items = [];
            this._closeNode = this._createCloseBtn();
            html.place(this.domNode, this._moreIconPaneCoverNode);
            html.setStyle(this.domNode, this._getPositionStyle(this._getMorePanelSize()));
            this.startup();
        },

        /**
         * Starts the widget by creating widget's UI.
         */
        startup: function() {
            this._viewStack = new ViewStack({
                views: [],
                viewType: "dom"
            }, this.pagesNode);
            this._viewStack.startup();
            this._createPages();
            if (this._viewStack.views.length > 0) {
                this._selectPage(0);
            }
            this._resize();
        },

        /**
         * Selects the page containing widgets in widget gallery.
         * @param {integer} pageIndex - Index of the page to be selected.
         */
        _selectPage: function(pageIndex) {
            if (this._pages.length > 1) {
                query(".point", this.domNode).removeClass("point-selected");
                html.addClass(this._pages[pageIndex].pointNode, "point-selected");
            }
            this._viewStack.switchView(this._pages[pageIndex].pageNode);
        },

        /**
         * Closes all other widget after selecting a widget in widget gallery.
         */
        _closeOtherWidgets: function() {
            var arrWidgetIDs = this._getWidgetsId(),
                widgetIndex,
                widget;
            for (widgetIndex = 0; widgetIndex < arrWidgetIDs.length; widgetIndex++) {
                widget = registry.byId(arrWidgetIDs[widgetIndex]);
                if (widget) {
                    if (widget.isOpen && widget.config.label !== this.config.label) {
                        widget.hide();
                    }
                }
            }
        },

        /**
         * Creates different pages as per total widget count.
         * * Each page can contain maximum 9 widgets.
         */
        _createPages: function() {
            var count = 0,
                pageIndex,
                pageNode,
                pages,
                pointNode,
                widgetIndex;
            //Get count and list of all the app header widgets which are not visible in app header.
            for (widgetIndex = 0; widgetIndex < this.appConfig.AppHeaderWidgets.length; widgetIndex++) {
                if (!this.appConfig.AppHeaderWidgets[widgetIndex].isVisible) {
                    this._items.push(this.appConfig.AppHeaderWidgets[widgetIndex]);
                    count++;
                }
            }
            this._count = count;
            pages = Math.ceil(count / 9); //get page count
            for (pageIndex = 0; pageIndex < pages; pageIndex++) {
                pageNode = this._createPageNode(pageIndex);
                this._createPageItems(pageIndex, pageNode);
                this._viewStack.addView(pageNode);
                if (pages > 1) {
                    pointNode = this._createPointNode(pageIndex);
                    on(pointNode, "click", lang.hitch(this, this._onPageNodeClick, pageIndex));
                }
                this._pages.push({
                    pageNode: pageNode,
                    pointNode: pointNode
                });
            }
        },

        /**
         * Creates node for page.
         * @returns {object} node - Dom element to view page.
         */
        _createPageNode: function() {
            var node = html.create("div", {
                "class": "page"
            });
            return node;
        },

        /**
         * Call _createItemNode() and _createEmptyItemNode() for the page, based on number of widget in that page.
         * * If Number of widgets is less than 9, then rest of the nodes will be empty node.
         * @param {integer} page - Index of the page in which nodes to be inserted.
         * @param {object} pageNode - page node for widgets.
         */
        _createPageItems: function(page, pageNode) {
            var empty,
                nextPageNodeCount = (page + 1) * 9,
                thumbnailCount = page * 9,
                thumbnailIndex;
            empty = nextPageNodeCount - this._count;
            for (thumbnailIndex = thumbnailCount; thumbnailIndex < Math.min(nextPageNodeCount, this._count); thumbnailIndex++) {
                this._createItemNode(thumbnailIndex, pageNode);
            }
            for (thumbnailIndex = this._count; thumbnailIndex < this._count + empty; thumbnailIndex++) {
                this._createEmptyItemNode(thumbnailIndex, pageNode);
            }
        },

        /**
         * Set position of the widget node.
         * @param {object} node - Dom element on which we have to set style for its position.
         * @param {integer} nodeIndex - Index of the node.
         */
        _setItemNodePosition: function(node, nodeIndex) {
            var marginLeft, marginTop, nodeStyle = {};
            nodeIndex++;
            if (nodeIndex % 3 === 1) {
                marginLeft = 0;
            } else {
                marginLeft = 2;
            }
            if (nodeIndex <= 3) {
                marginTop = 0;
            } else {
                marginTop = 2;
            }
            if (typeof this._nodeWidth === "number") {
                nodeStyle.width = this._nodeWidth + "px";
                nodeStyle.height = this._nodeWidth + "px";
            }
            if (typeof marginLeft === "number") {
                nodeStyle.marginLeft = marginLeft + "px";
            }
            if (typeof marginTop === "number") {
                nodeStyle.marginTop = marginTop + "px";
            }
            html.setStyle(node, nodeStyle);
        },

        /**
         * Select view page.
         * @param {integer} index - Index of the page to be selected.
         */
        _onPageNodeClick: function(index) {
            this._selectPage(index);
        },

        /**
         * Create and returns point node to select view page.
         * @returns {object} node - Dom element to select view page.
         */
        _createPointNode: function() {
            var node = html.create("div", {
                "class": "point"
            }, this.pointsNode);
            return node;
        },

        /**
         * Create and attach widget icon click event.
         * @param {integer} index - Index at which we have to place widget icon node.
         * @param {object} pageNode - A dom element of the page in which we have to append the widget icon node.
         */
        _createItemNode: function(index, pageNode) {
            var item,
                node,
                pathIcon;
            item = this._items[index];
            node = html.create("div", {
                "class": "icon-node",
                title: item.label,
                settingId: item.label
            }, pageNode);
            pathIcon = item.WidgetPath.slice(0, item.WidgetPath.lastIndexOf("/"));
            html.create("img", {
                "src": pathIcon + "/images/icon.png"
            }, node);
            html.create("div", {
                "class": "node-label",
                "title": item.label,
                "innerHTML": item.label
            }, node);
            node.config = item;
            this._setItemNodePosition(node, index);
            on(node, "click", lang.hitch(this, function() {
                this._onNodeClicked(node);
            }));
            this._nodes.push(node);
        },

        /**
         * Create empty icon node.
         * @param {integer} index - Index at which we have to place empty node.
         * @param {object} pageNode - A dom element of the page in which we have to append the empty node.
         */
        _createEmptyItemNode: function(index, pageNode) {
            var node;
            node = html.create("div", {
                "class": "icon-node"
            }, pageNode);
            this._setItemNodePosition(node, index);
            this._nodes.push(node);
            return node;
        },

        /**
         * Resize the widget gallery panel according to the screen size.
         */
        _resize: function() {
            var box = html.getMarginBox(this.domNode);
            this._nodeWidth = (box.w - this._margin * 2) / 3;
            this._nodes.forEach(lang.hitch(this, function(node, index) {
                this._setItemNodePosition(node, index);
            }));
        },

        /**
         * Create close button node, to close widget gallery panel.
         * @returns {object} node - Dom element of close icon node.
         */
        _createCloseBtn: function() {
            var node;
            node = html.create("div", {
                "class": "close"
            }, this.domNode);
            html.create("div", {
                "class": "close-inner"
            }, node);
            on(node, "click", lang.hitch(this, function() {
                this.hide();
            }));
            return node;
        },

        /**
         * Create cover node to overlap application in order to prevent the use to select anything
         * other the widget gallery options.
         */
        _createCoverNode: function() {
            this._moreIconPaneCoverNode = html.create("div", {
                "class": "moreIconCover"
            }, "mainContainer");
        },

        /**
         * Create and returns widget gallery panel size and position style object.
         * @param {object} position - Position object containing detail of widget panel size and position.
         * @returns {object} style - Style object containing position and size detail of widget gallery panel.
         */
        _getPositionStyle: function(position) {
            var arrGroups = ["left", "top", "right", "bottom", "width", "height"],
                boolKeyMatch = false,
                index,
                positionAttribute,
                style = {};
            for (positionAttribute in position) {
                if (position.hasOwnProperty(positionAttribute)) {
                    boolKeyMatch = false;
                    for (index = 0; index < arrGroups.length; index++) {
                        if (arrGroups[index].search(positionAttribute) !== -1) {
                            boolKeyMatch = true;
                            break;
                        }
                    }
                    if (boolKeyMatch) {
                        if (typeof position[positionAttribute] === "number") {
                            style[positionAttribute] = position[positionAttribute] + "px";
                        } else if (position[positionAttribute]) {
                            style[positionAttribute] = position[positionAttribute];
                        }
                    }
                }
            }
            return style;
        },

        /**
         * Returns widget gallery panel size and position according to screen size.
         * @returns {object} position - Detail value of position and size of widget gallery panel.
         */
        _getMorePanelSize: function() {
            var mapBox = html.getContentBox("mainContainer"),
                minLen,
                position;
            mapBox.h = mapBox.h - 40;
            minLen = Math.min(mapBox.w, mapBox.h);
            if (minLen < 600) {
                if (mapBox.w < mapBox.h) {
                    position = {
                        left: 20,
                        right: 20,
                        top: Math.max((mapBox.h - (mapBox.w - 40)) / 2, 70),
                        height: mapBox.w - 40,
                        width: mapBox.w - 40,
                        bottom: ""
                    };
                } else {
                    position = {
                        top: 70,
                        bottom: 20,
                        left: (mapBox.w - (mapBox.h - 40)) / 2,
                        width: mapBox.h - 40,
                        height: "",
                        right: ""
                    };
                }
            } else {
                position = {
                    top: Math.max((mapBox.h - 560) / 2, 70),
                    left: (mapBox.w - 560) / 2,
                    width: 560,
                    height: 560,
                    right: "",
                    bottom: ""
                };
            }
            return position;
        },

        /**
         * Perform actions after clicking the widget icon node in widget gallery panel
         * * Initializes the widget if not initialized else shows its panel.
         * * Replace the image node in application header panel with widget icon node.
         * * Close other widgets if open.
         * @param {object} node - Details of the widget to be initialized.
         */
        _onNodeClicked: function(node) {
            var divWidgetContainer = query(".appHeaderWidgetConainer")[0],
                widgetIndex,
                widgetIndexHide,
                nodeToRemove,
                nodeToRemoveIndex,
                widget = registry.byId(node.config.WidgetPath);
            nodeToRemoveIndex = divWidgetContainer.childNodes.length - 1;
            nodeToRemove = divWidgetContainer.childNodes[nodeToRemoveIndex].title;
            if (widget) {
                domClass.add(widget.widgetIcon, "appHeaderWidgetIcon");
                divWidgetContainer.replaceChild(widget.widgetIcon, divWidgetContainer.childNodes[nodeToRemoveIndex]);
                this._toggleWidget(widget);
            } else {
                this._initializeWidget(node, divWidgetContainer, nodeToRemoveIndex);
            }
            for (widgetIndex = 0; widgetIndex < this.appConfig.AppHeaderWidgets.length; widgetIndex++) {
                if (this.appConfig.AppHeaderWidgets[widgetIndex].label === node.title) {
                    this.appConfig.AppHeaderWidgets[widgetIndex].isVisible = true;
                    break;
                }
            }
            for (widgetIndexHide = 0; widgetIndexHide < this.appConfig.AppHeaderWidgets.length; widgetIndexHide++) {
                if (this.appConfig.AppHeaderWidgets[widgetIndexHide].label === nodeToRemove) {
                    this.appConfig.AppHeaderWidgets[widgetIndexHide].isVisible = false;
                    break;
                }
            }
            this.hide();
        },

        /**
         * Initializes the widget.
         * @param {object} node - Details of the widget to be initialized.
         * @param {object} divWidgetContainer - Widget container dom present in app header.
         * @param {integer} nodeToRemoveIndex - index of the node to be removed from app header widget container.
         */
        _initializeWidget: function(node, divWidgetContainer, nodeToRemoveIndex) {
            require([node.config.WidgetPath], lang.hitch(this, function(Widget) {
                var widgetInitialized = new Widget({
                    map: this.map,
                    id: node.config.WidgetPath,
                    config: node.config,
                    appUtils: this.appUtils
                });
                domClass.add(widgetInitialized.widgetIcon, "appHeaderWidgetIcon");
                divWidgetContainer.replaceChild(widgetInitialized.widgetIcon, divWidgetContainer.childNodes[nodeToRemoveIndex]);
                this._toggleWidget(widgetInitialized);
                on(widgetInitialized.widgetIcon, "click", lang.hitch(this, function() {
                    this._toggleWidget(widgetInitialized);
                }));
            }));
        },

        /**
         * Returns array of widgets ID.
         * @returns {array} arrWidgetIDs - List of widgets ID.
         */
        _getWidgetsId: function() {
            var arrWidgetIDs = [],
                index,
                widgetID;
            for (index = 0; index < this.appConfig.AppHeaderWidgets.length; index++) {
                widgetID = this.appConfig.AppHeaderWidgets[index].WidgetPath;
                arrWidgetIDs.push(widgetID);
            }
            return arrWidgetIDs;
        },

        /**
         * Toggles the widget panel, shows the panel of widget whose icon is clicked.
         * @param {object} widgetInitialized - Widget which is clicked.
         */
        _toggleWidget: function(widgetInitialized) {
            var arrWidgetIDs = this._getWidgetsId(),
                index,
                widget;
            for (index = 0; index < arrWidgetIDs.length; index++) {
                widget = registry.byId(arrWidgetIDs[index]);
                if (widget) {
                    if (widget.isOpen && widget.config.label !== widgetInitialized.config.label) {
                        widget.hide();
                    }
                }
            }
            widgetInitialized.show();
        }
    });
});
