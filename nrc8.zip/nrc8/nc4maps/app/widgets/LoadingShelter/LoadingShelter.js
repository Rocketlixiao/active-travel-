define([
    "dojo/_base/declare",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dojo/text!./LoadingShelterTemplate.html",
    "dojo/_base/html",
    "dojo/i18n"
], function(declare, _WidgetBase, _TemplatedMixin, template, html, i18n) {
    return declare([_WidgetBase, _TemplatedMixin], {
        baseClass: "Widget-LoadingShelter",
        templateString: template,
        loadingText: null,
        hidden: false,

        /**
         * Member of widget life cycle, invoked before rendering occurs, and before any dom nodes are created.
         * Creating fall back label for 'Loading Shelter'. This label is set in template.
         */
        postMixInProperties: function() {
            this.nls = {
                loading: "Loading"
            };
        },

        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting display of dom, loading image and text.
         */
        postCreate: function() {
            this.inherited(arguments);
            if (this.hidden) {
                html.setStyle(this.domNode, "display", "none");
            }
            this.loadingImg.src = "nc4maps/app/widgets/LoadingShelter/images/loading.gif";
            if (typeof this.loadingText === "string") {
                this.textNode.innerHTML = this.loadingText;
            }
        },

        /**
         * Display the 'Loading Shelter'.
         */
        show: function(loadingText) {
            if (!this.domNode) {
                return;
            }
            if (this.hidden) {
                if (typeof loadingText === "string") {
                    this.textNode.innerHTML = loadingText;
                }
                html.setStyle(this.domNode, "display", "block");
                this.hidden = false;
            }
        },

        /**
         * Hide the 'Loading Shelter'.
         */
        hide: function() {
            if (!this.domNode) {
                return;
            }
            if (!this.hidden) {
                html.setStyle(this.domNode, "display", "none");
                this.hidden = true;
            }
        }
    });
});
