define([
        "dojo/_base/declare",
        "dojo/topic",
        "dojo/on",
        "dojo/_base/lang",
        "dojo/dom-construct",
        "dojo/dom-style",
    	"dijit/registry",
        "app/widgets/Notifications/NC4Notification",
        "dijit/Dialog",
        "dojo/query"
], function(declare, topic, on, lang, domConstruct, domStyle, registry, NC4Notification, Dialog, query){
	
	return declare([],{			//constructor? or postcreate? _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin
		
		dOpt: null,
		map: null,
		haloEnabledLyrs: null,
		nc4Notify: null,
		
		constructor: function(p_DAP, p_map, p_listLyrHalo, p_showTravelerInfoLyr, p_acknowledgeProximityLyr, p_lyrsOnMap)
		{
	        this.dOpt = domConstruct.create("div", {}, null);
	        this.map = p_map;
            this.showTravelerInfoLyr = p_showTravelerInfoLyr;
            this.acknowledgeProximityLyr = p_acknowledgeProximityLyr;
            this.lyrsOnMap = p_lyrsOnMap;
            p_DAP.containerNode.appendChild(this.dOpt);
            
            this.map.halo = "refresh";
            this.haloEnabledLyrs = p_listLyrHalo || [];
            this.nc4Notify = new NC4Notification();
            this.activate();
		},
	
		activate: function()
		{
				
				//for now, just empty and repopulate
				if(this.haloEnabledLyrs.length > 0)
				{
					this.divRefOn = domConstruct.create("div", {id: "rOn", class: "dataOptions", innerHTML:"<img src='/maps/images/Buttons/halo_refresh_on.png' title='Existing halos are removed each time the map refreshes (Currently Activated)' />"}, null);
					this.divRefOff = domConstruct.create("div", {id: "rOff", class: "dataOptions", innerHTML:"<img src='/maps/images/Buttons/halo_refresh_off.png' title='Existing halos are removed each time the map refreshes (Currently Activated)' />"}, null);
					domStyle.set(this.divRefOff, "display", "none");
					this.divClkOn = domConstruct.create("div", {id: "cOn", class: "dataOptions", innerHTML:"<img src='/maps/images/Buttons/halo_mouse_on.png' title='Existing halos are removed only by clicking on them (Currently Activated)' />"}, null);
					domStyle.set(this.divClkOn, "display", "none");
					this.divClkOff = domConstruct.create("div", {id: "cOff", class: "dataOptions", innerHTML:"<img src='/maps/images/Buttons/halo_mouse_off.png' title='Existing halos are removed only by clicking on them (Click to Activate)' />"}, null);
					this.divClear = domConstruct.create("div", {class: "dataOptions", innerHTML:"<img src='/maps/images/Buttons/halo23_clear3.png' title='Click to remove all halos' />'"}, null);

					domConstruct.place(this.divRefOn, this.dOpt);
					domConstruct.place(this.divRefOff, this.dOpt);
					domConstruct.place(this.divClkOn, this.dOpt);
					domConstruct.place(this.divClkOff, this.dOpt);
					domConstruct.place(this.divClear, this.dOpt);
					
					on(this.divRefOff, "click", lang.hitch(this, function(e){
						domStyle.set(this.divRefOn, "display", "block");
						domStyle.set(this.divRefOff, "display", "none");
						domStyle.set(this.divClkOn, "display", "none");
						domStyle.set(this.divClkOff, "display", "block");
						this.map.halo = "refresh";
					}));
					
					on(this.divClkOff, "click", lang.hitch(this, function(e){
						domStyle.set(this.divRefOff, "display", "block");
						domStyle.set(this.divRefOn, "display", "none");
						domStyle.set(this.divClkOff, "display", "none");
						domStyle.set(this.divClkOn, "display", "block");
						this.map.halo = "click";
					}));
					
					
					on(this.divClear, "click", lang.hitch(this, function(e){
						var notify = this.nc4Notify.info("Acknowledging...");
						var graphicIds = this.map.graphicsLayerIds;
						for(var k = 0; k < graphicIds.length; k++)
						{
							var currId = graphicIds[k];
							
							for(var i = 0; i < this.haloEnabledLyrs.length; i++)
			            	{
			            		if(currId.indexOf(this.haloEnabledLyrs[i]) >= 0)
			            		{
			            			//good to continue
			            			var currLyr = this.map.getLayer(currId);
									if(currLyr == null)
										continue;
									var currFeatures = currLyr.graphics;
									if( currFeatures == null || currFeatures.length == 0)
									{	continue; }
									for(var j=0; j<=currFeatures.length; j++)
									{
										var currG = currFeatures[j];
										if(currG == null)
											continue;
										try{
				    			        	
						        			var currObjtype = currG.attributes.objtype;
						        			if(currObjtype != null && currObjtype.indexOf("highlight") >= 0)
						        			{
						        				
						        				currG.attributes.objtype = currG.attributes.objtypeO;
						        				
						        				var sym = currG._layer._defaultRenderer.getSymbol(currG);			//how to update symbol
						        				currG.setSymbol(sym);
						                    	//var desc = this.createPopup(candidate); //worry about updating cluster popups later
						                    	
						                    	//need to re-cluster
						                    	//topic.publish("nc4ClusterIcons");
						        			}
						        		}catch(error){console.error(error);}
									}
			            		}
			            	}
							
						}
						this.nc4Notify.hide(notify);
					}));
					
				}
				

				// console.log(this);
			  if(this.acknowledgeProximityLyr){
				  var proceed = false;
				  for(var i = 0; i < this.lyrsOnMap.length; i++)
				  {
					  var currLyr = this.lyrsOnMap[i];
					  if(currLyr && currLyr.id && currLyr.id == this.acknowledgeProximityLyr)
					  {
						  proceed = true;
						  break;
					  }
				  }
				  if(proceed == true)
				 {
					  this.divAcknowledgeProx = domConstruct.create("div", {class: "dataOptions", innerHTML:"<img src='/maps/images/Buttons/warning_clear_all2.png' title='Click to acknowledge all proximity warnings' />'"}, null);
						domConstruct.place(this.divAcknowledgeProx, this.dOpt);
						var mapInstance = this.map;
						on(this.divAcknowledgeProx, "click", function(e){
			                require(["app/nc4modules/RC/ProximityMgr"], function(ProximityMgr){
			                	var ProximityMgr = new ProximityMgr();
			                	ProximityMgr.clearAll();
			                });
						});
				 }
					
				}
				// }

				if(this.showTravelerInfoLyr){
					var proceed = false;
					  for(var i = 0; i < this.lyrsOnMap.length; i++)
					  {
						  var currLyr = this.lyrsOnMap[i];
						  if(currLyr && currLyr.id && currLyr.id == this.showTravelerInfoLyr)
						  {
							  proceed = true;
							  break;
						  }
					  }
					if(proceed == true)
					{

						this.divTsSearch = domConstruct.create("div", {class: "dataOptions", innerHTML:"<img id='tsSearchImage' src='/maps/images/icons/Transecur/transecur_search.png' title='Search ActivTravel locations' />'"}, null);
						domConstruct.place(this.divTsSearch, this.dOpt);
						on(this.divTsSearch, "click", lang.hitch(this, function(e){
							var widget = registry.byId("app/widgets/DataLayers/DataLayers");
			                if (widget) {
			                    if (widget.isOpen) {
			                        widget.hide();
			                    }
			                }
						    tsSearchDialog = new Dialog({
						        title: "Search ActivTravel Locations",
						        content: "<iframe width='600' height='400' src='/nc4maps/app/nc4modules/RC/transecur/tssearch.jsp'></iframe>",
						        style: "width: 600px; height: 400px;"
						    });
						    tsSearchDialog.show();
						}));
					}
				}
				
				/* not working
				on(this.divRefOff,mouse.enter, lang.hitch(this, function() {
                    this.map.setMapCursor("pointer");
                }));
				on(this.divRefOff,mouse.leave, lang.hitch(this, function() {
                    this.map.setMapCursor("default");
                }));
				on(this.divClkOff,mouse.enter, lang.hitch(this, function() {
                    this.map.setMapCursor("pointer");
                }));
				on(this.divClkOff,mouse.leave, lang.hitch(this, function() {
                    this.map.setMapCursor("default");
                }));
				*/
				
				//test tool, use one of methods below
				// on(this.divClkOn, "click", lang.hitch(this, function (e){
				// 	this.ringAll();
				// }));
				
		},
		
		//test tool: TODO comment out
		highlightAll: function()
		{
			var graphicIds = this.map.graphicsLayerIds;
			for(var k = 0; k < graphicIds.length; k++)
			{
				var currId = graphicIds[k];
				
				for(var i = 0; i < this.haloEnabledLyrs.length; i++)
            	{
            		if(currId.indexOf(this.haloEnabledLyrs[i]) >= 0)
            		{
            			//good to continue
            			var currLyr = this.map.getLayer(currId);
						if(currLyr == null)
							continue;
						var currFeatures = currLyr.graphics;
						if( currFeatures == null || currFeatures.length == 0)
						{	continue; }
						for(var j=0; j<=currFeatures.length; j++)
						{
							var currG = currFeatures[j];
							if(currG == null)
								continue;
							try{
	    			        	
			        			var currObjtype = currG.attributes.objtype;
			        			if(currObjtype != null && currObjtype.indexOf("highlight") >= 0)
			        			{
			        				continue;
			        			}
			        			else{
			        				currG.attributes.objtype = "highlight";
			        				
			        				var sym = currG._layer._defaultRenderer.getSymbol(currG);			//how to update symbol
			        				currG.setSymbol(sym);
			                    	
			                    	//need to re-cluster
			                    	//topic.publish("nc4ClusterIcons");
			        			}
			        		}catch(error){console.error(error);}
						}
            		}
            	}
				
			}
		},
		
		//test tool TODO: comment out
		ringAll: function()
		{
			var prefix = "_fac";

			var graphicLyrIds = this.map.graphicsLayerIds;
			for(var i = 0; i < graphicLyrIds.length; i++)
			{
				var currLyr = this.map.getLayer(graphicLyrIds[i]);
				
				if(currLyr.id.indexOf("_fac_") >=0)
				{
					var currGs = currLyr.graphics;
					for(var j = 0; j<currGs.length; j++)
					{
						var currGraphic = currGs[j];
						var objtype = currGraphic.attributes.objtype;
						if(objtype.indexOf("impacted") < 0)
						{
							if(objtype == "null")
								objtype = "impacted";
							else
								objtype = "impacted_" + objtype;
							currGraphic.attributes.objtype = objtype;
							var sym = currGraphic._layer._defaultRenderer.getSymbol(currGraphic);			//how to update symbol
							currGraphic.setSymbol(sym);
						}
					}
				}
			}
		}
	});
	
});