define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/on",
    "dojo/_base/lang",
    "dojo/fx/easing",
    "dojo/dom",
    "dojo/dom-attr",
    "dojo/text!./BottomPanelTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/aspect",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/TextBox",
    "dojo/domReady!"
], function(
    declare,
    html,
    on,
    lang,
    easing,
    dom,
    domAttr,
    template,
    sharedNls,
    aspect,
    _WidgetBase,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    TextBox
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        name: "BottomPanel",
        baseClass: "widget-BottomPanel",
        templateString: template,
        postCreate: function() {
            this.panelToggleIcon = html.create("div", {
                "class": "panelToggleIcon"
            }, null);
            html.place(this.panelToggleIcon, "mapContainerNode");
            html.place(this.domNode, "mapContainerNode");
            domAttr.set(this.resultPanelTitle, "innerHTML", this.resultTitle);
            on(this.panelToggleIcon, "click", lang.hitch(this, function() {
                this._animateBottomPanel();
            }));
            aspect.after(this.appUtils, "sidePanelOpen", lang.hitch(this, function() {
                this._resize(this.appUtils.isSidePanelOpen);
            }));
        },

        /**
         * Function to the animate on bottom panel
         */
        _animateBottomPanel: function() {
            var node = dom.byId(this.domNode);
            if (html.coords(node).h > 200) {
                this._closeBottomPanel();
            } else {
                this._openBottomPanel();
            }
        },

        /**
         * Function to close the bottom panel
         */
        _closeBottomPanel: function() {
            html.removeClass(this.panelToggleIcon, "panelToggleIcon");
            html.addClass(this.panelToggleIcon, "downImage");
            this.animateControlHeight(dom.byId(this.domNode), 600, 422, 0, "easing");
            this.animateControlPosition(dom.byId(this.panelToggleIcon), 600, 446, 24, "easing");
        },

        /**
         * Function to open the bottom panel
         */
        _openBottomPanel: function() {
            html.removeClass(this.panelToggleIcon, "downImage");
            html.addClass(this.panelToggleIcon, "panelToggleIcon");
            this.animateControlHeight(dom.byId(this.domNode), 600, 0, 422, "easing");
            this.animateControlPosition(dom.byId(this.panelToggleIcon), 600, 24, 446, "easing");
        },

        /**
         * Function to animate the control position property
         */
        animateControlHeight: function(node, timeSpan, startHeight, endHeight, animationType) {
            html.animateProperty({
                node: node,
                duration: timeSpan,
                easing: html.fx.easing[animationType],
                properties: {
                    height: {
                        end: endHeight,
                        start: startHeight
                    }
                }
            }).play();
        },

        /**
         * Function to animate the control position property
         */
        animateControlPosition: function(node, timeSpan, startHeight, endHeight, animationType) {
            html.animateProperty({
                node: node,
                duration: timeSpan,
                easing: html.fx.easing[animationType],
                properties: {
                    bottom: {
                        end: endHeight,
                        start: startHeight
                    }
                }
            }).play();
        },

        /**
         * Function to adjust the "bottom panel" UI when "side panel" open's.
         */
        _resize: function(isopen) {
            var mapBox = html.getMarginBox("mainContainer");
            if (isopen === false) {
                html.setStyle(this.domNode, "width", mapBox.w + "px");
                html.setStyle(this.panelToggleIcon, "left", (mapBox.w / 2 - 35) + "px");
            } else {
                html.setStyle(this.domNode, "width", (mapBox.w - 360) + "px");
                html.setStyle(this.panelToggleIcon, "left", (mapBox.w - 360) / 2 - 35 + "px");
            }
        }
    });
});
