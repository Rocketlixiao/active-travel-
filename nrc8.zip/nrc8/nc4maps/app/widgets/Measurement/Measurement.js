define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/dom-class",
    "dojo/_base/html",
    "dojo/text!./MeasurementTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/aspect",
    "dijit/_WidgetBase",
    "dijit/registry",
    "dijit/_TemplatedMixin",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter"
], function(
    declare,
    lang,
    on,
    domClass,
    html,
    template,
    sharedNls,
    aspect,
    _WidgetBase,
    registry,
    _TemplatedMixin,
    WidgetPanel,
    LoadingShelter
) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "Measurement",
        baseClass: "Widget-Measurement",
        templateString: template,
        sharedNls: sharedNls,
        _measurement: null,
        isOpen: false,
        _shelter: null,
        _panel: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 35 + "%"
        },

        postCreate: function() {
            this.inherited(arguments);
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetMeasurementIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
            this._attachWidgetRelatedEvents();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
                html.empty(this._measurementDiv);
                this._getMeasurment();
            }));
            this._getMeasurment();
            on(this._clearButtonDiv, "click", lang.hitch(this, function() {
                this._clearMeasurementGraphics();
            }));
        },

        /**
         * Display the panel.
         */
        show: function() {
            if (!this.isOpen) {
                domClass.add(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
            } else {
                this.hide();
            }
        },

        /**
         * Hide the panel
         */
        hide: function() {
            var activeTool;
            this.isOpen = false;
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                if (this._measurement) {
                    activeTool = this._measurement.getTool();
                    if (activeTool) {
                        this._measurement.setTool(activeTool.toolName, false);
                    }
                }
                this._panel.hide();
            }
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Attach widget related events. Resize the widget panel on window resize.
         */
        _attachWidgetRelatedEvents: function() {
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
            }));
        },

        /**
         * Initialize 'Measurement' widget, set default area and length unit.
         */
        _getMeasurment: function() {
            require(["esri/dijit/Measurement",
                "esri/units"
            ], lang.hitch(this, function(Measurement, esriUnits) {
                var json = {};
                json.map = this.map;
                /**
                 * In ArcGIS JavaScript API 3.12 for 'Measurement' widget following units are not supported:-
                 * For area - ARES, SQUARE_INCHES, SQUARE_MILLIMETERS, SQUARE_CENTIMETERS, SQUARE_DECIMETERS.
                 * For length - CENTIMETERS, DECIMAL_DEGREES, DECIMETERS, INCHES, NAUTICAL_MILES, POINTS, UNKNOWN.
                 */
                if(this.appUtils.configGeneralSettings.defaultMeasUnit.toLowerCase() == "metrics")
                {
                	json.defaultAreaUnit = esriUnits.SQUARE_KILOMETERS; //Setting default area unit to 'Sq Miles'.
                    json.defaultLengthUnit = esriUnits.KILOMETERS; //Setting default length unit to 'Miles'.
                }
                else
                {
                	json.defaultAreaUnit = esriUnits.SQUARE_MILES; //Setting default area unit to 'Sq Miles'.
                    json.defaultLengthUnit = esriUnits.MILES; //Setting default length unit to 'Miles'.
                }
                
                var test = html.create("div", {}, this._measurementDiv);
                this._measurement = new Measurement(json, test);
                this._measurement.startup();
                this._shelter.hide();
            }));
        },

        /**
         * Clear the Measurement graphics on map and deactivate the Measurement tool.
         */
        _clearMeasurementGraphics: function() {
            var activeTool = this._measurement.getTool();
            this._measurement.clearResult();
            if (activeTool) {
                this._measurement.setTool(activeTool.toolName, false);
            }
        }
    });
});
