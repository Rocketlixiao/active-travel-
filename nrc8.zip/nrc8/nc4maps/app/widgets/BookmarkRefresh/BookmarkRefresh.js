define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/on",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom",
    "dojo/dom-attr",
    "dojo/dom-class",
    "dojo/text!./BookmarkRefresh.html",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "esri/geometry/Extent",
    "esri/SpatialReference",
    "esri/geometry/webMercatorUtils"
], function(
    declare,
    html,
    on,
    lang,
    aspect,
    dom,
    domAttr,
    domClass,
    template,
    _WidgetBase,
    _TemplatedMixin,
    Extent,
    SpatialReference,
    webMercatorUtils
) {
    var clazz = declare([_WidgetBase, _TemplatedMixin], {
        name: "BookmarkRefresh",
        baseClass: "widget-BookmarkRefresh",
        templateString: template,

        /**
        * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
        * Setting widget icon, loading shelter, call to attach widget related events and initializing Bookmark Refresh widget.
        */
        postCreate: function() {
            domAttr.set(this.bookmarkRefreshNode, "title", "Bookmark Refresh");
            html.place(this.domNode, "mapContainerNode");
            on(this.bookmarkRefreshNode, "click", lang.hitch(this, this._getAddress));
            /*Below code for add custom base map and then pass map instance to all widgets*/
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
                on(this.bookmarkRefreshNode, "click", lang.hitch(this, this._getAddress));
            }));
        },

        /**
         * Displays the last selected bookmark.
         */
        _getAddress: function() {
            if (this.appUtils.arrLayerExtent) {
                var getBookmarkExtent,
                    startExtent = {},
                    extentObj = null;
                startExtent = new Extent();
                startExtent.xmax = parseFloat(this.appUtils.arrLayerExtent.xmax);
                startExtent.xmin = parseFloat(this.appUtils.arrLayerExtent.xmin);
                startExtent.ymin = parseFloat(this.appUtils.arrLayerExtent.ymin);
                startExtent.ymax = parseFloat(this.appUtils.arrLayerExtent.ymax);
                startExtent.spatialReference = new SpatialReference(parseInt(this.appUtils.arrLayerExtent.spatialReference, 10));
                extentObj = new Extent(webMercatorUtils.geographicToWebMercator(startExtent));
                getBookmarkExtent = this.map.setExtent(extentObj);
            }
        }
    });
    return clazz;
});
