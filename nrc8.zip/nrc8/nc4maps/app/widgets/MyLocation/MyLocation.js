define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "esri/dijit/LocateButton",
    "dojo/on",
    "dojo/dom-class",
    "dojo/query",
    "dojo/aspect",
    "dojo/_base/lang",
    "dojo/text!./MyLocation.html",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/domReady!"
], function(declare,
    html,
    LocateButton,
    on,
    domClass,
    query,
    aspect,
    lang,
    template,
    _WidgetBase,
    _TemplatedMixin,
    sharedNls) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "MyLocation",
        baseClass: "widget-MyLocation",
        templateString: template,
        _isLocationActive: false,
        geoLocate: null,
        sharedNls: sharedNls,

        /**
        * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
        * Setting widget icon, loading shelter, call to attach widget related events and initializing MyLocation widget.
        */
        postCreate: function() {
            html.place(this.domNode, "mapContainerNode");
            this._nc4Notify = this.appUtils.nc4Notify;

            var json = {
                "locateButton": {
                    "geolocationOptions": {
                        "timeout": 15000
                    },
                    "highlightLocation": true
                }
            };
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            json.map = this.map;
            this.geoLocate = new LocateButton(json);
            this.geoLocate.startup();
            html.place(this.geoLocate.domNode, this.domNode);
            this.own(on(this.geoLocate, "locate", lang.hitch(this, this.locate)));
            /*This function will call after mail function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
                this.geoLocate.map = this.map;
                this.geoLocate.startup();
            }));

        },

        /**
        * Function to displays the current location.
         * @param {object} parameters : Graphic and position.
        */
        locate: function(parameters) {
            if (parameters.error) {
                console.error(parameters.error.message);
                this._nc4Notify.error(sharedNls.Mylocation.errorMessages);
            }
            if (!this._isLocationActive) {
                domClass.add(query(".LocateButton")[0], "widgetIconFullOpacity");
                this._isLocationActive = true;
            } else {
                domClass.remove(query(".LocateButton")[0], "widgetIconFullOpacity");
                this.geoLocate.clear();
                this._isLocationActive = false;
            }
        }

    });
});
