define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/text!./DirectionsTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/aspect",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter"
], function(declare, html, lang, on, template, sharedNls, aspect, _WidgetBase, _TemplatedMixin, WidgetPanel, LoadingShelter) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "Directions",
        baseClass: "Widget-Directions",
        templateString: template,
        sharedNls: sharedNls,
        _shelter: null,
        _directions: null,
        isOpen: false,
        _panel: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },

        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and initializing esri direction widget.
         */
        postCreate: function() {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetDirectionsIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
            this._attachWidgetRelatedEvents();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
            this._getDirections();
        },

        /**
         * Display the panel and activate the directions widget.
         */
        show: function() {
            if (!this.isOpen) {
                html.addClass(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                if (this._directions) {
                    this._directions.activate();
                }
                this.isOpen = true;
                this.appUtils.sidePanelOpen(this.isOpen);
            } else {
                this.hide();
            }
        },

        /**
         * Hide the panel
         */
        hide: function() {
            this.isOpen = false;
            html.removeClass(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                if (this._directions) {
                    this._directions.deactivate();
                }
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
            }
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Widget Related Events, resize widget panel on window resize.
         */
        _attachWidgetRelatedEvents: function() {
        	//on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
            }));
        },

        /**
         * Load esri direction widget and call the ArcGIS services and perform directions operations.
         */
        _getDirections: function() {
            require(["esri/dijit/Directions",
                "esri/urlUtils"
            ], lang.hitch(this, function(Directions, urlUtils) {
                //all requests to route.arcgis.com will proxy to the proxyUrl defined in this object.
                urlUtils.addProxyRule({
                    urlPrefix: this.config.routeService,
                    proxyUrl: this.appUtils.configGeneralSettings.proxyPageURL
                });
                urlUtils.addProxyRule({
                    urlPrefix: this.config.trafficService,
                    proxyUrl: this.appUtils.configGeneralSettings.proxyPageURL
                });
                this._directions = new Directions({
                    map: this.map,
                    routeTaskUrl: this.config.routeService
                }, this.directionsNode);
                this._directions.defaults.showClearButton = true;
                this._directions.showClearButton = true;
                this._directions.options.searchOptions.autoComplete = true;
                this._directions.startup();
                on(this._directions, "load", lang.hitch(this, function() {
                    this._shelter.hide();
                }));
                on(this._directions, "error", lang.hitch(this, function(error) {
                    this._shelter.hide();
                }));
            }));
        }
    });
});
