define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/on",
    "dojo/dom-construct",
    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/dom",
    "dojo/dom-attr",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/text!./BasemapGalleryTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/aspect",
    "dijit/TitlePane",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/Button",
    "esri/request",
    "esri/map",
    "esri/layers/CSVLayer",
    "esri/geometry/Extent",
    "esri/SpatialReference",
    "esri/layers/KMLLayer",
    "esri/layers/MapImageLayer",
    "esri/layers/GeoRSSLayer",
    "esri/layers/MapImage",
    "esri/layers/ArcGISTiledMapServiceLayer",
    "app/widgets/DataLayers/ArcGISMSCachedManager",
    "esri/layers/ArcGISDynamicMapServiceLayer",
    "esri/virtualearth/VETiledLayer",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter",
    "app/widgets/AlertBox/AlertBox",
    "esri/tasks/ProjectParameters",    
    "esri/geometry/webMercatorUtils",
    "esri/tasks/GeometryService",
    "app/nc4modules/NC4GeometryService",
    "esri/graphicsUtils",
    "lodash/lodash"
], function(declare, html, lang, array, on, domConstruct, Deferred, all, dom, domAttr, domStyle, domClass, template, sharedNls, aspect,
    TitlePane, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin,Button,
    esriRequest, Map, CSVLayer, Extent, SpatialReference, KMLLayer, MapImageLayer, GeoRSSLayer, MapImage, ArcGISTiledMapServiceLayer, ArcGISMSCachedManager,
    ArcGISDynamicMapServiceLayer, VETiledLayer, WidgetPanel,
    LoadingShelter, AlertBox, ProjectParameters, webMercatorUtils, GeometryService, NC4GeometryService, graphicsUtils, _) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        name: "BasemapGallery",
        baseClass: "widget-BasemapGallery",
        sharedNls: sharedNls,
        templateString: template,
        _shelter: null,
        _arrLayersOnMap: null,
        isOpen: false,
        _panel: null,
        _btnSetBmDefault: null,
        _objBingBasemap: null,
        customBasemapDiv: null,
        esriBingBasemapDiv: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },

        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
         */
        postCreate: function() {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetBasemapGalleryIcon"
            }, null);
            this._placeWidgetContainer();
            this._alertBox = new AlertBox();
        	this._nc4Notify = this.appUtils.nc4Notify;
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
            this.customBasemapDiv = domConstruct.create("div", {}, null);
            this.esriBingBasemapDiv = domConstruct.create("div", {}, null);
            this.titlePaneCustom.containerNode.appendChild(this.customBasemapDiv);
            this.titlePaneEsriAndBing.containerNode.appendChild(this.esriBingBasemapDiv);
            this.titlePaneCustom.startup();
            this.titlePaneEsriAndBing.startup();
            this.titlePaneCustom.textContent = sharedNls.BasemapGallery.lblCustomBaseMap;
            this.titlePaneEsriAndBing.textContent = sharedNls.BasemapGallery.lblEsriBingBaseMap;
            
            this._btnSetBmDefault = new Button({
                label: "Set As Default"
            }, this.setDefaultBmButton);
            
            
            if(!this.config.saveDefaultsOptions){
            	domStyle.set(this._btnSetBmDefault.domNode, 'display', 'none');
            }
            
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            array.forEach(this.config.basemapGallery.basemaps, lang.hitch(this, function(basemap) {
                this._loadEsriAndBingBasemaps(basemap);
            }));
            this._attachWidgetRelatedEvents();
            if (this.config.CustomBasemapRetriveService) {
                this._getRequestFromCustomBasemapService();
            } else {
                this._shelter.hide();
            }
            aspect.after(this.appUtils, "addCustomBaseMapFromAddLayer", lang.hitch(this, function() {
                this._getRequestFromCustomBasemapService();												//TODO: james + why is this called again?S
            }));
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
            //this._shelter.hide();
        },

        /**
         * Function to load Esri and Bing base maps.
         * @param {object} basemap - Base map object
         */
        _loadEsriAndBingBasemaps: function(basemap) {
            var lblBasemap, classBasemap, layerUrl;
            lblBasemap = basemap.title;
            classBasemap = lblBasemap.replace(/ /g, "_");
            layerUrl = basemap.layers[0].url;
            this["main" + classBasemap] = html.create("div", {
                "class": "basemapGalleryUnSelectedNode"
            }, this.esriBingBasemapDiv);
            this[lblBasemap] = html.create("div", {
                "title": lblBasemap,
                "class": classBasemap,
                "url": layerUrl
            }, this["main" + classBasemap]);
            this[lblBasemap + "Label"] = html.create("div", {
                "class": "lblBasemaps"
            }, this[lblBasemap]);
            html.create("label", {
                innerHTML: lblBasemap
            }, this[lblBasemap + "Label"]);
            on(this[lblBasemap], "click", lang.hitch(this, function(evt) {
                this._shelter.show();
                var selectedBasemapUrl, baseMapType, selectedBasemapId;
                this._deselectAllBasemaps();
                var basemapNode = evt.currentTarget.parentNode;
                var className = evt.currentTarget.parentNode.className;
                html.removeClass(basemapNode, className);
                html.addClass(basemapNode, "basemapGallerySelectedNode");
                baseMapType = evt.currentTarget.textContent || "";
                
                //store the latest basemap that was clicked, in case user wants to save it.
                this._selectedBaseMap = evt.currentTarget.title;
                this.appUtils.configGeneralSettings.defaultBaseMap = evt.currentTarget.title;
                
                if (baseMapType === "Bing-Road" || baseMapType === "Bing-Aerial" || baseMapType === "Bing-Aerial with Labels") {
                    this._changeBingBasemap(baseMapType);
                } else {
                    selectedBasemapUrl = evt.currentTarget.attributes.url.value;
                    selectedBasemapId = evt.currentTarget.title;
                    this._checkBasemapSR(selectedBasemapUrl, selectedBasemapId);
                }
            }));
        },

        /**
         * Function to check base map spatial reference if it's same or different.
         * @param {string} selectedBasemapUrl - Base map url
         * @param {string} selectedBasemapId -  Base map id
         */
        _checkBasemapSR: function(selectedBasemapUrl, selectedBasemapId) {
            this._arrLayersOnMap = [];
            esriConfig.defaults.io.alwaysUseProxy = true;					

            esriRequest({
                url: selectedBasemapUrl,
                content: lang.mixin({
                    f: "json"
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, function(response) {
                    esriConfig.defaults.io.alwaysUseProxy = false;					

                    var k = 0;
                    var layer = this.map.getLayer(this.map.layerIds[k]);
                    if (layer) {
                        var currentBasemapSR = layer.spatialReference.wkid;
                        var selectedBasemapSR = response.fullExtent.spatialReference.wkid;

                       // this.appUtils.configGeneralSettings.defaultBaseMap = selectedBasemapId;

                        this._changeBasemapWithDiffSR(layer, response, selectedBasemapUrl, selectedBasemapId);
                    }
                }),
                error: lang.hitch(this, function(err) {
                    this._nc4Notify.error(err);
                    this._shelter.hide();
                })
            });
        },

        /**
         * Function to get all layers on map
         */
        _getLayersOnMap: function() {
            this._arrLayersOnMap = [];
            var mapGraphicsLayerIds = lang.clone(this.map.graphicsLayerIds);
            if (mapGraphicsLayerIds.length !== 0) {
                array.forEach(mapGraphicsLayerIds, lang.hitch(this, function(layer) {
                    var geoLayer = layer.indexOf("GeoRSSFeed");
                    if (geoLayer !== -1) {
                        var objGeo = this.map.getLayer(layer);
                        this.map.removeLayer(objGeo);
                        return;
                    }
                    var kmlLayer = layer.indexOf("KML");
                    if (kmlLayer !== -1) {
                        var objKml = this.map.getLayer(layer);
                        this.map.removeLayer(objKml);
                        return;
                    }
                    var name = layer;
                    var id = name.split("_layer");
                    if (this.appUtils.treeNode) {
                        var layerNode = this.appUtils.treeNode.query({
                            id: id[0]
                        });
                        if (layerNode[0]) {
                            if (layerNode[0].type === "kml") {
                                var objKmlFromService = this.map.getLayer(name);
                                this.map.removeLayer(objKmlFromService);
                                return;
                            }
                            if (layerNode[0].type === "georss") {
                                var objGeoFromService = this.map.getLayer(name);
                                this.map.removeLayer(objGeoFromService);
                                return;
                            }
                        }
                    }
                    var objLayer = this.map.getLayer(layer);
                    this._arrLayersOnMap.push(objLayer);
                    this.map.removeLayer(objLayer);
                }));
            }
            var mapLayerIds = lang.clone(this.map.layerIds);
            var i = 0;
            array.forEach(mapLayerIds, lang.hitch(this, function(layer) {
                i++;
                if (i === 1) {
                    return;
                }
                var objLayers = this.map.getLayer(layer);
                this._arrLayersOnMap.push(objLayers);
                this.map.removeLayer(objLayers);
            }));
        },


        /**
         * Function to change base map with different spatial reference.
         * @param {object} layer - Current base map object
         * @param {object} response -  It's contains lods if it's presents
         * @param {string} selectedBasemapUrl - Base map url
         * @param {string} selectedBasemapUrl - Base map id
         */
        _changeBasemapWithDiffSR: function(layer, response, selectedBasemapUrl, selectedBasemapId) {
            //this._shelter.show();
            this._getLayersOnMap();
            
            this.map.removeLayer(layer);
            if (this.map) {
                this.map.destroy();
            }
            
            /*
             * convert this.map.extent to sr of new base map
             * - then check if converted extent falls w/in new base map extent
             */
            this.appUtils.log.debug("this.map: ", this.map);
            var params = new ProjectParameters();
            params.geometries = [this.map.extent];
            params.outSR = new SpatialReference(response.fullExtent.spatialReference.wkid);
   		//callsite
            this.lastNewBasemapResponse = response;
            
            /*jt 2016 07 07 - is this in use?*/
            var newBasemap = {
            	layer: layer
            	, response: response
            	, selectedBasemapUrl: selectedBasemapUrl
            	, selectedBasemapId: selectedBasemapId
            	, map: this.map
            	, _changeBaseMapDiffSR_createNewMap: this._changeBaseMapDiffSR_createNewMap
            	, appUtils: this.appUtils
            	, _shelter: this._shelter
            }
            
            this.layer = layer;
            this.response = response;
            this.selectedBasemapUrl = selectedBasemapUrl;
            this.selectedBasemapId = selectedBasemapId;
            
            //TODO: before depending on ESRI's geometry service, check to see if the current map is 4326 or 102100/3857...and use built in js utils instead.

        	var gsvc = new NC4GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL, this.appUtils);        
        	gsvc.project(params, this, function(p_updatedExtent){
        		var updatedExtent = p_updatedExtent[0];
	        	var esriExtent = new Extent(this.response.fullExtent);
        		if(esriExtent.contains(updatedExtent))
	        		   this._changeBaseMapDiffSR_createNewMap(updatedExtent);
	        	   else
	        		   this._changeBaseMapDiffSR_createNewMap(esriExtent);
        	}, function(){
           		var esriExtent = new Extent(this.response.fullExtent);
        	    this._changeBaseMapDiffSR_createNewMap(esriExtent);
        	});
        },
        
        /*
         * 
         * p_initialExtent: esri Extent object or JSON representing extent
         */
        _changeBaseMapDiffSR_createNewMap: function(p_initialExtent){		
             var diffSRBasemap, newmap;
             if (this.response.tileInfo) {
                 if (this.response.tileInfo.lods) {
                	  newmap = new Map(this.appUtils.mapNode, {
                          extent: p_initialExtent
                         // , lod: this.response.tileInfo.lods				//TODO james: this is a setup for the future, we should probably setup the lod where possible, so that users will not zoom pass last lod
                      });
                	  
                	 var arcgisCachedMgr = new ArcGISMSCachedManager(this.selectedBasemapId, this.appUtils, newmap, this.selectedBasemapUrl, this._shelter, null, 100, 0);
         			 arcgisCachedMgr._addCachedServiceAsBaseMap();
         			
                     /*
         			 diffSRBasemap = new ArcGISTiledMapServiceLayer(this.selectedBasemapUrl, {
                         id: this.selectedBasemapId,
                         visible: true
                     });*/
                   
                 }
                 //no else here...possible room for crashing, put else statement here - james
             } else {
                 diffSRBasemap = new ArcGISDynamicMapServiceLayer(this.selectedBasemapUrl, {
                     id: this.selectedBasemapId,
                     visible: true
                 });
                 newmap = new Map(this.appUtils.mapNode, {
                     extent: p_initialExtent
                 });
                 newmap.addLayer(diffSRBasemap);
                 newmap.reorderLayer(diffSRBasemap, 0);
             }
             this.map = newmap;
             
             this._shelter.hide();
             
             this.appUtils.boolBasemapChanged = true;
             on(this.map, "load", lang.hitch(this, function() {
                 this._shelter.show();
                 this.map.autoResize = true;
                 this.map.enableKeyboardNavigation();
                 this.appUtils.updateMapInstance(this.map);
                 array.forEach(this._arrLayersOnMap, lang.hitch(this, function(layer) {
                     var layerType = layer.customLayerType;
                     this.appUtils.log.debug("diffSRBasemap Change, layerType: ", layerType);
                     switch (layerType) {
                         case "georss":
                             this._loadGeoRss(layer);			   
                             return;
                         case "kml":
                             this._loadKMLLayer(layer.url, layer);
                             return;
                         case "csv":
                             this._loadCSVLayer(layer);				//no outSR param in constructor
                             return;
                         case "image":
                             this._loadImage(layer);				//no outSR param in constructor, coordines must be in same SR as current map SR
                             return;
                         case "arcgis_cached_service":
                        	 this.map.addLayer(layer);
                        	 this._performStrikeOutOfCachedLayer(layer);			//if arcgisTiledMapService - no re-projection is supported, if dynamic, then server should re-project automatically
                             return;
                         case "wms":
                        	 this._loadWmsLayer(layer);
                        	 return;
                         case "arcgis_map_service":					//featureservice and dynamic map service - serivce should reproject (js lib will send new request with outSR set
                        	 this.map.addLayer(layer);
                        	 return;
                         case "arcgis_dynamic_service":					//featureservice and dynamic map service - serivce should reproject (js lib will send new request with outSR set
                             layer._img = null;
                             this.map.addLayer(layer);
                        	 return;
                         case undefined:
                            if(layer.geometryType == "esriGeometryPolygon"){
                                this.map.addLayer(layer);
                                return;
                            }
                     }
                     
                     //if made it this far, check other attributes for layer type:
                     console.log("currlayer: ", layer);
                     if(layer.declaredClass)
                     {
                    	 layerType = layer.declaredClass;
                         //NOTE: Assumption: we do not have Graphics layer consisting of geometries w/ different spatial reference
                    	 if(layerType.indexOf("Graphics") > 0)
                    	 {
                    		if( layer.id.indexOf("_cluster") > 0)
                    		{
                    			//NOTE: This is the current definition of a business point layer (Graphics Layer that is clustered, with data being pulled from the Feature Services)
                    			
                    			//reset values that will be altered:
                             	layer.id = layer.id.substring(0, layer.id.indexOf("_cluster"));
                             	layer.opacity = layer.opacity * 100;
                             	//end reset
                             	
                             	//add layer if it doesn't exist on map instance
                             	if (!this.map.getLayer(layer.id + "_cluster")) {
                                	if(layer.opacity == 0)												//james - opacity will be 0 only if defaulted from server.  app allows you to set to as low as 0.1.  So default to default app value
                                		layer.opacity = this.appUtils.configGeneralSettings.defaultOpacity;
                                 	this.appUtils.clustering.addClusters(this.map, layer); 
                                }
                             	this._attachLayerEvents(layer);
                             	//end re-create and add to new map of biz layer
                             	
                             	//start re-do refresh rate:
                                	var mapClassInstance = this;
                                 	var map = this.map;            	
                                    
                                    if (this.appUtils.arrIntervalForClusters.length > 0) {
                                        for (var i = 0; i < this.appUtils.arrIntervalForClusters.length; i++) {
                                            if (this.appUtils.arrIntervalForClusters[i].id === layer.id) 
                                            {
                                            	var existingRefresh = this.appUtils.arrIntervalForClusters[i].refresh;
                                            	var interval = setInterval(function () {
                                                    if (mapClassInstance.map.getLayer(layer.id + "_cluster")) {
                                                    	
                                                    	mapClassInstance.appUtils.clustering.addClusters(map, layer);
                                                    }
                                                }, parseInt(existingRefresh));	
                                            	
                                                clearInterval(this.appUtils.arrIntervalForClusters[i].interval);
                                                this.appUtils.arrIntervalForClusters[i].interval = interval;
                                                result = false;
                                            }
                                        }
                                    }
                                    else{
                                        console.info("Unable to update refresh rate for layer: ", layer);
                                    }
                                 //end re-do refresh rate 
                    		}
                    		else
                    		{
                    			if(layer.graphics && layer.graphics.length <= 0)
                    			{
                    				layer.spatialReference = this.map.spatialReference;
                    				return;
                    			}
                    			layer.opacity = layer.opacity * 100;
                             	//end reset
                             	
                             	var params = new ProjectParameters();
                                params.geometries = graphicsUtils.getGeometries(layer.graphics);
                                params.outSR = this.map.spatialReference;
                                
                            	var gsvc = new NC4GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL, this.appUtils);
                            	var alteredLayer = layer;
                            	var contextObj =
                            	{
                           		   map: this.map,
                           		   layer: alteredLayer,
                           		   galleryObj: this
                           	   	};
                            	
                            	gsvc.project(params, contextObj, function(updatedGeometries)
                            		{
                                		for(var i =0; i<layer.graphics.length;i++){
                  		            		var currGraphics = layer.graphics[i];
                  		            		var currGeometry = updatedGeometries[i];
                  		            		currGraphics.setGeometry(currGeometry);
                       	           		}
                                 		layer.spatialReference = this.map.spatialReference;
                                     	if (!this.map.getLayer(layer.id)) {
                                        	if(layer.opacity == 0)												//james - opacity will be 0 only if defaulted from server.  app allows you to set to as low as 0.1.  So default to default app value
                                        		layer.opacity = this.appUtils.configGeneralSettings.defaultOpacity;
                                        	this.map.addLayer(layer);
                                     	}
                                     	this.galleryObj._attachLayerEvents(layer);
                            		}, 
                            		function(err){console.error("error projecting: ", err);}
                            	);
                    		}
                    		
                    	 }
                     }
                     else
                   {
                    this.appUtils.debug("other layer type not accounted for: " , layer);
                    this._attachLayerEvents(layer);
                    this.map.addLayer(layer);
                   } 
                 }));
                 this._shelter.hide();
             }));
        },

        /**
         * Function to load grorss layer and layer added from data layer widget.
         * @param {object} layer - kml url
         */
        _loadGeoRssFromSavedLayer: function(name, layer) {
            var geoName = name;
            var geoRssId = geoName.replace("_layer_" + layer._ulid, "");
            if (this.appUtils.treeNode) {
                var geoRssIdNode = this.appUtils.treeNode.query({
                    id: geoRssId
                });
                if (geoRssIdNode[0]) {
                    if (geoRssIdNode[0].type === "georss") {
                        var georss = new GeoRSSLayer(geoRssIdNode[0].url, {
                            id: geoRssIdNode[0].id,
                            name: geoRssIdNode[0].name,
                            opacity: geoRssIdNode[0].opacity,
                            refreshInterval: geoRssIdNode[0].refresh
                        });
                        this._attachLayerEvents(georss);
                        this.map.addLayer(georss);
                        return;
                    }
                }
            }
        },

        /**
         * Function to load grorss layer and layer added from add layer widget.
         * @param {object} layer - kml url
         */
        _loadGeoRss: function(layer) {
            var georss = new GeoRSSLayer(layer.url, {
                id: layer.id,
                name: layer.id,
                opacity: layer.opacity,
                refreshInterval: layer.refreshInterval,
                outSpatialReference: this.map.spatialReference
            });
            georss.customLayerType = "georss";
            this._attachLayerEvents(georss);
            this.map.addLayer(georss);
            return;
        },

        /**
         * Function to validate kml layer.
         * @param {string} strUrl - kml url
         * @param {array} kmlNode - kml label node
        
        _validateKmlLayer: function(layer) {				//James - no need to call validate kml layer anywhere else besides add layer!
            var cmpString,
                requestHandle,
                strUrl = layer.url;
            requestHandle = esriRequest({
                "url": strUrl,
                "content": lang.mixin({
                    "f": "json"
                }, null),
                "callbackParamName": "callback"
            });
            requestHandle.then(lang.hitch(this, function(response) {}), lang.hitch(this, function(error) {
                cmpString = lang.trim(error.message);
                if (cmpString.toLowerCase() === "Access is denied.".toLowerCase()) {
                    this._shelter.hide();
                    this._nc4Notify.error(sharedNls.AddLayer.errorMessages.invalidURLError);
                }
            }));
            if (_.contains(strUrl, ".kml") || _.contains(strUrl, ".kmz")) {
                this._loadKMLLayer(strUrl, layer);
            } else {
                this._shelter.hide();
                this._nc4Notify.error(sharedNls.AddLayer.errorMessages.invalidURLError);
            }
        },
 */
        /**
         * Function to add kml layer on map.
         * @param {string} strUrl - kml url
         * @param {array} kmlNode - kml label node
         */
        _loadKMLLayer: function(strUrl, layer) {
            var kml = new KMLLayer(strUrl, {
                id: layer.id,
                name: layer.id,
                outFields: ["*"],
                opacity: layer.opacity,
                refreshInterval: layer.refreshInterval,
                outSR: this.map.spatialReference
            });
            kml.customLayerType = "kml";
            this._attachLayerEvents(kml);
            this.map.addLayer(kml);
            //this.appUtils.updateMapInstance(this.map);
            return;
        },

        /**
         * Function to perform strike out operation of cached layer.
         * @param {evt} evt - event
         */
        _performStrikeOutOfCachedLayer: function(p_layer) {
            //if (p_layer.type === "arcgis_cached_service") {
                var visible = false; //p_layer.visibleAtMapScale;
                if( p_layer.spatialReference.wkid == this.map.spatialReference.wkid || (p_layer.spatialReference._isWebMercator() && this.map.spatialReference._isWebMercator()) )
                	visible = true;
                if (this.appUtils.treeNode) {
                	var layerId = p_layer.id.replace("_layer", "");
                    var layerNode = this.appUtils.treeNode.query({
                        id: layerId
                    });
                    if (layerNode[0]) {
                        if (layerNode[0].type === "arcgis_cached_service") {
                            if (visible === true) {
                                layerNode[0].strike = "No";
                                this.appUtils.layerAddedOnBasemap(true);
                                return;
                            } else {
                                layerNode[0].strike = "Yes";
                                this.appUtils.layerAddedOnBasemap(true);
                                return;
                            }
                        }
                    }
                }
                else {	//jt 06.06.2016 not sure what the below is for:
                    if (this.appUtils.mapServerLayers) {
                        array.forEach(this.appUtils.mapServerLayers, lang.hitch(this, function(layer) {
                            if ("arcgis_cached_service" === layer.type) {
                                if (visible === true) {
                                    layer.strike = "No";
                                    this.appUtils.layerAddedOnBasemap(true);
                                    return;
                                } else {
                                    layer.strike = "Yes";
                                    this.appUtils.layerAddedOnBasemap(true);
                                    return;
                                }
                            }
                        }));
                    }
                    this.appUtils.boolBasemapChanged = false;
                    this._shelter.hide();
                }
            //}
        },
        
        /**
         * Function to add WMS layer onto map
         * @param {ESRI Layer object}
         */
        _loadWmsLayer: function(p_layer) {
        	//loop through layer.layerinfos.  get a list of layers whose spatialreference[] matches the current base map's sr.  then call setvisibleLayer
        	
        	//The datalayer tree or filter is the manager of layers, so only take action if that is not present
        	if(!(this.appUtils.treeNode) )
        	{
        		var visibleLayers = [];
            	var mapIsWebMerc = this.map.spatialReference.isWebMercator();
            	
            	
            	for(var i = 0; i < p_layer.layerInfos.length; i++)
                {
            		var containsNonCompat = true; //set to true.  will convert to false only if layer contains no supported sr
                	var currLayerInfo = p_layer.layerInfos[i];
                	
                	//since we are not sure if the layer can re-project on its own, add all layers to list of visible layers:
            		visibleLayers.push(currLayerInfo.name);
                	
                	var currSrs = currLayerInfo.spatialReferences;
                	for(var j = 0; j < currSrs.length; j++)
                	{
                		var currSr = currSrs[j];
                		//if the current map proj is not listed as a supported proj explicitly, just show a warning
                		if( this.map.spatialReference.wkid == currSr || 
                				(mapIsWebMerc == true && (currSr == 102113 || currSr == 102100 || currSr == 3857) ) )
                		{
                			containsNonCompat = false;
                			break;
                		}
                	}
                }
            	if(containsNonCompat == true || visibleLayers.length == 0)
    				this._nc4Notify.warn(sharedNls.Common.wmsPartialNotSupported); //(NOte title from service, not custom name

            	p_layer.setVisibleLayers(visibleLayers);
            	this.map.addLayer(p_layer);
        	}
        	else
        	{
        		this.map.addLayer(p_layer);
        		this.appUtils.layerAddedOnBasemap(true); //triggers event for data layer manager to act on
        	}
        },
        
        /**
         * associated strikeout method for loadwms
         */
        _performStrikeOutOfWmsLayer: function(p_layerNode)
        {
        	
        	this.appUtils.boolBasemapChanged = false;
        	//probably don't need this anymore
        	//this.appUtils.layerAddedOnBasemap(true);
        },
        
        /**
         * Function to add csv layer on map.
         * @param {object} layer - csv label node
         */
        _loadCSVLayer: function(layer) {
            var csvLayer = new CSVLayer(layer.url, {
                id: layer.id,
                name: layer.name,
                opacity: layer.opacity,
                refreshInterval: layer.refreshInterval
            });
            csvLayer.customLayerType = "csv";
            this._attachLayerEvents(csvLayer);
            this.map.addLayer(csvLayer);
            //this.appUtils.updateMapInstance(this.map);
            return;
        },

        /**
         * Function to add image layer on map.
         * @param {array} kmlNode - Image node
         */
        _loadImage: function(layer) {
        	console.info("image layer: " , layer);
            var mapimglayer = new MapImageLayer({
                id: layer.id,
                name: layer.id,
                opacity: layer.opacity,
                refreshInterval: layer.refreshInterval
            });
            var extent = layer._mapImages[0].extent;
            
            var params = new ProjectParameters();
            params.geometries = [extent];
            params.outSR = this.map.spatialReference;
            
        	var gsvc = new NC4GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL, this.appUtils);
            
        	var contextObj = {
        		mapimglayer: mapimglayer,
        		map: this.map,
        		appUtils: this.appUtils,
        		_shelter: this._shelter,
        		layer: layer
        	};
        	
        	gsvc.project(params, contextObj, function(p_extent){
        		var extent = p_extent[0];
        		if (extent) {
                    var getMapImage = new MapImage({
                        "extent": extent,
                        "href": this.layer._mapImages[0].href,
                        "height": this.layer._mapImages[0].height,
                        "width": this.layer._mapImages[0].width
                    },true);
                }
        		else
        		{
        			console.error("issue checking/projecting image layer ")
        		}
        		
        		this.mapimglayer.addImage(getMapImage);
                this.mapimglayer.customLayerType = "image";
                this.map.addLayer(mapimglayer);
                this.map.reorderLayer(mapimglayer, 1);
                //this.appUtils.updateMapInstance(this.map);
                this.appUtils.layerAddedOnBasemap(true);
                this._shelter.hide();
                console.info("after image layer reprojected, layer: ", mapimglayer);
                return;
        	}, 
        	function(){
        		console.error("unknown issue checking/projecting image layer");
        	}, true ); //disable re-projection for now

        	/*
            this code seems to be useless (the data layer gets triggered to cross out the label in the data layer tree, so what is this for?
            if (this.appUtils.customLayerCollection) {
                var basemap = this.map.getLayer(this.map.layerIds[0]);
                var basemapSR = basemap.spatialReference.wkid;
                if (basemapSR !== 102100 && basemapSR !== 4326) {
                    array.forEach(this.appUtils.customLayerCollection, lang.hitch(this, function(layer) {
                        if ("image" === layer.type) {
                            layer.strike = "Yes";
                        }
                    }));
                } else {
                    array.forEach(this.appUtils.customLayerCollection, lang.hitch(this, function(layer) {
                        if ("image" === layer.type) {
                            layer.strike = "No";
                        }
                    }));
                }
            }
           */
        },

        /**
         * Function to perform update-end event operations.
         * @param {evt} evt - Event
         */
        _performUpdateEndEventOperations: function(evt) {
            this._shelter.show();
            var name = evt.target.id;
            var id = name.replace("_layer", "");
            if (this.appUtils.treeNode) {
                var layerNode = this.appUtils.treeNode.query({
                    id: id
                });
                if (layerNode[0]) {
                    if (layerNode[0].type === "georss" || layerNode[0].type === "kml") {
                        this._checkStrikeOutOfKmlGeoRss(evt, layerNode);
                    } 
                    /*
                    else if(layerNode[0].type === "wms")
                    {
                    	if(this.appUtils.boolBasemapChanged)
                    		this._performStrikeOutOfWmsLayer(layerNode);
                    }*/
                    else {
                        this._removeStrikeOut(evt, layerNode);
                    }
                }
            } else {
                var type = evt.target.customLayerType;
                if (type === "georss" || type === "kml") {
                    this._checkStrikeOfGeoRssKmlWithOutDataTree(evt, type);
                } 
                
                /* n/a for wms since wms servers may have re-project capabilities w/o specifying
                else if(type === "wms")
                {
                	if(this.appUtils.boolBasemapChanged)
                		this._performStrikeOutOfWmsLayer(layerNode);
                	//this.appUtils.layerAddedOnBasemap(true);
                }*/
            }
            this._shelter.hide();
        },

       
        /**
         * Function to perform strike out operation of CSV layer form error event.
         * @param {evt} evt - Event
         */
        _performStrikeOutOfCsvLayerFromErrorEvent: function(evt) {
            var layerNode;
            var id = evt.target.id;
            var layerId = id.replace("_layer", "");
            if (this.appUtils.treeNode) {
                layerNode = this.appUtils.treeNode.query({
                    id: layerId
                });
                if (layerNode[0]) {
                    if (layerNode[0].type === "csv") {
                        layerNode[0].strike = "Yes";
                        //this.appUtils.boolBasemapChanged = true;
                        this.appUtils.layerAddedOnBasemap(true);
                    }
                }
            } else {
                var type = evt.target.customLayerType;
                if (type === "csv") {
                    if (this.appUtils.customLayerCollection) {
                        array.forEach(this.appUtils.customLayerCollection, lang.hitch(this, function(layer) {
                            if (type === layer.type) {
                                layer.strike = "Yes";
                            }
                        }));
                    }
                }
            }
        },

        /**
         * Function to perform error event operations.
         * @param {evt} evt - Event
         */
        _performErrorEventOperations: function(evt) {
            this._shelter.show();
            var id, layerId, layerNode;
            var message = evt.error.message;
            if (message === "Unable to draw graphic (null): Cannot read property '0' of null") {
                this._performStrikeOutOfCsvLayerFromErrorEvent(evt);
            }
            if (message === "Unable to draw graphic (null): Unable to complete  operation.") {
                id = evt.target.id;
                layerId = id.replace("_layer", "");
                if (this.appUtils.treeNode) {
                    layerNode = this.appUtils.treeNode.query({
                        id: layerId
                    });
                    if (layerNode[0].strike) {
                        layerNode[0].strike = "Yes";
                        //this.appUtils.boolBasemapChanged = true;
                        this.appUtils.layerAddedOnBasemap(true);
                    }
                }
            }
            //For WMS Layer
            var notValid = message.indexOf("Unable to load image");
            if (notValid !== -1) {
                id = evt.target.id;
                layerId = id.replace("_layer", "");
                if (this.appUtils.treeNode) {
                    layerNode = this.appUtils.treeNode.query({
                        id: layerId
                    });
                    if (layerNode[0]) {
                        layerNode[0].strike = "Yes";
                        //this.appUtils.boolBasemapChanged = true;
                        this._nc4Notify.warn(sharedNls.Common.notCompatible); //(NOte title from service, not custom name
                        this.appUtils.layerAddedOnBasemap(true);
                    }
                }
            }
            this._shelter.hide();
        },

        /**
         * Function to attach events for layers.
         * @param {object} layer - layer object
         */
        _attachLayerEvents: function(layer) {
            this.own(on(layer, "update-end", lang.hitch(this, "_performUpdateEndEventOperations")));
            this.own(on(layer, "error", lang.hitch(this, "_performErrorEventOperations")));
        },

        /**
         * Function to execute strikeout operation of GeoRss and KML layer when data layer tree were not generated.
         * @param {event} evt - event
         * @param {string} type - layer type
         */
        _checkStrikeOfGeoRssKmlWithOutDataTree: function(evt, type) {
            var mapSR = this.map.spatialReference,
                layerOutSR = evt.target._outSR,
                isValidSR;
            if (mapSR.wkid) {
                isValidSR = mapSR._isWebMercator() && layerOutSR._isWebMercator() || mapSR.wkid === layerOutSR.wkid;
            } else if (mapSR.wkt) {
                isValidSR = mapSR.wkt === layerOutSR.wkt;
            } else {
                var x = 0; //jshint ignore:line
            }
            if (!isValidSR) {
                if (mapSR._isWebMercator() && 4326 === layerOutSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else if (layerOutSR._isWebMercator() && 4326 === mapSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else {
                    if (this.appUtils.customLayerCollection) {
                        array.forEach(this.appUtils.customLayerCollection, lang.hitch(this, function(layer) {
                            if (type === layer.type) {
                                layer.strike = "Yes";
                            }
                        }));
                    }
                    this.appUtils.layerAddedOnBasemap(true);
                    this._shelter.hide();
                    return;
                }
            }
            if (this.appUtils.customLayerCollection) {
                array.forEach(this.appUtils.customLayerCollection, lang.hitch(this, function(layer) {
                    if (type === layer.type) {
                        layer.strike = "No";
                    }
                }));
            }
            this.appUtils.layerAddedOnBasemap(true);
            this._shelter.hide();
        },

        /**
         * Function to remove striked out from layer.
         * @param {event} evt - event
         * @param {object} layerNode - layer object
         */
        _removeStrikeOut: function(evt, layerNode) {
            if (!evt.error) {
                if (layerNode[0].strike) {
                    layerNode[0].strike = "No";
                    this.appUtils.layerAddedOnBasemap(true);
                }
                /* TODO: enable this back some time in the future when things are more stable
                if (layerNode[0].type === "arcgis_cached_service") {
                    if (evt.target.customLayerType === "arcgis_cached_service") {
                        var cachedLayerVisible = evt.target.visibleAtMapScale;
                        if (cachedLayerVisible === true) {
                            layerNode[0].strike = "No";
                            this.appUtils.layerAddedOnBasemap(true);
                        } else {
                            layerNode[0].strike = "Yes";
                            this.appUtils.layerAddedOnBasemap(true);
                        }
                    } else {
                        layerNode[0].strike = "No";
                        this.appUtils.layerAddedOnBasemap(true);
                    }
                }*/
                if (layerNode[0].type === "wms") {
                    layerNode[0].strike = "No";
                    this.appUtils.layerAddedOnBasemap(true);
                }
            }
        },

        /**
         * Function to check strikeout of georss and kml layer's.
         * @param {event} evt - event
         * @param {object} layerNode - layer object
         */
        _checkStrikeOutOfKmlGeoRss: function(evt, layerNode) {
            var mapSR = this.map.spatialReference,
                layerOutSR = evt.target._outSR,
                isValidSR;
            if (mapSR.wkid) {
                isValidSR = mapSR._isWebMercator() && layerOutSR._isWebMercator() || mapSR.wkid === layerOutSR.wkid;
            } else if (mapSR.wkt) {
                isValidSR = mapSR.wkt === layerOutSR.wkt;
            } else {
                layerNode[0].strike = "Yes";
                this.appUtils.layerAddedOnBasemap(true);
                this._shelter.hide();
                return;
            }
            if (!isValidSR) {
                if (mapSR._isWebMercator() && 4326 === layerOutSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else if (layerOutSR._isWebMercator() && 4326 === mapSR.wkid) {
                    var x = 0; //jshint ignore:line
                } else {
                    layerNode[0].strike = "Yes";
                    this.appUtils.layerAddedOnBasemap(true);
                    this._shelter.hide();
                    return;
                }
            }
            layerNode[0].strike = "No";
            this.appUtils.layerAddedOnBasemap(true);
            this._shelter.hide();
        },

        /**
         * Function to change bing basemap.
         * @param {string} baseMapType - Basemap type
         */
        _changeBingBasemap: function(baseMapType) 
        {         
            this._objBingBasemap = null;
            var k = 0;
            var layer = this.map.getLayer(this.map.layerIds[k]);
            var currentBasemapSR = layer.spatialReference.wkid;			
            
            //if current basemap is 102100, and we are switching to 102100, then keep same extent, if possible.
            if (layer.spatialReference.isWebMercator()) 
            {
                this.map.removeLayer(layer);
                this._getBingBaseMap(baseMapType);
                this.map.addLayer(this._objBingBasemap); //sets teh 
                
                var initialExtent = new Extent({
                    "xmin": this.map.extent.xmin,
                    "ymin": this.map.extent.ymin,
                    "xmax": this.map.extent.xmax,
                    "ymax": this.map.extent.ymax,
                    "spatialReference": {
                        "wkid": 102100
                    }
                });
                
                //just to be safe, need to check if current map extent is w/in full extent of new base map:
                //		in case someone uses a custom basemap (in 102100 ) of tampa only, for example.
                var bingExtent = this._objBingBasemap.initialExtent;
                if(!bingExtent.contains(initialExtent))
                	initialExtent = bingExtent;
                this.map.setExtent(initialExtent);	
                this.map.reorderLayer(this._objBingBasemap, 0);	
                
                on(this.map, "load", lang.hitch(this, function() {
                    this.map.autoResize = true;
                    this.map.enableKeyboardNavigation();
                    this.appUtils.updateMapInstance(this.map);						
                    this._shelter.hide();
                }));
                this._shelter.hide();
            } 
            else {
            	//difference projections
            	
                this._getLayersOnMap();
                
                //save the extent, use it to set the initial extent of the new basemap's SR
                var initialExtent = new Extent({				
                    "xmin": this.map.extent.xmin,									
                    "ymin": this.map.extent.ymin,
                    "xmax": this.map.extent.xmax,
                    "ymax": this.map.extent.ymax,
                    "spatialReference": {
                        "wkid": layer.spatialReference.wkid
                    }
                });
                
                this.map.removeLayer(layer);
                if (this.map) {
                    this.map.destroy();
                }
                this._getBingBaseMap(baseMapType);
                
                var bingExtent = this._objBingBasemap.initialExtent;
                
                //no need to covert extent projection in order to compare?, since we're not using 'setExtent'
                if( !bingExtent.contains(initialExtent) )	//not sure how this is working, may need to update this to reproject extent before comparing,
                {												//this case may never be reached TODO
                	initialExtent = bingExtent;	
                	this._changeBingBasemap_createNewMap(initialExtent);
                }
                else
                {
                	//if current map extent exists w/in bing's extent, then convert it to be in SR 102100:
                    var params = new ProjectParameters();
                    params.geometries = [initialExtent];
                    params.outSR = bingExtent.spatialReference;
                    
                	var gsvc = new NC4GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL, this.appUtils);
                	this.newInitialExtent = initialExtent;
                
                	gsvc.project(params, this, this._changeBingBasemap_createNewMap, this._changeBingBasemap_createNewMap );
               	}
               
            }
        },
        
        
        _changeBingBasemap_createNewMap: function(p_initialExtent){
        	 var esriExtent = new Extent(p_initialExtent[0]);		//NC4GeometryService returns array of geometries
             var map = new Map(this.appUtils.mapNode, {
                 extent: esriExtent
             });
             this.map = map;			
             var bingLayer = this._objBingBasemap;
             this.map.addLayer(bingLayer);
             this.map.reorderLayer(bingLayer, 0);
             this.appUtils.boolBasemapChanged = true;
             on(bingLayer, "load", lang.hitch(this, function() {
            	 console.log("bing this: " ,this);
            	 this.map.autoResize = true;
                 this.map.enableKeyboardNavigation();
                 array.forEach(this._arrLayersOnMap, lang.hitch(this, function(layer) {	//james - re-adding layer on new map, TODO-re add help and x icon
                	 var layerType = layer.customLayerType;
                     this.appUtils.log.debug("bingSRBasemap Change, layerType: ", layerType);
                     switch (layerType) {
	                     case "georss":
	                         this._loadGeoRss(layer);			   //i think we need to set outSR here
	                         return;
	                     case "kml":
	                    	 this._loadKMLLayer(layer.url, layer);
	                    	 return;
                         case "csv":
                             this._loadCSVLayer(layer);				//no outSR param in constructor
                             return;
                         case "image":
                             this._loadImage(layer);				//no outSR param in constructor, coordines must be in same SR as current map SR
                             return;
                         case "arcgis_cached_service":
                        	 this.map.addLayer(layer);
                        	 this._performStrikeOutOfCachedLayer(layer);			//if arcgisTiledMapService - no re-projection is supported, if dynamic, then server should re-project automatically
                             return;
                         case "wms":
                        	 this._loadWmsLayer(layer);
                        	 return;
                         case "arcgis_map_service":					//featureservice and dynamic map service - serivce should reproject (js lib will send new request with outSR set
                        	 this.map.addLayer(layer);
                        	 return;
                         case "arcgis_dynamic_service":					//featureservice and dynamic map service - serivce should reproject (js lib will send new request with outSR set
                             this.map.addLayer(layer);
                        	 return;
                     }
                	 
                	 
                	 //biz layers
                    	 if(layer.declaredClass)
                         {
                        	 layerType = layer.declaredClass;
                             //NOTE: Assumption: we do not have Graphics layer consisting of geometries w/ different spatial reference
                        	 if(layerType.indexOf("Graphics") > 0)
                        	 {
                        		if( layer.id.indexOf("_cluster") > 0)
                        		{
                        			//NOTE: This is the current definition of a business point layer (Graphics Layer that is clustered, with data being pulled from the Feature Services)
                        			
                        			//reset values that will be altered:
                                 	layer.id = layer.id.substring(0, layer.id.indexOf("_cluster"));
                                 	layer.opacity = layer.opacity * 100;
                                 	//end reset
                                 	//add layer if it doesn't exist on map instance
                                 	if (!this.map.getLayer(layer.id + "_cluster")) {
                                    	if(layer.opacity == 0)												//james - opacity will be 0 only if defaulted from server.  app allows you to set to as low as 0.1.  So default to default app value
                                    		layer.opacity = this.appUtils.configGeneralSettings.defaultOpacity;
                                     	this.appUtils.clustering.addClusters(this.map, layer); 
                                    }
                                 	this._attachLayerEvents(layer);
                                 	//end re-create and add to new map of biz layer
                                 	
                                 	//start re-do refresh rate:
                                    	var mapClassInstance = this;
                                     	var map = this.map;            	
                                        
                                        if (this.appUtils.arrIntervalForClusters.length > 0) {
                                            for (var i = 0; i < this.appUtils.arrIntervalForClusters.length; i++) {
                                                if (this.appUtils.arrIntervalForClusters[i].id === layer.id) 
                                                {
                                                	var existingRefresh = this.appUtils.arrIntervalForClusters[i].refresh;
                                                	var interval = setInterval(function () {
                                                        if (mapClassInstance.map.getLayer(layer.id + "_cluster")) {
                                                        	
                                                        	mapClassInstance.appUtils.clustering.addClusters(map, layer);
                                                        }
                                                    }, parseInt(existingRefresh));	//TODO - james: cluster layer refresh applied
                                                	
                                                    clearInterval(this.appUtils.arrIntervalForClusters[i].interval);
                                                    this.appUtils.arrIntervalForClusters[i].interval = interval;
                                                    result = false;
                                                }
                                            }
                                        }
                                        else{
                                            console.error("Unable to update refresh rate for layer: " + layer.id);
                                            console.infor("Unable to update refresh rate for layer: ", layer);
                                        }
                                     //end re-do refresh rate 
                        		}
                        		else
                        		{
                        			//only other graphic layer that is an overlay layer - TODO
                        			//unlike biz point graphics layer, this does not have the structure to request points in diff sr, should we just project client side?
                        			
                        			//reset values that will be altered:
                                 	layer.opacity = layer.opacity * 100;
                                 	//end reset
                                 	
                                 	var params = new ProjectParameters();
                                    params.geometries = graphicsUtils.getGeometries(layer.graphics);
                                    params.outSR = this.map.spatialReference;
                                    
                                	var gsvc = new NC4GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL, this.appUtils);
                                	var alteredLayer = layer; //Be Careful not to use this.layer ==> completely different object (probably base map)
                                	var contextObj =
                                	{
                               		   map: this.map,
                               		   layer: alteredLayer,
                               		   galleryObj: this
                               	   	};
                                	
                                	gsvc.project(params, contextObj, function(updatedGeometries)
                                		{
	                                		for(var i =0; i<layer.graphics.length;i++){
	                  		            		var currGraphics = layer.graphics[i];
	                  		            		var currGeometry = updatedGeometries[i];
	                  		            		currGraphics.setGeometry(currGeometry);
	                       	           		}
	                                 		layer.spatialReference = this.map.spatialReference;
	                                     	if (!this.map.getLayer(layer.id)) {
	                                        	if(layer.opacity == 0)												//james - opacity will be 0 only if defaulted from server.  app allows you to set to as low as 0.1.  So default to default app value
	                                        		layer.opacity = this.appUtils.configGeneralSettings.defaultOpacity;
	                                        	this.map.addLayer(layer);
	                                     	}
	                                     	this.galleryObj._attachLayerEvents(layer);
                                		}, 
                                		function(){console.error("error TODO");}
                                	);
                        		}
                        	 }
                         }
                         else
                    		 this.map.addLayer(layer);					//TODO -  default case, all other layers can be added directly? may need to re-project?
                     
                     //WMS was not even added here...TODO-add WMS, WMTS also?
                 }));
                 this.appUtils.updateMapInstance(this.map);
                 this.appUtils.layerAddedOnBasemap(true);
                
                 //TODO: what else? maybe re-attache the help icon?
             }));
             this._shelter.hide();
        },
        

        /**
         * Function to require bing lib.
         * @param {string} baseMapType - Basemap type
         */
        _getBingBaseMap: function(baseMapType) {
            switch (baseMapType) {
                case "Bing-Road":
                    this._objBingBasemap = new VETiledLayer({
                        bingMapsKey: this.appUtils.configGeneralSettings.bingAccessKey,
                        mapStyle: VETiledLayer.MAP_STYLE_ROAD,
                        culture: "en-IN"
                    });
                    break;
                case "Bing-Aerial":
                    this._objBingBasemap = new VETiledLayer({
                        bingMapsKey: this.appUtils.configGeneralSettings.bingAccessKey,
                        mapStyle: VETiledLayer.MAP_STYLE_AERIAL,
                        culture: "en-IN"
                    });
                    break;
                case "Bing-Aerial with Labels":
                    this._objBingBasemap = new VETiledLayer({
                        bingMapsKey: this.appUtils.configGeneralSettings.bingAccessKey,
                        mapStyle: VETiledLayer.MAP_STYLE_AERIAL_WITH_LABELS,
                        culture: "en-IN"
                    });
                    break;
            }
        },

        /**
         * Function to retrieve base maps from service
         */
        _getRequestFromCustomBasemapService: function() {
            esriRequest({
                url: this.config.CustomBasemapRetriveService,
                content: lang.mixin({
                    f: "jsonp"
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, function(response) {
                    this._addCustomBaseMapFromService(response.DataLayerGroups[0].layers);
                }),
                error: lang.hitch(this, function(err) {
                    this._nc4Notify.error(err);
                    this._shelter.hide();
                })
            });
        },

        /**
         * Function to display custom base maps.
         * @param {array} basemapsList - Basemap list.
         */
        _addCustomBaseMapFromService: function(basemapsList) {
            if (this.appUtils.customBaseMapsFromAddLayer === true) {
                dom.byId(this.customBasemapDiv).textContent = "";
                this.appUtils.customBaseMapsFromAddLayer = false;
            }
            var basemap, customBaseMapName, customBasemapUrl, customBasemapId;
            for (var i = 0; i < basemapsList.length; i++) {
                basemap = basemapsList[i];
                customBaseMapName = basemap.name;
                var classBasemap = customBaseMapName.replace(/ /g, "_");
                customBasemapUrl = basemap.url;
                customBasemapId = basemap.id || customBaseMapName; 	//TODO ? should we have name as backup?
                this["main" + classBasemap] = html.create("div", {
                    "class": "basemapGalleryUnSelectedNode",
                    "id": "main" + classBasemap
                }, this.customBasemapDiv);

                this[customBaseMapName] = html.create("div", {
                    "title": customBaseMapName,
                    "class": "customBasemapFromAddLayer",
                    "url": customBasemapUrl,
                    "id": customBasemapId
                }, this["main" + classBasemap]);

                this["delete" + classBasemap] = html.create("div", {
                    "class": "deleteBasemap",
                    "title": "Delete Basemap",
                    "id": basemap.id
                }, this["main" + classBasemap]);

                this[customBaseMapName + "Label"] = html.create("div", {
                    "class": "lblBasemaps"
                }, this[customBaseMapName]);

                html.create("label", {
                    innerHTML: customBaseMapName
                }, this[customBaseMapName + "Label"]);

                on(this["delete" + classBasemap], "click", lang.hitch(this, "_deleteCustomBasemap"));
                on(this[customBaseMapName], "click", lang.hitch(this, function(evt) {									//this[customBaseMapName] points to the div
                	//don't use 'customBaseMapName' by itself, will refer to the last value it was left at.
                	//console.log("evt original target id: " + evt.originalTarget.id);
                	
                	this._shelter.show();
                    var selectedBasemapId, selectedBasemapUrl;
                    this._deselectAllBasemaps();
                    var basemapNode = evt.currentTarget.parentNode;
                    var className = evt.currentTarget.parentNode.className;
                    html.removeClass(basemapNode, className);
                    html.addClass(basemapNode, "basemapGallerySelectedNode");
                    
                    //console.log("evt current taget: " , evt.currentTarget);
                    
                    selectedBasemapId = evt.currentTarget.title;
                    selectedBasemapUrl = evt.currentTarget.attributes.url.value;
                    
                  //James - need to set as current base map - inc case user saves as default
                    //console.log("evt obj: " , evt);
                    this._selectedBaseMap = evt.currentTarget.id;
                    this.appUtils.configGeneralSettings.defaultBaseMap = evt.currentTarget.id;//this[customBaseMapName].id;
                    this._checkBasemapSR(selectedBasemapUrl, selectedBasemapId);
                 
                }));
            }
            this._shelter.hide();
        },

        /**
         * Function to delete custom base maps from service.
         * @param {object} evt - Basemap object
         */
        _deleteCustomBasemap: function(evt) {
            this._shelter.show();
            var basemapNode = evt.currentTarget.parentNode;
            var currentBasemapClass = basemapNode.className;
            var isSelected = currentBasemapClass.indexOf("basemapGallerySelectedNode");
            if (isSelected === -1) {
                var basemapName = evt.target.parentNode.textContent;
                var basemapId = "main" + basemapName;
                var basemapSavedId = evt.target.id;
                var deletePromtMessage = this._alertBox.confirm("Click OK to delete base map.");
                deletePromtMessage.then(lang.hitch(this, function(res) {
                    esriRequest({
                        url: this.config.CustomBasemapDeleteService,
                        content: lang.mixin({
                            customLayerID: basemapSavedId
                        }, null),
                        callbackParamName: "callback",
                        load: lang.hitch(this, function(response) {
                            if (response.success === true) {
                                domConstruct.destroy(basemapId);
                                this._nc4Notify.success("Base map deleted successfully.");
                                this._shelter.hide();
                            } else {
                                this._shelter.hide();
                                this._nc4Notify.error("Unable to delete base map OR base map already deleted");
                            }
                        }),
                        error: lang.hitch(this, function(err) {
                            this._nc4Notify.error(err);
                            this._shelter.hide();
                        })
                    });
                }));
                this._shelter.hide();
            } else {
                this._nc4Notify.warn("Current basemap cannot be deleted");
                this._shelter.hide();
            }
        },

        /**
         * Function to deselect base maps.
         */
        _deselectAllBasemaps: function() {
            array.forEach(this.customBasemapDiv.children, lang.hitch(this, function(basemap) {
                if (basemap.className === "basemapGallerySelectedNode") {
                    html.removeClass(basemap, basemap.className);
                    html.addClass(basemap, "basemapGalleryUnSelectedNode");
                }
            }));
            array.forEach(this.esriBingBasemapDiv.children, lang.hitch(this, function(basemap) {
                if (basemap.className === "basemapGallerySelectedNode") {
                    html.removeClass(basemap, basemap.className);
                    html.addClass(basemap, "basemapGalleryUnSelectedNode");
                }
            }));
        },

        /**
         * Function to get default extent.
         * @param {object} defaultExtent - default extent object
         * @param {string} defaultExtentSpatialRef - spatial reference
         */
        _getDefaultExtent: function(defaultExtent, defaultExtentSpatialRef) {
            var initialExtent, extent;
            if (defaultExtent && (defaultExtent.split(",").length == 4) && defaultExtentSpatialRef) {
                extent = defaultExtent.split(",");
            } else {
                this.log.info("Default extent is undefined or not configured properly. Setting extent to USA.");
                extent = "-14803100.645816434,3095975.801835673,-8120669.885014963,6241512.3898264095".split(",");
                defaultExtentSpatialRef = 4326;
            }
            initialExtent = new Extent({
                "xmin": parseFloat(extent[0]),
                "ymin": parseFloat(extent[1]),
                "xmax": parseFloat(extent[2]),
                "ymax": parseFloat(extent[3]),
                "spatialReference": {
                    "wkid": parseInt(defaultExtentSpatialRef, 10)
                }
            });
            return initialExtent;
        },

        /**
         * Display the panel.
         */
        show: function() {
            if (!this.isOpen) {
                domClass.add(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                this.appUtils.sidePanelOpen(this.isOpen);
            } else {
                this.hide();
            }
        },

        /**
         * Hide the panel
         */
        hide: function() {
            this.isOpen = false;
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
            }
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Widget Related Events
         */
        _attachWidgetRelatedEvents: function() {
        	on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
            }));
            this.own(on(this._btnSetBmDefault, "click", lang.hitch(this, function(evt) {
                this._setDefaultBmClick();
            })));
        },
        
      //TODO: when the default options widget saves, make sure to update default options variables (prevents user from having to refresh)
        
         _setDefaultBmClick: function() {
        	 
                 if (this._selectedBaseMap == null) {
                 	this._nc4Notify.error("Please select a base map to set as default");
                     this._shelter.hide();
                     return false;
                 } else {
                 	
                 	var jsonBmSave = {
                             "mconfig": this.appUtils.configGeneralSettings.defaultBaseMap,
                             "bdefault": this.appUtils.configGeneralSettings.defaultBookmark,
                             "mudefault": this.appUtils.configGeneralSettings.defaultMeasUnit,
                             "odefault": this.appUtils.configGeneralSettings.defaultOpacity,
                             "rdefault": this.appUtils.configGeneralSettings.defaultRefRate,
                             "geomServer": this.appUtils.configGeneralSettings.geometryServiceURL,
                             "gtype": "ArcGIS",
                             "gurl": this.appUtils.configGeneralSettings.geocodeUrl,
                             "maxGResults": this.appUtils.configGeneralSettings.geocodeResults,
                             "printServer": this.appUtils.configGeneralSettings.printService
                         };
                         var objJson = JSON.stringify(jsonBmSave);
                         esriRequest({
                             url: this.config.saveDefaultsOptions,
                             content: lang.mixin({
                                 defaults: objJson
                             }, null),
                             callbackParamName: "callback",
                             load: lang.hitch(this, function(response) {
                                 if (response === true) {
                                 	this._nc4Notify.success("Default base map saved successfully");
                                     this._shelter.hide();
                                 } else {
                                 	this._nc4Notify.error("Unable to save selected base map as default");
                                     this._shelter.hide();
                                 }
                             }),
                             error: lang.hitch(this, function(err) {
                             	this._nc4Notify.error("Unable to save selected base map as default");
                                 this._shelter.hide();
                             })
                         });
                     
                 }
         }
       
    });
    
});
