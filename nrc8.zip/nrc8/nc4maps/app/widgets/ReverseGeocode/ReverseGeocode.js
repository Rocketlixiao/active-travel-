define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/_base/array",
    "dojo/on",
    "dojo/aspect",
    "dojo/_base/lang",
    "dojo/dom-attr",
    "dojo/dom-class",
    "dojo/text!./ReverseGeocodeTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/query",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/registry",
    "esri/graphic",
    "esri/layers/GraphicsLayer",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/Color",
    "esri/request",
    "esri/tasks/locator",
    "esri/InfoTemplate",
    "esri/symbols/SimpleLineSymbol",
    "esri/geometry/webMercatorUtils"
], function(
    declare,
    html,
    array,
    on,
    aspect,
    lang,
    domAttr,
    domClass,
    template,
    sharedNls,
    dojoQuery,
    _WidgetBase,
    _TemplatedMixin,
    registry,
    Graphic,
    GraphicsLayer,
    SimpleMarkerSymbol,
    Color,
    esriRequest,
    Locator,
    InfoTemplate,
    SimpleLineSymbol,
    webMercatorUtils
) {
    var clazz = declare([_WidgetBase, _TemplatedMixin], {
        id: "ReverseGeocode",
    	name: "ReverseGeocode",
        baseClass: "Widget-ReverseGeocode",
        templateString: template,
        sharedNls: sharedNls,
        infoTemplate: null,
        graphic: null,
        bingLocationPoints: null,
        bingGraphic: null,
        _isGeocoderActive: false, //flag to check Geocoder state(active or inactive)
        _handleLocateAddress: null, //handler for 'Locate Address' event (activate/deactivate)
        _handleLocateError: null, //handler for 'Locate Address Error' event (activate/deactivate)
        _handleMapClick: null, //handler for 'Map Click' event (activate/deactivate)
        _graphicsLayer: null,
        _bingGraphicsLayer: null,
        mapPoint: null,
        symbolGraphic: null,

        postCreate: function() {
            html.place(this.domNode, "mapContainerNode");
            domAttr.set(this.revGeocoderDiv, "title", "Show address");
            on(this.revGeocoderDiv, "click", lang.hitch(this, function(){
            	this._disableConflictingWidgets();
            	this._getAddress();
            }));
            
            on(window, "resize", lang.hitch(this, function() {
                setTimeout(lang.hitch(this, function() {
                    if (this.graphic) {
                        this.map.centerAt(this.graphic.geometry);
                    }
                }), 1000);
            }));
            this.symbolGraphic = new SimpleMarkerSymbol(
                SimpleMarkerSymbol.STYLE_CIRCLE,
                15,
                new SimpleLineSymbol(
                    SimpleLineSymbol.STYLE_SOLID,
                    new Color([0, 0, 255, 0.5]),
                    8
                ),
                new Color([0, 0, 255])
            );
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after mail function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
        },

        _disableConflictingWidgets: function() {
        	var widgetIdentify = registry.byId("Identify");
        	if( widgetIdentify != null && widgetIdentify._state == true)
        	{
        		this.appUtils.nc4Notify.warn("Disabling 'Identify' Tool.");
        		widgetIdentify._showHideWidget();
        	}
        },
        
        /**
         * _showHideWidget function is for changing the opacity of the reverse geocoding widget &
         * activating, deactivating the required events based on selection.
         * set flag (_isGeocoderActive) indicating widget state
         */
        _showHideWidget: function() {
            if (!this._isGeocoderActive) {
                domClass.add(this.revGeocoderDiv, "widgetIconFullOpacity");
                //this._hideLayersInfoWindow();
                this._graphicsLayer = new GraphicsLayer();
                this.map.addLayer(this._graphicsLayer);
                this._isGeocoderActive = true;
            } else {
                domClass.remove(this.revGeocoderDiv, "widgetIconFullOpacity");
                //this._showLayersInfoWindow();
                this.map.removeLayer(this._graphicsLayer);
                this._isGeocoderActive = false;
            }
        },

        /**
         * for hiding the infowindow of other layers when this widget is in active state
         */
        _hideLayersInfoWindow: function() {
            var layer;
            array.forEach(this.map.graphicsLayerIds, lang.hitch(this, function(id) {
                layer = this.map.getLayer(id);
                layer.setInfoTemplate(null);
            }));
        },

        /**
         * for showing the infowindow of other layers when this widget is inactive
         */
        _showLayersInfoWindow: function() {
            var layer;
            array.forEach(this.map.graphicsLayerIds, lang.hitch(this, function(id) {
                layer = this.map.getLayer(id);
                layer.setInfoTemplate(this.infoTemplate);
            }));
        },

        _getInfoTemplate: function(p_title, p_content)
        {
        	var pt = "<div  class='infowindow-content '>";
			pt += "<div class='content-wrap'>";
				pt += "<div class='title'>" + p_title + "</div>";
					pt += "</div>";
				pt += "</div>";
				pt += "<div class='infowindow-additional'>";
					pt += "<div class='additional-detail'>";
						pt += p_content;
					pt += "</div>";
				pt+="</div>";
            

			var	infoTemplate = new InfoTemplate("&nbsp;", pt);
			return infoTemplate;
        },
        /**
         * Map click event which gets fired on widgets active state.
         * The point where the user has clicked is sent to locator which either returns the address("location-to-address-complete") or "error".
         */
        _getAddress: function() {
            var locator;
            
            var gUrl = this.appUtils.configGeneralSettings.geocodeUrl;
            if(gUrl.indexOf("nc4geocoder") >= 0 )
            	gUrl = this.appUtils.configGeneralSettings.esriGeocodeServiceURL;
            
            this._showHideWidget();
            if (this._isGeocoderActive) {
            	this.appUtils.nc4Notify.info("'Show Address' Tool Enabled.")
                locator = new Locator(gUrl);
                this.infoTemplate = this._getInfoTemplate("Location", "Address: ${Address}");
                this._handleLocateAddress = locator.on("location-to-address-complete", lang.hitch(this, function(evt) {
                    this._searchAddressUsingEsri(evt);
                }));

                /*'location to adress' error below message popups up*/
                this._handleLocateError = locator.on("error", lang.hitch(this, function(evt) {
                    this.map.infoWindow.hide();
                    this.appUtils.nc4Notify.error(sharedNls.ReverseGeocode.errorMessages.revGeocodeError);
                }));

                /*'Map click' event - to get the location find for locating address*/
                this._handleMapClick = on(this.map, "click", lang.hitch(this, function(evt) {
                    if(!this._isGeocoderActive)
                    	return;
                	if (this.appUtils.configGeneralSettings.service === "Bing") {
                        this._graphicsLayer.clear();
                        this.mapPoint = evt.mapPoint;
                        this._searchAddressUsingBing(evt);
                    } else {
                        this._graphicsLayer.clear();
                        this.mapPoint = evt.mapPoint;
                        locator.locationToAddress(webMercatorUtils.webMercatorToGeographic(evt.mapPoint), 100);
                    }
                }));
            } else {
                /*When the tool is inactive- clear the graphics and infowindow from map. Also remove the active events.*/
                this._graphicsLayer.clear();
                this.map.infoWindow.hide();
                this._handleLocateAddress.remove();
                this._handleLocateError.remove();
                this._handleMapClick.remove();
            }
        },

        /*
         * for searching the address using esri service.
         */
        _searchAddressUsingEsri: function(evt) {
            var address,
                addressLocation,
                zoomTohandler,
                zoomToSpan;
            if (evt.address.address) {
                address = evt.address.address;
                addressLocation = webMercatorUtils.geographicToWebMercator(evt.address.location);
                this.graphic = new Graphic(addressLocation, this.symbolGraphic, address);
                this._graphicsLayer.add(this.graphic);
                this.graphic.setInfoTemplate(this._getInfoTemplate("Location", "${Match_addr}"));
                //this.map.infoWindow.setTitle("Location");
                //this.map.infoWindow.setContent(evt.address.address.Match_addr);
                this.map.infoWindow.setFeatures([this.graphic]);
                this.map.infoWindow.resize(200, 100);
                this.map.infoWindow.show(evt.address.location, {closestFirst: true});//, this.map.getInfoWindowAnchor(this.map.toScreen(addressLocation)));
                zoomToSpan = dojoQuery(".actionList.hidden >a>span")[0];
                if (zoomToSpan) {
                    zoomTohandler = on(zoomToSpan, "click", lang.hitch(this, function() {
                        var currentZoom,
                            maxZoom,
                            zoomToLevel;
                        maxZoom = this.map.getMaxZoom();
                        currentZoom = this.map.getZoom();
                        if (maxZoom > currentZoom) {
                            zoomToLevel = currentZoom + 6;
                            if (zoomToLevel >= maxZoom) {
                                this.map.setZoom(maxZoom);
                            } else {
                                this.map.setZoom(zoomToLevel);
                            }
                            this.map.centerAt(this.mapPoint);
                        }
                    }));
                    on(this.map.infoWindow, "hide", lang.hitch(this, function() {
                        zoomTohandler.remove();
                    }));
                }
            }
        },

        /*
         *for searching the address using bing service.
         */
        _searchAddressUsingBing: function(evt) {
            var latitude,
                longitude,
                layerUrl,
                layersRequest,
                objConvertedToLngLat;
            objConvertedToLngLat = webMercatorUtils.xyToLngLat(evt.mapPoint.x, evt.mapPoint.y);
            evt.mapPoint.x = objConvertedToLngLat[0];
            evt.mapPoint.y = objConvertedToLngLat[1];
            this.bingLocationPoints = evt.mapPoint;
            latitude = evt.mapPoint.y;
            longitude = evt.mapPoint.x;
            layerUrl = "nc4proxy.jsp?" + this.appUtils.configGeneralSettings.bingGeocodeServiceURL + latitude + "," + longitude + "?o=json&key=" + this.appUtils.configGeneralSettings.bingAccessKey;
            layersRequest = esriRequest({
                url: layerUrl,
                handleAs: "json"
            });
            layersRequest.then(lang.hitch(this, function(response) {
                this._displayAddressUsingBing(response);
            }), this._requestFailed);
        },

        /*
         *for displying address using bing service.
         */
        _displayAddressUsingBing: function(response) {
            var address,
                addressLocation,
                zoomToSpan;
            if (response.resourceSets[0].resources.length !== 0) {
                address = response.resourceSets[0].resources[0].name;
                addressLocation = webMercatorUtils.geographicToWebMercator(this.bingLocationPoints);
                this.bingGraphic = new Graphic(addressLocation, this.symbolGraphic, address);
                this._graphicsLayer.add(this.bingGraphic);
                this.bingGraphic.setInfoTemplate(this._getInfoTemplate("Location", address));
                // this.map.infoWindow.setTitle("Location");
                // this.map.infoWindow.setContent(address);
                this.map.infoWindow.setFeatures([this.bingGraphic]);
                this.map.infoWindow.resize(200, 100);
                this.map.infoWindow.show(addressLocation, {closestFirst: true}); // this.map.getInfoWindowAnchor(this.map.toScreen(addressLocation)));
                zoomToSpan = dojoQuery(".actionList.hidden >a>span")[0];
                if (zoomToSpan) {
                    var zoomTohandler = on(zoomToSpan, "click", lang.hitch(this, function() {
                        var currentZoom,
                            maxZoom,
                            zoomToLevel;
                        maxZoom = this.map.getMaxZoom();
                        currentZoom = this.map.getZoom();
                        if (maxZoom > currentZoom) {
                            zoomToLevel = currentZoom + 6;
                            if (zoomToLevel >= maxZoom) {
                                this.map.setZoom(maxZoom);
                            } else {
                                this.map.setZoom(zoomToLevel);
                            }
                            this.map.centerAt(this.bingGraphic.geometry);
                        }
                    }));
                    on(this.map.infoWindow, "hide", lang.hitch(this, function() {
                        zoomTohandler.remove();
                    }));
                }
            } else {
                this.map.infoWindow.hide();
                this.appUtils.nc4Notify.error(sharedNls.ReverseGeocode.errorMessages.revGeocodeError);
            }
        },

        /*
         *For exception handler.
         */
        _requestFailed: function(err) {
        	this.appUtils.nc4Notify.error(err);
        }
    });
    return clazz;
});
