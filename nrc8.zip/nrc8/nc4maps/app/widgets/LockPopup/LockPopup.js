define([
    "dojo/_base/declare",
    "dojo/query",
    "dojo/on",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dijit/_WidgetBase",
    "dojo/dom-class"
], function(declare, query, on, html, lang, domStyle, _WidgetBase, domClass) {
    return declare([_WidgetBase], {
    	_state: false, //default to not locked
		_lockpopup: null,
		
        postCreate: function() {
            this.inherited(arguments);
           
                /**
                 * Create and place 'Help' button widget to show help page.
                 */
            var zoomOut = query(".esriSimpleSliderDecrementButton");
			if (zoomOut.length > 0) {
                this._lockpopup = html.create("div", {
                    "title": this.config.label,
                    "class": "widget-Lockpopup"
                }, null);
                html.place(this._lockpopup, zoomOut[0], "after");
                if(this.config.left)
                	domStyle.set(this._lockpopup, "left", this.config.left);
                if(this.config.top)
                	domStyle.set(this._lockpopup, "top", this.config.top);
                on(this._lockpopup, "click", lang.hitch(this, function(){
                	this._showHideWidget();
                }));
			}
       },
        
        /**
         * _showHideWidget function is for changing the opacity of the reverse geocoding widget &
         * activating, deactivating the required events based on selection.
         * set flag (_isGeocoderActive) indicating widget state
         */
        _showHideWidget: function() {
            if (!this._state) {
                domClass.add(this._lockpopup, "widgetIconFullOpacity");
                this._state=true;
                this.map.infoWindow.multiple = true;
                this.appUtils.nc4Notify.info("'Lock Pop-ups' Tool Enabled.")
            } else {
                domClass.remove(this._lockpopup, "widgetIconFullOpacity");
                this._state=false;
                this.map.infoWindow.multiple = false;
                this.appUtils.nc4Notify.info("'Lock Pop-ups' Tool Disabled.")
            }
        }

    });
});
