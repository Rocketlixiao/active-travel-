define([
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/_base/html",
    "dojo/on",
    "dojo/dom",
    "dojo/dom-attr",
    "dojo/text!./CustomIcons.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/query",
    "dijit/_TemplatedMixin",
    "dijit/form/Select",
    "dijit/form/RadioButton",
    "dijit/form/ValidationTextBox",
    "dijit/form/Button",
    "dijit/_WidgetBase",
    "esri/request",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter",
    "lodash/lodash"
], function(
    declare,
    array,
    lang,
    html,
    on,
    dom,
    domAttr,
    template,
    sharedNls,
    query,
    _TemplatedMixin,
    Select,
    RadioButton,
    ValidationTextBox,
    Button,
    _WidgetBase,
    esriRequest,
    WidgetPanel,
    LoadingShelter,
    _
) {
    var clazz = declare([_WidgetBase, _TemplatedMixin], {
        name: "Custom Icons",
        baseClass: "widget-CustomIcons",
        sharedNls: sharedNls,
        templateString: template,
        isOpen: false,
        _shelter: null,
        _panel: null,
        _reportType: null,
        _arrReportTypes: null,
        _arrSubReportValue: null,
        _selectedReportFeild: [],
        _iconSuggestLabel: null,
        _arrIconSuggestValue: [],
        _colorSuggestValue: [],
        _arrColorSuggestValue: null,
        _count: 0,
        _btnSave: null,
        _field1: null,
        _field2: null,
        _field3: null,
        _customIconPath: null,
        _uploadIconData: null,
        _uploadIconName: null,
        _iconCount: 0,
        _iconPreview: null,
        canvasCtx: null,
        _customImgURL: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },


        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
         */
        postCreate: function() {
            this.inherited(arguments);
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetCustomIconsIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
        	this._nc4Notify = this.appUtils.nc4Notify;
            this._reportType = new Select({
                options: [{
                    label: sharedNls.CustomIcons.select,
                    value: sharedNls.CustomIcons.select
                }]
            });
            this._reportType.placeAt(this.reportsTypeNode).startup();
            this._createWidgetUI();
            this.lblCustomImage.textContent = sharedNls.CustomIcons.suggestedIcon;
            this._btnSave = new Button({
                label: sharedNls.CustomIcons.save
            }, this.savediv);
            this._attachWidgetRelatedEvents();
            html.addClass(this.customImageNode, "hide");
            html.removeClass(this.customImageNode, "show");
            this._arrSubReportValue.disabled = true;
            this._colorSuggestLabel.disabled = true;
        },


        /**
         * Create widget UI.
         * Combo box to select layer type and display information related to selected type.
         */
        _createWidgetUI: function() {
            this._count = 0;
            this._getReportTypeValues();
            domAttr.set(this.fieldReportValueLabelNode, "innerHTML", sharedNls.CustomIcons.subReportType);
            domAttr.set(this.colorLabelNode, "innerHTML", sharedNls.CustomIcons.status);
            this._arrSubReportValue = new Select({
                options: [{
                    label: sharedNls.CustomIcons.select,
                    value: sharedNls.CustomIcons.select
                }]
            });
            this._arrSubReportValue.placeAt(this.fieldReportValueNode).startup();
            this._colorSuggestLabel = new Select({
                options: [{
                    label: sharedNls.CustomIcons.select,
                    value: sharedNls.CustomIcons.select
                }]
            });
            this._colorSuggestLabel.placeAt(this.colorValueNode).startup();
            this._iconUpload();
        },

        /**
         * This function is upload the icons .
         */
        _iconUpload: function() {
            var imageChooseButton = dom.byId("icon");
            on(imageChooseButton, "change", lang.hitch(this, function(evt) {
                var cxt,
                    base64IconUpload,
                    reader;
                this._customImgURL = null;
                this.imageFile = evt.target.files[0];
                this._uploadIconName = this.imageFile.name;
                reader = new FileReader();
                reader.onload = lang.hitch(this, function(event) {
                    this._iconPreview = new Image();
                    this._iconPreview.onload = lang.hitch(this, function(evt) {
                        this.canvasCtx = document.getElementById("panel");
                        this.canvasCtx.height = this._iconPreview.height;
                        this.canvasCtx.width = this._iconPreview.width;
                        cxt = this.canvasCtx.getContext("2d");
                        cxt.drawImage(this._iconPreview, 0, 0);
                        html.setStyle(this.canvasCtx, {
                            "background-color": "gray"
                        });
                        on(this.canvasCtx, "click", lang.hitch(this, function(evt) {
                            var removeSelectedClass = query(".selectedCustomIcon");
                            if (removeSelectedClass.length > 0) {
                                html.removeClass(removeSelectedClass[0], "selectedCustomIcon");
                                html.addClass(removeSelectedClass[0], "displayCustomIcon");
                                this._customImgURL = null;
                            }
                            if (this.canvasCtx) {
                                html.setStyle(this.canvasCtx, {
                                    "background-color": "gray"
                                });
                            }
                            this._uploadIconData = base64IconUpload.replace(/^data:image\/(png|jpg|gif);base64,/, "");
                        }));
                    });
                    base64IconUpload = event.target.result;
                    this._iconPreview.src = base64IconUpload;
                    this._uploadIconData = base64IconUpload.replace(/^data:image\/(png|jpg|gif);base64,/, "");
                    this.imgHeightNode.value = this._iconPreview.height;
                    this.imgWidthNode.value = this._iconPreview.width;
                    var removeSelectedClass = query(".selectedCustomIcon");
                    if (removeSelectedClass.length > 0) {
                        html.removeClass(removeSelectedClass[0], "selectedCustomIcon");
                        html.addClass(removeSelectedClass[0], "displayCustomIcon");
                    }
                });
                reader.readAsDataURL(this.imageFile);
            }));
        },

        /**
         * This function is fetching the report type list values.
         */
        _getReportTypeValues: function() {
            esriRequest({
                url: this.config.reportTypeURL,
                content: lang.mixin({
                    f: "json"
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, this._getReportTypes),
                error: lang.hitch(this, this._onErrordelete)
            });
        },

        /**
         * Get the report type list and passing to "drop down list".
         * @param(value) reportTypes - reportTypes selected value from the report type dropdown.
         */
        _getReportTypes: function(reportTypes) {
            this._arrReportTypes = [];
            for (var i = 0; i < reportTypes.length; i++) {
                if (reportTypes[i] === null) {
                    this._arrReportTypes.push("none");
                } else {
                    this._arrReportTypes.push(reportTypes[i]);
                }
            }
            array.forEach(this._arrReportTypes, lang.hitch(this, function(layer) {
                	this._reportType.addOption({
                        label: layer.name,
                        value: layer.id
                    });
            	
            }));
            this._shelter.hide();
        },

        /**
         * This function is fetching the sub report type list values.
         * @param(value) objSelectedValue - objSelectedValue selected value from the report type dropdown.
         */
        _getSelectedReportField: function(objSelectedValue) {
            this._count = 0;
            this._field1 = objSelectedValue;
            esriRequest({
                url: this.config.subReportTypeURL,
                content: lang.mixin({
                    f: "json",
                    field1: this._field1
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, this._getReportFeildValues),
                error: lang.hitch(this, this._onErrordelete)
            });
        },

        /**
         * This function is displays the sub report type list values.
         * @param(value) getReportFeilds - list of sub report type values.
         */
        _getReportFeildValues: function(getReportFeilds) {
            this._selectedReportFeild = [];
            this._arrSubReportValue.options = [];
            for (var j = 0; j < getReportFeilds.length; j++) {
                if (getReportFeilds[j] === null) {
                    this._selectedReportFeild.push("none");
                    this._arrSubReportValue.disabled = false;
                } else {
                    this._selectedReportFeild.push(getReportFeilds[j]);
                    this._arrSubReportValue.disabled = false;
                }
            }
            if (this._arrSubReportValue.options.length === 0) {
                this._arrSubReportValue.addOption({
                    label: sharedNls.CustomIcons.select,
                    value: sharedNls.CustomIcons.select
                });
            }
            if (getReportFeilds.length <= 0) {
                this._arrSubReportValue.addOption({
                    label: "none",
                    value: "none"
                });
                this._arrSubReportValue.disabled = false;

            }
            array.forEach(this._selectedReportFeild, lang.hitch(this, function(layer) {
                this._arrSubReportValue.addOption({
                    label: layer.name,
                    value: layer.id
                });
            }));
            this._shelter.hide();
        },

        /**
         * This function is fetching the status list values.
         * @param(value) objIconValue - selected value from the sub report type dropdown.
         */
        _getSelectedFieldReportValue: function(objIconValue) {
            this._count = 0;
            this._field2 = objIconValue;
            if (objIconValue === "none") {
                this._field2 = null;
            }
            esriRequest({
                url: this.config.iconStatusURL,
                content: lang.mixin({
                    f: "json",
                    field1: this._field1,
                    field2: this._field2
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, this._getColorValue),
                error: lang.hitch(this, this._onErrordelete)
            });
        },

        /**
         * This function is displays the status type list values.
         * @param(value) getColorValue - list of status type values.
         */
        _getColorValue: function(getColorValue) {
            this._arrColorSuggestValue = [];
            this._colorSuggestLabel.options = [];
            for (var j = 0; j < getColorValue.length; j++) {
                if (getColorValue[j] === null) {
                    this._arrColorSuggestValue.push("none");
                    this._colorSuggestLabel.disabled = false;
                } else {
                    this._arrColorSuggestValue.push(getColorValue[j]);
                    this._colorSuggestLabel.disabled = false;
                }
            }
            if (this._colorSuggestLabel.options.length === 0) {
                this._colorSuggestLabel.addOption({
                    label: sharedNls.CustomIcons.select,
                    value: sharedNls.CustomIcons.select
                });
            }
            array.forEach(this._arrColorSuggestValue, lang.hitch(this, function(layer) {
                this._colorSuggestLabel.addOption({
                    label: layer,
                    value: layer
                });
            }));
            this._shelter.hide();
        },

        /**
         * This function is fetch the unique icon.
         * @param(value) getUniqueValue - selected value from the status type dropdown
         */
        _getUnqiueValue: function(getUniqueValue) {
            this._field3 = getUniqueValue;
            this.appUtils.log.info("getUniqueValue: " , getUniqueValue);

            if (getUniqueValue === "Select One") {
                this._CustomIconsDivHide();
                this._shelter.hide();
                return false;
            }
            if (getUniqueValue === "" || getUniqueValue === "none" || getUniqueValue === "NULL") {
                this._field3 = null;
            }
            esriRequest({
                url: this.config.uniqueValueIconURL,
                content: lang.mixin({
                    f: "json",
                    field1: this._field1,
                    field2: this._field2,
                    field3: this._field3
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, this._unqiueValueUI),
                error: lang.hitch(this, this._onErrordelete)
            });
            this._getSelectedColorValue(getUniqueValue);
        },

        /**
         * This function is displays the unique icon.
         * @param(value) unqiueValue - selected value from the status type dropdown
         */
        _unqiueValueUI: function(unqiueValue) {
        	this.appUtils.log.info("_unqiueValueUI.uniqueValue: " , unqiueValue);
            var imgUniqueUrl, imgDefaultUrl, unqiueImage, defaultImage;
            html.removeClass(this.currentIconNode, "hide");
            html.addClass(this.currentIconNode, "show");
            html.empty(this.iconCurrentImgNode);
            html.empty(this.iconCurrentLabelNode);
            html.empty(this.iconDefaultLabelNode);
            html.empty(this.iconDefaultImgNode);
            html.empty(this.iconCurrentImgNodeDelete);

            this._customIconPath = unqiueValue.customIcon || "";
            
            try
            {
            	if (this._customIconPath)
            	{
            		html.removeClass(this.iconCurrentLabelNode, "hide");
            		html.removeClass(this.iconCurrentImgNode, "hide");
            		html.addClass(this.iconCurrentLabelNode, "show");
            		html.addClass(this.iconCurrentImgNode, "show");
            		imgUniqueUrl = this._customIconPath; 
            		 domAttr.set(this.iconCurrentLabelNode, "innerHTML", sharedNls.CustomIcons.currentIcon);
                     unqiueImage = html.create("img", {
                         "src": imgUniqueUrl
                     }, this.iconCurrentImgNode);
                     //delete button:
                    var deletebtn = dojo.create("img", { "src": "app/images/delete.svg", title: "Delete" }, this.iconCurrentImgNodeDelete);
                    on(deletebtn, "click", lang.hitch(this, function(){
                    	this.appUtils.log.info("this: " , this);
                    	try
                    	{

                        	esriRequest({
                                url: this.config.removeCustomIconURL,
                                content: lang.mixin({
                                    f: "json",
                                    field1: this._field1,
                                    field2: this._field2,
                                    field3: this._field3,
                                    path: this._customIconPath
                                }, null),
                                callbackParamName: "callback",
                                load: lang.hitch(this, function(){
                                	this._getUnqiueValue(this._field3);
                                	}),
                                error: lang.hitch(this, this._onErrordelete)
                            });
                    	}
                    	catch(error)
                    	{
                    		console.error("unable to delete: , " + error);
                    	}
                    }));
                     
            	}
            	else
            	{
            		html.addClass(this.iconCurrentLabelNode, "hide");
            		html.addClass(this.iconCurrentImgNode, "hide");
            	}
            	
                imgDefaultUrl = unqiueValue.eteamIcon;
                domAttr.set(this.iconDefaultLabelNode, "innerHTML", sharedNls.CustomIcons.defaultIcon);
                defaultImage = html.create("img", {
                    "src": imgDefaultUrl
                }, this.iconDefaultImgNode);
                this._shelter.hide();
            }
            catch(error)
            {
            	console.error("exception retreiving current and custom icon. ", error);
            	return;
            }
           
        },

        /**
         * This function is fetch the custom icons.
         * @param(value) objIconValue - selected value from the status type dropdown
         */
        _getSelectedColorValue: function(objIconValue) {
            this._field3 = objIconValue;
            if (objIconValue === "none") {
                this._field3 = null;
            }
            esriRequest({
                url: this.config.iconSuggestURL,
                content: lang.mixin({
                    f: "json",
                    field: this._field3
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, this._dynamicUI),
                error: lang.hitch(this, this._onErrordelete)
            });
        },

        /**
         * This function to displays the error results while getting unique values results and  status results.
         * @param(value) err - shows the error message
         */
        _onErrordelete: function(err) {
            this._nc4Notify.error(err);
            this._shelter.hide();
        },

        /**
         * This function is creating UI for custom icons.
         * @param(value) iconImages - displays the custom icons
         */
        _dynamicUI: function(iconImages) {
            this._count = 0;
            this._iconCount = 0;
            this._arrIconSuggestValue = [];
            html.addClass(this.customImageNode, "show");
            html.removeClass(this.customImageNode, "hide");
            html.empty(this.imgCustomNode);
            for (var j = 0; j < iconImages.length; j++) {
                if (iconImages[j]) {
                    this._arrIconSuggestValue.push(iconImages[j]);
                }
            }
            array.forEach(this._arrIconSuggestValue, lang.hitch(this, function(imgURL) {
                this._arrIconSuggestValue = [];
                var customImgName,
                    dynmainImgCreate,
                    imageURL = imgURL;
                dynmainImgCreate = html.create("div", {
                    "class": "displayCustomIcon",
                    "id": "icon" + this._iconCount++,
                    "ImageUrl": imageURL
                }, this.imgCustomNode);
                customImgName = html.create("img", {
                    "id": "img" + this._iconCount++,
                    "src": imageURL
                }, dynmainImgCreate);
                domAttr.set(dynmainImgCreate, "customIconPath", imageURL);
                on(dynmainImgCreate, "click", lang.hitch(this, function(evt) {
                    this._uploadIconData = null;
                    var removeSelectedClass = query(".selectedCustomIcon");
                    if (removeSelectedClass.length > 0) {
                        html.removeClass(removeSelectedClass[0], "selectedCustomIcon");
                        html.addClass(removeSelectedClass[0], "displayCustomIcon");
                        this._customImgURL = null;
                    }
                    this._customImgURL = domAttr.get(evt.currentTarget.id, "customIconPath");
                    html.removeClass(evt.currentTarget.id, "displayCustomIcon");
                    html.addClass(evt.currentTarget.id, "selectedCustomIcon");
                    if (this.canvasCtx) {
                        html.setStyle(this.canvasCtx, {
                            "background-color": "transparent"
                        });
                    }
                }));
            }));
            this._shelter.hide();
        },

        /**
         * This function is save the custom icons
         */
        btnSaveIcon: function(evt) {
            this._shelter.show();
            var base64String = this._uploadIconData;
            if (base64String === null && this._customImgURL === null) {
                this._nc4Notify.error(sharedNls.CustomIcons.selectOneIcon);
                this._shelter.hide();
            } else if (base64String != null && this._customImgURL === null) {
                this._uploadIconSave();
            } else if (this._customImgURL != null && base64String === null) {
                this._customIconSave();
            }
        },

        /**
         * This function will save the uploaded icons
         */
        _uploadIconSave: function() {
            var base64String,
                iconName,
                fileName,
                imgExt;
            iconName = this._uploadIconName.split(".");
            base64String = this._uploadIconData;
            fileName = iconName[0];
            imgExt = iconName[1];
            esriRequest({
                url: this.config.setCustomIconURL,
                content: lang.mixin({
                    f: "json",
                    field1: this._field1,
                    field2: this._field2,
                    field3: this._field3,
                    name: fileName,
                    ext: imgExt,
                    base64string: base64String
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, function(response) {
                    if (response === true) {
                        this._nc4Notify.success(sharedNls.CustomIcons.saveSuccess);
                        this._shelter.hide();
                    } else {
                        this._nc4Notify.error(sharedNls.CustomIcons.saveError);
                        this._shelter.hide();
                    }
                  //refresh display with new icon or current icon in case of fail
                    this._getUnqiueValue(this._field3);
                }),
                error: lang.hitch(this, this._onErrordelete)
            });
        },

        /**
         * This function will save the custom icons
         */
        _customIconSave: function() {
            var iconName,
                fileName,
                imgPath,
                imgExt;
            imgPath = this._customImgURL.substring(this._customImgURL.lastIndexOf("/") + 1);
            iconName = imgPath.split(".");
            fileName = iconName[0];
            imgExt = iconName[1];
            esriRequest({
                url: this.config.setCustomIconURL,
                content: lang.mixin({
                    f: "json",
                    field1: this._field1,
                    field2: this._field2,
                    field3: this._field3,
                    name: fileName,
                    ext: imgExt,
                    customIconPath: this._customImgURL
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, function(response) {
                    if (response === true) {
                        this._nc4Notify.success(sharedNls.CustomIcons.saveSuccess);
                        this._shelter.hide();
                    } else {
                        this._nc4Notify.error(sharedNls.CustomIcons.saveError);
                        this._shelter.hide();
                    }
                  //refresh display with new icon or current icon in case of fail
                    this._getUnqiueValue(this._field3);
                }),
                error: lang.hitch(this, this._onErrordelete)
            });

        },
        /**
         * Display the widget panel.
         */
        show: function() {
            if (!this.isOpen) {
                html.addClass(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                this.appUtils.sidePanelOpen(this.isOpen);
                html.empty(this.iconCurrentImgNode);
                html.empty(this.iconDefaultImgNode);
                html.empty(this.imgCustomNode);
                html.empty(this.iconCurrentImgNodeDelete);
                this._CustomIconsDivHide();
                this._reportType.reset();
                this._arrSubReportValue.disabled = true;
                this._colorSuggestLabel.disabled = true;
                if (this.canvasCtx) {
                    this._uploadIconName = "";
                    document.getElementById("icon").value = "";
                    var cxt = this.canvasCtx.getContext("2d");
                    html.setStyle(this.canvasCtx, {
                        "background-color": "transparent"
                    });
                    cxt.clearRect(0, 0, this.canvasCtx.width, this.canvasCtx.height);
                    this.imgWidthNode.value = "";
                    this.imgHeightNode.value = "";
                    this._customImgURL = null;
                    this._uploadIconData = null;
                    this.canvasCtx = null;
                }
            } else {
                this.hide();
            }
        },

        /**
         * Hide the widget panel
         */
        hide: function() {
            this.isOpen = false;
            html.removeClass(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
            }
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Attach widget related events
         */
        _attachWidgetRelatedEvents: function() {
        	on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
            }));
            on(this._btnSave, "click", lang.hitch(this, function(evt) {
                this.btnSaveIcon(evt);
            }));
            on(this.imgHeightNode, "change", lang.hitch(this, function(evt) {
                var heightValue,
                    isValidHeight,
                    regexp = /^[0-9\b]+$/;
                heightValue = this.imgHeightNode.value;
                isValidHeight = regexp.test(heightValue);
                if (isValidHeight === false && heightValue !== "") {
                    this._nc4Notify.error(sharedNls.CustomIcons.validValues);
                    this._shelter.hide();
                    return false;
                } else if (heightValue === "" && this._uploadIconName) {
                    this.imgHeightNode.value = this._iconPreview.height;
                }
            }));
            this._iconPositionChange();
            this._arrFeildReportTypeChange();
            this._arrSubReportTypeChange();
            this._arrStatusChange();
        },

        /**
         * This function is set the height and width for uploaded icons
         */
        _iconPositionChange: function() {
            on(this.imgWidthNode, "change", lang.hitch(this, function(evt) {
                var base64IconUpload,
                    cxt,
                    widthValue,
                    isValidWidth,
                    regexp = /^[0-9\b]+$/;
                widthValue = this.imgWidthNode.value;
                isValidWidth = regexp.test(widthValue);
                if (isValidWidth === false && widthValue !== "") {
                    this._nc4Notify.error(sharedNls.CustomIcons.validValues);
                    this._shelter.hide();
                    return false;
                } else if (widthValue === "" && this._uploadIconName) {
                    this.imgWidthNode.value = this._iconPreview.width;
                }
                if (this._uploadIconName) {
                    this.canvasCtx.width = this.imgWidthNode.value;
                    this.canvasCtx.height = this.imgHeightNode.value;
                    cxt = this.canvasCtx.getContext("2d");
                    cxt.drawImage(this._iconPreview, 0, 0, this.imgWidthNode.value, this.imgHeightNode.value);
                    base64IconUpload = this.canvasCtx.toDataURL("image/gif");
                }
            }));
        },

        /**
         * Attach related events for report type
         */
        _arrFeildReportTypeChange: function() {
            on(this._reportType, "change", lang.hitch(this, function(option) {
                this._shelter.show();
                if (this._reportType.value === "Select One") {
                    if (this._count === 0) {
                        this._arrSubReportValue.disabled = true;
                        this._colorSuggestLabel.disabled = true;
                        this._arrSubReportValue.reset();
                        this._arrSubReportValue.options = [];
                        if (this._arrSubReportValue.options.length === 0) {
                            this._arrSubReportValue.addOption({
                                label: sharedNls.CustomIcons.select,
                                value: sharedNls.CustomIcons.select
                            });
                        }
                        this._shelter.hide();
                        this._count++;
                        return false;
                    }
                }
                this._CustomIconsDivHide();
                if (this.canvasCtx) {
                    this._uploadIconName = "";
                    document.getElementById("icon").value = "";
                    var cxt = this.canvasCtx.getContext("2d");
                    cxt.clearRect(0, 0, this.canvasCtx.width, this.canvasCtx.height);
                    html.setStyle(this.canvasCtx, {
                        "background-color": "transparent"
                    });
                    this.imgWidthNode.value = "";
                    this.imgHeightNode.value = "";
                    this.canvasCtx = null;
                }
                this._customImgURL = null;
                this._uploadIconData = null;
                this._getSelectedReportField(option);
                this._colorSuggestLabel.reset();
                this._colorSuggestLabel.options = [];
                if (this._colorSuggestLabel.options.length === 0) {
                    this._colorSuggestLabel.addOption({
                        label: sharedNls.CustomIcons.select,
                        value: sharedNls.CustomIcons.select
                    });
                }
                this._colorSuggestLabel.disabled = true;
            }));
        },

        /**
         * Attach related events for sub report type
         */
        _arrSubReportTypeChange: function() {
            on(this._arrSubReportValue, "change", lang.hitch(this, function(option) {
                this._shelter.show();
                if (this._arrSubReportValue.value === "Select One") {
                    if (this._count === 0) {
                        this._getSelectedFieldReportValue(option);
                        this._shelter.hide();
                        this._colorSuggestLabel.disabled = true;
                        this._CustomIconsDivHide();
                        this._count++;
                        return false;
                    }
                }
                this._CustomIconsDivHide();
                if (this.canvasCtx) {
                    this._uploadIconName = "";
                    document.getElementById("icon").value = "";
                    var cxt = this.canvasCtx.getContext("2d");
                    html.setStyle(this.canvasCtx, {
                        "background-color": "transparent"
                    });
                    cxt.clearRect(0, 0, this.canvasCtx.width, this.canvasCtx.height);
                    this.imgWidthNode.value = "";
                    this.imgHeightNode.value = "";
                    this.canvasCtx = null;
                }
                this._customImgURL = null;
                this._uploadIconData = null;
                this._getSelectedFieldReportValue(option);
                //   this._colorSuggestLabel.disabled = false;

            }));
        },

        /**
         * Attach related events for status type
         */
        _arrStatusChange: function() {
            on(this._colorSuggestLabel, "change", lang.hitch(this, function(option) {
                this._shelter.show();
                if (this._colorSuggestLabel.value === "Select One") {
                    if (this._count === 0) {
                        this._CustomIconsDivHide();
                        if (this.canvasCtx) {
                            this._uploadIconName = "";
                            document.getElementById("icon").value = "";
                            var cxt = this.canvasCtx.getContext("2d");
                            html.setStyle(this.canvasCtx, {
                                "background-color": "transparent"
                            });
                            cxt.clearRect(0, 0, this.canvasCtx.width, this.canvasCtx.height);
                            this.imgWidthNode.value = "";
                            this.imgHeightNode.value = "";
                            this._customImgURL = null;
                            this._uploadIconData = null;
                            this.canvasCtx = null;
                        }
                        this._shelter.hide();
                        this._count++;
                        return false;
                    }
                }
                this._customImgURL = null;
                this._getUnqiueValue(option);
            }));
        },

        /**
         * Custom Icon container show and hide
         */
        _CustomIconsDivHide: function() {
            html.addClass(this.customImageNode, "hide");
            html.removeClass(this.customImageNode, "show");
            html.addClass(this.currentIconNode, "hide");
            html.removeClass(this.currentIconNode, "show");
        }
    });
    return clazz;
});
