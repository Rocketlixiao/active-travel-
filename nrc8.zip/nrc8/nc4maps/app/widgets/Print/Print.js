define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/on",
    "dojo/dom",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/dom-attr",
    "dojo/text!./PrintTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/aspect",
    "dojo/query",
    "dojo/json",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/form/Select",
    "dijit/form/TextBox",
    "dijit/form/Button",
    "esri/tasks/PrintTemplate",
    "esri/tasks/LegendLayer",
    "esri/layers/FeatureLayer",
    "esri/IdentityManager",
    "esri/tasks/Geoprocessor",
    "app/widgets/Print/ExportToWebMap",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter"
], function (
    declare,
    html,
    lang,
    arrayUtils,
    on,
    dom,
    domClass,
    domConstruct,
    domAttr,
    template,
    sharedNls,
    aspect,
    query,
    JSON,
    _WidgetsInTemplateMixin,
    _WidgetBase,
    _TemplatedMixin,
    Select,
    TextBox,
    Button,
    PrintTemplate,
    LegendLayer,
    FeatureLayer,
    IdentityManager,
    Geoprocessor,
    ExportToWebMap,
    WidgetPanel,
    LoadingShelter
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        name: "Print",
        baseClass: "widget-Print",
        templateString: template,
        sharedNls: sharedNls,
        _shelter: null,
        isOpen: false,
        _panel: null,
        _dynamicPrintContainer: null,
        _printdata: {},
        _PrintId: 0,
        _btnClear: null,
        defObj: null,
        printformat: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },

        postCreate: function () {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetPrintIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: true
            });
            this._shelter.placeAt(this.domNode);
            this._nc4Notify = this.appUtils.nc4Notify;
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            this._attachWidgetRelatedEvents();
            this._dynamicPrintContainer = html.create("div", {
                "class": "test"
            }, this.printImage);
            this._btnClear = new Button({
                label: "Clear",
                "class": "hide"
            }, this.clearButton);
            this._getPrintInfo();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after mail function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function () {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
        },

        // get print templates from the export web map task
        _getPrintInfo: function () {
            require(["esri/dijit/Print",
                "esri/tasks/PrintTask",
                "esri/tasks/PrintParameters",
                "esri/request"
            ], lang.hitch(this, function (Print, PrintTask, PrintParameters, esriRequest) {
                this.printTask = new PrintTask(this.appUtils.configGeneralSettings.printService);
                this.printParam = new PrintParameters();
                // get print templates from the export web map task
                this.printInfo = esriRequest({
                    "url": this.appUtils.configGeneralSettings.printService,
                    "content": {
                        "f": "json"
                    }
                });
                this.printInfo.then(lang.hitch(this, this._handlePrintInfo), lang.hitch(this, this._handleError));
            }));
        },

        //fetching the PrintLayout and PrintFormat values from the print service
        _handlePrintInfo: function (resp) {
            var formatSupported, layoutTemplate, mapOnlyIndex, printFormat, templateNames;
            layoutTemplate = arrayUtils.filter(resp.parameters, function (param, idx) {
                return param.name === "Layout_Template";
            });
            if (layoutTemplate.length === 0) {
                console.log("print service parameters name for templates must be \"Layout_Template\"");
                return;
            }
            var layoutOptions = [];
            for (var i = 0; i < layoutTemplate[0].choiceList.length; i++) {
                layoutOptions.push(layoutTemplate[0].choiceList[i]);
            }
            templateNames = this._getColumnName(layoutOptions);

            mapOnlyIndex = arrayUtils.indexOf(templateNames, "MAP_ONLY");
            if (mapOnlyIndex > -1) {
                var mapOnly = templateNames.splice(mapOnlyIndex, mapOnlyIndex + 1)[0];
                templateNames.push(mapOnly);
            }

            formatSupported = arrayUtils.filter(resp.parameters, function (param, idx) {
                return param.name === "Format";
            });

            if (formatSupported.length === 0) {
                console.log("print service parameters name for format must be \"Format\"");
                return;
            }

            printFormat = this._getColumnName(formatSupported[0].choiceList);
            this.printFormat.set("options", printFormat);
            this.printFormat.set("disabled", false);
            this.printFormat.startup();
            this.printLayout.set("options", templateNames);
            this.printLayout.set("disabled", false);
            this.printLayout.startup();
            this._shelter.hide();
        },

        /**
        * Validation for PrintLayout and PrintFormat fields in print widget
        */
        _printMap: function () {
            var i, legendLayers, legends;
            if (this.printLayout.value === "" || this.printLayout.value === "Select one") {
                this._nc4Notify.warn(sharedNls.Print.emptyURL);
                this._shelter.hide();
                return false;
            } else if (this.printTitle.value === "") {
                this._nc4Notify.warn(sharedNls.Print.emptyURL);
                this._shelter.hide();
                return false;
            } else if (this.printFormat.value === "" || this.printFormat.value === "Select one") {
                this._nc4Notify.warn(sharedNls.Print.emptyURL);
                this._shelter.hide();
                return false;
            }

            legendLayers = arrayUtils.map(this.map.graphicsLayerIds, lang.hitch(this, function (graphicsLayerID) {
                var featureLayer = this.map.getLayer(graphicsLayerID);
                if (featureLayer.type === "Feature Layer" && featureLayer.url) {
                    var legendLayer = new LegendLayer();
                    legendLayer.layerId = graphicsLayerID;
                    return legendLayer;
                }
            }));

            legends = [];
            for (i = 0; i < legendLayers.length; i++) {
                if (legendLayers[i] !== undefined) {
                    legends.push(legendLayers[i]);
                }
            }
            this._shelter.show("Printing");
            this._getfeatureInfo();
        },

        /**
        * Validation for PrintLayout and PrintFormat fields in print widget
        * @param {object} response - fetch the response from the geoprocess service
        * @param {string} id - ID for print service.
        */
        _PrintFormatUI: function (response, id) {
            var printFormatText, url;
            if (this.printFormat.value) {
                printFormatText = html.create("div", {
                    innerHTML: this.printTitle.value,
                    "id": id + "formatText",
                    "class": "formatText"
                }, dom.byId(id));
            }
            domAttr.set(dom.byId(id + "formatText"), "text", response.results[0].value.url);
            html.removeClass(this._btnClear.domNode, "hide");
            html.addClass(this._btnClear.domNode, "show");
            html.removeClass(dom.byId(id + "sample"), "sample");
            on(printFormatText, "click", lang.hitch(this, function (evt) {
                url = {
                    "text": domAttr.get(evt.currentTarget.id, "text")
                };
                window.open(url.text);
                this._shelter.hide();
            }));

            on(this._btnClear, "click", lang.hitch(this, function (evt) {
                domConstruct.empty(this._dynamicPrintContainer);
                html.removeClass(this._btnClear.domNode, "show");
                html.addClass(this._btnClear.domNode, "hide");
                this._PrintId = 0;
                this._shelter.hide();
            }));
            this._shelter.hide();
        },

        /**
        * Perform the Geoprocessor process and printing process.
        */
        _getfeatureInfo: function () {
            var basemapOBJECT, layoutOptions, output, objMapOption, outputJSON, referencedObject;
            this.printJSON = {};
            objMapOption = {};
            referencedObject = null;
            outputJSON = new ExportToWebMap({
                map: this.map
            });
            layoutOptions = {
                "authorText": sharedNls.Print.PrintingAuthor,
                "copyrightText": "",
                "legendLayers": [], //legends,
                "titleText": this.printTitle.value, //"Community Program",
                "scalebarUnit": "Miles"
            };
            objMapOption = {
                "extent": {
                    "xmin": this.map.extent.xmin,
                    "ymin": this.map.extent.ymin,
                    "xmax": this.map.extent.xmax,
                    "ymax": this.map.extent.ymax,
                    "spatialReference": {
                        "wkid": this.map.extent.spatialReference.wkid
                    }
                },
                "spatialReference": {
                    "wkid": this.map.extent.spatialReference.wkid
                }
            };
            basemapOBJECT = {};
            var objBasemap = this.map.getLayer(this.map.layerIds[0]);
            basemapOBJECT = {
                "title": "Basemap",
                "baseMapLayers": [{
                    "id": objBasemap.id,
                    "opacity": 1,
                    "visibility": true,
                    "url": objBasemap.url
                }]
            };
            this.mapJson = {};
            this.mapJson.mapOptions = objMapOption;
            this.mapJson.baseMap = basemapOBJECT;
            this.mapJson.layoutOptions = layoutOptions;
            aspect.after(outputJSON, "onLayerObjectCreated", lang.hitch(this, function (layerJSON) {
                referencedObject = layerJSON;
                this.mapJson.operationalLayers = referencedObject.operationalLayersObj;
                output = JSON.stringify(this.mapJson);
                var gpTaskPdf = new Geoprocessor(this.appUtils.configGeneralSettings.printService + "/execute");
                var exportParams = {};
                exportParams.Layout_Template = this.printLayout.value;
                exportParams.Format = this.printFormat.value;
                exportParams.Web_Map_as_JSON = output;
                var divID = this.printTitle.value + this._PrintId;
                this._PrintId++;
                var printformatimg, printformat;
                printformatimg = html.create("div", {
                    "id": divID,
                    "class": (this.printFormat.value === "PDF") ? "formatImg" : "formatImg1"
                }, this._dynamicPrintContainer);
                printformat = html.create("div", {
                    "class": "sample",
                    "id": divID + "sample"
                }, this._dynamicPrintContainer);
                this._shelter.hide();
                esriConfig.defaults.io.alwaysUseProxy = true;
                gpTaskPdf.submitJob(exportParams, lang.hitch(this, function (jobInfo) {
                    esriConfig.defaults.io.alwaysUseProxy = false;
                    this._printdata = jobInfo;
                    this._shelter.hide();
                    this._PrintFormatUI(jobInfo, divID);
                }), lang.hitch(this, function (jobInfo) {
                    //If unable to export to pdf file.
                    if (status.toLowerCase() === "esriJobFailed".toLowerCase()) {
                        esriConfig.defaults.io.alwaysUseProxy = false;
                        this._shelter.hide();
                        this._nc4Notify.error(sharedNls.Print.exportPDF);
                    }
                }), lang.hitch(this, function (error) {
                    esriConfig.defaults.io.alwaysUseProxy = false;
                    if (error.message === "Timeout exceeded") {
                        html.create("span", {
                            innerHTML: "Server busy, try again",
                            "id": divID + "errorText",
                            "class": "errorText"
                        }, printformatimg);
                     }
                    else {
                        html.create("span", {
                            innerHTML: "Error, try again",
                            "id": divID + "errorText",
                            "class": "errorText"
                        }, printformatimg);
                    }
                    domConstruct.empty(dom.byId(divID + "sample"));
                    html.removeClass(dom.byId(divID + "sample"), "sample");
                }));
            }));
            esriConfig.defaults.io.alwaysUseProxy = false;
            outputJSON.createLayerJson(null, null, null);
        },

        _handlePrintResponce: function (resp) {
            this._shelter.hide();
            window.open(resp.url);
        },

        _handleError: function () {
            this._nc4Notify.error(sharedNls.Print.PrintError);
            this._shelter.hide();
        },

        _getColumnName: function (features) {
            var columnNames, i, storeValues = [];
            storeValues.push({
                value: "Select one",
                label: "Select one",
                selected: true
            });
            columnNames = features[1];
            for (i = 0; i < features.length; i++) {
                storeValues.push({
                    value: features[i].toString(),
                    label: features[i].toString()
                });
            }
            return storeValues;
        },

        /**
        * Display the panel and activate the directions widget.
        */
        show: function () {
            if (!this.isOpen) {
                domClass.add(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
            } else {
                this.hide();
            }
        },

        /**
        * Hide the panel
        */
        hide: function () {
            this.isOpen = false;
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                esriConfig.defaults.io.alwaysUseProxy = false;
            }
        },

        /**
        * Setting the widget panel position.
        */
        _placeWidgetContainer: function () {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
        * Widget Related Events
        */
        _attachWidgetRelatedEvents: function () {
        	on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function () {
                this._panel.resize();
            }));
        }
    });
});
