define([
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/_base/array",
        "dojo/dom-construct",
        "dojo/Deferred",
        "dojo/DeferredList",
        "dijit/_Widget",
        "dijit/_WidgetBase",
        "dijit/_TemplatedMixin",
        "dijit/_WidgetsInTemplateMixin",
        "dojo/json",
        "dojo/promise/all",
        "esri/IdentityManager"
    ],
    function (declare, lang, array, domConstruct, Deferred, DeferredList, _Widget, _WidgetBase, _TemplatedMixin,
        _WidgetsInTemplateMixin, JSON, all, IdentityManager) {
        return declare([_Widget], {

            postCreate: function () {
                this.inherited(arguments);
            },

            //to generate basemap layer url with extent and layers
            createLayerJson: function (urlKey, customBaseUrl, showAttr) {
                var operationalLayersObj = [],
                    dfrdList = [],
                    dfrdArray = [],
                    visibleLayers = [],
                    baseMap;

                for (var i = 0; i < this.map.graphicsLayerIds.length; i++) {

                    if ( this.map.graphicsLayerIds[i] != "esriGraphicLayer" && this.map.graphicsLayerIds[i] != "bingGraphicLayer") {
                        if (this.map.graphicsLayerIds[i] === "Drawing") {
                            var layer = this.map.getLayer(this.map.graphicsLayerIds[i]), dynamicMapArray, featureAttr;
                            array.forEach(layer.graphics, lang.hitch(this, function (graphic) {
                                if (graphic.toJson().symbol) {
                                    var geometryType = null;
                                    switch (graphic.geometry.type) {
                                        case "point":
                                            geometryType = "esriGeometryPoint";
                                            break;
                                        case "polygon":
                                            geometryType = "esriGeometryPolygon";
                                            break;
                                        case "polyline":
                                            geometryType = "esriGeometryPolyline";
                                            break;
                                    }
                                    var featuresObj = [];
                                    featuresObj.push(featureAttr = {
                                        "geometry": graphic.toJson().geometry,
                                        "attributes": graphic.toJson().attributes,
                                        "symbol": graphic.toJson().symbol
                                    });
                                    operationalLayersObj.push(dynamicMapArray = {
                                        "id": layer.id,
                                        "visibility": true,
                                        "opacity": 1,
                                        "featureCollection": {
                                            "layers": [{
                                                "layerDefinition": {
                                                    "name": "graphics layer",
                                                    "type": "Graphics Layer",
                                                    "description": "",
                                                    "geometryType": geometryType
                                                },
                                                "featureSet": {
                                                    "features": featuresObj,
                                                    "geometryType": geometryType
                                                }
                                            }]
                                        }
                                    });
                                }



                            }));
                        
                        }
                        else if (this.map.graphicsLayerIds[i].indexOf("_cluster") > -1) {
                            dfrdArray.push(this._clusterLayer(operationalLayersObj, this.map.getLayer(this.map.graphicsLayerIds[i])));
                        } else {
                            visibleLayers.push(this.map.getLayer(this.map.graphicsLayerIds[i]));
                        }
                    }
                }

                // loop through the layers and push them in the deferred array 
                array.forEach(visibleLayers, lang.hitch(this, function (layer) {
                    if (layer.declaredClass !== "esri.layers.ArcGISTiledMapServiceLayer" && layer.visible) {
                        dfrdArray.push(this._createOperationalLayersJson(operationalLayersObj, layer, showAttr));
                    }
                }));
                // loop through the dynamic map services to get the basemap layer 
                array.forEach(this.map.layerIds, function (lid) {
                    var layer = this.map.getLayer(lid);
                    if (layer.declaredClass === "esri.layers.ArcGISDynamicMapServiceLayer") {
                        operationalLayersObj.push(this._serializeDynamic(layer));
                    }
                    if (layer.declaredClass === "esri.layers.ArcGISImageServiceLayer") {
                        operationalLayersObj.push(this._serializeImage(layer));
                    }
                    if (layer.declaredClass === "esri.layers.WMSLayer") {

                        dfrdArray.push(this._serializeWMSLayer(operationalLayersObj, layer));
                    }
                    if (layer.declaredClass === "esri.layers.MapImageLayer") {

                        dfrdArray.push(this._serializeMapImageLayer(operationalLayersObj, layer));
                    }
                    if (layer.declaredClass === "esri.layers.KMLLayer") {

                        dfrdArray.push(this._serializeKMLLayer(operationalLayersObj, layer));
                    }


                }, this);

                dfrdList = new DeferredList(dfrdArray);
                // when all the layers are pushed in an array then generate the web map ID
                dfrdList.then(lang.hitch(this, function () {

                    this.onLayerObjectCreated(operationalLayersObj, baseMap, urlKey, customBaseUrl);
                }));
            },

            _createOperationalLayersJson: function (operationalLayersObj, layer, showAttr) {
                var featuresObj = [],
                    dfrd = new Deferred(),
                    geometryType, dynamicMapArray, featureAttr, popUpJson = layer.infoTemplate ? layer.infoTemplate.toJson() : null;
                //if layer has url and is visible on map
                if (layer.url) {
                    var token = "";
                    //loop get the credentials for secured layer which are added on map
                    array.forEach(IdentityManager.credentials, lang.hitch(this, function (credentials, index) {
                        // loop to get resources of credentials
                        array.forEach(credentials.resources, lang.hitch(this, function (resource, index) {
                            // Check if current layer is secured then pass token else set token to blank
                            if (layer.url.indexOf(resource) > -1) {
                                token = this.appUtils.generatedToken;
                                return true;
                            } else {
                                token = "";
                            }
                        }));
                    }));
                    // structure for layer to publish as a web map
                    operationalLayersObj.push(dynamicMapArray = {
                        "layerDefinition": { // if layer has definition expression set
                            "definitionExpression": layer._defnExpr ? layer._defnExpr : "",
                            "drawingInfo": {
                                "renderer": layer.renderer ? layer.renderer.toJson() : null
                            }
                        },
                        "url": layer.url,
                        "id": layer.title,
                        "token": token, // provide token for secured layer
                        "visibility": true,
                        "opacity": layer.opacity ? layer.opacity : 1,
                        "title": layer.title,
                        "popupInfo": popUpJson
                    });
                    dfrd.resolve();
                }
                // if layer is custom layer without url and is visible on map
                else if (layer.url === null) {
                    // if layer is cluster layer then publish the base layer from which the cluster layer is formed
                    //                    if (layer.declaredClass === "ClusterLayer") {
                    //                        layer = layer._baseLayer;
                    //                    }
                    // to check the type of the layer
                    if (layer._params.addedType === "graphics") {

                        array.forEach(layer.graphics, lang.hitch(this, function (graphic) {
                            if (graphic.toJson().symbol) {
                                var geometryType = null;
                                switch (graphic.geometry.type) {
                                    case "point":
                                        geometryType = "esriGeometryPoint";
                                        break;
                                    case "polygon":
                                        geometryType = "esriGeometryPolygon";
                                        break;
                                    case "polyline":
                                        geometryType = "esriGeometryPolyline";
                                        break;
                                }
                                var featuresObj = [];
                                featuresObj.push(featureAttr = {
                                    "geometry": graphic.toJson().geometry,
                                    "attributes": graphic.toJson().attributes,
                                    "symbol": graphic.toJson().symbol
                                });
                                operationalLayersObj.push(dynamicMapArray = {
                                    "id": layer.id,
                                    "visibility": true,
                                    "opacity": 1,
                                    "featureCollection": {
                                        "layers": [{
                                            "layerDefinition": {
                                                "name": "graphics layer",
                                                "type": "Graphics Layer",
                                                "description": "",
                                                "geometryType": geometryType
                                            },
                                            "featureSet": {
                                                "features": featuresObj,
                                                "geometryType": geometryType
                                            }
                                        }]
                                    }
                                });
                            }



                        }));
                        dfrd.resolve();

                    }
                    else {
                        switch (layer.graphics[0].geometry.type) {
                            case "point":
                                geometryType = "esriGeometryPoint";
                                break;
                            case "polygon":
                                geometryType = "esriGeometryPolygon";
                                break;
                            case "polyline":
                                geometryType = "esriGeometryPolyline";
                                break;
                        }
                        //in case of graphics layer field are undefined, then push one field of type "esriFieldTypeOID"
                        if (layer.fields === undefined) {
                            layer.fields = [];
                            layer.fields.push({
                                "name": "OBJECTID",
                                "alias": "OBJECTID",
                                "type": "esriFieldTypeOID"
                            });
                        }
                        // to loop through layer graphics               
                        array.forEach(layer.graphics, lang.hitch(this, function (graphic) {
                            // if layer graphics is undefined push one attribute with field esriFieldTypeOID
                            if (graphic.attributes === undefined) {
                                graphic.attributes = {};
                                graphic.attributes.OBJECTID = 1;
                            }
                            if (graphic.visible) {
                                //if publish webmap button is clicked then send attributes
                                if (showAttr) {
                                    featuresObj.push(featureAttr = {
                                        "geometry": graphic.geometry,
                                        "attributes": graphic.attributes
                                    });
                                } else {
                                    featuresObj.push(featureAttr = {
                                        "geometry": graphic.geometry
                                    });
                                }
                            }
                        }));

                        if (layer.renderer.declaredClass === "esri.renderer.SimpleRenderer") {
                            // if custom layer has picture marker symbol then convert the symbol in image data
                            if (layer.renderer.symbol.type === "picturemarkersymbol") {
                                // call this function to get image data for the picture marker symbol 
                                popUpJson = showAttr ? popUpJson : null;
                                this._createBase64Image(layer.renderer.symbol.url).then(lang.hitch(this, function (imageData) {
                                    layer.renderer.symbol.imageData = imageData;
                                    layer.renderer.symbol.contentType = "image/png";
                                    // structure for layer without url to publish as a web map
                                    this._createCustomLayerStructure(operationalLayersObj, layer, geometryType, featuresObj, popUpJson);
                                    dfrd.resolve();
                                }), function (error) {

                                    dfrd.reject(error);
                                });
                            } else {
                                this._createCustomLayerStructure(operationalLayersObj, layer, geometryType, featuresObj, popUpJson);
                                dfrd.resolve();
                            }
                        } else if (layer.renderer.declaredClass === "esri.renderer.UniqueValueRenderer" || layer.renderer.declaredClass === "esri.renderer.ClassBreaksRenderer") {
                            array.forEach(layer.renderer.infos, lang.hitch(this, function (uniqueLayer) {
                                if (uniqueLayer.symbol.type === "picturemarkersymbol") {
                                    // call this function to get image data for the picture marker symbol 
                                    popUpJson = showAttr ? popUpJson : null;
                                    this._createBase64Image(uniqueLayer.symbol.url).then(lang.hitch(this, function (imageData) {
                                        layer.renderer.symbol.imageData = imageData;
                                        layer.renderer.symbol.contentType = "image/png";
                                        // structure for layer without url to publish as a web map
                                        this._createCustomLayerStructure(operationalLayersObj, layer, geometryType, featuresObj, popUpJson);
                                        dfrd.resolve();
                                    }), function (error) {

                                        dfrd.reject(error);
                                    });
                                } else {
                                    this._createCustomLayerStructure(operationalLayersObj, layer, geometryType, featuresObj, popUpJson);
                                    dfrd.resolve();
                                }
                            }));
                        }
                    }
                }
                return dfrd.promise;
            },

            //to create json for the custom layers
            _createCustomLayerStructure: function (operationalLayersObj, layer, geometryType, featuresObj, popUpJson) {
                var objectFieldName, dynamicMapArray;
                array.some(layer.fields, function (field) {
                    if (field.type === "esriFieldTypeOID") {
                        objectFieldName = field.name;
                        return true;
                    }
                });
                operationalLayersObj.push(dynamicMapArray = {
                    "id": layer.title,
                    "visibility": true,
                    "opacity": 1,
                    "title": layer.title,
                    "featureCollection": {
                        "layers": [{
                            "layerDefinition": {
                                "currentVersion": 10.21,
                                "name": layer.title,
                                "type": "Feature Layer",
                                "description": "",
                                "geometryType": geometryType,
                                "extent": layer.fullExtent,
                                "drawingInfo": {
                                    "renderer": layer.renderer.toJson()
                                },
                                "allowGeometryUpdates": true,
                                "hasAttachments": false,
                                "htmlPopupType": "esriServerHTMLPopupTypeNone",
                                "objectIdField": objectFieldName,
                                "fields": layer.fields,
                                "supportedQueryFormats": "JSON"
                            },
                            "featureSet": {
                                "features": featuresObj,
                                "geometryType": geometryType
                            },
                            "popupInfo": popUpJson
                        }],
                        "showLegend": true
                    }
                });
            },

            // to create image data out of the picture marker symbol
            _createBase64Image: function (imgUrl) {
                var deferred = new Deferred(),
                    canvas, context, img, url, symbol;
                canvas = domConstruct.create("canvas");
                context = canvas.getContext("2d");
                img = new Image();
                img.src = imgUrl;
                //img.crossOrigin = null;
                img.setAttribute("crossOrigin", "Anonymous");
                img.onload = function () {
                    canvas.width = img.width;
                    canvas.height = img.height;
                    context.drawImage(img, 0, 0, img.width, img.height);
                    url = canvas.toDataURL();
                    symbol = url.replace(/^data:image\/(png|jpg);base64,/, "");
                    deferred.resolve(symbol);
                };
                return deferred.promise;
            },

            onLayerObjectCreated: function (operationalLayersObj, baseMap, urlKey, customBaseUrl) {
                var layerObject = {};
                layerObject.operationalLayersObj = operationalLayersObj;
                layerObject.baseMap = baseMap;
                layerObject.urlKey = urlKey;
                layerObject.customBaseUrl = customBaseUrl;
                //var output = JSON.stringify(layerObject);

                // this.printJSON.layerObject = layerObject;
                return layerObject;
            },
            _serializeDynamicCommon: function (layer) {
                var info = {};

                info.url = layer.url;
                info.id = layer.id;
                info.visibility = layer.visible;
                info.opacity = layer.opacity;
                info.title = layer.title || layer.id;

                return info;
            },
            _serializeDynamic: function (layer) {
                var info = this._serializeDynamicCommon(layer);

                // TODO: other dynamic layer specific properties
                // such as visibleLayers, renderers for dynamic layers?

                return info;
            },
            _serializeMapImageLayer: function (operationalLayersObj, layer) {
                var dfrd = new Deferred(), dynamicMapArray;
                //var imageData = null;
                //                this._createBase64Image(layer._mapImages[0].href).then(lang.hitch(this, function (imageData) {
                //                    imageData = imageData;

                //                    dfrd.resolve();
                //                }), function (error) {

                //                    dfrd.reject(error);
                //                });
                operationalLayersObj.push(dynamicMapArray = {
                    "type": "image",
                    "extent": {
                        "xmin": layer._mapImages[0].extent.xmin,
                        "ymin": layer._mapImages[0].extent.ymin,
                        "xmax": layer._mapImages[0].extent.xmax,
                        "ymax": layer._mapImages[0].extent.ymax,
                        "spatialReference": layer._mapImages[0].extent.spatialReference
                    },
                    "url": layer._mapImages[0].href
                    //                    ,
                    //                    "imageData": imageData
                });
                //                dfrd.resolve();
                dfrd.resolve();
                return dfrd.promise;
            },
            _serializeWMSLayer: function (operationalLayersObj, layer) {
                var dfrd = new Deferred(), dynamicMapArray;
                if (layer.visibleLayers.length > 0) {
                    operationalLayersObj.push(dynamicMapArray = {
                        "url": layer.url,
                        "title": layer.title,
                        "type": "wms",
                        "opacity": layer.Opacity,
                        "version": layer.version,
                        "transparentBackground": true
                    });
                }

                dfrd.resolve();
                return dfrd.promise;
            },
            _clusterLayer: function (operationalLayersObj, layer) {
                var dfrd = new Deferred(), dynamicMapArray, featureAttr;
                var featuresObj = [], textlayers = [];
                layer._fileds.push({
                    "name": "clusterCount",
                    "alias": "clusterCount",
                    "type": "esriFieldTypeInteger"
                });
                var defferedAllGraphics = [];
                array.forEach(layer.graphics, lang.hitch(this, function (graphic) {
                    if (graphic.visible) {
                        //if publish webmap button is clicked then send attributes
                        if (graphic.toJson().symbol) {
                            if (graphic.toJson().symbol.type === "esriTS") {
                                var dfrdGraphics = new Deferred();
                                textlayers.push({
                                    "visibility": true,
                                    "opacity": 1,
                                    "featureCollection": {
                                        "layers": [{ "layerDefinition": {
                                            "geometryType": "esriGeometryPoint"

                                        },
                                            "featureSet": {
                                                "features": [{
                                                    "geometry": graphic.toJson().geometry,
                                                    "symbol": graphic.toJson().symbol
                                                }],
                                                "geometryType": "esriGeometryPoint"
                                            }
                                        }]
                                    }
                                });
                                defferedAllGraphics.push(dfrdGraphics.promise);
                                dfrdGraphics.resolve();

                            }
                            else {

                                if (graphic.toJson().symbol.url) {
                                    dfrdGraphics = new Deferred();
                                    this._createBase64Image(graphic.toJson().symbol.url).then(lang.hitch(this, function (imageData) {
                                        imageData = imageData;
                                        graphic.symbol.imageData = imageData;
                                        featuresObj.push(featureAttr = {
                                            "geometry": graphic.toJson().geometry,
                                            "attributes": graphic.toJson().attributes,
                                            "symbol": graphic.toJson().symbol
                                        });
                                        //graphic.symbol.contentType = "image/png";
                                        // layer.renderer.symbol.contentType = "image/png";
                                        // structure for layer without url to publish as a web map
                                        dfrdGraphics.resolve();
                                    }), function (error) {

                                        dfrdGraphics.reject(error);
                                    });
                                    defferedAllGraphics.push(dfrdGraphics.promise);
                                } else {
                                    dfrdGraphics = new Deferred();
                                    featuresObj.push(featureAttr = {
                                        "geometry": graphic.toJson().geometry,
                                        "attributes": graphic.toJson().attributes,
                                        "symbol": graphic.toJson().symbol
                                    });
                                    defferedAllGraphics.push(dfrdGraphics.promise);
                                    dfrdGraphics.resolve();
                                }
                            }
                        } else {
                            dfrdGraphics = new Deferred();
                            featuresObj.push(featureAttr = {
                                "geometry": graphic.geometry,
                                "attributes": graphic.toJson().attributes
                            });
                            defferedAllGraphics.push(dfrdGraphics.promise);
                            dfrdGraphics.resolve();
                        }
                    }
                }));
                all(defferedAllGraphics).then(lang.hitch(this, function () {
                    operationalLayersObj.push(dynamicMapArray = {
                        "id": layer.title,
                        "visibility": true,
                        "opacity": 1,
                        "title": layer.title,
                        "featureCollection": {
                            "layers": [{
                                "layerDefinition": {
                                    "name": layer.title,
                                    "type": "Feature Layer",
                                    "description": "",
                                    "geometryType": "esriGeometryPoint",
                                    "extent": layer.fullExtent,
                                    "drawingInfo": {
                                        "renderer": layer.renderer.toJson()
                                    },
                                    //"objectIdField": objectFieldName,
                                    "fields": layer._fileds
                                },
                                "featureSet": {
                                    "features": featuresObj,
                                    "geometryType": "esriGeometryPoint"
                                }
                            }]
                        }
                    });
                    for (var k = 0; k < textlayers.length; k++) {
                        operationalLayersObj.push(textlayers[k]);
                    }
                    dfrd.resolve();
                }));

                //
                return dfrd.promise;
            },

            _serializeKMLLayer: function (operationalLayersObj, layer) {
                var dfrd = new Deferred(), dynamicMapArray;
                operationalLayersObj.push(dynamicMapArray = {
                    "type": "kml",
                    "url": layer.url


                });
                dfrd.resolve();
                return dfrd.promise;
            },
            _serializeImage: function (layer) {
                var info = this._serializeDynamicCommon(layer);

                if (layer.renderingRule && layer.renderingRule.toJson) {
                    info.renderingRule = layer.renderingRule.toJson();
                }

                // TODO:
                //    "bandIds":[0],
                //    "format":"jpgpng",
                //    "mosaicRule":
                //    {
                //      "mosaicMethod" : "esriMosaicLockRaster",
                //      "lockRasterIds":[1,3,5,6],
                //      "ascending": true,
                //      "mosaicOperation" : "MT_FIRST",
                //      "where":"objected<7"
                //    },
                //    "layerDefinition":{"definitionExpression":"objected<7"},
                //    "popupInfo":{...}

                return info;
            }
        });
    });
