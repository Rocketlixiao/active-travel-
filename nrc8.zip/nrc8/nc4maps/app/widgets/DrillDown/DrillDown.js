define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/on",
    "dojo/_base/lang",
    "dojo/dom",
    "dojo/text!./DrillDownTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "esri/map",
    "dojo/query",
    "esri/tasks/GeometryService",
    "esri/graphic",
    "esri/config",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin"
], function(
    declare,
    html,
    on,
    lang,
    dom,
    template,
    sharedNls,
    Map,
    query,
    GeometryService,
    Graphic,
    config,
    _WidgetBase,
    _TemplatedMixin
) {
    //========================================================================================================================//
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "DrillDown",
        baseClass: "widget-DrillDown",
        sharedNls: sharedNls,
        _spatilReferenceList: null,
        templateString: template,

        /**
         * Create footer panel and set application name
         */
        postCreate: function() {
            if(dom.byId("mainDrillDown")){
                dojo.destroy("mainDrillDown");
            }
            // console.log(query(".return")[0]);
            // query(".return")[0].classList.remove("hidden");
            var DrillDown = html.create("div", {
                "class": "DrillDown",
                "id": "mainDrillDown",
                "returnZoom": this.returnZoom
            }, "mainContainer");
            html.place(this.domNode, DrillDown);
        },

        _loadDrillDownInfo: function(content){
            var domNode = this.domNode
            this.drillDown.innerHTML = content;
            var map = this.mapInstance;
            on(dom.byId("drillDownClose"), "click", function() {
                dojo.destroy("mainDrillDown");
                map.isDrillDown = false;
            });
            var homeButton = query(".HomeButton");
            if(homeButton != null && homeButton.length > 0){
                on(homeButton[0], "click", function() {
                    dojo.destroy("mainDrillDown");
                    if(query(".return").length > 0 && query(".zoomTo").length > 1){
                        dojo.addClass(query(".return")[0]," hidden");
                       // dojo.removeClass(query(".zoomTo")[1], "hidden");
                        var arrNodes = query(".zoomTo");
                        if(arrNodes != null)
                        {
                            for (var i = 0; i < arrNodes.length; i++)
                            {
                                var currNode = arrNodes[i];
                                dojo.removeClass(currNode, "hidden");
                            }
                        }
                    }
                    map.isDrillDown = false;
                });
            }
        },


    });
});
