define(["dojo/_base/declare",
    "dojo/_base/html",
    "dojo/dom",
    "dojo/dom-class",
    "dojo/query",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin"
], function (declare, html, dom, domClass, query, _WidgetBase, _TemplatedMixin) {
    var criticality = 360; //Threshold value to decide the widget panel width.

    /**
     * Returns the width of panel according to screen size and criticality value.
     * @returns {string} - Width of the widget panel
     */
    function getPanelWidth() {
        var layoutBox = html.getMarginBox("mainContainer");
        //critical value to set widget panel size, if criticality is 70% or greater of the screen width, panel width will be 100%.
        if (layoutBox.w * 0.7 <= criticality) {
            return "100%";
        } else {
            return "360px";
        }
    }

    return declare([_WidgetBase, _TemplatedMixin], {
        templateString: "<div class='widgetPanel'><div data-dojo-attach-point='widgetContainer' class='widgetContainer'></div></div>", //Class 'widgetPanel' and 'widgetContainer' are present in <reference path="../styles/css/Style.css" />

        /**
         * Sets the size and position of panel according to screen size, criticality value and widget requirement.
         */
        startup: function () {
            html.setStyle(this.domNode, this._getPositionStyle(this.position));
            this._setPanelWidth();
            html.place(this.domNode, dom.byId("mainContainer"));
            this._setPanelHeight();
        },

        /**
         * Resize the widget panel on window resize.
         */
        resize: function () {
            this._setPanelWidth();
            this._setPanelHeight();
        },

        /**
         * Set the widget panel width.
         */
        _setPanelWidth: function () {
            html.setStyle(this.domNode, {
                width: getPanelWidth()
            });
        },

        /**
         * Calculate and returns the widget panel height.
         * @returns {string} panelHeight - Widget panel height.
         */
        _getPanelHeight: function () {
            var layoutBox = html.getMarginBox(this.domNode),
                mapBox,
                panelHeight;
            mapBox = html.getMarginBox("mainContainer");
            if (layoutBox.h < (mapBox.h - layoutBox.t)) {
                panelHeight = (layoutBox.h - 5) + "px"; //add some margin to avoid layout mess in this case 5px
                return panelHeight;
            }       
           
            //panelHeight = (layoutBox.h - (layoutBox.t + 65)) + "px"; //add some margin to avoid layout mess in this case 5px
            panelHeight = (mapBox.h - mapBox.t - layoutBox.t - 5) + "px"; //Make all of data layers visible in mobile device.

            return panelHeight;
        },

        /**
         * Set the widget panel height.
         */
        _setPanelHeight: function () {
            html.setStyle(this.widgetContainer, {
                height: this._getPanelHeight()
            });
        },

        /**
         * Create and returns widget gallery panel size and position style object.
         * @param {object} position - Position object containing detail of widget panel size and position.
         * @returns {object} style - Style object containing position and size detail of widget gallery panel.
         */
        _getPositionStyle: function (position) {
            var arrGroups = ["left", "top", "right", "bottom", "width", "height"],
                boolKeyMatch = false,
                index,
                p,
                style = {};
            for (p in position) {
                if (position.hasOwnProperty(p)) {
                    boolKeyMatch = false;
                    for (index = 0; index < arrGroups.length; index++) {
                        if (arrGroups[index].search(p) !== -1) {
                            boolKeyMatch = true;
                            break;
                        }
                    }
                    if (boolKeyMatch) {
                        if (typeof position[p] === "number") {
                            style[p] = position[p] + "px";
                        } else if (position[p]) {
                            style[p] = position[p];
                        }
                    }
                }
            }
            return style;
        },

        /**
         * Shows widget panel
         */
        show: function () {
            var divMapLogo,
                mapBox,
                panelHeight;
            html.setStyle(this.domNode, "display", "block");
            panelHeight = html.getMarginBox(this.domNode).h;
            mapBox = html.getMarginBox("mapContainerNode").h;
            //if widget panel overlaps the esri map logo on opening then slide it by criticality value.
            if (panelHeight > (mapBox - 40)) { //40px is the size of header panel
                divMapLogo = query(".esriControlsBR > div");
                if (divMapLogo) {
                    domClass.add(divMapLogo[0], "mapLogoSlideIn");
                }
            }
        },

        /**
         * Hide widget panel
         */
        hide: function () {
            var divMapLogo;
            html.setStyle(this.domNode, "display", "none");
            divMapLogo = query(".esriControlsBR > div");
            if (divMapLogo) {
                domClass.remove(divMapLogo[0], "mapLogoSlideIn");
            }
        }
    });
});
