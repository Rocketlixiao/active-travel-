define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/on",
    "dojo/_base/lang",
    "dojo/text!./AddressLocatorTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/query",
    "dojo/aspect",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "esri/dijit/Geocoder",
    "esri/layers/GraphicsLayer",
    "esri/graphic",
    "esri/InfoTemplate",
    "esri/symbols/PictureMarkerSymbol",
    "esri/virtualearth/VEGeocoder",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/geometry/webMercatorUtils"
], function(
    declare,
    html,
    on,
    lang,
    template,
    sharedNls,
    dojoQuery,
    aspect,
    _WidgetBase,
    _TemplatedMixin,
    Geocoder,
    GraphicsLayer,
    Graphic,
    InfoTemplate,
    PictureMarkerSymbol,
    VEGeocoder,
    SimpleMarkerSymbol,
    webMercatorUtils
) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "AddressLocator",
        baseClass: "Widget-AddressLocator",
        sharedNls: sharedNls,
        graphic: null,
        templateString: template,
        graphicLayerEsri: null,
        graphicLayerBing: null,
        geocoder: null,
        bingGeocoder: null,

        postCreate: function() {
            html.place(this.domNode, "mapContainerNode");
            on(window, "resize", lang.hitch(this, function() {
                setTimeout(lang.hitch(this, function() {
                    if (this.graphic) {
                        this.map.centerAt(this.graphic.geometry);
                    }
                }), 1000);
            }));
            this._getLayersFromEsri();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after mail function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
                this.esriGeocoder.map = this.map;
                this.esriGeocoder.startup();
            }));
        },

        /**
         * Perform the geocoding operation and show's the geoposition on map with infotemplate
         * @param {object} evt - To add graphics, features and geometry.
         */
        _searchAddressCompleteFromEsri: function(evt) {
            var infoTemplate,
                point,
                symbol,
                zoomTohandler,
                zoomToSpan;
            this.map.addLayer(this.graphicLayerEsri);
            if (this.graphicLayerEsri) {
                this.graphicLayerEsri.clear();
                this.map.infoWindow.hide();
            }
            point = evt.result.feature.geometry;
            symbol = new PictureMarkerSymbol({
                "url": "./app/images/popupSymbol.png",
                "height": 20,
                "width": 15
            });
            this.graphic = new Graphic(point, symbol);
            this.graphicLayerEsri.add(this.graphic);
            
    					var pt = "<div  class='infowindow-content '>";
    	    			pt += "<div class='content-wrap'>";
    	    				pt += "<div class='title'>" + sharedNls.AddressLocator.infoWindowTitle + "</div>";
    	    					pt += "</div>";
    	    				pt += "</div>";
    	    				pt += "<div class='infowindow-additional'>";
    	    					pt += "<div class='additional-detail'>";
    	    						pt+=evt.result.name;
    							pt += "</div>";
    						pt+="</div>";
    	                
            
            infoTemplate = new InfoTemplate("&nbsp;", pt);
            this.graphic.setInfoTemplate(infoTemplate);
            //this.map.infoWindow.setTitle(sharedNls.AddressLocator.infoWindowTitle);
            //this.map.infoWindow.setContent(evt.result.name);
            this.map.infoWindow.setFeatures([this.graphic]);
            this.map.infoWindow.show(evt.result.feature.geometry, {closestFirst: true});
            zoomToSpan = dojoQuery(".actionList >a>span")[0];
            zoomTohandler = on(zoomToSpan, "click", lang.hitch(this, function() {
                var maxZoom = this.map.getMaxZoom();
                var currentZoom = this.map.getZoom();
                if (maxZoom > currentZoom) {
                    var zoomToLevel = currentZoom + 6;
                    if (zoomToLevel >= maxZoom) {
                        this.map.setZoom(maxZoom);
                    } else {
                        this.map.setZoom(zoomToLevel);
                    }
                }
            }));
            on(this.map.infoWindow, "hide", lang.hitch(this, function() {
                zoomTohandler.remove();
            }));
            
           
            	//means that result was picked by NC4 Logic since ESRI Logic was broken (not picking the highest score)
            	this.map.setExtent(evt.result.extent);
            
        },

        /*
         * Address locater with Bing services.
         */
        _getLayersFromBing: function(searchAddress) {
            var pointSymbol,
                query;
            this.map.addLayer(this.graphicLayerBing);
            this.bingGeocoder = new VEGeocoder({
                bingMapsKey: this.appUtils.configGeneralSettings.bingAccessKey,
                autoComplete: true,
                map: this.map
            }, this.geocoder);
            query = searchAddress;
            this.bingGeocoder.addressToLocations(query);
            pointSymbol = new PictureMarkerSymbol({
                "url": "./app/images/popupSymbol.png",
                "height": 20,
                "width": 15
            });
            on(this.bingGeocoder, "address-to-locations-complete", lang.hitch(this, function(geocodeResults) {
                var bingInfoTemplate,
                    locationGraphic,
                    pointMeters,
                    zoomToSpan,
                    zoomTohandler;
                pointMeters = webMercatorUtils.geographicToWebMercator(geocodeResults[0].location);
                locationGraphic = new Graphic(pointMeters, pointSymbol, geocodeResults[0].displayName);
                this.graphicLayerBing.add(locationGraphic);
                
            	var pt = "<div  class='infowindow-content '>";
    			pt += "<div class='content-wrap'>";
    				pt += "<div class='title'>" + sharedNls.AddressLocator.infoWindowTitle + "</div>";
    					pt += "</div>";
    				pt += "</div>";
    				pt += "<div class='infowindow-additional'>";
    					pt += "<div class='additional-detail'>";
    						pt+=geocodeResults[0].displayName;
						pt += "</div>";
					pt+="</div>";
                
                bingInfoTemplate = new InfoTemplate("&nbsp;", pt);
               // bingInfoTemplate.setContent(geocodeResults[0].displayName);
                locationGraphic.setInfoTemplate(bingInfoTemplate);
                this.map.infoWindow.setFeatures([locationGraphic]);
                this.map.infoWindow.resize(200, 100);
                this.map.infoWindow.show(pointMeters);
                // this.map.infoWindow.setTitle(sharedNls.AddressLocator.infoWindowTitle);
                // this.map.infoWindow.setContent(geocodeResults[0].displayName);
                zoomToSpan = dojoQuery(".actionList.hidden >a>span")[0];
                if (zoomToSpan) {
                    zoomTohandler = on(zoomToSpan, "click", lang.hitch(this, function() {
                        var currentZoom,
                            maxZoom,
                            zoomToLevel;
                        maxZoom = this.map.getMaxZoom();
                        currentZoom = this.map.getZoom();
                        if (maxZoom > currentZoom) {
                            zoomToLevel = currentZoom + 3;
                            if (zoomToLevel >= maxZoom) {
                                this.map.setZoom(maxZoom);
                            } else {
                                this.map.setZoom(zoomToLevel);
                            }
                            this.map.centerAt(pointMeters);
                        }
                    }));
                    on(this.map.infoWindow, "hide", lang.hitch(this, function() {
                        zoomTohandler.remove();
                    }));
                }
                this.map.centerAt(pointMeters);
            }));
        },

        /*
         * Address locater with Google services.
         */
        _getLayersFromGoogle: function() {},

        /*
         * Address locater with Esri services.
         * JT: this was somewhat of a hack implementation.  The ESRI Geocoder will still be use for the suggest operation, and a geocoding request still gets
         * 			sent to ESRI for every geocode request.  The hack is that if Bing is in use, then the event for an esri 'select' is used to perform a Bing Geocode.
         */
        _getLayersFromEsri: function() {
            /*Some depends on this graphic layer*/
            this.graphicLayerEsri = new GraphicsLayer({
                id: "esriGraphicLayer"
            });
            this.graphicLayerBing = new GraphicsLayer({
                id: "bingGraphicLayer"
            });
            
            //jt todo, if set to nc4geocoder, just point to world geocoder directly for performance reasons plus its free
            var gUrl = this.appUtils.configGeneralSettings.esriGurl;
            if(gUrl != null && gUrl.indexOf("nc4geocoder") >= 0 )
            	gUrl = this.appUtils.configGeneralSettings.esriGeocodeServiceURL;
            
            this.esriGeocoder = new Geocoder({
                arcgisGeocoder: {
                	url: gUrl,
                    placeholder: sharedNls.AddressLocator.placeHolder
                },
                maxLocations: this.appUtils.configGeneralSettings.geocodeResults,
                autoComplete: true,
                autoNavigate: false,	//james - leave this false in case we pick the location based on NC4 Logic
                map: this.map
            }, this.geocoder);
            this.esriGeocoder.startup();

            on(this.esriGeocoder, "select", lang.hitch(this, function(address) {
            	
            	//The Geocoder is broken when searching for 500 W. Temple St. (doesn't select highest score), writing our own:
            	var results = this.esriGeocoder.results;
            	var highestAddr = address;
            	if(results.length > 0)
            	{
            		for(var i = 0; i < results.length; i++)
            		if(results[i].feature.attributes.score > address.result.feature.attributes.score)
            		{
            			highestAddr = {};
            			highestAddr.result = results[i];
            			highestAddr.target = address.target;
            			highestAddr.nc4selected = true;
            		}
            	}
            	//if current base map is B
            	var isBingBaseMap = "";
            	try{ isBingBaseMap = this.map.getLayer(this.map.layerIds[0]).declaredClass.indexOf("virtualearth"); }catch(error){};
                var searchAddress = highestAddr.result.name;
                console.info("this.appUtils: " , this.appUtils);
                switch (this.appUtils.configGeneralSettings.service) {
                    case "Esri":
                        this._searchAddressCompleteFromEsri(highestAddr);
                        break;
                    case "Bing":
                    	if(isBingBaseMap > 0)											//can only use Bing Geocoder on Bing Base map
                    		this._getLayersFromBing(searchAddress);
                    	else
                    		this._searchAddressCompleteFromEsri(highestAddr);
                        break;
                    case "Google":
                        break;
                }
            }));

            on(this.esriGeocoder, "clear", lang.hitch(this, function() {
                if (this.graphicLayerEsri) {
                    this.map.removeLayer(this.graphicLayerEsri);
                    this.map.infoWindow.hide();
                }
                if (this.graphicLayerBing) {
                    this.map.removeLayer(this.graphicLayerBing);
                    this.map.infoWindow.hide();
                }
            }));
        }
    });
});
