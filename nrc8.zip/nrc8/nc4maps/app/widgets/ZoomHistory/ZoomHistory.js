define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/on",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom",
    "dojo/dom-attr",
    "dojo/dom-class",
    "dojo/text!./ZoomHistory.html",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "esri/geometry/webMercatorUtils",
    "esri/toolbars/navigation"
], function(
    declare,
    html,
    on,
    lang,
    aspect,
    dom,
    domAttr,
    domClass,
    template,
    _WidgetBase,
    _TemplatedMixin,
    webMercatorUtils,
    Navigation
) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "ZoomHistory",
        baseClass: "widget-ZoomHistory",
        templateString: template,
        _currentIndex: 0,
        navToolbar: null,

        /**
        * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
        * Setting widget icon, loading shelter, call to attach widget related events and initializing ZoomHistory widget.
        */
        postCreate: function() {
            html.place(this.domNode, "mapContainerNode");
            this._createZoomHistoryWidget();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
                this._createZoomHistoryWidget();
            }));
        },

        /**
        * This function to get the current map extent.
        */
        _createZoomHistoryWidget: function() {
            domAttr.set(this.previousExtentNode, "title", "Previous Zoom");
            domAttr.set(this.nextExtentNode, "title", "Next Zoom");
            this.navToolbar = new Navigation(this.map);
            on(this.map, "extent-change", lang.hitch(this, this.extentChangeHandler));
            on(this.previousExtentNode, "click", lang.hitch(this, this._setPreviousExtent));
            on(this.nextExtentNode, "click", lang.hitch(this, this._setNextExtent));
        },

        /**
        *  Map is at the first extent.
        */
        _setPreviousExtent: function() {
            this.navToolbar.zoomToPrevExtent();
            if (this.navToolbar.isFirstExtent()) {
                html.removeClass(this.previousExtentNode, "previousExtentSelected");
                html.addClass(this.previousExtentNode, "previousExtent");
            }
            html.removeClass(this.nextExtentNode, "nextExtent");
            html.addClass(this.nextExtentNode, "nextExtentSelected");
        },

        /**
        * map is at the last extent.
        */
        _setNextExtent: function() {
            this.navToolbar.zoomToNextExtent();
            if (this.navToolbar.isLastExtent()) {
                html.addClass(this.nextExtentNode, "nextExtent");
                html.removeClass(this.nextExtentNode, "nextExtentSelected");
            }
            html.addClass(this.previousExtentNode, "previousExtentSelected");
            html.removeClass(this.previousExtentNode, "previousExtent");
        },
        extentChangeHandler: function() {
            if (this._currentIndex < 1) {
                html.addClass(this.previousExtentNode, "previousExtentSelected");
                html.removeClass(this.previousExtentNode, "previousExtent");
                this._currentIndex++;
            }

        }
    });
});
