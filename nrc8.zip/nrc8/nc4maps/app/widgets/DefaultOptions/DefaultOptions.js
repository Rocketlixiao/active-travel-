define([
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/_base/html",
    "dojo/on",
    "dojo/dom",
    "dojo/dom-attr",
    "dojo/text!./DefaultOptionsTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dijit/_TemplatedMixin",
    "dijit/form/Select",
    "dijit/form/TextBox",
    "dijit/form/ValidationTextBox",
    "dijit/form/Button",
    "dijit/_WidgetBase",
    "esri/request",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter",
    "lodash/lodash"
], function(
    declare,
    array,
    lang,
    html,
    on,
    dom,
    domAttr,
    template,
    sharedNls,
    _TemplatedMixin,
    Select,
    TextBox,
    ValidationTextBox,
    Button,
    _WidgetBase,
    esriRequest,
    WidgetPanel,
    LoadingShelter,
    _
) {
    var clazz = declare([_WidgetBase, _TemplatedMixin], {
        name: "Default Options",
        baseClass: "widget-DefaultOptions",
        sharedNls: sharedNls,
        templateString: template,
        isOpen: false,
        _shelter: null,
        _panel: null,
        _txtCurrentBasmap: null,
        _txtCurrentBookmark: null,
        _measuringUnitType: null,
        _defaultOpacityValue: null,
        _defaultRefreshRateValue: null,
        _geoCodeTypeValue: null,
        _txtGeoCodeSerivceURL: null,
        _txtArcgisIntersectSerivce: null,
        _txtCustomIntersectSerivce: null,
        _txtRoutingSerivce: null,
        _txtGeoCodeSerivceKey: null,
        _txtgeocodeMaxResult: null,
        //_txtMinimumScore: null,
        _txtGeometryServiceURL: null,
        _txtPrintServiceURL: null,
        _btnSaveDefaultOptions: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },


        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
         */
        postCreate: function() {
            this.inherited(arguments);
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetDefaultOptionsIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
        	this._nc4Notify = this.appUtils.nc4Notify;
            this._createWidgetUI();
            this._attachWidgetRelatedEvents();
            this._shelter.hide();
        },

        /**
         * Create widget UI.
         * Combo box and Textboxes for default options widget.
         */
        _createWidgetUI: function() {
        	 //this is not needed, first- it doesn't work (will only set on intial load. second - we're keeping track of the current basemap
        	//		in the appUtils var
        	//domAttr.set(this.currentBasemap, "value", this.appUtils.configGeneralSettings.defaultBaseMap);
        	
        	//same comment as basemap...since this can change durring the session, this will not work.
        	//domAttr.set(this.currentBookmark, "value", this.appUtils.configGeneralSettings.defaultBookmark);
            
            this._measuringUnitType = new Select();
            this._measuringUnitType.placeAt(this.measuringUnit).startup();
            array.forEach(this.config.MeasuringUnit, lang.hitch(this, function(measuringUnit) {
               
            	   this._measuringUnitType.addOption({
	                    label: measuringUnit,
	                    value: measuringUnit
	                });
            }));
            this._measuringUnitType.set("displayedValue", this.appUtils.configGeneralSettings.defaultMeasUnit);
            
            this._defaultOpacityValue = new ValidationTextBox({
                "class": "defaultTextbox",
                "regExp": "^[0-9 ]*$",
                "invalidMessage": sharedNls.DefaultOptions.invalidFormat,
                "value": this.appUtils.configGeneralSettings.defaultOpacity
            }, this.defaultOpacity);
            this._defaultRefreshRateValue = new ValidationTextBox({
                "class": "defaultTextbox",
                "regExp": "^[0-9 ]*$",
                "invalidMessage": sharedNls.DefaultOptions.invalidFormat,
                "value": this.appUtils.configGeneralSettings.defaultRefRate
            }, this.defaultRefreshRate);
            this._geoCodeTypeValue = new Select();
            this._geoCodeTypeValue.placeAt(this.geoCodeType).startup();
            array.forEach(this.config.GeocoderType, lang.hitch(this, function(geocoderType) {
                this._geoCodeTypeValue.addOption({
                    label: geocoderType,
                    value: geocoderType
                });
            }));
            this._createDefaultOptionsUI();
            this._shelter.hide();
        },

        /**
         * Create widget UI.
         * Combo box and Textboxes for default options widget.
         */
        _createDefaultOptionsUI: function() {
            domAttr.set(this.geoCodeSerivceURL, "value", this.appUtils.configGeneralSettings.geocodeUrl);
            //intersect is using geometry service
            // domAttr.set(this.arcgisIntersectService, "value", this.appUtils.configGeneralSettings.onlineIntersectService);
            // domAttr.set(this.customIntersectService, "value", this.appUtils.configGeneralSettings.customIntersectService);
            //domAttr.set(this.routingService, "value", this.appUtils.configGeneralSettings.routingServiceUrl || "get from widget");
            //domAttr.set(this.geoCodeSerivceKey, "value", this.appUtils.configGeneralSettings.geocodeKey);
            this._txtgeocodeMaxResult = new ValidationTextBox({
                "class": "defaultTextbox",
                "regExp": "^[0-9 ]*$",
                "invalidMessage": sharedNls.DefaultOptions.invalidFormat,
                "value": this.appUtils.configGeneralSettings.geocodeResults
            }, this.geocodeMaxResult);
            /*
            this._txtMinimumScore = new ValidationTextBox({
                "class": "defaultTextbox",
                "regExp": "^[0-9 ]*$",
                "invalidMessage": sharedNls.DefaultOptions.invalidFormat,
                "value": this.appUtils.configGeneralSettings.geocodeScore
            }, this.minimumScore);
            */
            domAttr.set(this.geometryServiceURL, "value", this.appUtils.configGeneralSettings.geometryServiceURL);
            domAttr.set(this.maxPointRequest, "value", this.appUtils.configGeneralSettings.maxPointRequest || 1500);
            domAttr.set(this.printServiceURL, "value", this.appUtils.configGeneralSettings.printService);
            this._btnSaveDefaultOptions = new Button({
                label: sharedNls.Bookmark.buttonSave
            }, this.saveDefaultOptions);
        },

        /**
         * It will save the information for defaults options.
         */
        //TODO: create vars: this.appUtils.configGeneralSettings.initialBaseMap && this.appUtils.configGeneralSettings.intialBookmark
        _saveDefaultsOptions: function() {
        	
        	 var basemapToSave = "";
        	 if( this.appUtils.configGeneralSettings.defaultBaseMap != "" && this.appUtils.configGeneralSettings.defaultBaseMap != null)
        	 {
        		 this.appUtils.log.debug("basemap checkbox checked!");
        		 basemapToSave = this.appUtils.configGeneralSettings.defaultBaseMap;
        	 }
             else
        	 	basemapToSave = this.appUtils.configGeneralSettings.initialBaseMap;
        	 
        	 var bookmarkToSave = "";
        	 this.appUtils.log.debug("possible default bookmark: " + this.appUtils.configGeneralSettings.defaultBookmark);
        	 if( this.appUtils.configGeneralSettings.defaultBookmark != "" && this.appUtils.configGeneralSettings.defaultBookmark != null)
        	 {
        		 this.appUtils.log.debug("bookmark checkbox checked");
        		 bookmarkToSave = this.appUtils.configGeneralSettings.defaultBookmark;
        	 }
        	else
         		bookmarkToSave = this.appUtils.configGeneralSettings.initialBookmark;
         	 
        	
        	var jsonSave = {
                "mconfig": basemapToSave, //this._txtCurrentBasmap.value,
                "bdefault": bookmarkToSave,
                "mudefault": this._measuringUnitType.value,
                "odefault": this._defaultOpacityValue.value,
                "rdefault": this._defaultRefreshRateValue.value,
               // "routingService": this.routingService.value,
                "geomServer": this.geometryServiceURL.value,
                "maxPointRequest": this.maxPointRequest.value,
                "gurl": this.geoCodeSerivceURL.value,
                "gtype": this._geoCodeTypeValue.value,
                //"minArcGISScore": this._txtMinimumScore.value,
                "maxGResults": this._txtgeocodeMaxResult.value,
                "printServer": this.printServiceURL.value
                /* TODO testing basemap
                "gkey": this._txtGeoCodeSerivceKey.value,
                "arcgisOnlineIntersectService": this._txtArcgisIntersectSerivce.value,
                "arcgisCustomIntersectService": this._txtCustomIntersectSerivce.value,
                
                */
            };
            var objJson = JSON.stringify(jsonSave);
            esriRequest({
                url: this.config.saveDefaultsOptions,
                content: lang.mixin({
                    defaults: objJson
                }, null),
                callbackParamName: "callback",
                load: lang.hitch(this, function(response) {
                    if (response === true) {
                    	this._nc4Notify.success("Default Options saved successfully");
                        this._shelter.hide();
                        
                        //update current vars
                        this.appUtils.configGeneralSettings.defaultMeasUnit = this._measuringUnitType.value;
                        this.appUtils.configGeneralSettings.defaultOpacity = this._defaultOpacityValue.value;
                        this.appUtils.configGeneralSettings.defaultRefRate = this._defaultRefreshRateValue.value;
                        this.appUtils.configGeneralSettings.geometryServiceURL = this.geometryServiceURL.value;
                        this.appUtils.configGeneralSettings.geocodeUrl = this.geoCodeSerivceURL.value;
                        this.appUtils.configGeneralSettings.geocodeType = this._geoCodeTypeValue.value;
                        this.appUtils.configGeneralSettings.geocodeResults = this._txtgeocodeMaxResult.value;
                        this.appUtils.configGeneralSettings.printService = this.printServiceURL.value;
                        
                    } else {
                    	this._nc4Notify.error("unable to save");
                        this._shelter.hide();
                    }
                }),
                error: lang.hitch(this, function(err) {
                	this._nc4Notify.error(err);
                    this._shelter.hide();
                })
            });
        },


        /**
         * Display the widget panel.
         */
        show: function() {
            if (!this.isOpen) {
                html.addClass(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                this.appUtils.sidePanelOpen(this.isOpen);
            } else {
                this.hide();
            }
        },

        /**
         * Hide the widget panel
         */
        hide: function() {
            this.isOpen = false;
            html.removeClass(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
            }
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Attach widget related events
         */
        _attachWidgetRelatedEvents: function() {
        	on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
            }));
            on(this._btnSaveDefaultOptions, "click", lang.hitch(this, function() {
                this._saveDefaultsOptions();
            }));
        }
    });
    return clazz;
});
