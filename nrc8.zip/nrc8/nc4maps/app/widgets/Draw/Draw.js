/*global define,dojo */
/*jslint browser:true,sloppy:true,nomen:true,unparam:true,plusplus:true,indent:4 */

//============================================================================================================================//
define([
    "dojo/_base/declare",
    "app/widgets/Draw/DrawingLayer",    
    "app/widgets/AlertBox/AlertBox",
    "esri/tasks/ProjectParameters", 
    "app/nc4modules/NC4GeometryService", 
    "esri/SpatialReference",
    "dojo/dom",
    "dojo/_base/html",
    "dojo/_base/array",
    "dojo/on",
    "dojo/topic",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-attr",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter",
    "dojo/text!./Draw.html",
    "dojo/dom-class",
    "esri/toolbars/draw",
    "esri/graphic",
    "esri/config",
    "esri/layers/FeatureLayer",
    "esri/layers/GraphicsLayer",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/symbols/SimpleLineSymbol",
    "esri/symbols/SimpleFillSymbol",
    "esri/geometry/Circle",
    "esri/units",
    "esri/Color",
    "dojo/promise/all",
    "dojo/Deferred",
    "dojo/DeferredList",
    "dojo/data/ObjectStore",
    "dojo/store/Memory",
    "dojo/json",
    "dijit/form/Form",
    "esri/toolbars/edit",
    "dijit/form/TextBox",
    "dijit/form/CheckBox",
    "dojo/dom-construct",
    "esri/geometry/screenUtils",
    "dijit/Fieldset", "dijit/ColorPalette", "dijit/form/DropDownButton", "dijit/TooltipDialog", "dijit/form/HorizontalSlider", "dijit/form/Select",
     "dojo/query", "dijit/form/Button", "dojo/dom-style", "esri/request", "dojo/parser", "dojo/domReady!"
], function (declare, DrawingLayer, AlertBox, ProjectParameters, NC4GeometryService, SpatialReference, dom, html, array, on, topic, lang, aspect, domAttr, sharedNls, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, WidgetPanel, LoadingShelter, template, domClass, Draw, 
		Graphic, esriConfig, FeatureLayer, GraphicsLayer, SimpleMarkerSymbol, SimpleLineSymbol, SimpleFillSymbol, Circle, Units, Color, all, Deferred, DeferredList, ObjectStore, 
		Memory, JSON, Form, Edit, TextBox, CheckBox, domConstruct, screenUtils, Fieldset, ColorPalette, DropDownButton, TooltipDialog, HorizontalSlider, Select, query, Button, domStyle, esriRequest) {
    //========================================================================================================================//
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        name: "Draw",
        baseClass: "widget-Draw",
        templateString: template,
        sharedNls: sharedNls,
        _shelter: null,
        isOpen: false,
        _panel: null,
        selectedGraphic: null,
        selectedGraphicContent: null,
        _defaultFillColor: "#B0B0B0",
        _defaultLineColor: "#FF0000",
        _defaultLineWidth: 1,
        _defaultOpacity: 0.5,
        _defaultLineOpacity: 1,
        _graphicFillColor: null,
        _graphicLineColor: null,
        _graphicTitle: null,
        _graphicDescription: null,
        _graphicLineWidth: 0,
        _modifiedOpacity: null,
        _modifiedFillColor: null,
        _modifiedLineColor: null,
        _modifiedLineWidth: 1,
        _modifiedTitle: null,
        _modifiedDescription: null,
        _modifiedLineOpacity: null,
        _currentFillColor: null,
        _currentLineColor: null,
        _currentWidth: null,
        _deletedGraphicDesc: null,
        _btnSaveOverlay: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },

        /**
        * create Draw widget
        *
        * @class
        * @name widgets/Draw/Draw
        */
        postCreate: function () {
            this.elementIndex = 1;

            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetDrawIcon"
            }, null);
            this._placeWidgetContainer();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            this._shelter = new LoadingShelter({
                hidden: true
            });
            this._shelter.placeAt(this.domNode);
            this._shelter.show("Loading....");
            this._attachWidgetRelatedEvents();
            this._nc4Notify = this.appUtils.nc4Notify;
            domAttr.set(this.imgCreateOverlay, "title", this.config.createOverlayLabel);
            domAttr.set(this.textOverlayName, "placeholder", this.config.saveOverlayPlaceHolder);
            domAttr.set(this.imgSaveOverlay, "title", this.config.saveOverlayLabel);
            domAttr.set(this.createOverlayMessageDiv, "innerHTML", this.config.overlayMessage);
            if (this.config.createOverlayURL) {
                html.addClass(this.createAndSaveDiv, "createAndSaveDom");
                html.removeClass(this.createAndSaveDiv, "hide");
            } else {
                html.removeClass(this.createAndSaveDiv, "createAndSaveDom");
                html.addClass(this.createAndSaveDiv, "hide");
            }
            this.toolbar = new Draw(this.map);
            this.toolbar.on("draw-end", lang.hitch(this, this._addToMap));
            this.editToolbar = new Edit(this.map);
            this.toolbar.deactivate();
            var defaultColor = new Color(this._defaultFillColor);

            var symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                    new Color(this._defaultLineColor)).setWidth(this._defaultLineWidth),
                new Color([defaultColor.r, defaultColor.g, defaultColor.b, this._defaultOpacity])
            );
            //this.textOverlayName.placeholder = "Overlay Name";
            this._btnSaveOverlay = new Button({
                label: "Save"
            }, this.addSaveOverlayButton);

            this.own(on(this._btnSaveOverlay, "click", lang.hitch(this, function () {
                if (this.textOverlayName.value === "") {
                    this._nc4Notify.warn("Please enter the overlay name to save");
                    return;
                }
                
                var dLayer = new DrawingLayer(this.map, this.appUtils, this._shelter, this.config, 
                		this._nc4Notify, this.textOverlayName, this.toolbar);
                var currDrawingsLayer = this.map.getLayer("Drawing");
                var defaultState = 0;
                if(this.checkboxOverlayState.checked && this.checkboxOverlayState.checked == true)
                	defaultState = 1;
                dLayer.saveNew(currDrawingsLayer, this.textOverlayName.value, defaultState);
                
                //TODO: subscribe to event?
                domStyle.set("createOverlayDom", "display", "none");
                domStyle.set("saveOverlayDom", "display", "none");
                domClass.remove(query(".imgCreateOverlay")[0], "imgCreateSelected");
                domClass.remove(query(".imgSaveOverlaySelected ")[0], "imgSaveOverlaySelected");
                var domlength = query(".drawContainerDimention")[0].children.length;
                for (var j = 0; j < domlength; j++) {
                    if (domClass.contains(query(".drawContainerDimention")[0].children[j], "imgSelected") === true) {
                        domClass.remove(query(".drawContainerDimention")[0].children[j], "imgSelected");
                        this.toolbar.deactivate();
                    }
                }
                this.textOverlayName.textbox.value = "";
            })));
            
            if(this.btnSaveUpdates == null)
            {
            	this.btnSaveUpdates = new Button({
                    label: "Update"
                }, this.divUpdateOverlays);
            }
            html.removeClass(this.btnSaveUpdates.domNode, "show");
            html.addClass(this.btnSaveUpdates.domNode, "hide");
            
            html.removeClass(this.divUpdateState, "show");
            html.addClass(this.divUpdateState, "hide");
            
            this.own(on(this.btnSaveUpdates, "click", lang.hitch(this, function(evt) {
                var dLayer = new DrawingLayer(this.map, this.appUtils, this._shelter, this.config, this._nc4Notify, null, null);
                
                var defaultState = 0;
                if(this.checkboxUpdateOverlayState.checked && this.checkboxUpdateOverlayState.checked == true)
                	defaultState = 1;
                
                this.appUtils.currentOverlayEdit.state = defaultState;
                this.appUtils.currentOverlayEdit.fromWidget = "draw";
                dLayer.update(this.appUtils.currentOverlayEdit, this.appUtils.editOverlayLayerId);
            	html.removeClass(this.btnSaveUpdates.domNode, "show");
                html.addClass(this.btnSaveUpdates.domNode, "hide");
              
                this.graphicsLayer = null;                
            })));
            
            
            this.map.on("click", lang.hitch(this, function (e) {
                // alert("hdhdh");

                var displayContainer = false;
                for (var i = 0; i < query(".imgSelected").length; i++) {
                    if (query(".imgSelected")[0].title === "Circle") {
                        displayContainer = true;
                    }
                }
                if (displayContainer) {
                    if (document.getElementById("fixed").checked) {
                        var radius = dojo.byId("radiusValue").value;
                        if (isNaN(radius) || radius === "") {
                            this._nc4Notify.warn("Please enter valid number for radius");
                            return;
                        }
                        var units = dojo.byId("units").value;
                        var esriUnits = Units.MILES;
                        if (units === "km") {
                            esriUnits = Units.KILOMETERS;
                        }
                        var circle = new Circle({
                            center: e.mapPoint,
                            radius: radius,
                            radiusUnit: esriUnits

                        });
                        var graphic = new Graphic(circle, symbol, {
                            "id": "Element" + this.elementIndex,
                            "description": "Element" + this.elementIndex
                        });
                        this.graphicsLayer.add(graphic);
                        this.elementIndex++;
                    }
                }

            }));

            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function () {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
            this._shelter.hide();
        },

        clear: function (evt) {
            this.editToolbar.deactivate();
            this.toolbar.deactivate();
            domStyle.set("createOverlayDom", "display", "none");
            domStyle.set("saveOverlayDom", "display", "none");
            this.hideFixedRadiusDom();
            if (query(".imgCreateOverlay")[0]) {
                domClass.remove(query(".imgCreateOverlay")[0], "imgCreateSelected");
            }
            if (query(".imgSaveOverlaySelected ")[0]) {
                domClass.remove(query(".imgSaveOverlaySelected ")[0], "imgSaveOverlaySelected");
            }
            var domlength = query(".drawContainerDimention")[0].children.length;
            for (var i = 0; i < domlength; i++) {
                if (domClass.contains(query(".drawContainerDimention")[0].children[i], "imgSelected") === true) {
                    domClass.remove(query(".drawContainerDimention")[0].children[i], "imgSelected");
                    this.toolbar.deactivate();
                }
            }
            this.textOverlayName.textbox.value = "";
            domConstruct.destroy("editFeaturesMainContainer");
            if (this.appUtils.iscreateOverlayMode) {
                this.clearAllGraphics();
                this.appUtils.createOverlayMode(false);
            }
        },

        clearAllGraphics: function (evt) {
            if (this.appUtils.overlayLayers.length) {
                for (var j = 0; j < this.appUtils.overlayLayers.length; j++) {
                    var layer = this.map.getLayer(this.appUtils.overlayLayers[j].id + "_layer");
                    if (layer) {
                        this.map.removeLayer(layer);
                    }
                }
            }
            if (this.appUtils.treeNode) {
                var childNodes = this.appUtils.treeNode.query({
                    parent: "nc4maps_overlays"
                });
                array.forEach(childNodes, lang.hitch(this, function (node, i) {
                    var checkNode = dom.byId(node.id + "_checkBox");
                    if (checkNode) {
                        if (checkNode.className === "checked") {
                            domClass.remove(checkNode, "checked");
                            domClass.remove(checkNode, "partialChecked");
                            domClass.add(checkNode, "unchecked");
                        }
                    }
                }));
                var parentNode = this.appUtils.treeNode.query({
                    id: "nc4maps_overlays"
                });
                array.forEach(parentNode, lang.hitch(this, function (node, i) {
                    var checkParentNode = dom.byId(node.id + "_checkBox");
                    if (checkParentNode) {
                        if (checkParentNode.className === "checked" || checkParentNode.className === "partialChecked") {
                            domClass.remove(checkParentNode, "checked");
                            domClass.remove(checkParentNode, "partialChecked");
                            domClass.add(checkParentNode, "unchecked");
                        }
                    }
                }));
            }
            var objLayer = this.map.getLayer("Drawing");
            if (objLayer) {
                objLayer.clear();
            }
        },

        createOverlay: function (evt) {
            domStyle.set("createOverlayDom", "display", "block");
            domStyle.set("saveOverlayDom", "display", "none");
            domClass.add(query(".imgCreateOverlay")[0], "imgCreateSelected");
            if (query(".imgSaveOverlaySelected ")[0]) {
                domClass.remove(query(".imgSaveOverlaySelected ")[0], "imgSaveOverlaySelected");
            }
            if (query(".imgSelected")[0]) {
                domClass.remove(query(".imgSelected")[0], "imgSelected");
            }
            this.hideFixedRadiusDom();
            this.clearAllGraphics();
            this.editToolbar.deactivate();
            this.toolbar.deactivate();
            this.appUtils.createOverlayMode(true);
            this.appUtils.overlayLayers = [];
        },

        enableSave: function (evt) {
            if (!domClass.contains("imgCreateOverlay", "imgCreateSelected")) {
                this._nc4Notify.warn("Please select the create mode to save overlay");
                return;
            }
            if (query(".imgCreateOverlay")[0]) {
                domClass.remove(query(".imgCreateOverlay")[0], "imgCreateSelected");
            }
            domClass.add(query(".imgSaveOverlay")[0], "imgSaveOverlaySelected");
            domStyle.set("createOverlayDom", "display", "none");
            domStyle.set("saveOverlayDom", "display", "block");
            var domlength = query(".drawContainerDimention")[0].children.length;
            for (var i = 0; i < domlength; i++) {
                if (domClass.contains(query(".drawContainerDimention")[0].children[i], "imgSelected") === true) {
                    domClass.remove(query(".drawContainerDimention")[0].children[i], "imgSelected");
                    this.toolbar.deactivate();
                }
            }
            //alert("save");
        },

        _dSelect: function (divclass) {
            var qryfind = "." + divclass;
            var domlength = query(".drawContainerDimention")[0].children.length;
            for (var i = 0; i < domlength; i++) {
                if (domClass.contains(query(".drawContainerDimention")[0].children[i], "imgSelected") === true) {
                    domClass.remove(query(".drawContainerDimention")[0].children[i], "imgSelected");
                }
            }
            var domEditlength = query(".editContainerDimention")[0].children.length;
            for (i = 0; i < domEditlength; i++) {
                if (domClass.contains(query(".editContainerDimention")[0].children[i], "imgSelected") === true) {
                    domClass.remove(query(".editContainerDimention")[0].children[i], "imgSelected");
                }
            }
            if (qryfind.indexOf("imgSelected") < 0) {
                domClass.add(query(qryfind)[0], "imgSelected");
            } else {
                this.editToolbar.deactivate();
                this.toolbar.deactivate();
                domConstruct.destroy("editFeaturesMainContainer");
            }
        },

        _variableCircle: function (evt) {
            this.editToolbar.deactivate();
            var displayContainer = false;
            for (var i = 0; i < query(".imgSelected").length; i++) {
                if (query(".imgSelected")[0].title === "Circle") {
                    displayContainer = true;
                }
            }
            if (displayContainer) {
                if (document.getElementById("variable").checked) {
                    //    alert("1");
                    var tool = "CIRCLE";
                    this.toolbar.activate(Draw[tool]);
                }
            }

        },

        _fixedCircle: function (evt) {
            this.toolbar.deactivate();
        },

        _draw: function (evt) {
            this.editToolbar.deactivate();
            this._dSelect(evt.currentTarget.className);
            domConstruct.destroy("editFeaturesMainContainer");
            var tool = evt.currentTarget.title.toUpperCase().replace(/ /g, "_");
            this._shelter.show("Loading");

            if (query(".imgSelected").length > 0) {
                if (tool === "CIRCLE") {
                    domStyle.set("drawCircleOptions", "display", "block");
                    if (document.getElementById("variable").checked) {
                        this.toolbar.activate(Draw[tool]);
                    }

                } else {
                    domStyle.set("drawCircleOptions", "display", "none");
                    this.toolbar.activate(Draw[tool]);
                }
            } else {
                domStyle.set("drawCircleOptions", "display", "none");
                this.toolbar.deactivate();
            }

            this._shelter.hide();
        },

        _edit: function (evt) {
            this.editToolbar.deactivate();
            this.toolbar.deactivate();
            domConstruct.destroy("editFeaturesMainContainer");
            this.hideFixedRadiusDom();
            this._dSelect(evt.currentTarget.className);
            this.graphicsLayer.on("click", lang.hitch(this, function (evt) {

                var displayContainer = false;
                for (var i = 0; i < query(".imgSelected").length; i++) {
                    if (query(".imgSelected")[0].title === "Edit") {
                        displayContainer = true;
                    }
                }
                if (displayContainer) {
                    evt.stopPropagation();
                    this.editToolbar.activate(Edit.EDIT_VERTICES, evt.graphic);
                }
            }));
        },

        _move: function (evt) {
            this.editToolbar.deactivate();
            this.toolbar.deactivate();
            domConstruct.destroy("editFeaturesMainContainer");
            this.hideFixedRadiusDom();
            this._dSelect(evt.currentTarget.className);
            this.graphicsLayer.on("click", lang.hitch(this, function (evt) {
                var displayContainer = false;
                for (var i = 0; i < query(".imgSelected").length; i++) {
                    if (query(".imgSelected")[0].title === "Move") {
                        displayContainer = true;
                    }
                }
                if (displayContainer) {
                    evt.stopPropagation();
                    this.editToolbar.activate(Edit.MOVE, evt.graphic);
                }
            }));
        },

        _rotate: function (evt) {
            this.editToolbar.deactivate();
            this.toolbar.deactivate();
            domConstruct.destroy("editFeaturesMainContainer");
            this.hideFixedRadiusDom();
            this._dSelect(evt.currentTarget.className);
            this.graphicsLayer.on("click", lang.hitch(this, function (evt) {
                var displayContainer = false;
                for (var i = 0; i < query(".imgSelected").length; i++) {
                    if (query(".imgSelected")[0].title === "Rotate") {
                        displayContainer = true;
                    }
                }
                if (displayContainer) {
                    evt.stopPropagation();
                    this.editToolbar.activate(Edit.ROTATE, evt.graphic);
                }
            }));
        },
        _scale: function (evt) {
            this.editToolbar.deactivate();
            this.toolbar.deactivate();
            domConstruct.destroy("editFeaturesMainContainer");
            this.hideFixedRadiusDom();
            this._dSelect(evt.currentTarget.className);
            this.graphicsLayer.on("click", lang.hitch(this, function (evt) {
                var displayContainer = false;
                for (var i = 0; i < query(".imgSelected").length; i++) {
                    if (query(".imgSelected")[0].title === "Scale") {
                        displayContainer = true;
                    }
                }
                if (displayContainer) {
                    evt.stopPropagation();
                    this.editToolbar.activate(Edit.SCALE, evt.graphic);
                }
            }));
        },
        _deleteGraphic: function (evt) {
            this.editToolbar.deactivate();
            this.toolbar.deactivate();
            domConstruct.destroy("editFeaturesMainContainer");
            this.hideFixedRadiusDom();
            this._dSelect(evt.currentTarget.className);
            this.graphicsLayer.on("click", lang.hitch(this, function (evt) {
                var displayContainer = false;
                for (var i = 0; i < query(".imgSelected").length; i++) {
                    if (query(".imgSelected")[0].title === "Delete") {
                        displayContainer = true;
                    }
                }
                if (displayContainer) {
                    evt.stopPropagation();
                    if (this._deletedGraphicDesc != evt.graphic.attributes.description) {
                    	//create new NC4Notify for custom options
                    	var deleteAlert = new AlertBox();
                        var savePromtMessage = deleteAlert.confirm("Click OK to delete the graphic");
                        savePromtMessage.then(lang.hitch(this, function (res) {
                            this.graphicsLayer.remove(evt.graphic);

                        }), lang.hitch(this, function (res) {
                            this._deletedGraphicDesc = null;
                        }));
                    }
                    this._deletedGraphicDesc = evt.graphic.attributes.description;
                }
            }));
        },
        _EditFeatures: function (evt) {
            this.editToolbar.deactivate();
            this.toolbar.deactivate();
            this._dSelect(evt.currentTarget.className);
            this.hideFixedRadiusDom();
            this.graphicsLayer.on("click", lang.hitch(this, function (evt) {
                this.editToolbar.deactivate();
                this.toolbar.deactivate();
                var displayContainer = false;
                for (var i = 0; i < query(".imgSelected").length; i++) {
                    if (query(".imgSelected")[0].title === "Edit Features") {
                        displayContainer = true;
                    }
                }
                if (displayContainer) {
                    evt.stopPropagation();
                    this.selectedGraphic = evt.graphic;
                    this._graphicTitle = evt.graphic.attributes.id;
                    this._graphicDescription = evt.graphic.attributes.description;
                    this._modifiedFillColor = null;
                    this._modifiedLineColor = null;
                    this._modifiedLineWidth = 1;
                    this._modifiedTitle = null;
                    this._modifiedDescription = null;
                    this._modifiedLineOpacity = null;
                    this._modifiedOpacity = null;
                    if (evt.graphic.geometry.type === "polygon") {
                        this._currentFillColor = evt.graphic.symbol.getFill();
                    }
                    this._currentLineColor = evt.graphic.symbol.getStroke().color;
                    this._currentWidth = evt.graphic.symbol.getStroke().width;
                    domConstruct.destroy("editFeaturesMainContainer");
                    //placeholder for editing features of graphic
                    var domContentDynamicMain = domConstruct.create("div", {
                        "id": "editFeaturesMainContainer",
                        "class": "editFeaturesMainContainer"
                    }, "mapContainerNode");
                    //Description Section start                
                    var descriptionHeader = domConstruct.create("div", {
                        "class": "editFeaturesDescr"
                    }, domContentDynamicMain);
                    descriptionHeader.innerHTML = "Description";
                    var domContentDynamic = domConstruct.create("div", {}, domContentDynamicMain);
                    var editPanelSpan = domConstruct.create("div", {
                        "class": "labelFeaturesContainer"
                    }, domContentDynamic);
                    editPanelSpan.innerHTML = "Title : ";
                    var editPanel = domConstruct.create("div", {
                        "class": "FeaturesContainer"
                    }, domContentDynamic);
                    var editPanelTextbox = domConstruct.create("div", {}, editPanel);
                    var myTextBox = new TextBox({
                        name: "Title",
                        value: evt.graphic.attributes.id,
                        /* no or empty value! */
                        placeHolder: evt.graphic.attributes.id,
                        size: "15",
                        onChange: lang.hitch(this, function (value) {
                            this._modifiedTitle = value;
                            evt.graphic.attributes.id = value;
                        })
                    });
                    domConstruct.place(myTextBox.domNode, editPanelTextbox);
                    var editPanelSpanDescription = domConstruct.create("div", {
                        "class": "FeaturesContainerdes"
                    }, domContentDynamic);
                    editPanelSpanDescription.innerHTML = "Detail : ";
                    var editPanel1 = domConstruct.create("div", {
                        "class": "desFeaturesContainer"
                    }, domContentDynamic);
                    var editPaneldiv = domConstruct.create("div", {}, editPanel1);
                    var myTextBox1 = new TextBox({
                        name: "description",
                        "class": "layername",
                        value: evt.graphic.attributes.description,
                        /* no or empty value! */
                        placeHolder: evt.graphic.attributes.description,
                        onChange: lang.hitch(this, function (value) {
                            this._modifiedDescription = value;
                            evt.graphic.attributes.description = value;
                        })
                    });
                    domConstruct.place(myTextBox1.domNode, editPaneldiv);

                    if (evt.graphic.geometry.type == "polygon") {
                        var editPanel14 = domConstruct.create("div", {
                            "class": "editFeaturesDescrForFill"
                        }, domContentDynamicMain);
                        editPanel14.innerHTML = "Fill";

                        var editPanelSpanForColor = domConstruct.create("div", {
                            "class": "editFeaturesDescrForFillColor"
                        }, domContentDynamicMain);
                        editPanelSpanForColor.innerHTML = "Color : ";

                        var editPanelS = domConstruct.create("div", {
                            "class": "FeaturesContainerdd"
                        }, domContentDynamicMain);
                        var editPaneldropdown = domConstruct.create("div", {}, editPanelS);
                        var myPalette = new ColorPalette({
                            palette: "7x10",
                            onChange: lang.hitch(this, function (val) {
                                var lineColor, borderWidth, fillOpacity, fillLineOpacity;
                                if (this._modifiedLineColor) {
                                    lineColor = this._modifiedLineColor;
                                } else {
                                    lineColor = this._currentLineColor;
                                }
                                if (this._modifiedLineWidth) {
                                    borderWidth = this._modifiedLineWidth;
                                } else {
                                    borderWidth = this._currentWidth;
                                }
                                if (this._modifiedLineOpacity) {
                                    fillLineOpacity = this._modifiedLineOpacity;
                                } else {
                                    fillLineOpacity = this._currentLineColor.a;
                                }
                                if (this._modifiedOpacity) {
                                    fillOpacity = this._modifiedOpacity;
                                } else {
                                    fillOpacity = this._currentFillColor.a;
                                }
                                var deafultLineColor = new Color(lineColor);
                                lineColor = new Color(val);
                                this._modifiedFillColor = val;
                                this.selectedGraphic.setSymbol(new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                        new Color([deafultLineColor.r, deafultLineColor.g, deafultLineColor.b, fillLineOpacity])).setWidth(borderWidth),
                                    new Color([lineColor.r, lineColor.g, lineColor.b, fillOpacity])
                                ));
                                dojo.style(dojo.byId("colorSwatchForFill"), {
                                    backgroundColor: val
                                });
                            })
                        });

                        var myDialog = new TooltipDialog({
                            content: myPalette
                        });
                        var colorButton = new DropDownButton({
                            label: "<span id=\"colorText\">color <span id=\"colorSwatchForFill\" style=\"height: 10px; width: 10px; border: 0px solid black; background-color: " + this._currentFillColor + ";\">&nbsp;&nbsp;</span></span>",
                            dropDown: myDialog
                        });
                        domConstruct.place(colorButton.domNode, editPaneldropdown);
                        var opacitySpan = domConstruct.create("div", {
                            id: "fillSliderValue",
                            "class": "fillOpacity"
                        }, domContentDynamicMain);
                        var opacitySpanSlider = domConstruct.create("div", {}, opacitySpan);
                        var opcityValue = this.selectedGraphic.symbol.color.a ? this.selectedGraphic.symbol.color.a : 0.5;
                        opacitySpanSlider.innerHTML = "Opacity : " + Math.round(opcityValue * 100) + " %";
                        var domContentForSlider = domConstruct.create("div", {
                            "class": "fillSlider"
                        }, domContentDynamicMain);
                        var domContentForSliderright = domConstruct.create("div", {}, domContentForSlider);
                        var sliderForColor = new HorizontalSlider({
                            name: "slider",
                            minimum: 1,
                            maximum: 100,
                            value: Math.round(opcityValue * 100),
                            intermediateChanges: true,
                            onChange: lang.hitch(this, function (value) {
                                dom.byId("fillSliderValue").innerHTML = "Opacity : " + Math.round(value) + " %";
                                var opacityValue = value / 100;
                                this._modifiedOpacity = opacityValue;
                                var fillColor, lineColor, borderWidth, fillLineOpacity;
                                if (this._modifiedFillColor) {
                                    fillColor = this._modifiedFillColor;
                                } else {
                                    fillColor = this._currentFillColor;
                                }
                                if (this._modifiedLineColor) {
                                    lineColor = this._modifiedLineColor;
                                } else {
                                    lineColor = this._currentLineColor;
                                }
                                if (this._modifiedLineWidth) {
                                    borderWidth = this._modifiedLineWidth;
                                } else {
                                    borderWidth = this._currentWidth;
                                }
                                if (this._modifiedLineOpacity) {
                                    fillLineOpacity = this._modifiedLineOpacity;
                                } else {
                                    fillLineOpacity = this._currentLineColor.a;
                                }
                                var defaultColor = new Color(fillColor);
                                var deafultLineColor = new Color(lineColor);
                                this.selectedGraphic.setSymbol(new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                        new Color([deafultLineColor.r, deafultLineColor.g, deafultLineColor.b, fillLineOpacity])).setWidth(borderWidth),
                                    new Color([defaultColor.r, defaultColor.g, defaultColor.b, opacityValue])
                                ));
                            })
                        });
                        domConstruct.place(sliderForColor.domNode, domContentForSliderright);
                    }
                    if (evt.graphic.geometry.type == "polygon" || evt.graphic.geometry.type == "polyline") {
                        var domNodeForBorderContent = domConstruct.create("div", {
                            "class": "editFeaturesDescrForBorder"
                        }, domContentDynamicMain);
                        domNodeForBorderContent.innerHTML = "Border";
                        var editPanelSpanForBorderColor = domConstruct.create("div", {
                            "class": "editPanelSpanForBorderColor",
                            "id": "editPanelSpanForBorderColor"
                        }, domContentDynamicMain);
                        editPanelSpanForBorderColor.innerHTML = "Color : ";
                        var domContentForBorderColorPallettemain = domConstruct.create("div", {
                            "class": "FeaturesContainertooltip"
                        }, domContentDynamicMain);
                        var domContentForBorderColorPallette = domConstruct.create("div", {}, domContentForBorderColorPallettemain);
                        var domContentForBorderColorPallettetooltip = domConstruct.create("div", {}, domContentForBorderColorPallette);
                        var colorPaletteForBorder = new ColorPalette({
                            palette: "7x10",
                            onChange: lang.hitch(this, function (val) {
                                var fillColor, borderWidth, fillLineOpacity, fillOpacity;
                                if (this._modifiedFillColor) {
                                    fillColor = this._modifiedFillColor;
                                } else {
                                    if (this._currentFillColor) {
                                        fillColor = this._currentFillColor;
                                    }
                                }
                                if (this._modifiedLineWidth) {
                                    borderWidth = this._modifiedLineWidth;
                                } else {
                                    borderWidth = this._currentWidth;
                                }
                                if (this._modifiedLineOpacity) {
                                    fillLineOpacity = this._modifiedLineOpacity;
                                } else {
                                    fillLineOpacity = this._currentLineColor.a;
                                }
                                if (this._modifiedOpacity) {
                                    fillOpacity = this._modifiedOpacity;
                                } else {
                                    if (this._currentFillColor) {
                                        fillOpacity = this._currentFillColor.a;
                                    }
                                }
                                var modifiedLineColor = new Color(val);
                                var defaultFillColor = new Color(fillColor);
                                this._modifiedLineColor = val;
                                if (this.selectedGraphic.geometry.type == "polyline") {
                                    this.selectedGraphic.setSymbol(new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                        new Color([modifiedLineColor.r, modifiedLineColor.g, modifiedLineColor.b, fillLineOpacity])).setWidth(borderWidth));
                                } else {
                                    this.selectedGraphic.setSymbol(new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                        new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                            new Color([modifiedLineColor.r, modifiedLineColor.g, modifiedLineColor.b, fillLineOpacity])).setWidth(borderWidth),
                                        new Color([defaultFillColor.r, defaultFillColor.g, defaultFillColor.b, fillOpacity])
                                    ));
                                }
                                dojo.style(dojo.byId("colorSwatch"), {
                                    backgroundColor: val
                                });
                            })
                        });
                        var tooltipDialogForBorder = new TooltipDialog({
                            content: colorPaletteForBorder
                        });
                        var borderColorButton = new DropDownButton({
                            label: "<span id=\"colorText\">color <span id=\"colorSwatch\" style=\"height: 10px; width: 10px; border: 0px solid black; background-color: " + this._currentLineColor + ";\">&nbsp;&nbsp;</span></span>",
                            dropDown: tooltipDialogForBorder
                        });
                        domConstruct.place(borderColorButton.domNode, domContentForBorderColorPallettetooltip);
                        var opacitySpanForBorder = domConstruct.create("div", {
                            id: "borderSliderValue",
                            "class": "Opacity"
                        }, domContentDynamicMain);
                        var opcityBorderValue = 1;
                        if (this.selectedGraphic.symbol.outline) {
                            opcityBorderValue = this.selectedGraphic.symbol.outline.color.a ? this.selectedGraphic.symbol.outline.color.a : 1;
                        }
                        opacitySpanForBorder.innerHTML = "Opacity : " + Math.round(opcityBorderValue * 100) + " %";
                        var domContentForBorderSlider = domConstruct.create("div", {
                            "class": "borderSlider"
                        }, domContentDynamicMain);
                        var domContentForBorderSliderright = domConstruct.create("div", {}, domContentForBorderSlider);
                        var sliderForBorder = new HorizontalSlider({
                            name: "sliderForSlider",
                            minimum: 1,
                            maximum: 100,
                            value: Math.round(opcityBorderValue * 100),
                            intermediateChanges: true,
                            onChange: lang.hitch(this, function (value) {
                                dom.byId("borderSliderValue").innerHTML = "Opacity : " + Math.round(value) + " %";
                                var opacityValue = value / 100;
                                this._modifiedLineOpacity = opacityValue;
                                var fillColor, lineColor, borderWidth, fillOpacity;
                                if (this._modifiedFillColor) {
                                    fillColor = this._modifiedFillColor;
                                } else {
                                    if (this._currentFillColor) {
                                        fillColor = this._currentFillColor;
                                    }
                                }
                                if (this._modifiedLineColor) {
                                    lineColor = this._modifiedLineColor;
                                } else {
                                    lineColor = this._currentLineColor;
                                }
                                if (this._modifiedLineWidth) {
                                    borderWidth = this._modifiedLineWidth;
                                } else {
                                    borderWidth = this._currentWidth;
                                }
                                if (this._modifiedOpacity) {
                                    fillOpacity = this._modifiedOpacity;
                                } else {
                                    if (this._currentFillColor) {
                                        fillOpacity = this._currentFillColor.a;
                                    }
                                }
                                var defaultColor = new Color(fillColor);
                                var deafultLineColor = new Color(lineColor);
                                if (this.selectedGraphic.geometry.type == "polyline") {
                                    this.selectedGraphic.setSymbol(new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                        new Color([deafultLineColor.r, deafultLineColor.g, deafultLineColor.b, opacityValue])).setWidth(borderWidth));
                                } else {
                                    this.selectedGraphic.setSymbol(new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                        new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                            new Color([deafultLineColor.r, deafultLineColor.g, deafultLineColor.b, opacityValue])).setWidth(borderWidth),
                                        new Color([defaultColor.r, defaultColor.g, defaultColor.b, fillOpacity])
                                    ));
                                }
                            })
                        });
                        domConstruct.place(sliderForBorder.domNode, domContentForBorderSliderright);
                        var domContentSelectBorderWidthSpan = domConstruct.create("div", {
                            "class": "domContentSelectBorderWidthSpan"
                        }, domContentDynamicMain);
                        domContentSelectBorderWidthSpan.innerHTML = "Width";
                        var domContentSelectBorderWidth = domConstruct.create("div", {
                            "class": "domContentSelectBorderWidth"
                        }, domContentDynamicMain);
                        var domContentSelectBorderWidth12 = domConstruct.create("div", {}, domContentSelectBorderWidth);
                        var selectBorderWidth = new Select({
                            name: "width",
                            options: [{
                                label: "1",
                                value: "1"
                            }, {
                                label: "2",
                                value: "2"
                            }, {
                                label: "3",
                                value: "3"
                            }, {
                                label: "4",
                                value: "4"
                            }, {
                                label: "5",
                                value: "5"
                            }],
                            onChange: lang.hitch(this, function (value) {
                                var fillColor, lineColor, borderOpacity, fillOpacity;
                                if (this._modifiedFillColor) {
                                    fillColor = this._modifiedFillColor;
                                } else {
                                    if (this._currentFillColor) {
                                        fillColor = this._currentFillColor;
                                    }
                                }
                                if (this._modifiedLineColor) {
                                    lineColor = this._modifiedLineColor;
                                } else {
                                    lineColor = this._currentLineColor;
                                }
                                if (this._modifiedBorderOpacity) {
                                    borderOpacity = this._modifiedBorderOpacity;
                                } else {
                                    borderOpacity = this._currentLineColor.a;
                                }
                                if (this._modifiedOpacity) {
                                    fillOpacity = this._modifiedOpacity;
                                } else {
                                    if (this._currentFillColor) {
                                        fillOpacity = this._currentFillColor.a;
                                    }
                                }
                                var defaultColor = new Color(fillColor);
                                var deafultLineColor = new Color(lineColor);
                                if (this.selectedGraphic.geometry.type == "polyline") {
                                    this.selectedGraphic.setSymbol(new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                        new Color([deafultLineColor.r, deafultLineColor.g, deafultLineColor.b, borderOpacity])).setWidth(value));
                                } else {
                                    this.selectedGraphic.setSymbol(new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                        new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                            new Color([deafultLineColor.r, deafultLineColor.g, deafultLineColor.b, borderOpacity])).setWidth(value),
                                        new Color([defaultColor.r, defaultColor.g, defaultColor.b, fillOpacity])
                                    ));
                                }
                                this._modifiedLineWidth = value;
                            })
                        });
                        selectBorderWidth.set("value", this._currentWidth);
                        domConstruct.place(selectBorderWidth.domNode, domContentSelectBorderWidth12);
                    }
                    var buttonDiv = domConstruct.create("div", {
                        "class": "buttonClass"
                    }, domContentDynamicMain);
                    var saveButton = new Button({
                        label: "OK"
                    });
                    saveButton.startup();
                    saveButton.placeAt(buttonDiv);
                    saveButton.on("click", function (event) {
                        domConstruct.destroy("editFeaturesMainContainer"); // `this` points to the button
                    });
                    var cancelButton = new Button({
                        label: "Cancel"
                    });
                    cancelButton.startup();
                    cancelButton.placeAt(buttonDiv);
                    cancelButton.on("click", lang.hitch(this, function (event) {
                        if (evt.graphic.geometry.type === "polygon") {
                            var defaultColor = new Color(this._currentFillColor);
                            this.selectedGraphic.setSymbol(new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                    new Color(this._currentLineColor)).setWidth(this._currentWidth),
                                new Color([defaultColor.r, defaultColor.g, defaultColor.b, this._currentFillColor.a])
                            ));
                            this.selectedGraphic.attributes.id = this._graphicTitle;
                            this.selectedGraphic.attributes.description = this._graphicDescription;
                        }
                        domConstruct.destroy("editFeaturesMainContainer");
                    }));
                    var screenGeometry = screenUtils.toScreenGeometry(this.map.extent, this.map.width, this.map.height, evt.graphic._extent.getCenter());
                    if (evt.graphic.geometry.type == "point") {
                        html.setStyle(domContentDynamicMain, {
                            position: "absolute",
                            left: screenGeometry.x + "px",
                            top: screenGeometry.y + "px",
                            height: "130px"
                        });
                    } else if (evt.graphic.geometry.type == "polyline") {
                        html.setStyle(domContentDynamicMain, {
                            position: "absolute",
                            left: screenGeometry.x + "px",
                            top: screenGeometry.y + "px",
                            height: "300px"
                        });
                    } else {
                        html.setStyle(domContentDynamicMain, {
                            position: "absolute",
                            left: screenGeometry.x + "px",
                            top: screenGeometry.y + "px",
                            height: "400px"
                        });
                    }
                    screenGeometry.y = screenGeometry.y + 65;
                    var mapScreenGeometry = screenUtils.toMapGeometry(this.map.extent, this.map.width, this.map.height, screenGeometry);
                    this.map.centerAndZoom(mapScreenGeometry, this.map.getZoom());
                    on(this.map, "extent-change", lang.hitch(this, function (evt) {
                        var screenGeometry = screenUtils.toScreenGeometry(this.map.extent, this.map.width, this.map.height, this.selectedGraphic._extent.getCenter());
                        if (dom.byId("editFeaturesMainContainer")) {
                            domStyle.set("editFeaturesMainContainer", "left", screenGeometry.x + "px");
                            domStyle.set("editFeaturesMainContainer", "top", screenGeometry.y + "px");
                        }
                    }));
                }
            }));
        },
        
        _addToMap: function (evt) {
            this._shelter.show("Loading");
            var symbol;
            switch (evt.geometry.type) {
                case "point":
                    symbol = new SimpleMarkerSymbol();
                    break;
                case "multipoint":
                    symbol = new SimpleMarkerSymbol();
                    break;
                case "polyline":
                    symbol = new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                        new Color(this._defaultLineColor)).setWidth(this._defaultLineWidth);
                    break;
                default:
                    {
                        var defaultColor = new Color(this._defaultFillColor);

                        symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                            new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                new Color(this._defaultLineColor)).setWidth(this._defaultLineWidth),
                            new Color([defaultColor.r, defaultColor.g, defaultColor.b, this._defaultOpacity])
                        );

                        break;
                    }
            }
            var graphic = new Graphic(evt.geometry, symbol, {
                "id": "Element" + this.elementIndex,
                "description": "Element" + this.elementIndex
            });
            this.elementIndex++;
            if ( (this.graphicsLayer == null || !this.map.getLayer(this.graphicsLayer.id) ) && !this.map.getLayer("Drawing")) {
                this.graphicsLayer = new GraphicsLayer({
                    "id": "Drawing"
                });
                this.map.addLayer(this.graphicsLayer);
            }
            this.graphicsLayer.add(graphic);
            this._shelter.hide();
        },

        activateToolbar: function (graphic) {
            var tool = tool || Edit.MOVE;
            this.editToolbar.activate(tool, graphic);
        },

        /**
        * Display the panel and activate the directions widget.
        */
        show: function () {
            if (!this.isOpen) {
                domClass.add(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                //create graphics layer
                if (this.appUtils.editOverlayLayerId) {
                    this.graphicsLayer = this.map.getLayer(this.appUtils.editOverlayLayerId + "_layer");
                    html.removeClass(this.createAndSaveDiv, "createAndSaveDom");
                    html.addClass(this.createAndSaveDiv, "hide");
                    
                    html.removeClass(this.btnSaveUpdates.domNode, "hide");
                    html.addClass(this.btnSaveUpdates.domNode, "show");
                    
                    html.removeClass(this.divUpdateState, "hide");
                    html.addClass(this.divUpdateState, "show");
                    
                    if(this.appUtils.currentOverlayEdit.state == 1)
                    	this.checkboxUpdateOverlayState.set("checked", true);
                    else
                    	this.checkboxUpdateOverlayState.set("checked", false);
                    
                } else {
                    if (this.config.createOverlayURL) {
                        html.addClass(this.createAndSaveDiv, "createAndSaveDom");
                        html.removeClass(this.createAndSaveDiv, "hide");
                    }
                    if (!this.map.getLayer("Drawing")) {
                        this.graphicsLayer = new GraphicsLayer({
                            "id": "Drawing"
                        });
                        this.map.addLayer(this.graphicsLayer);
                    }
                    if(this.btnSaveUpdates != null)
                    {
                    	html.removeClass(this.btnSaveUpdates.domNode, "show");
                        html.addClass(this.btnSaveUpdates.domNode, "hide");
                    }
                    if(this.divUpdateState != null)
                    {
                    	html.removeClass(this.divUpdateState, "show");
                        html.addClass(this.divUpdateState, "hide");
                    }
                }
            } else {
                this.hide();
            }
        },

        /**
        * Hide the panel
        */
        hide: function () {
            this.isOpen = false;
            this.editToolbar.deactivate();
            this.toolbar.deactivate();
            if (query(".imgSelected")[0]) {
                domClass.remove(query(".imgSelected")[0], "imgSelected");
            }
            this.hideFixedRadiusDom();
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
            }
        },
        hideFixedRadiusDom: function () {

            domStyle.set("drawCircleOptions", "display", "none");

        },
        /**
        * Setting the widget panel position.
        */
        _placeWidgetContainer: function () {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
        * Widget Related Events
        */
        _attachWidgetRelatedEvents: function () {
            on(window, "resize", lang.hitch(this, function () {
                this._panel.resize();
            }));
        }
    });
});
