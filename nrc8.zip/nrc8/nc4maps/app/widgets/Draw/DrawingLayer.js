define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/html",
    "esri/tasks/ProjectParameters", 
    "app/nc4modules/NC4GeometryService", 
    "esri/SpatialReference",
    "esri/layers/GraphicsLayer",
    "esri/InfoTemplate",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/query",
    "dojo/promise/all",
    "dojo/Deferred"
], function(declare, lang, html,ProjectParameters, NC4GeometryService, SpatialReference, GraphicsLayer, InfoTemplate, domStyle, domClass, query, all, Deferred) {
	return declare([], {
		
		map: null,
		appUtils: null,
		_shelter: null,
		config: null,
		_nc4Notify: null,
		textOverlayName: null,
		toolbar: null,
		
		constructor: function(p_map, p_appUtils, p_shelter, p_config, p_nc4Notify, p_textOverlayName, p_toolbar)
		{
			this.map = p_map;
			this.appUtils = p_appUtils;
			this._shelter = p_shelter;
			this.config = p_config;
			this._nc4Notify = p_nc4Notify;
			this.textOverlayName = p_textOverlayName;
			this.toolbar = p_toolbar;
		},
		
		/*
		 * p_layerMeta - same as clusterNode[0].item object
		 */
		update: function(p_layerMeta, p_id)
		{
			this._shelter.show();
			
			var id = (this.appUtils.editOverlayLayerId) ? this.appUtils.editOverlayLayerId : p_layerMeta.id;
            objLayer = this.map.getLayer(id + "_layer");
			
			if(objLayer)
			{
				all([this._projectGeometry(objLayer)]).then(lang.hitch(this, function(p_graphics){
	            	this._update(p_layerMeta, true, p_graphics);
	            }));
			}
			else
				this._update(p_layerMeta, false );
			
		},
		
		_update: function(p_layerMeta,  p_includeGraphics, p_grahicsData)
		{
			var postData = null;
			
			var opacity = 100;
			
			if(p_layerMeta.fromWidget && p_layerMeta.fromWidget == "draw")
				opacity = p_layerMeta.opacity * 100;
			else if(p_layerMeta.opacity)
				opacity = p_layerMeta.opacity;
			
			
			if(p_includeGraphics && p_includeGraphics == true)
			{
				postData = {
            		f: "jsonp",
                    id: p_layerMeta.id,
                    name: p_layerMeta.name,
                    graphics: p_grahicsData,
                    wkid: 102100,
                    parent: "nc4maps_overlays",
                    opacity: opacity,
                    refresh: p_layerMeta.refresh,
                    state: p_layerMeta.state
            	};
			}
			else
			{
				postData = {
            		f: "jsonp",
                    id: p_layerMeta.id,
                    name: p_layerMeta.name,
                    wkid: 102100,
                    parent: "nc4maps_overlays",
                    opacity: opacity,
                    refresh: p_layerMeta.refresh,
                    state: p_layerMeta.state
            	};
			}
			
			
			dojo.xhrPost({
            	url: this.config.OverlayUpdateService,
            	handleAs: "json",
            	postData: postData,
            	load: lang.hitch(this, function (response) {
            		this._nc4Notify.success("Layer saved Successfully");
                    this._shelter.hide();
                    this.appUtils.openWidget("DataLayers");
                    this.appUtils.doneOverlayEditing();
                    
            	}),
            	error: lang.hitch(this, function(response) {
            		this._nc4Notify.error("Unable to Save Layer");
            		console.error("Unable to save, responses: " , response);
                    this._shelter.hide();
            	})
            });
		},
		
		_projectGeometry: function(p_layer)
		{
			var deferred = new Deferred();
			var objGeometries = [];
			var objFeaturecollection = [];
			
			var objLayer = p_layer;
            for (var j = 0; j < objLayer.graphics.length; j++) 
            {
                var currGeom = objLayer.graphics[j].geometry;
            	objGraphics = {
                        "symbol": objLayer.graphics[j].toJson().symbol,
                        "attributes": objLayer.graphics[j].toJson().attributes
                    };
            	objGeometries.push(currGeom);
            	objFeaturecollection.push(objGraphics);
            }
            var params = new ProjectParameters();
            params.geometries = objGeometries;
            
            this.outSR = null;
            if(this.config.saveSR)
            {
            	try{
            		this.outSR = new SpatialReference(this.config.saveSR)
            	}
            	catch(error)
            	{
            		this.outSR = new SpatialReference(4326)
            	}
            }
            else 
            	this.outSR = this.map.spatialReference;
            
            params.outSR = this.outSR;
            var gsvc = new NC4GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL, this.appUtils);
            this.objFeaturecollection = objFeaturecollection,
            gsvc.project(params, this, function(updatedGeometries)
            		{
                		for(var i =0; i<this.objFeaturecollection.length;i++){
  		            		var currFeatColl = this.objFeaturecollection[i];
  		            		var currGeometry = updatedGeometries[i];
  		            		currFeatColl.geometry = currGeometry;
       	           		}
                        var graphicsData = JSON.stringify(this.objFeaturecollection);
                        deferred.resolve(graphicsData);
            		}, 
            		function(){console.error("error TODO");}
            	);
        	return deferred.promise;
		},
		
		
        saveNew: function (p_layer, overlayName, p_defaultState) {
            all([this._projectGeometry(p_layer)]).then(lang.hitch(this, function(p_graphics){
            	this.setOverlayData(p_graphics, overlayName, p_defaultState);
            }));
        },

        setOverlayData: function (graphicData, overlayName, p_defaultState) {
            esriConfig.defaults.io.alwaysUseProxy = false;
            this._shelter.show();
            
            //TODO James: Use dojo doPost instead.  ESRI Request will automatically post to proxy if request is over 2000.
            dojo.xhrPost({
            	url: this.config.createOverlayURL,
            	handleAs: "json",
            	postData: {
            		 f: "jsonp",
                    name: overlayName,
                    graphics: graphicData,
                    wkid: this.outSR.wkid,
                    parent: "nc4maps_overlays",
                    opacity: this.appUtils.configGeneralSettings.defaultOpacity || 100,					
                    refresh: this.appUtils.configGeneralSettings.defaultRefRate || 0,
                    state: p_defaultState
            	},
            	load: lang.hitch(this, function (response) {
                    if (response.success === true) {
                    	this._nc4Notify.success("Overlay saved successfully");
                    	
                    		var layerDetail = {
                                    "type": "graphics",
                                    "url": this.config.responseOverlayURL + response.processedObjects.id,
                                    "opacity": this.appUtils.configGeneralSettings.defaultOpacity / 100 || 1,			//we store in the database from 0 - 100, but js api  needs from 0 - 1
                                    "refresh": this.appUtils.configGeneralSettings.defaultRefRate || 0,
                                    "bbox": 0,
                                    "id": response.processedObjects.id,
                                    "name": overlayName,
                                    "state": 1,
                                    "sr": this.map.spatialReference.wkid.toString(),
                                    "basemap": 0,
                                    "parent": "nc4maps_overlays"
                                };
                    		
                    		if (this.appUtils.treeNode) {
                                this.appUtils.customLayerAdded(layerDetail);
                            }
                    		
                        	//Create a graphic layer and add overlay graphics in it
                            var graphicsLayer = new GraphicsLayer({
                                "id": layerDetail.id + "_layer",
                                "addedType": "graphics",
                                "name": overlayName,
                                infoTemplate: new InfoTemplate(overlayName, "${*}")
                            });
                            graphicsLayer.customLayerType = "Drawing";
                            graphicsLayer.overlayCustomLayerType = overlayName;
                            this.map.addLayer(graphicsLayer);
                            graphicsLayer.enableMouseEvents();
                            var drawGraphicsLayer = this.map.getLayer("Drawing");
                            if (drawGraphicsLayer) {
                                for (var i = 0; i < drawGraphicsLayer.graphics.length; i++) {
                                    graphicsLayer.add(drawGraphicsLayer.graphics[i]);
                                }
                                /*reset drawing layer instead of removing:
                                while(drawGraphicsLayer.graphics.length > 0)
                                {
                                	drawGraphicsLayer.remove(drawGraphicsLayer.graphics[0])
                                }*/
                                this.map.removeLayer(drawGraphicsLayer);
                            }
                            graphicsLayer.on("mouse-over", lang.hitch(this, function () {
                                this.map.setMapCursor("pointer");
                            }));
                            graphicsLayer.on("mouse-out", lang.hitch(this, function () {
                                this.map.setMapCursor("default");
                            }));
                            
                            this.appUtils.overlayLayersAdded(layerDetail); //Store added overlay details
                            this.appUtils.createOverlayMode(false);
                        
                        
                        this._shelter.hide();
                    } else {
                        this._nc4Notify.error("Overlay not saved");
                        this._shelter.hide();
                    }
                }),
                error: lang.hitch(this, this._onErrordelete)
            });
        },
        
        _onErrordelete: function(error) {
            this._shelter.hide();
            this._nc4Notify.error("Unable to save Overlay");
        }
        
	});
});