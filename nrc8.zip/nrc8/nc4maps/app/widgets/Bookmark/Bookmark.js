define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom",
    "dojo/dom-attr",
    "dojo/on",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/text!./BookmarkTemplate.html",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/form/Button",
    "esri/request",
    "esri/SpatialReference",
    "esri/geometry/Extent",
    "esri/geometry/webMercatorUtils",
    "esri/config",
    "esri/tasks/ProjectParameters",
    "esri/geometry/Polygon",
    "app/widgets/AlertBox/AlertBox",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter"
], function(
    declare,
    html,
    lang,
    aspect,
    dom,
    domAttr,
    on,
    domClass,
    domStyle,
    sharedNls,
    template,
    _WidgetBase,
    _TemplatedMixin,
    Button,
    esriRequest,
    SpatialReference,
    Extent,
    webMercatorUtils,
    esriConfig,
    ProjectParameters,
    Polygon,
    AlertBox,
    WidgetPanel,
    LoadingShelter
) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "Bookmark",
        baseClass: "widget-Bookmark",
        sharedNls: sharedNls,
        templateString: template,
        isOpen: false,
        _panel: null,
        _shelter: null,
        _dynamicBookmarkContainer: null,
        _alertBox: null,
        _btnAddBookmark: null,
        _btnSaveBookmark: null,
        _btnSetDefault: null,
        _btnDeleteBookmark: null,
        _bookmarkInputName: null,
        _textContent: null,
        _storeBookmarkNames: [],
        _storeBookmarkData: [],
        _storeServiceBookmarkNames: [],
        _selectedBookmark: null,
        _saveButton: null,
        _extentValues: [],
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },

        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and create some widget UI.
         */
        postCreate: function() {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetBookmarkIcon"
            }, null);
            this._placeWidgetContainer();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
            this.textBookmarkName.placeholder = sharedNls.Bookmark.bookmarkName;
            this._dynamicBookmarkContainer = html.create("div", {
                "class": "dynamicAddBookmark"
            }, this.addBookmarkContainer);
            this._getButtons();
            this._getBookmarkData();
            this._alertBox = new AlertBox();
        	this._nc4Notify = this.appUtils.nc4Notify;
            this._attachWidgetRelatedEvents();
            if(this.config.add == 0){
                console.log(this);
                html.removeClass(this.addBookmark, "show");
                html.addClass(this.addBookmark, "hide");
                html.removeClass(this._btnAddBookmark.domNode, "show");
                html.addClass(this._btnAddBookmark.domNode, "hide");
                this._btnAddBookmark.disabled = true;
            }
            if (this.config.deleteBookmarkService) {
                html.addClass(this._btnDeleteBookmark.domNode, "show");
                html.removeClass(this._btnDeleteBookmark.domNode, "hide");
                this._btnDeleteBookmark.disabled = false;
            } else {
                html.removeClass(this._btnDeleteBookmark.domNode, "show");
                html.addClass(this._btnDeleteBookmark.domNode, "hide");
                //this._btnBookmark.disabled = true;
            }
            
            if(this.config.saveBookmarkServiceUrl){
            	html.addClass(this._btnSetDefault.domNode, "show");
                html.removeClass(this._btnSetDefault.domNode, "hide");
                this._btnSetDefault.disabled = false;
            } else {
                html.removeClass(this._btnSetDefault.domNode, "show");
                html.addClass(this._btnSetDefault.domNode, "hide");
                //this._btnBookmark.disabled = true;
            }
            
            this._btnSaveBookmark.disabled = true;
            html.removeClass(this._btnSaveBookmark.domNode, "show");
            html.addClass(this._btnSaveBookmark.domNode, "hide");
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
        },

        /**
         * Buttons ADD,Save and  for bookmark.
         */
        _getButtons: function() {
            this._btnAddBookmark = new Button({
                label: sharedNls.Bookmark.buttonAdd
            }, this.addBookmarkButton);
            this._btnSaveBookmark = new Button({
                label: sharedNls.Bookmark.buttonSave

            }, this.saveBookmarkButton);
            this._btnSetDefault = new Button({
                label: "Set As Default"
            }, this.setDefaultButton);
            this._btnDeleteBookmark = new Button({
                label: sharedNls.Bookmark.buttonDelete
            }, this.deleteBookmarkButton);
        },

        /**
         *This function validates the bookmark name provided by the user.
         */
        _validateBookmark: function() {
            var BookmarkNames,
                isValidUrl,
                i,
                j,
                regexp,
                ServiceBookmarkNames;
            this._BookmarkInputName = lang.trim(this.textBookmarkName.value);
            if (this._BookmarkInputName === "") {
                this._nc4Notify.error(sharedNls.Bookmark.emptyBookmark);
                this._shelter.hide();
                return false;
            }
            regexp = /^[a-zA-Z0-9\-\s]+$/;
            isValidUrl = regexp.test(this._BookmarkInputName);
            if (isValidUrl === false) {
            	this._nc4Notify.error(sharedNls.Bookmark.errorBookmarkTextbox);
                this._shelter.hide();
                return false;
            }
            if (this._storeServiceBookmarkNames.length > 0) {
                for (i = 0; i < this._storeServiceBookmarkNames.length; i++) {
                    BookmarkNames = this._storeServiceBookmarkNames[i].toUpperCase();
                    if (BookmarkNames == this._BookmarkInputName.toUpperCase()) {
                    	this._nc4Notify.error(sharedNls.Bookmark.nameExists);
                        return false;
                    }
                }
            }
            if (this._storeBookmarkNames.length > 0) {
                for (j = 0; j < this._storeBookmarkNames.length; j++) {
                    ServiceBookmarkNames = this._storeBookmarkNames[j].toUpperCase();
                    if (ServiceBookmarkNames == this._BookmarkInputName.toUpperCase()) {
                    	this._nc4Notify.error(sharedNls.Bookmark.nameExists);
                        return false;
                    }
                }
            }
            this._bookmarkExtentData();
        },

        /**
         * This function is convert the bookmark extent data to webMercator format.
         */
        _bookmarkExtentData: function() {
            var bookmarkData,
                geometryService,
                newExtent,
                polygon,
                params;
            this._shelter.show();
            if (this.map.spatialReference.wkid === 4326 || this.map.spatialReference.wkid === 102100) {
                bookmarkData = webMercatorUtils.webMercatorToGeographic(new Extent(this.map.extent.xmin, this.map.extent.ymin, this.map.extent.xmax, this.map.extent.ymax, this.map.spatialReference));
                this._addBookMarkData(bookmarkData);
            } else {
                polygon = new Polygon(new SpatialReference({
                    wkid: this.map.spatialReference.wkid
                }));
                polygon.addRing([
                    [parseFloat(this.map.extent.xmin), parseFloat(this.map.extent.ymin)],
                    [parseFloat(this.map.extent.xmin), parseFloat(this.map.extent.ymax)],
                    [parseFloat(this.map.extent.xmax), parseFloat(this.map.extent.ymax)],
                    [parseFloat(this.map.extent.xmax), parseFloat(this.map.extent.ymin)]
                    //[parseFloat(extent.xmin), parseFloat(extent.ymin)]
                ]);
                params = new ProjectParameters();
                params.geometries = [polygon];
                params.outSR = new SpatialReference(4326);
                geometryService = esriConfig.defaults.geometryService;
                geometryService.project(params, lang.hitch(this, function(geometries) {
                    newExtent = geometries[0].getExtent();
                    if (newExtent) {
                        this._addBookMarkData(newExtent);
                    } else {
                        this._shelter.hide();
                        this._nc4Notify.error(sharedNls.Bookmark.spatialReferenceError);
                    }
                }), lang.hitch(this, function(error) {
                    this._shelter.hide();
                    this._nc4Notify.error(sharedNls.Bookmark.spatialReferenceError);
                }));
            }
        },

        /**
         * Adding the bookmark.
         * @param {object} bookmarkExtent - Bookmark extent data.
         */
        _addBookMarkData: function(bookmarkExtent) {
            var bookmarkContainer = this._createBookmark();
            var savebookmark;
            domAttr.set(bookmarkContainer, "name", this._BookmarkInputName);
            domAttr.set(bookmarkContainer, "xmin", bookmarkExtent.xmin);
            domAttr.set(bookmarkContainer, "ymin", bookmarkExtent.ymin);
            domAttr.set(bookmarkContainer, "xmax", bookmarkExtent.xmax);
            domAttr.set(bookmarkContainer, "ymax", bookmarkExtent.ymax);
            domAttr.set(bookmarkContainer, "spatialReference", bookmarkExtent.spatialReference.wkid);
            this._storeBookmarkData.push(savebookmark = {
                "bookmark_name": this._BookmarkInputName,
                "xmin": bookmarkExtent.xmin,
                "ymin": bookmarkExtent.ymin,
                "xmax": bookmarkExtent.xmax,
                "ymax": bookmarkExtent.ymax,
                "sr": bookmarkExtent.spatialReference.wkid.toString()
            });
            this._addBookmarkEvent(bookmarkExtent, bookmarkContainer);
            this._shelter.hide();
        },

        /**
         * Added Bookmark attached event.
         * @param {object} bookmarkExtent - Bookmark extent data.
         */
        _addBookmarkEvent: function(bookmarkExtent, bookmarkContainer) {
            on(bookmarkContainer, "click", lang.hitch(this, function(evt) {
                var getBookmarkextent = {
                    "name": domAttr.get(evt.currentTarget.id, "name"),
                    "xmin": domAttr.get(evt.currentTarget.id, "xmin"),
                    "ymin": domAttr.get(evt.currentTarget.id, "ymin"),
                    "xmax": domAttr.get(evt.currentTarget.id, "xmax"),
                    "ymax": domAttr.get(evt.currentTarget.id, "ymax"),
                    "spatialReference": domAttr.get(evt.currentTarget.id, "spatialReference")
                };
                this.appUtils.layerExtent(getBookmarkextent);
                this._ServiceBookmarkResults(getBookmarkextent);
            }));
            this._storeBookmarkNames.push(lang.trim(this.textBookmarkName.value));
            this.textBookmarkName.value = "";
            domAttr.set(this.textBookmarkName, "displayedValue", "");
            if (this.config.saveBookmarkServiceUrl) {
                this._btnSaveBookmark.disabled = false;
                html.removeClass(this._btnSaveBookmark.domNode, "hide");
                html.addClass(this._btnSaveBookmark.domNode, "show");
            } else {
                this._btnSaveBookmark.disabled = true;
                html.addClass(this._btnSaveBookmark.domNode, "hide");
                html.removeClass(this._btnSaveBookmark.domNode, "show");
            }
        },

        /**
         * Creating the selected bookmark.
         */
        _createBookmark: function() {
            var bookServiceNames,
                bookmarkContainer,
                bookmarkContainerMain,
                imageContainer;
            bookmarkContainerMain = html.create("div", {
                "id": this._BookmarkInputName + "_main"
            }, this._dynamicBookmarkContainer, "first");

            bookmarkContainer = html.create("div", {
                "class": "dynamicImageAddgray",
                "id": this.textBookmarkName.value
            }, bookmarkContainerMain);

            on(bookmarkContainerMain, "click", lang.hitch(this, function(evt) {
                if (this._selectedBookmark) {
                    domClass.toggle(this._selectedBookmark, "bookmarkImgBlueMain");
                }
                domClass.toggle(evt.currentTarget.id, "bookmarkImgBlueMain");
                this._selectedBookmark = evt.currentTarget.id;
                this._textContent = evt.currentTarget.textContent;
            }));
            imageContainer = html.create("div", {
                "class": "dynamicImageGray",
                "id": this.textBookmarkName.value + "image"
            }, bookmarkContainer);

            bookServiceNames = html.create("span", {
                "class": "bookmarktext",
                "innerHTML": this.textBookmarkName.value
            }, imageContainer);
            return bookmarkContainer;
        },

        
        /**
         * refresh bookmark list.  should be called after save or if a refresh button is implemented
         */
        _refreshBookmarkList: function()
        {
        	//first, remove all:
             this._storeBookmarkNames = [];
             this._storeServiceBookmarkNames = [];
             this._storeBookmarkData = [];
             this._selectedBookmark = null;
             this._textContent = null;
             
             require(["dojo/query", "dojo/dom"], function(query, dom){
            	 query(".dynamicAddBookmark").forEach(function(node){
            		 html.destroy(node);
            	 });
            	 html.destroy(this._dynamicBookmarkContainer);
             });
             
             //re-add
             this._dynamicBookmarkContainer = html.create("div", {
                 "class": "dynamicAddBookmark"
             }, this.addBookmarkContainer);
             
             this._getBookmarkData();
             
        },
        
        /**
         * Deleting the selected bookmark.
         * @param {array} response - array fields of book mark data.
         */
        _deleteBookmark: function(response) {
            var deletingArrayitem,
                deletingArrayitemdiv,
                delCount,
                i,
                ServiceArrayItem;
            deletingArrayitem = (this._selectedBookmark.split("_")[0]);
            for (i = 0; i < response.length; i++) {
                if (this._textContent == response[i].name) {
                    esriRequest({
                        url: this.config.deleteBookmarkService,
                        content: lang.mixin({
                            id: response[i].id
                        }, null),
                        callbackParamName: "callback",
                        load: lang.hitch(this, this._deleteBookmarksuccess),
                        error: lang.hitch(this, this._onErrordelete)
                    });
                }
            }
            deletingArrayitemdiv = this._storeBookmarkNames.indexOf(this._selectedBookmark.split("_")[0]);
            if (deletingArrayitemdiv >= 0) {
                this._storeBookmarkNames.splice(deletingArrayitemdiv);
            }
            ServiceArrayItem = this._storeServiceBookmarkNames.indexOf(this._textContent.split("_")[0]);
            if (ServiceArrayItem >= 0) {
                this._storeServiceBookmarkNames.splice(ServiceArrayItem, 1);
            }
            for (delCount = 0; delCount < this._storeBookmarkData.length; delCount++) {
                if (this._storeBookmarkData[delCount].bookmark_name === deletingArrayitem) {
                    this._storeBookmarkData.splice(delCount, 1);
                    this._deleteBookmarksuccess();
                }
            }
            html.destroy(this._selectedBookmark);
            this._selectedBookmark = null;
        },

        /**
         * This function is displays the success message to user for deleted bookmark.
         */
        _deleteBookmarksuccess: function() {
        	this._nc4Notify.success(sharedNls.Bookmark.deleteBookmarkService);
        },

        /**
         * This function is displays the error message to user.
         */
        _onErrordelete: function() {
            this._shelter.hide();
            this._nc4Notify.error(sharedNls.Bookmark.errorBookmark);
        },

        /**
         * Save the bookmark data.
         */
        _saveBookmark: function() {
            var customBookmarksdata = JSON.stringify(this._storeBookmarkData);
            esriRequest({
                url: this.config.saveBookmarkServiceUrl,
                content: lang.mixin({
                    customBookmarks: customBookmarksdata
                }),
                callbackParamName: "callback",
                load: lang.hitch(this, this._saveBookmarksuccess),
                error: lang.hitch(this, this._onErrordelete)
            }, null);
        },

        /**
         * This function is displays the success message to user for saved bookmark.
         */
        _saveBookmarksuccess: function() {
            var i;
            for (i = 0; i < this._storeBookmarkNames.length; i++) {
                domClass.replace(this._storeBookmarkNames[i] + "image", "dynamicImageBlue", "dynamicImageGray");
            }
            this._btnSaveBookmark.disabled = true;
            html.removeClass(this._btnSaveBookmark.domNode, "show");
            html.addClass(this._btnSaveBookmark.domNode, "hide");
            this._nc4Notify.success(sharedNls.Bookmark.saveBookmarkService);
            this._storeBookmarkData = [];
            
            //now do a refresh of the bookmarks:
            this._refreshBookmarkList();
            
            this._shelter.hide();
        },

        /**
         * Fetching the bookmark data from service.
         */
        _getBookmarkData: function() {
            if(this.config.bookmarkService != null && this.config.bookmarkService != "")
        	{
            	esriRequest({
                    url: this.config.bookmarkService,
                    content: lang.mixin({
                        f: "json"
                    }, null),
                    callbackParamName: "callback",
                    load: lang.hitch(this, function(response) {
                        this._createWidgetUI(response, "service");
                        this._shelter.hide();
                    }),
                    error: lang.hitch(this, this._onErrorTasks)
                });
        	}
            else
            	this._shelter.hide();
            	
        },

        /**
         * Create the bookmark widget.
         * @param {Object} response - Object having detail of specific bookmark data.
         */
        _createWidgetUI: function(response, createFrom) {
            var bookServiceNames,
                bookmarkContainerMain,
                bookmarkContainer,
                imageContainer,
                i;
            for (i = 0; i < response.length; i++) {
                this._storeServiceBookmarkNames.push(response[i].name);
                bookmarkContainerMain = html.create("div", {
                    "id": response[i].id + "_main"
                }, this._dynamicBookmarkContainer);
                bookmarkContainer = html.create("div", {
                    "class": "bookmarkImgBlue",
                    "id": response[i].id
                }, bookmarkContainerMain);
                imageContainer = html.create("div", {
                    "class": "dynamicImageBlue",
                    "id": response[i].name
                }, bookmarkContainer);
                bookServiceNames = html.create("span", {
                    "class": "bookmarktext",
                    "innerHTML": response[i].name
                }, imageContainer);
                domAttr.set(bookmarkContainer, "xmin", response[i].extent.xmin);
                domAttr.set(bookmarkContainer, "ymin", response[i].extent.ymin);
                domAttr.set(bookmarkContainer, "xmax", response[i].extent.xmax);
                domAttr.set(bookmarkContainer, "ymax", response[i].extent.ymax);
                domAttr.set(bookmarkContainer, "spatialReference", response[i].extent.spatialReference.wkid);
                this._bookmarkAttachedEvents(bookmarkContainerMain, bookmarkContainer);
            }
            this._shelter.hide();
        },

        /**
         * Attached events for bookmark.
         */
        _bookmarkAttachedEvents: function(bookmarkContainerMain, bookmarkContainer) {
            var bookmarkextent;
            on(bookmarkContainerMain, "click", lang.hitch(this, function(evt) {
                if (this._selectedBookmark) {
                    domClass.toggle(this._selectedBookmark, "bookmarkImgBlueMain");
                }
                domClass.toggle(evt.currentTarget.id, "bookmarkImgBlueMain");
                this._selectedBookmark = evt.currentTarget.id;
                this._textContent = evt.currentTarget.textContent;
            }));
            on(bookmarkContainer, "click", lang.hitch(this, function(evt) {
                bookmarkextent = {
                    "xmin": domAttr.get(evt.currentTarget.id, "xmin"),
                    "ymin": domAttr.get(evt.currentTarget.id, "ymin"),
                    "xmax": domAttr.get(evt.currentTarget.id, "xmax"),
                    "ymax": domAttr.get(evt.currentTarget.id, "ymax"),
                    "spatialReference": domAttr.get(evt.currentTarget.id, "spatialReference")
                };
                this.appUtils.layerExtent(bookmarkextent);
                this._ServiceBookmarkResults(bookmarkextent);
                
                //assign for save default service
                this.appUtils.configGeneralSettings.defaultBookmark = evt.currentTarget.id;
            }));
        },
        
        /**
         * This function shows the bookmark results
         * @param {Object} extent - Object having detail of specific bookmark extent details.
         */
        _ServiceBookmarkResults: function(extent) {
            var getBookmarkExtent,
                startExtent = {},
                extentObj = null;
            this._shelter.show();
            startExtent = new Extent();
            startExtent.xmin = parseFloat(extent.xmin);
            startExtent.ymin = parseFloat(extent.ymin);
            startExtent.xmax = parseFloat(extent.xmax);
            startExtent.ymax = parseFloat(extent.ymax);
            startExtent.spatialReference = new SpatialReference(parseInt(extent.spatialReference, 10));
            if (this.map.spatialReference.wkid === 4326) {
                getBookmarkExtent = this.map.setExtent(startExtent);
                getBookmarkExtent.then(lang.hitch(this, function(evt) {
                    this._shelter.hide();
                }));
            } else if (this.map.spatialReference.wkid === 102100) {
                extentObj = new Extent(webMercatorUtils.geographicToWebMercator(startExtent));
                getBookmarkExtent = this.map.setExtent(extentObj);
                getBookmarkExtent.then(lang.hitch(this, function(evt) {
                    this._shelter.hide();
                }));
            } else {
                this._bookmarkExtentGeometry(extent);
            }
        },

        /**
         * This function to change the spatial reference of bookmark
         * @param {Object} extent - Object having detail of specific bookmark extent details.
         */
        _bookmarkExtentGeometry: function(extent) {
            var getBookmarkExtent,
                geometryService,
                newExtent,
                polygon,
                params;
            polygon = new Polygon(new SpatialReference({
                wkid: 4326
            }));
            polygon.addRing([
                [parseFloat(extent.xmin), parseFloat(extent.ymin)],
                [parseFloat(extent.xmin), parseFloat(extent.ymax)],
                [parseFloat(extent.xmax), parseFloat(extent.ymax)],
                [parseFloat(extent.xmax), parseFloat(extent.ymin)]
                //[parseFloat(extent.xmin), parseFloat(extent.ymin)]
            ]);
            params = new ProjectParameters();
            params.geometries = [polygon];
            params.outSR = new SpatialReference(this.map.spatialReference.wkid);
            geometryService = esriConfig.defaults.geometryService;
            geometryService.project(params, lang.hitch(this, function(geometries) {
                newExtent = geometries[0];
                getBookmarkExtent = this.map.setExtent(newExtent.getExtent());
                getBookmarkExtent.then(lang.hitch(this, function(evt) {
                    this._shelter.hide();
                }));
            }), lang.hitch(this, function(error) {
                this._shelter.hide();
                this._nc4Notify.error(sharedNls.Bookmark.noProjection);
            }));
        },

        /**
         * Report an error, if occurred while requesting data layer tree service.
         * @param {string} err : Error message.
         */
        _onErrorTasks: function(err) {
        	this._nc4Notify.error(sharedNls.Bookmark.invalidService);
            this._shelter.hide();
        },

        /**
         * Display the widget panel.
         */
        show: function() {
            if (!this.isOpen) {
                domClass.add(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                this.appUtils.sidePanelOpen(this.isOpen);
            } else {
                this.hide();
            }
        },

        /**
         * Hide the widget panel
         */
        hide: function() {
            this.isOpen = false;
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.appUtils.sidePanelOpen(this.isOpen);
            }
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Attach widget related events
         */
        _attachWidgetRelatedEvents: function() {
        	on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
            }));
            this.own(on(this._btnAddBookmark, "click", lang.hitch(this, function() {
                this._validateBookmark();
            })));
            this._deleteBookmarkClick();
            this.own(on(this._btnSetDefault, "click", lang.hitch(this, function(evt) {
                     this._setDefaultClick();
             })));
            this.own(on(this._btnSaveBookmark, "click", lang.hitch(this, function(evt) {
               // var savePromtMessage = this._.confirm(sharedNls.Bookmark.saveBookmark);
               // savePromtMessage.then(lang.hitch(this, function(res) {
                    this._saveBookmark(evt);
               // }));
            })));
        },

        /**
         * Attach widget for delete Bookmark events
         */
        _deleteBookmarkClick: function() {
            this.own(on(this._btnDeleteBookmark, "click", lang.hitch(this, function(evt) {
                if (this._selectedBookmark == null) {
                	this._nc4Notify.error(sharedNls.Bookmark.emptySelectedBookmark);
                    this._shelter.hide();
                    return false;
                } else {
                    var deletePromtMessage = this._alertBox.confirm(sharedNls.Bookmark.deleteBookmark);
                    deletePromtMessage.then(lang.hitch(this, function(res) {
                        esriRequest({
                            url: this.config.bookmarkService,
                            content: lang.mixin({
                                f: "json"
                            }, null),
                            callbackParamName: "callback",
                            load: lang.hitch(this, this._deleteBookmark),
                            error: lang.hitch(this, this._onErrordelete)
                        });
                    }));
                }
            })));
        },
        
        
        //TODO: when the default options widget saves, make sure to update default options variables (prevents user from having to refresh)
        
        _setDefaultClick: function() {
                if (this._selectedBookmark == null) {
                	this._nc4Notify.error(sharedNls.Bookmark.emptySelectedBookmark);
                    this._shelter.hide();
                    return false;
                } else {
                	var currBookmark = this._selectedBookmark.split("_")[0];
                	if( dom.byId(currBookmark + "image") != null && domClass.contains(dom.byId(currBookmark + "image"), "dynamicImageGray") )
                	{
                		this._nc4Notify.error("Please save selected bookmark before attempting to set it as default.");
                		return;
                	}
                	
                	var jsonSave = {
                            "mconfig": this.appUtils.configGeneralSettings.defaultBaseMap,
                            "bdefault": this.appUtils.configGeneralSettings.defaultBookmark,
                            "mudefault": this.appUtils.configGeneralSettings.defaultMeasUnit,
                            "odefault": this.appUtils.configGeneralSettings.defaultOpacity,
                            "rdefault": this.appUtils.configGeneralSettings.defaultRefRate,
                            "geomServer": this.appUtils.configGeneralSettings.geometryServiceURL,
                            "gtype": "ArcGIS",
                            "gurl": this.appUtils.configGeneralSettings.geocodeUrl,
                            "maxGResults": this.appUtils.configGeneralSettings.geocodeResults,
                            "printServer": this.appUtils.configGeneralSettings.printService
                        };
                        var objJson = JSON.stringify(jsonSave);
                        esriRequest({
                            url: this.config.saveDefaultsOptions,
                            content: lang.mixin({
                                defaults: objJson
                            }, null),
                            callbackParamName: "callback",
                            load: lang.hitch(this, function(response) {
                                if (response === true) {
                                	this._nc4Notify.success("Default bookmark saved successfully");
                                    this._shelter.hide();
                                } else {
                                	this._nc4Notify.error("Unable to save selected bookmark as default");
                                    this._shelter.hide();
                                }
                            }),
                            error: lang.hitch(this, function(err) {
                            	this._nc4Notify.error("Unable to save selected bookmark as default");
                                this._shelter.hide();
                            })
                        });
                    
                }
        }
      
        
        
    });
});
