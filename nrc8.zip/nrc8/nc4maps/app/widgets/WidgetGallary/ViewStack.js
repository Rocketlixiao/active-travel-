define(["dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/html",
    "dojo/_base/array",
    "dijit/_WidgetBase"
], function(declare, lang, html, array, _WidgetBase) {
    return declare(_WidgetBase, {
        // summary: 
        // a dijit which can hold many views but display only one at on time
        // description:
        // the constructor params is {views: []}, every view should have a property: label.
        // View can be a dijit or dom
        baseClass: "CS-viewstack",
        _currentView: null,

        /**
         * Place multiple views in container
         */
        postCreate: function() {
            this.inherited(arguments);
            if (!this.views) {
                this.views = [];
            }
            array.forEach(this.views, lang.hitch(this, function(view) {
                if (view.nodeType === 1) {
                    html.place(view, this.domNode);
                    html.addClass(view, "view");
                } else if (view.domNode) {
                    html.place(view.domNode, this.domNode);
                    html.addClass(view.domNode, "view");
                }
            }));
        },

        /**
         * Starts the first view
         */
        startup: function() {
            this.inherited(arguments);
            if (this.views.length > 0) {
                this.switchView(0);
            }
        },

        /**
         * Returns the current view
         * @returns {object} this._currentView - The current view
         */
        getSelectedView: function() {
            return this._currentView;
        },

        /**
         * Returns the label of current view
         * @returns {string} label - The current view's label
         */
        getSelectedLabel: function() {
            var label = "",
                view = this.getSelectedView();
            if (view) {
                label = view.label;
            }
            return label;
        },

        /**
         * Returns the label of current view
         * @param {string} label - Label of the view
         * @returns {object|null} - The view with perticuler label or null.
         */
        getViewByLabel: function(label) {
            var i;
            for (i = 0; i < this.views.length; i++) {
                if (label === this.views[i].label) {
                    return this.views[i];
                }
            }
            return null;
        },

        /**
         * Adds view to view stack
         * @param {object} view - The view to be added.
         */
        addView: function(view) {
            this.views.push(view);
            if (view.nodeType === 1) {
                html.place(view, this.domNode);
                html.addClass(view, "view");
            } else if (view.domNode) {
                html.place(view.domNode, this.domNode);
                html.addClass(view.domNode, "view");
            }
        },

        /**
         * Removes view from view stack
         * @param {object} view - The view to be removed.
         */
        removeView: function(view) {
            var c1 = this.views.length,
                c2;
            this.views = array.filter(this.views, function(v) {
                return view !== v;
            });
            c2 = this.views.length;
            if (c1 !== c2) {
                if (view.nodeType === 1) {
                    html.destroy(view);
                } else if (view.domNode) {
                    view.destroyRecursive();
                }
            }
        },

        /**
         * Changes the view.
         * @param {object|Number|string} v - The view to be selected.
         */
        switchView: function(v) {
            var view, dom;
            if (typeof v === "number") {
                view = this.views[v];
            } else if (typeof v === "string") {
                view = this.getViewByLabel(v);
            } else {
                view = v;
            }

            this.views.forEach(lang.hitch(this, function(_v) {
                if (!_v) {
                    return;
                }
                if (_v.nodeType === 1) {
                    dom = _v;
                } else if (_v.domNode) {
                    dom = _v.domNode;
                }
                if (_v === view) {
                    html.setStyle(dom, "display", "block");
                    if (_v.domNode && !_v._started) {
                        _v.startup();
                        _v._started = true;
                    }
                } else {
                    html.setStyle(dom, "display", "none");
                }
            }));
            this._currentView = view;
            this.onViewSwitch(view);
        },

        /**
         * Action to be performed on switching the view.
         */
        onViewSwitch: function() {}
    });
});
