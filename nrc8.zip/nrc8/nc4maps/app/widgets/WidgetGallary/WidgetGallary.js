define([
    "dojo/_base/declare",
    "dojo/dom",
    "dojo/_base/html",
    "dijit/registry",
    "dojo/on",
    "dojo/topic",
    "dojo/dom-class",
    "dojo/query",
    "dojo/_base/lang",
    "app/widgets/WidgetGallary/ViewStack",
    "dojo/text!./WidgetGallaryTemplate.html",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin"
], function(declare, dom, html, registry, on, topic, domClass, query, lang, ViewStack, template, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin) {

    //========================================================================================================================//

    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        baseClass: "widget-Gallary",
        templateString: template,
        margin: 4,
        nodeWidth: null,
        nodes: [],
        pages: [],
        viewStack: null,
        items: [],
        _count: 0,
        _closeNode: null,
        _moreIconPaneCoverNode: null,

        /**
         * Creates widget icon and attach widget related events like resize and click.
         */
        postCreate: function() {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetWidgetGallaryIcon"
            }, null);
            on(window, "resize", lang.hitch(this, function() {
                html.setStyle(this.domNode, this._getPositionStyle(this._getMorePanelSize()));
                this._resize();
            }));
            this.own(on(this.widgetIcon, "click", lang.hitch(this, function() {
                this.show();
            })));
        },

        /**
         * Hides the widget's UI.
         */
        hide: function() {
            html.setStyle(this._moreIconPaneCoverNode, "display", "none");
            //domClass.toggle(this.widgetIcon, "widgetIconFullOpacity");
            domClass.remove(this.widgetIcon, "widgetIconFullOpacity");
        },

        /**
         * Shows the widget's UI.
         */
        show: function() {
            if (!this._moreIconPaneCoverNode) {
                this._createCoverNode();
            }
            html.setStyle(this._moreIconPaneCoverNode, "display", "block");
            // domClass.toggle(this.widgetIcon, "widgetIconFullOpacity");
            domClass.add(this.widgetIcon, "widgetIconFullOpacity");
            this._closeOtherWidgets();
            html.empty(this.pagesNode);
            html.empty(this.pointsNode);
            if (this._closeNode) {
                html.destroy(this._closeNode);
            }
            if (this.viewStack) {
                this.viewStack.destroyRecursive(true);
            }
            this.nodes = [];
            this.pages = [];
            this.items = [];

            this._closeNode = this._createCloseBtn();

            html.place(this.domNode, this._moreIconPaneCoverNode);
            html.setStyle(this.domNode, this._getPositionStyle(this._getMorePanelSize()));
            this.startup();
        },

        /**
         * Starts the widget by creating widget's UI.
         */
        startup: function() {
            this.viewStack = new ViewStack({
                views: [],
                viewType: "dom"
            }, this.pagesNode);
            this.viewStack.startup();
            this._createPages();
            if (this.viewStack.views.length > 0) {
                this._selectPage(0);
            }
            this._resize();
        },

        /**
         * Selects the page containing widgets in widget gallery.
         * @param {integer} p - Index of the page to be selected.
         */
        _selectPage: function(p) {
            if (this.pages.length > 1) {
                query(".point", this.domNode).removeClass("point-selected");
                html.addClass(this.pages[p].pointNode, "point-selected");
            }
            this.viewStack.switchView(this.pages[p].pageNode);
        },

        /**
         * Closes all other widget after selecting a widget in widget gallery.
         */
        _closeOtherWidgets: function() {
            var arrWidgetIDs = this._getWidgetsId();
            for (var i = 0; i < arrWidgetIDs.length; i++) {
                var widget = registry.byId(arrWidgetIDs[i]);
                if (widget) {
                    if (widget.isOpen && widget.config.label !== this.config.label) {
                        widget.hide();
                    }
                }
            }
        },

        /**
         * Creates different pages as per total widget count.
         * * Each page can contain maximum 9 widgets.
         */
        _createPages: function() {
            var i, count = 0,
                pages, p, pageNode, pointNode;
            /*
             *Get count and list of all the app header widgets which are not visible in app header
             */
            for (i = 0; i < this.appConfig.AppHeaderWidgets.length; i++) {
                if (!this.appConfig.AppHeaderWidgets[i].isVisible) {
                    this.items.push(this.appConfig.AppHeaderWidgets[i]);
                    count++;
                }
            }
            this._count = count;
            pages = Math.ceil(count / 9); //get page count
            for (p = 0; p < pages; p++) {
                pageNode = this._createPageNode(p);
                this._createPageItems(p, pageNode);
                this.viewStack.addView(pageNode);
                if (pages > 1) {
                    pointNode = this._createPointNode(p);
                    on(pointNode, "click", lang.hitch(this, this._onPageNodeClick, p));
                }
                this.pages.push({
                    pageNode: pageNode,
                    pointNode: pointNode
                });
            }
        },

        /**
         * Creates node for page.
         */
        _createPageNode: function() {
            var node;
            node = html.create("div", {
                "class": "page"
            });
            return node;
        },

        /**
         * Call _createItemNode() and _createEmptyItemNode() for the page, based on number of widget in that page.
         * * If Number of widgets is less than 9, then rest of the nodes will be empty node.
         * @param {integer} page - Index of the page in which nodes to be inserted.
         * @param {object} pageNode - page node for widgets.
         */
        _createPageItems: function(page, pageNode) {
            var b,
                count,
                e,
                empty,
                i;
            count = this._count;
            b = page * 9;
            e = (page + 1) * 9;
            empty = e - count;
            for (i = b; i < Math.min(e, count); i++) {
                this._createItemNode(i, pageNode);
            }
            for (i = count; i < count + empty; i++) {
                this._createEmptyItemNode(i, pageNode);
            }
        },

        /**
         * Set position of the widget node.
         * @param {object} node - Dom element on which we have to set style for its position.
         * @param {integer} i - Index of the node.
         */
        _setItemNodePosition: function(node, i) {
            var ml, mt, nodeStyle = {};
            i++;
            if (i % 3 === 1) {
                ml = 0;
            } else {
                ml = 2;
            }

            if (i <= 3) {
                mt = 0;
            } else {
                mt = 2;
            }

            if (typeof this.nodeWidth === "number") {
                nodeStyle.width = this.nodeWidth + "px";
                nodeStyle.height = this.nodeWidth + "px";
            }
            if (typeof ml === "number") {
                nodeStyle.marginLeft = ml + "px";
            }
            if (typeof mt === "number") {
                nodeStyle.marginTop = mt + "px";
            }
            html.setStyle(node, nodeStyle);
        },

        /**
         * Select view page.
         * @param {integer} p - Index of the page to be selected.
         */
        _onPageNodeClick: function(p) {
            this._selectPage(p);
        },

        /**
         * Create and returns point node to select view page.
         * @returns {object} node - Dom element to select view page.
         */
        _createPointNode: function() {
            var node;
            node = html.create("div", {
                "class": "point"
            }, this.pointsNode);
            return node;
        },

        /**
         * Create and attach widget icon click event.
         * @param {integer} i - Index at which we have to place widget icon node.
         * @param {object} pageNode - A dom element of the page in which we have to append the widget icon node.
         */
        _createItemNode: function(i, pageNode) {
            var item,
                node,
                pathIcon;
            item = this.items[i];
            node = html.create("div", {
                "class": "icon-node",
                title: item.label,
                settingId: item.label
            }, pageNode);

            pathIcon = item.WidgetPath.slice(0, item.WidgetPath.lastIndexOf("/"));
            html.create("img", {
                "src": pathIcon + "/images/icon.png"
            }, node);

            html.create("div", {
                "class": "node-label",
                "title": item.label,
                "innerHTML": item.label
            }, node);
            node.config = item;
            this._setItemNodePosition(node, i);
            on(node, "click", lang.hitch(this, function() {
                this._onNodeClicked(node);
            }));
            this.nodes.push(node);
        },

        /**
         * Create empty icon node.
         * @param {integer} i - Index at which we have to place empty node.
         * @param {object} pageNode - A dom element of the pagein which we have to append the empty node.
         */
        _createEmptyItemNode: function(i, pageNode) {
            var node;
            node = html.create("div", {
                "class": "icon-node"
            }, pageNode);
            this._setItemNodePosition(node, i);
            this.nodes.push(node);
            return node;
        },

        /**
         * Resize the widget gallery panel according to the screen size.
         */
        _resize: function() {
            var box;
            box = html.getMarginBox(this.domNode);
            this.nodeWidth = (box.w - this.margin * 2) / 3;

            this.nodes.forEach(lang.hitch(this, function(node, i) {
                this._setItemNodePosition(node, i);
            }));
        },

        /**
         * Create close button node, to close widget gallery panel.
         * @returns {object} node - Dom element of close icon node.
         */
        _createCloseBtn: function() {
            var node;
            node = html.create("div", {
                "class": "close"
            }, this.domNode);
            html.create("div", {
                "class": "close-inner"
            }, node);
            on(node, "click", lang.hitch(this, function() {
                this.hide();
            }));
            return node;
        },

        /**
         * Create cover node to overlap application in order to prevent the use to select anything
         * other the widget gallery options.
         * @returns {object} node - A dom element of close icon node.
         */
        _createCoverNode: function() {
            this._moreIconPaneCoverNode = html.create("div", {
                "class": "moreIconCover"
            }, "mainContainer");
        },

        /**
         * Create and returns widget gallery panel size and position style object.
         * @param {object} position - Position object containing detail of widget panel size and position.
         * @returns {object} style - Style object containing position and size detail of widget gallery panel.
         */
        _getPositionStyle: function(position) {
            var style = {},
                p, boolKeyMatch = false,
                index, arrGroups = ["left", "top", "right", "bottom", "width", "height"];
            for (p in position) {
                if (position.hasOwnProperty(p)) {
                    boolKeyMatch = false;
                    for (index = 0; index < arrGroups.length; index++) {
                        if (arrGroups[index].search(p) !== -1) {
                            boolKeyMatch = true;
                            break;
                        }
                    }
                    if (boolKeyMatch) {
                        if (typeof position[p] === "number") {
                            style[p] = position[p] + "px";
                        } else if (position[p]) {
                            style[p] = position[p];
                        }
                    }
                }
            }
            return style;
        },

        /**
         * Returns widget gallery panel size and position according to screen size.
         * @returns {object} position - Detail value of position and size of widget gallery panel.
         */
        _getMorePanelSize: function() {
            var mapBox, minLen, position;
            mapBox = html.getContentBox("mainContainer");
            mapBox.h = mapBox.h - 40;
            minLen = Math.min(mapBox.w, mapBox.h);
            if (minLen < 600) {
                if (mapBox.w < mapBox.h) {
                    position = {
                        left: 20,
                        right: 20,
                        top: Math.max((mapBox.h - (mapBox.w - 40)) / 2, 70),
                        height: mapBox.w - 40,
                        width: mapBox.w - 40,
                        bottom: ""
                    };
                } else {
                    position = {
                        top: 70,
                        bottom: 20,
                        left: (mapBox.w - (mapBox.h - 40)) / 2,
                        width: mapBox.h - 40,
                        height: "",
                        right: ""
                    };
                }
            } else {
                position = {
                    top: Math.max((mapBox.h - 560) / 2, 70),
                    left: (mapBox.w - 560) / 2,
                    width: 560,
                    height: 560,
                    right: "",
                    bottom: ""
                };
            }
            return position;
        },

        /**
         * Perform actions after clicking the widget icon node in widget gallery panel
         * * Initializes the widget if not initialized else shows its panel.
         * * Replace the image node in application header panel with widget icon node.
         * * Close other widgets if open.
         */
        _onNodeClicked: function(node) {
            var j, k, nodeToRemove, nodeToRemoveIndex, divWidgetContainer = query(".appHeaderWidgetConainer")[0];
            nodeToRemoveIndex = divWidgetContainer.childNodes.length - 1;
            nodeToRemove = divWidgetContainer.childNodes[nodeToRemoveIndex].title;
            var widget = registry.byId(node.config.WidgetPath);
            var mapInstance = this.map;
            if (widget) {
                domClass.add(widget.widgetIcon, "appHeaderWidgetIcon");
                divWidgetContainer.replaceChild(widget.widgetIcon, divWidgetContainer.childNodes[nodeToRemoveIndex]);
                //widget.show();
                this._toggleWidget(widget);
            } else {
                require([node.config.WidgetPath], lang.hitch(this, function(Widget) {
                    var widgetInitialized = new Widget({
                        map: mapInstance,
                        id: node.config.WidgetPath,
                        config: node.config
                    });
                    domClass.add(widgetInitialized.widgetIcon, "appHeaderWidgetIcon");
                    divWidgetContainer.replaceChild(widgetInitialized.widgetIcon, divWidgetContainer.childNodes[nodeToRemoveIndex]);
                    //widgetInitialized.show();
                    this._toggleWidget(widgetInitialized);
                    on(widgetInitialized.widgetIcon, "click", lang.hitch(this, function() {
                        this._toggleWidget(widgetInitialized);
                    }));
                }));
            }
            for (j = 0; j < this.appConfig.AppHeaderWidgets.length; j++) {
                if (this.appConfig.AppHeaderWidgets[j].label === node.title) {
                    this.appConfig.AppHeaderWidgets[j].isVisible = true;
                    break;
                }
            }
            for (k = 0; k < this.appConfig.AppHeaderWidgets.length; k++) {
                if (this.appConfig.AppHeaderWidgets[k].label === nodeToRemove) {
                    this.appConfig.AppHeaderWidgets[k].isVisible = false;
                    break;
                }
            }
            this.hide();
        },

        /**
         * Returns array of widgets ID.
         * @returns {array} arrWidgetIDs - List of widgets ID.
         */
        _getWidgetsId: function() {
            var arrWidgetIDs = [];
            for (var i = 0; i < this.appConfig.AppHeaderWidgets.length; i++) {
                var widgetID = this.appConfig.AppHeaderWidgets[i].WidgetPath;
                arrWidgetIDs.push(widgetID);
            }
            return arrWidgetIDs;
        },

        /**
         * Toggles the widget panel, shows the panel of widget whose icon is clicked.
         * @param {object} widgetInitialized - Widget which is clicked.
         */
        _toggleWidget: function(widgetInitialized) {
            var arrWidgetIDs = this._getWidgetsId(),
                i,
                widget;
            for (i = 0; i < arrWidgetIDs.length; i++) {
                widget = registry.byId(arrWidgetIDs[i]);
                if (widget) {
                    if (widget.isOpen && widget.config.label !== widgetInitialized.config.label) {
                        widget.hide();
                    }
                }
            }
            widgetInitialized.show();
        }
    });
});
