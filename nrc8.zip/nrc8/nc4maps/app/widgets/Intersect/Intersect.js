define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/dom-attr",
    "dojo/json",
    "dojo/_base/window",
    "dojo/touch",
    "dojo/store/Memory",
    "dojo/text!./IntersectTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "dojo/promise/all",
    "dojo/aspect",
    "dojo/Deferred",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/form/Button",
    "dijit/form/Select",
    "dijit/form/MultiSelect",
    "dijit/registry",
    "dgrid/OnDemandGrid",
    "dgrid/Keyboard",
    "dgrid/Selection",
    "dgrid/extensions/Pagination",
    "esri/tasks/query",
    "esri/tasks/GeometryService",
    "esri/tasks/QueryTask",
    "esri/request",
    "esri/tasks/RelationParameters",
    "esri/SpatialReference",
    "app/widgets/WidgetPanel/WidgetPanel",
    "app/widgets/LoadingShelter/LoadingShelter",
    "app/widgets/BottomPanel/BottomPanel",
    "lodash/lodash"
], function(
    declare,
    html,
    array,
    lang,
    on,
    domAttr,
    JSON,
    win,
    touch,
    Memory,
    template,
    sharedNls,
    all,
    aspect,
    Deferred,
    _WidgetBase,
    _TemplatedMixin,
    Button,
    Select,
    MultiSelect,
    registry,
    Grid,
    Keyboard,
    Selection,
    Pagination,
    Query,
    GeometryService,
    QueryTask,
    esriRequest,
    RelationParameters,
    SpatialReference,
    WidgetPanel,
    LoadingShelter,
    BottomPanel,
    _
) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "Intersect",
        baseClass: "widget-Intersect",
        templateString: template,
        sharedNls: sharedNls,
        _shelter: null,
        _btnIntersect: null,
        _arrStore: null,
        _gridData: null,
        _dupData: null,
        _count: null,
        _isItFirst: null,
        _arrStoreForFields: null,
        _singleElementGeometry: null,
        _allElementGeometry: [],
        _currentSelectedFields: null,
        _arryIntersection: [],
        _tempArray: [],
        _fieldsLengthBool: null,
        _attributesOfAllSelectedLayers: null,
        _bottomPanel: null,
        _exportParams: null,
        _arrResponse: null,
        isShowing: false,
        _objLayer: null,
        _currentSelectedElement: null,
        _unionGeometry: null,
        _arrSelectedFields: [],
        _allGeometryOfLayer: null,
        _currentSelectedLayers: null,
        isOpen: false,
        _panel: null,
        _widgetPosition: {
            right: 0,
            top: 41,
            height: 100 + "%"
        },

        /**
         * Member of widget life cycle, its call indicates widget has been rendered (but note that child widgets in the containerNode have not!).
         * Setting widget icon, loading shelter, call to attach widget related events and initializing Intersect widget.
         */
        postCreate: function() {
            this.widgetIcon = html.create("div", {
                "title": this.config.label,
                "class": "widgetIntersectIcon"
            }, null);
            this._placeWidgetContainer();
            this._shelter = new LoadingShelter({
                hidden: false,
                loadingText: sharedNls.LoadingShelter.lblLoading
            });
            this._shelter.placeAt(this.domNode);
            this._nc4Notify = this.appUtils.nc4Notify;
            this._count = 0;
            this._isItFirst = 0;
            this.selectOutputData.textContent = sharedNls.Intersect.selectOutputData;
            this.selectFieldsForReport.textContent = sharedNls.Intersect.selectFieldsForReport;
            this.hint.textContent =  sharedNls.Intersect.hint;
            this.hintR.textContent = ""; //TODO, how to add configurable hints? sharedNls.Intersect.hintRequired;
            this.selectBoundingArea.textContent = sharedNls.Intersect.selectBoundingArea;
            this.layer.textContent = sharedNls.Intersect.layer;
            this.element.textContent = sharedNls.Intersect.element;
            this._arryIntersection.push(sharedNls.Intersect.lblCommonFields);
            this._btnIntersect = new Button({
                label: sharedNls.Intersect.apply
            }, this.btnApply);
            this._attachWidgetRelatedEvents();
            /*Below function to resolve iPad issues*/
            this._resolveIpadIssues();
            this._shelter.hide();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            if (this.appUtils.mapInstance) {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
            }));
        },

        /**
         * Function to resolve iPad and tab issues.
         */
        _resolveIpadIssues: function() {
            var tablet = navigator.userAgent.match(/android/i) != null;
            var isiPad = navigator.userAgent.match(/iPad/i) != null;
            if (isiPad) {
                html.setStyle(this.hintDiv, "display", "none");
            }
            if (tablet) {
                html.setStyle(this.hintDiv, "display", "none");
            }
        },

        /**
         * Display the panel and activate the Intersect widget.
         */
        show: function() {
            if (!this.isOpen) {
                html.addClass(this.widgetIcon, "widgetIconFullOpacity");
                this._panel.show();
                this.isOpen = true;
                this._getLayersOnMap();
                this.appUtils.sidePanelOpen(this.isOpen);
                if (this.appUtils.bottomPanelGrid) {
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                }
                if (this.selectFields) {
                    while (this.selectFields.hasChildNodes()) {
                        this.selectFields.removeChild(this.selectFields.lastChild);
                    }
                }
                if (this._cmbBoundingLayer) {
                    this._cmbBoundingLayer.disabled = true;
                }
                if (this._cmbBoundingElement) {
                    this._cmbBoundingElement.disabled = true;
                }
                if (this._currentSelectedLayers) {
                    this._currentSelectedLayers = null;
                }
                if (this._arrSelectedFields) {
                    this._arrSelectedFields = null;
                }
                this._shelter.hide();
            } else {
                this.hide();
            }
        },

        /**
         * Hide the panel
         */
        hide: function() {
            html.removeClass(this.widgetIcon, "widgetIconFullOpacity");
            if (this._panel) {
                this._panel.hide();
                this.isOpen = false;
                this.appUtils.sidePanelOpen(this.isOpen);
                if (this.appUtils.bottomPanelGrid) {
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                }
            }
        },

        /**
         * Setting the widget panel position.
         */
        _placeWidgetContainer: function() {
            var widgetPanelPosition;
            if (this._widgetPosition) {
                widgetPanelPosition = this._widgetPosition;
            } else {
                widgetPanelPosition = {
                    right: 0,
                    top: 41,
                    height: 100 + "%"
                };
            }
            this._panel = new WidgetPanel({
                position: widgetPanelPosition,
                id: "Panel_" + this.config.label
            });
            this._panel.startup();
            html.place(this.domNode, this._panel.widgetContainer);
        },

        /**
         * Widget Related Events, resize widget panel on window resize.
         */
        _attachWidgetRelatedEvents: function() {
        	on(this.map, "click", lang.hitch(this, function(){this.hide()}));	//james
            on(window, "resize", lang.hitch(this, function() {
                this._panel.resize();
                this.appUtils.sidePanelOpen(this.isOpen);
                if (this.appUtils.bottomPanelGrid) {
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                }
            }));
            if (this._btnIntersect) {
                on(this._btnIntersect, touch.press, lang.hitch(this, function() {
                    if (this.layersOnMapDiv.options.length > 0) {
                        if (!this._currentSelectedLayers) {
                            this._nc4Notify.warn(sharedNls.Intersect.selectOutputDataLayer);
                            this._shelter.hide();
                            return;
                        }
                        if (!this._arrSelectedFields) {
                            this._nc4Notify.warn(sharedNls.Intersect.selectFieldsForReport);
                            this._shelter.hide();
                            return;
                        }
                        if (this._cmbBoundingLayer.value === sharedNls.Intersect.lblLayer) {
                            this._nc4Notify.warn(sharedNls.Intersect.selectBoundingLayer);
                            this._shelter.hide();
                            return;
                        }
                        if (this._cmbBoundingElement.value === sharedNls.Intersect.lblElement) {
                            this._nc4Notify.warn(sharedNls.Intersect.selectBoundingElement);
                            this._shelter.hide();
                            return;
                        }
                        if (this._cmbBoundingElement.value === sharedNls.Intersect.all) {
                            if (this._allElementGeometry && this._allElementGeometry.length !== 0) {
                                this._doIntersectOpearation();
                            } else {
                                this._nc4Notify.warn(sharedNls.Intersect.noResultsFound);
                                this._shelter.hide();
                            }
                        } else {
                            this._doIntersectOpearation();
                        }
                    } else {
                        this._nc4Notify.warn(sharedNls.Intersect.addLayerOnMap);
                        this._shelter.hide();
                    }
                }));
            }
        },

        /**
         * Get the layers list which are added on map and passing to "multi select" combo box.
         */
        _getLayersOnMap: function() {
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            var item,
                i,
                objLayer,
                options,
                selectItem;
            this._arrStore = [];
            if (this.layersOnMapDiv) {
                while (this.layersOnMapDiv.hasChildNodes()) {
                    this.layersOnMapDiv.removeChild(this.layersOnMapDiv.lastChild);
                }
            }
            for (i = 0; i < this.map.graphicsLayerIds.length; i++) {
            	if(this.map.graphicsLayerIds[i] == "nc4CL" || this.map.graphicsLayerIds[i].indexOf("_ignore_") >= 0)
            		continue;
                objLayer = this.map.getLayer(this.map.graphicsLayerIds[i]);
                if (objLayer) {
                    var currentTitle = (objLayer._params) ? objLayer._params.name : ((objLayer._options) ? objLayer._options.name : "");
                    selectItem = {};
                    selectItem.value = objLayer.id;
                    selectItem.label = currentTitle || objLayer.overlayCustomLayerType || objLayer.name || objLayer.id;
                    selectItem.geometryType = objLayer.geometryType || "";
                    if(objLayer.overlayCustomLayerType)
                    	selectItem.overlayCustomLayerType = objLayer.overlayCustomLayerType;
                    this._arrStore.push(selectItem);
                }
                //jt: NOTE: for KMLLayer, the kmllayer does not get added , just the feature layers that makes up the kml layer
            }
            if(this._arrStore.length > 0){
                $("#noIntLayerMsg").hide();
                for (item in this._arrStore) {
                    if (this._arrStore.hasOwnProperty(item)) {
                    	if(this._arrStore[item].geometryType == "esriGeometryPolygon" || (this._arrStore[item].geometryType !== "esriGeometryPolygon" && this._arrStore[item].label == "Drawing") )
                       {}
                    	else
                    	{
                    		options = win.doc.createElement("option");
                            options.value = this._arrStore[item].value;
                            options.geometryType = this._arrStore[item].geometryType;
                            options.textContent = this._arrStore[item].label;
                            this.layersOnMapDiv.appendChild(options);
                    	}
                    }
                }
                for (var key = 0; key < this.layersOnMapDiv.options.length; key++) {
                    if (this.layersOnMapDiv.options[key].label === "Drawing") {
                        this.layersOnMapDiv.options[key].disabled = true;
                        this.layersOnMapDiv.options[key].style.display = "none";
                    }
                    var objOverlay = this.map.getLayer(this.layersOnMapDiv.options[key].value);
                    if (objOverlay) {
                        if (objOverlay.overlayCustomLayerType) {
                            this.layersOnMapDiv.options[key].disabled = true;
                            this.layersOnMapDiv.options[key].style.display = "none";
                        }
                    }
                }
            }
            else{
                $("#noIntLayerMsg").show();
            }
            this._getBoundingArea();
            this._shelter.hide();
        },

        /**
         * Get the selected layer in "multi select" combo box and get fields of layer.
         */
        _getSelectedLayers: function(evt) {
            var  l,
                m,
                n,
                objSelectedLayer;
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            this._currentSelectedLayers = [];
            this._dupCurrentSelectedLayers = [];
            for (l = 0; l < this.layersOnMapDiv.childNodes.length; l++) {
                if (this.layersOnMapDiv.childNodes[l].selected === true) {
                    if (this._currentSelectedLayers.indexOf(this.layersOnMapDiv.childNodes[l].value) < 0) {
                        if (this.layersOnMapDiv.childNodes[l].value !== "Drawing") {
                            this._currentSelectedLayers.push(this.layersOnMapDiv.childNodes[l].value);
                            this._dupCurrentSelectedLayers.push(this.layersOnMapDiv.childNodes[l].label);
                        }
                    }
                }
            }
            var arrCommonFields = [],
                dupArrCommonFields = [];
            var arrFieldsObject = [];
            var count = 0;
            for (m = 0; m < this._currentSelectedLayers.length; m++) {
                objSelectedLayer = this.map.getLayer(this._currentSelectedLayers[m]);
                if (objSelectedLayer) {
                    count++;
                    arrFieldsObject = (objSelectedLayer.fields) ? objSelectedLayer.fields : objSelectedLayer._fileds || [];
                    var arrLayerFields = [];
                    var dupArrLayerFields = [];
                    for (n = 0; n < arrFieldsObject.length; n++) {
                        //arrLayerFields.push(arrFieldsObject[n].name.toLowerCase());
                        arrLayerFields.push(arrFieldsObject[n].name);
                        if(arrFieldsObject[n].alias)
                        	dupArrLayerFields.push(arrFieldsObject[n].alias);
                        else
                        	dupArrLayerFields.push(arrFieldsObject[n].name);
                    }
                    dupArrCommonFields = (count === 1) ? _.intersection(dupArrLayerFields, dupArrLayerFields) : _.intersection(dupArrLayerFields, dupArrCommonFields);
                    arrCommonFields = (count === 1) ? _.intersection(arrLayerFields, arrLayerFields) : _.intersection(arrLayerFields, arrCommonFields);
                }
            }
            this._selectFields(arrCommonFields, dupArrCommonFields, this._currentSelectedLayers.length);
            this._shelter.hide();
        },

        /**
         * Funtion to insert fields in multi select combo box.
         * @param {array} arrLayerFields : array fields
         * @param {string} title : title
         * @param {bool} isNameUsed : true/false
         */
        _pushingFields: function(arrLayerFields, dupArrCommonFields, title, isNameUsed) {
            var n = 0;
            var opt1 = win.doc.createElement("option");
            opt1.value = n++;
            opt1.textContent = title;
            this.selectFields.appendChild(opt1);
            for (var i = 0; i < arrLayerFields.length; i++) {
                opt1 = win.doc.createElement("option");
                opt1.value = n++;
                opt1.id = (isNameUsed) ? arrLayerFields[i].name : arrLayerFields[i];
                //opt1.textContent = (isNameUsed) ? arrLayerFields[i].alias : arrLayerFields[i];
                opt1.textContent = dupArrCommonFields[i];
                
				//TODO: in the future, somehow hide these from solution since
				//		these are solution specific fields
                if(opt1.textContent == "Hover Text")
                	continue;
                if(opt1.textContent == "Pop-up Text")
                {
                	continue;
                }
                
                this.selectFields.appendChild(opt1);
            }
        },

        /**
         * Displaying fields in "multi select" combo box.
         * @param {array} arrLayerFields : array fields
         * @param {number} count : value
         */
        _selectFields: function(arrLayerFields, dupArrCommonFields, count) {
            var l,
                n = 0,
                opt1,
                objSelectedLayer,
                j,
                arrFieldsObject;
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            this._arrStoreForFields = [];
            if (this.selectFields) {
                while (this.selectFields.hasChildNodes()) {
                    this.selectFields.removeChild(this.selectFields.lastChild);
                }
            }
            //Pushing common fields
            if (count > 1 && arrLayerFields.length && dupArrCommonFields.length) {
                this._pushingFields(arrLayerFields, dupArrCommonFields, sharedNls.Intersect.lblCommonFields, false);
            }
            //pushing layer's unique fields
            if (count === 1) {
                objSelectedLayer = this.map.getLayer(this._currentSelectedLayers[0]);
                arrFieldsObject = (objSelectedLayer.fields) ? objSelectedLayer.fields : objSelectedLayer._fileds || [];
                this._pushingFields(arrFieldsObject, dupArrCommonFields, this._dupCurrentSelectedLayers[0].toUpperCase(), true);
            } else {
                for (j = 0; j < this._currentSelectedLayers.length; j++) {
                    var arrUniqueFields = this._getLayersUniqueFields(this._currentSelectedLayers[j], arrLayerFields, dupArrCommonFields);
                    if (arrUniqueFields.length) {
                        opt1 = win.doc.createElement("option");
                        opt1.value = n++;
                        opt1.textContent = this._dupCurrentSelectedLayers[j].toUpperCase();
                        this.selectFields.appendChild(opt1);
                    }
                    for (l = 0; l < arrUniqueFields.length; l++) {
                        opt1 = win.doc.createElement("option");
                        opt1.value = n++;
                        opt1.id = arrUniqueFields[l];
                        opt1.textContent = arrUniqueFields[l];
                        this.selectFields.appendChild(opt1);
                    }
                }
            }
            this._disableLayerAndCommonFiledsText();
            this._shelter.hide();
        },

        /**
         * Function to perform Disable layer name and common field text selection
         */
        _disableLayerAndCommonFiledsText: function() {
            var r,
                key;
            for (r = 0; r < this._dupCurrentSelectedLayers.length; r++) {
                for (key = 0; key < this.selectFields.options.length; key++) {
                    if (this.selectFields.options[key].label === this._dupCurrentSelectedLayers[r].toUpperCase() || this.selectFields.options[key].label === sharedNls.Intersect.lblCommonFields) {
                        this.selectFields.options[key].style.font = "bold 13px arial";
                        this.selectFields.options[key].disabled = true;
                    }
                }
            }
        },

        /**
         * Function to get unique fields from selected layer fields.
         * @param {string} layerID : layer id
         * @param {array} arrCommonFields : Common fields array
         * @returns {array} arrUniqueFields : Array unique fields
         */
        _getLayersUniqueFields: function(layerID, arrCommonFields, dupArrCommonFields) {
            var arrUniqueFields = [],
                arrFieldsObject = [],
                isNotUniqueField,
                fieldIndex,
                commonField,
                objSelectedLayer = this.map.getLayer(layerID);
            arrFieldsObject = (objSelectedLayer.fields) ? objSelectedLayer.fields : objSelectedLayer._fileds || [];
            if (dupArrCommonFields.length === 0) {
                for (fieldIndex = 0; fieldIndex < arrFieldsObject.length; fieldIndex++) {
                    arrUniqueFields.push(arrFieldsObject[fieldIndex].name);
                }
                return arrUniqueFields;
            }
            for (fieldIndex = 0; fieldIndex < arrFieldsObject.length; fieldIndex++) {
                isNotUniqueField = false;
                for (commonField = 0; commonField < dupArrCommonFields.length; commonField++) {
                    try
                    {
                    	if (arrFieldsObject[fieldIndex].alias.toLowerCase() === dupArrCommonFields[commonField].toLowerCase()) {
                            isNotUniqueField = true;
                            break;
                        }
                    }
                	catch(error)
                	{
                		//do nothing
                	}
                }
                if (!isNotUniqueField) {
                    arrUniqueFields.push(arrFieldsObject[fieldIndex].name);
                }
            }
            return arrUniqueFields;
        },

        /**
         * Creating bounding area drop down boxes dynamically.
         */
        _getBoundingArea: function() {
            var count = 0;
            if (!this._cmbBoundingLayer) {
                this._cmbBoundingLayer = new Select();
                this._cmbBoundingLayer.placeAt(this.boundingLayerDiv).startup();
                this._cmbBoundingLayer.disabled = true;
            }
            this._cmbBoundingLayer.options.length = 0;
            this._cmbBoundingLayer.addOption({
                label: sharedNls.Intersect.lblLayer,
                value: sharedNls.Intersect.lblLayer
            });
            array.forEach(this._arrStore, lang.hitch(this, function(layer) {
            	if(layer.geometryType == "esriGeometryPolygon" || (layer.geometryType !== "esriGeometryPolygon" && layer.label == "Drawing") 
            			|| (layer.overlayCustomLayerType))
            	{
            		if (this._cmbBoundingLayer.options.length !== 0) {
                        this._cmbBoundingLayer.addOption({					//jt: this if else doesn't make sense, same outcome??
                            label: layer.label,
                            value: layer.value
                        });
                    } else {
                        this._cmbBoundingLayer.addOption({
                            label: layer.label,
                            value: layer.value
                        });
                    }
            	}	
            	
            }));
            if (this._arrStore.length > 0) {
                this._cmbBoundingLayer.disabled = false;
            }
            on(this._cmbBoundingLayer, "change", lang.hitch(this, function(evt) {
                count++;
                this._getGeometryFromlayer(evt, count);
            }));
            if (!this._cmbBoundingElement) {
                this._cmbBoundingElement = new Select();
                this._cmbBoundingElement.placeAt(this.boundingElementDiv).startup();
                this._cmbBoundingElement.disabled = true;
                this._cmbBoundingElement.options.length = 0;
                this._cmbBoundingElement.addOption({
                    label: sharedNls.Intersect.all,
                    value: sharedNls.Intersect.all
                });
            }
            on(this._cmbBoundingElement, "change", lang.hitch(this, function(evt) {
                this._performGeometryUnion(evt);
            }));
        },

        /**
         * Funtion to get geometry from layer.
         * @param {string} evt : string value
         * @param {number} count : value
         */
        _getGeometryFromlayer: function(evt, count) {
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            var arrElements, objLayer;
            if (evt !== sharedNls.Intersect.lblLayer) {
                arrElements = [];
                if (this._cmbBoundingElement.options.length !== 0) {
                    this._cmbBoundingElement.options.length = 0;
                    this._cmbBoundingElement.addOption({
                        label: sharedNls.Intersect.lblElement,
                        value: sharedNls.Intersect.lblElement
                    });
                    this._cmbBoundingElement.addOption({
                        label: sharedNls.Intersect.all,
                        value: sharedNls.Intersect.all
                    });
                }
                objLayer = this.map.getLayer(evt);
                if (objLayer._clusterData) {
                    this._getClusterElements(objLayer, count, arrElements);
                } else {
                    this._getGraphicElements(objLayer, count, arrElements);
                }
                if (arrElements.length > 0) {
                    this._cmbBoundingElement.disabled = false;
                }
                array.forEach(arrElements, lang.hitch(this, function(layer) {
                    this._cmbBoundingElement.addOption({
                        label: layer,
                        value: layer
                    });
                }));
            }
            setTimeout(lang.hitch(this, function() {
                this._shelter.hide();
                this._cmbBoundingElement.startup();
            }), 600);
        },

        /**
         * Get elements from cluster layer
         * @param {object} objLayer : layer list
         * @param {integer} count : value
         * @param {array} arrElements : elements list
         * @returns {array} arrElements
         */
        _getClusterElements: function(objLayer, count, arrElements) {
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            if (objLayer._clusterData.length === 0) {
                if (count === 1) {
                    this._nc4Notify.error(objLayer.id + sharedNls.Intersect.notAddedOnMap);
                    this._cmbBoundingElement.disabled = true;
                    this._shelter.hide();
                }
            } else {
                this._cmbBoundingElement.disabled = false;
                for (var j = 0; j < objLayer._clusterData.length; j++) {
                    var fieldName;
                    fieldName = objLayer._clusterData[j].attributes["rept.report_name"] || objLayer._clusterData[j].attributes["rept.report_name"] + objLayer._clusterData[j].attributes.sub_type ||
                        objLayer._clusterData[j].attributes.SILOCAL || objLayer._clusterData[j].attributes.created_user + objLayer._clusterData[j].attributes.objectid ||
                        objLayer.id + objLayer._clusterData[j].attributes.objectid;
                    if (fieldName) {
                        arrElements.push(fieldName);
                    }
                }
                return arrElements;
            }
        },

        /**
         * Get elements from graphics layer
         * @param {object} objLayer : layer list
         * @param {integer} count : value
         * @param {array} arrElements : elements list
         * @returns {array} arrElements
         */
        _getGraphicElements: function(objLayer, count, arrElements) {
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            if (objLayer.graphics.length !== 0) {
                this._cmbBoundingElement.disabled = true;
                for (var i = 0; i < objLayer.graphics.length; i++) {
                    var fieldNames;
                    
                    //TODO: this needs to be cleaned up for both Solutions.  it should be required that a 'name' attribute exists.
                    fieldNames = objLayer.graphics[i].attributes["rept.report_name"] + objLayer.graphics[i].attributes.sub_type || objLayer.graphics[i].attributes.name || 
                        objLayer.graphics[i].attributes.FIELD_NAME || objLayer.graphics[i].attributes.id ||
                        objLayer.graphics[i].attributes.issue_name || objLayer.graphics[i].attributes.City ||
                        objLayer.graphics[i].attributes.NAME10 || objLayer.graphics[i].attributes.PO_NAME ||
                        objLayer.graphics[i].attributes.NAME || objLayer.graphics[i].attributes.STATE_NAME || objLayer.graphics[i].attributes.description
                        sharedNls.Intersect.perimeter + objLayer.graphics[i].attributes.OBJECTID ||
                        sharedNls.Intersect.perimeter + objLayer.graphics[i].attributes.objectid;
                    if (fieldNames) {
                        arrElements.push(fieldNames);
                    }
                }
                return arrElements;
            } else {
                if (count === 1) {
                    this._nc4Notify.error(objLayer.id + sharedNls.Intersect.notAddedOnMap);
                    this._cmbBoundingElement.disabled = true;
                    this._shelter.hide();
                }
            }
        },

        /**
         * Perform union geometry operation.
         * @param {string} evt : String value
         */
        _performGeometryUnion: function(evt) {
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            if (evt !== sharedNls.Intersect.lblElement) {
                this._currentSelectedElement = evt;
                if (this._cmbBoundingLayer._lastValueReported !== sharedNls.Intersect.lblLayer) {
                    if (evt === sharedNls.Intersect.all) {
                        var strLayers = this._cmbBoundingLayer._lastValueReported;
                        var objLayers = this.map.getLayer(strLayers);
                        this.gsvc = new GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL);
                        if (objLayers._clusterData) {
                            this._getPolygonGeometriesFromCluster(strLayers, objLayers);
                            if (this._allElementGeometry && this._allElementGeometry.length !== 0) {
                                this.gsvc.union(this._allElementGeometry, lang.hitch(this, this._unionSuccess), lang.hitch(this, this._unionError));
                            } else {
                                this._shelter.hide();
                            }
                        } else {
                            this._getPolygonGeometriesFromGraphics(strLayers, objLayers);
                            if (this._allElementGeometry && this._allElementGeometry.length !== 0) {
                                this.gsvc.union(this._allElementGeometry, lang.hitch(this, this._unionSuccess), lang.hitch(this, this._unionError));
                            } else {
                                this._shelter.hide();
                            }
                        }
                    } else {
                        var strLayer = this._cmbBoundingLayer._lastValueReported;
                        var objLayer = this.map.getLayer(strLayer);
                        if (objLayer._clusterData) {
                            for (var i = 0; i < objLayer._clusterData.length; i++) {
                                if (objLayer._clusterData[i].attributes["rept.report_name"] === evt ||
                                    objLayer._clusterData[i].attributes["rept.report_name"] + objLayer._clusterData[i].attributes.sub_type === evt ||
                                    objLayer._clusterData[i].attributes.SILOCAL === evt ||
                                    objLayer._clusterData[i].attributes.created_user + objLayer._clusterData[i].attributes.objectid === evt ||
                                    objLayer.id + objLayer._clusterData[i].attributes.objectid === evt) {
                                    this._singleElementGeometry = objLayer._clusterData[i].geometry;
                                }
                            }
                        } else {
                            for (var j = 0; j < objLayer.graphics.length; j++) {
                            	var currG = objLayer.graphics[j];
                            	if(currG == null)
                            		continue;
                            	var currA = currG.attributes;
                            	var singleElementFound = false;
                            	if(currA == null)
                            	{
                            		singleElementFound = "Fire Perimeter" + objLayer.graphics[j].attributes.OBJECTID === evt ||
                                    	"Fire Perimeter" + objLayer.graphics[j].attributes.objectid === evt;
                            	}
                            	else
                            	{
                            		var legacyId = "";
                            		if( currA["rept.report_name"] != null && currA.sub_type != null)
                                		legacyId = currA["rept.report_name"] + currA.sub_type;
                            		
                            		if (legacyId === evt ||
                            				currA.id === evt ||
                            				currA.FIELD_NAME === evt ||
                            				currA.issue_name === evt ||
                            				currA.City === evt ||
                            				currA.NAME10 === evt ||
                            				currA.PO_NAME === evt ||
                            				currA.NAME === evt || currA.STATE_NAME === evt ||
                            				currA.name === evt || currA.description === evt ||
                                            "Fire Perimeter" + currA.OBJECTID === evt ||
                                            "Fire Perimeter" + currA.objectid === evt
                                        )
                            			singleElementFound = true;
                            	}
                            	
                            	
                                if (singleElementFound == true) {
                                	//TODO, update in the future to support all proj
                                    this._singleElementGeometry = objLayer.graphics[j].geometry;
                                    if(this._singleElementGeometry.spatialReference.isWebMercator())
                                    {
                                    	var newSR = new SpatialReference(102100);
                                    	this._singleElementGeometry.spatialReference = newSR;
                                    }
                                }
                            }
                        }
                        this._shelter.hide();
                    }
                } else {
                    this._nc4Notify.warn(sharedNls.Intersect.selectLayer);
                    this._shelter.hide();
                }
            } else {
                this._nc4Notify.warn(sharedNls.Intersect.selectElement);
                this._shelter.hide();
            }
        },

        /**
         * Function to get only polygon geometry's.
         * @param {string} strLayers : Type of layer.
         * @param {object} objLayers : Object of layer.
         */
        _getPolygonGeometriesFromCluster: function(strLayers, objLayers) {
            if (strLayers === "Drawing") {
                this._allElementGeometry = [];
                for (var i = 0; i < objLayers._clusterData.length; i++) {
                    var type = objLayers._clusterData[i].geometry.type;
                    if (type === "polygon") {
                        this._allElementGeometry.push(objLayers._clusterData[i].geometry);
                    }
                }
            } else {
                this._allElementGeometry = [];
                this._count = 0;
                for (var l = 0; l < objLayers._clusterData.length; l++) {
                    this._allElementGeometry.push(objLayers._clusterData[l].geometry);
                }
            }
        },

        /**
         * Function to get only polygon geometry's.
         * @param {string} strLayers : Type of layer.
         * @param {object} objLayers : Object of layer.
         */
        _getPolygonGeometriesFromGraphics: function(strLayers, objLayers) {
            if (strLayers === "Drawing" || objLayers.layerFrom && objLayers.layerFrom === "overlay") {
                this._allElementGeometry = [];
                for (var i = 0; i < objLayers.graphics.length; i++) {
                    var type = objLayers.graphics[i].geometry.type;
                    if (type === "polygon") {
                        this._allElementGeometry.push(objLayers.graphics[i].geometry);
                    }
                }
            } else {
                this._allElementGeometry = [];
                for (var k = 0; k < objLayers.graphics.length; k++) {
                    this._allElementGeometry.push(objLayers.graphics[k].geometry);
                }
            }
        },

        /**
         * Function to get all geometry's of layer.
         * @param {object} layerObject : Object of geometry's
         */
        _getAllGeometryOfLayer: function(layerObject) {
            this._allGeometryOfLayer = [];
            if (layerObject._clusterData) {
                for (var i = 0; i < layerObject._clusterData.length; i++) {
                    this._allGeometryOfLayer.push(layerObject._clusterData[i].geometry);
                }
            } else {
                for (var j = 0; j < layerObject.graphics.length; j++) {
                    this._allGeometryOfLayer.push(layerObject.graphics[j].geometry);
                }
            }
        },

        /**
         * Get union geometry results
         * @param {object} geometry : result object
         */
        _unionSuccess: function(geometry) {
            this._unionGeometry = geometry;
            this._shelter.hide();
        },

        /**
         * Get union error
         * @param {object} err : Error object
         */
        _unionError: function(err) {
            this._count++;
            if (this._count === 1) {
                this._nc4Notify.error(err);
                this._shelter.hide();
            }
        },

        /**
         * Get the fields.
         */
        _getSelectedFields: function() {
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            this._currentSelectedFields = [];
            this._arrSelectedFields = [];
            for (var l = 0; l < this.selectFields.childNodes.length; l++) {
                if (this.selectFields.childNodes[l].selected === true) {
                    var obj = {};
                    this._currentSelectedFields.push(this.selectFields.childNodes[l].id);
                    obj.field = this.selectFields.childNodes[l].id;
                    obj.label = this.selectFields.childNodes[l].label.charAt(0).toUpperCase() + this.selectFields.childNodes[l].label.substr(1);
                    this._arrSelectedFields.push(obj);
                }
            }
            if (this._cmbBoundingLayer) {
                this._cmbBoundingLayer.disabled = false;
            }
            if (this._cmbBoundingElement) {
                this._cmbBoundingElement.disabled = false;
            }
            this._shelter.hide();
        },

        /**
         * Perform intersect operation.
         */
        _doIntersectOpearation: function() {
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            var deferredArray = [];
            this._attributesOfAllSelectedLayers = [];
            if (this._currentSelectedLayers) {
                if (this._cmbBoundingElement.value !== sharedNls.Intersect.lblElement) {
                    for (var k = 0; k < this._currentSelectedLayers.length; k++) {
                        this._objLayer = this.map.getLayer(this._currentSelectedLayers[k]);
                        this._attributesOfAllSelectedLayers.push(this._objLayer);
                        this._getAllGeometryOfLayer(this._objLayer);
                        this._sendQueryRequest(deferredArray, k);
                    }
                    all(deferredArray).then(lang.hitch(this, function(results) {
                        var resultArray = [];
                        this._getAllLayersResults(results, resultArray);
                        var count = 0;
                        for (var i = 0; i < resultArray.length; i++) {
                            if (resultArray[i]) {
                                if (resultArray[i] !== 0) {
                                    count++;
                                }
                            }
                        }
                        if (count > 0) {
                            this._changeGridDataFormat(resultArray);
                            this._showResultsOnGrid(resultArray);
                        } else {
                            this._nc4Notify.warn(sharedNls.Intersect.noResultsFound);
                            this._shelter.hide();
                        }
                    }));
                } else {
                    this._nc4Notify.warn(sharedNls.Intersect.selectElement);
                    this._shelter.hide();
                }
            } else {
                this._nc4Notify.warn(sharedNls.Intersect.selectLayer);
                this._shelter.hide();
            }
        },

        /**
         * Function to get all layers results
         * @param {object} results : result object
         * @param {array} resultArray : results array.
         * @returns {array} resultArray
         */
        _getAllLayersResults: function(results, resultArray) {
            if (this._objLayer) {
                for (var i = 0; i < results.length; i++) {
                    for (var j = 0; j < results[i].length; j++) {
                        var indexValue = results[i][j].geometry1Index;
                        if (this._attributesOfAllSelectedLayers[i]._clusterData) {
                            resultArray.push(this._attributesOfAllSelectedLayers[i]._clusterData[indexValue]);
                        } else {
                            resultArray.push(this._attributesOfAllSelectedLayers[i].graphics[indexValue]);
                        }
                    }
                }
            }
            return resultArray;
        },

        /**
         * Function to change grid format
         * @param {object} results : result object
         * @returns {array} results
         */
        _changeGridDataFormat: function(results) {
            if (this._currentSelectedLayers.length > 1) {
                for (var h = 0; h < this._currentSelectedFields.length; h++) {
                    for (var l = 0; l < results.length; l++) {
                        if (results[l].attributes) {
                            for (var n in results[l].attributes) {
                                if (results[l].attributes.hasOwnProperty(n)) {
                                    var str = this._currentSelectedFields[h];
                                    var keys = Object.keys(results[l].attributes);
                                    for (var i = 0; i < keys.length; i++) {
                                        if (keys[i].toLowerCase() === str) {
                                            str = keys[i];
                                        }
                                    }
                                    if (!results[l].attributes.hasOwnProperty(str)) {
                                        results[l].attributes[str] = "null";
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return results;
        },

        /**
         * Perform query operation for intersect.
         * @param {array} deferredArray -ArrayResults
         * @param {integer} index - Value
         */
        _sendQueryRequest: function(deferredArray, index) {
            var deferred = new Deferred();
            var serviceGeometry = new GeometryService(this.appUtils.configGeneralSettings.geometryServiceURL);
            var relationParams = new RelationParameters();
            relationParams.geometries1 = this._allGeometryOfLayer; //This is for selected layer. pass geometry of all graphics
            relationParams.geometries2 = (this._currentSelectedElement === sharedNls.Intersect.all) ? [this._unionGeometry] : [this._singleElementGeometry];
            relationParams.relation = RelationParameters.SPATIAL_REL_INTERSECTION;
            serviceGeometry.relation(relationParams, lang.hitch(this, function(response) {
                deferred.resolve(response);
            }), lang.hitch(this, function(err) {
                deferred.resolve(false);
            }));
            deferredArray.push(deferred);
        },

        /**
         * Displaying results in grid and showing grid on bottom panel.
         * @param {array} results -Intersect results
         */
        _showResultsOnGrid: function(resultArray) {
        	var widgetBottomPanel = registry.byId("NC4BottomPanel");
        	//lets destroy and re-create instead
        	if (widgetBottomPanel) 
        	{
        		widgetBottomPanel.destroyRecursive(false);
        		//this._bottomPanel = widgetBottomPanel;
        	}
        		
            this._isItFirst++;
            var CustomGrid,
                x = 15;
            if (this._currentSelectedFields) {
                this._arrResponse = [];
                if (resultArray.length > 1) {
                    for (var b = 0; b < resultArray.length; b++) {
                        if (resultArray[b] !== false) {
                            if (resultArray[b]) {
                                this._arrResponse.push(resultArray[b]);
                            }
                        }
                    }
                } else {
                    this._arrResponse = resultArray;
                }
                if (this.appUtils.bottomPanelGrid) {
                    this.appUtils.bottomPanelGrid.store.setData("");
                    this.appUtils.bottomPanelGrid.refresh();
                }
                CustomGrid = declare([Grid, Keyboard, Selection, Pagination], {
                    keepScrollPosition: true,
                    pagingLinks: false,
                    store: new Memory({
                        data: []
                    }),
                    pagingTextBox: true,
                    firstLastArrows: true,
                    rowsPerPage: x
                });
                
                
                
               // if (!this._bottomPanel) {
                    this._bottomPanel = new BottomPanel({
                        id: "NC4BottomPanel",
                        resultTitle: "Results",
                        appUtils: this.appUtils
                    });
                    if (this.config.saveResults) {
                        this._bottomPanel.saveReportIcon.style.display = "block";
                    } else {
                        this._bottomPanel.saveReportIcon.style.display = "none";
                    }
                    /*
                } else {
                    if (this._bottomPanel.bottomPanelResultContainer.clientHeight === 0) {
                        this._bottomPanel._openBottomPanel();
                    }
                }*/
                this._bottomPanel.saveReportIcon.hidden = false;
                this._bottomPanel.bottomPanelResultContainer.innerHTML = "";
                this.appUtils.bottomPanelGrid = new CustomGrid({
                    columns: this._arrSelectedFields
                }, this._bottomPanel.bottomPanelResultContainer);
                on(this.appUtils.bottomPanelGrid, "dgrid-select", lang.hitch(this, function(evt) {}));
                on(this._bottomPanel.searchTextboxIcon, "click", lang.hitch(this, function() {
                    this._searchInGrid();
                }));
                on(this._bottomPanel.exportExcelIcon, "click", lang.hitch(this, function() {
                    this._exportToExcel();
                }));
                if (this._isItFirst === 1) {
                    this.own(on(this._bottomPanel.saveReportIcon, "click", lang.hitch(this, function() {
                        this.isShowing = false;
                        this._saveReport();
                    })));
                }
                on(this._bottomPanel.searchTextbox, "keyUp", lang.hitch(this, function() {
                    if (this._bottomPanel.searchTextbox.displayedValue === "") {
                        this.appUtils.bottomPanelGrid.refresh();
                        this.appUtils.bottomPanelGrid.resize();
                        this.appUtils.bottomPanelGrid.setStore(new Memory({
                            data: this._dupData
                        }));
                        this.appUtils.bottomPanelGrid.startup();
                        this._shelter.hide();
                    }
                }));
                setTimeout(lang.hitch(this, function() {
                    var data = [];
                    this._gridData = data;
                    this._dupData = data;
                    for (var j = 0, al = this._arrResponse.length; j < al; j++) {
                        var obj = {};
                        for (var l = 0; l < this._currentSelectedFields.length; l++) {
                            var str = this._currentSelectedFields[l];
                            var keys = Object.keys(this._arrResponse[j].attributes);
                            for (var i = 0; i < keys.length; i++) {
                                if (keys[i].toLowerCase() === str) {
                                    str = keys[i];
                                }
                            }
                            if (this._arrResponse[j].attributes.hasOwnProperty(str)) {
                                var currSelField = this._currentSelectedFields[l];
                            	obj[currSelField] = this._arrResponse[j].attributes[str];
                                if(obj[currSelField] == "null")
                                	obj[currSelField] = "N/A";
                                obj.id = j;
                            }
                        }
                        //                        for (k in this._arrResponse[j].attributes) {
                        //                            if (this._arrResponse[j].attributes.hasOwnProperty(k)) {
                        //                                obj[k] = this._arrResponse[j].attributes[k];
                        //                                obj.id = j;
                        //                            }
                        //                        }
                        data.push(obj);
                    }
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                    this.appUtils.bottomPanelGrid.setStore(new Memory({
                        data: data
                    }));
                    this.appUtils.bottomPanelGrid.startup();
                    /* Converting grid data into json format */
                    this._exportParams = {};
                    for (var item = 0; item < this._arrSelectedFields.length; item++) {
                        if (this._arrSelectedFields[item].grid && this._arrSelectedFields[item].headerNode) {
                            this._arrSelectedFields[item].grid = null;
                            this._arrSelectedFields[item].headerNode = null;
                        }
                    }
                    this._shelter.hide();
                }, 1000));
            }
            this._shelter.hide();
        },

        /**
         * Function to search data in grid.
         */
        _searchInGrid: function() {
            var resultData = [];
            var str = this._bottomPanel.searchTextbox.value;
            if (str) {
                var j;
                for (var i = 0; i < this._gridData.length; i++) {
                    for (j in this._gridData[i]) {
                        if (j !== "id" && this._gridData[i][j] !== null && this._gridData[i][j].toString() === str) {
                            resultData.push(this._gridData[i]);
                            break;
                        }
                    }
                }
                if (resultData) {
                    this.appUtils.bottomPanelGrid.refresh();
                    this.appUtils.bottomPanelGrid.resize();
                    this.appUtils.bottomPanelGrid.setStore(new Memory({
                        data: resultData
                    }));
                    this.appUtils.bottomPanelGrid.startup();
                    this._shelter.hide();
                }
            }
        },

        /**
         * Function to export to csv of grid data
         */
        _exportToExcel: function() {
            var excelContent = {
                "Values": this._gridData
            };
            this._exportParams = JSON.stringify(excelContent);
            this._shelter.show(sharedNls.LoadingShelter.lblLoading);
            var form = document.createElement("form");
            var postData = document.createElement("input");
            form.method = "POST";
            form.id = "someForm";
            form.action = this.config.exportToCSV;
            form.target = "_blank";
            postData.value = this._exportParams;
            postData.name = "json";
            postData.type = "text";
            form.appendChild(postData);
            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
            this._shelter.hide();
        },

        /**
         * Function to save grid data in service.
         */
        _saveReport: function() {
            var reptIds = "",
                globalReptIds = "",
                isValid = true;
            for (var i = 0; i < this._gridData.length; i++) {
                if (this._gridData[i].hasOwnProperty("rept.report_id")) {
                    reptIds = reptIds + this._gridData[i]["rept.report_id"] + ",";
                } else {
                    isValid = false;
                    break;
                }
                if (this._gridData[i].hasOwnProperty("rept.global_report_id")) {
                    globalReptIds = globalReptIds + this._gridData[i]["rept.global_report_id"] + ",";
                } else {
                    isValid = false;
                    break;
                }
            }
            globalReptIds = globalReptIds.replace(/,\s*$/, "");
            reptIds = reptIds.replace(/,\s*$/, "");
            var objLayer = this.map.getLayer(this._cmbBoundingLayer._lastValueReported);
            
            var currentTitle = (objLayer._params) ? objLayer._params.name : ((objLayer._options) ? objLayer._options.name : "");
            var saveTitle = currentTitle || objLayer.overlayCustomLayerType || objLayer.name || objLayer.id;
           
            var name = saveTitle + " - " + ( new Date() ).toLocaleString();					//james - may need to update so that it uses time zone preference
            if (isValid) {
            	
            	
            	dojo.xhrPost({
                 	url: this.config.saveResults,
                 	handleAs: "text",
                 	postData: {
                         name: name,
                         data: globalReptIds,
                         reportIds: reptIds
                 	},
                 	load: lang.hitch(this, function (response) {
                 			if(response.indexOf("Success") >= 0)
                 				this._nc4Notify.success("Data sent to NC4 Main Solution");
                 			else
                 				this._nc4Notify.error("Unable to send data to NC4 Main Solution");
                        }),
                 	error: lang.hitch(this,function(){
                 		this._nc4Notify.error("Unable to send data to NC4 Main Solution");
                 	})
            	});
            	
            	/*
                esriRequest({	//update this to not go through proxy
                    url: this.config.saveResults,
                    content: lang.mixin({
                        name: name,
                        data: globalReptIds,
                        reportIds: reptIds
                    }, null)
                });*/
                
            } else {
                if (!this.isShowing) {
                    this.isShowing = true;
                    this._nc4Notify.error("Save analysis is applicable only to business layers with 'Report Id' and 'Global report id'");
                }
            }
        }
    });
});
