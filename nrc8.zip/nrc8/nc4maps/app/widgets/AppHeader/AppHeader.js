define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/html",
    "dojo/_base/array",
    "dojo/aspect",
    "dojo/on",
    "dojo/dom-attr",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/query",
    "dojo/text!./AppHeaderTemplate.html",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/registry",
    "esri/urlUtils"
], function (
    declare,
    lang,
    html,
    array,
    aspect,
    on,
    domAttr,
    domClass,
    domStyle,
    query,
    template,
    _WidgetBase,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    registry,
    urlUtils
) {
        //========================================================================================================================//
        return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
            templateString: template,
            _appHeaderWidgetCount: 14, //Set the number of widget icons appear at a time in application header, rest will be in 'Widget Gallery'.
            _createMoreIcon: false,
            _headerIconCount: 1,
            _iconWidth: null,
            _mapInstance: null,
            _maxIconCount: -1,

            /**
             * Create header panel and set application name
             */
          postCreate: function () {          
                var applicationHeaderDiv;
                applicationHeaderDiv = html.create("div", {}, query(".header")[0]);
                html.place(this.domNode, applicationHeaderDiv);

                var url = location.href.toString();
                var urlObject = urlUtils.urlToObject(url), queryParam = null, appHeaderTitle = null;
                if (urlObject.query) {
                    queryParam = urlObject.query;
                    appHeaderTitle = queryParam.lyr1name || "";
                }

                if (appHeaderTitle == null || appHeaderTitle == "")
                    appHeaderTitle = this.config.ApplicationName
                domAttr.set(this.applicationHeaderName, "innerHTML", appHeaderTitle);
                on(window, "resize", lang.hitch(this, function () {
                    this._resize();
                }));

                if (this.config.appClose != null) {
                    this.own(on(this.appClose, "click", lang.hitch(this, function () {
                        window.close();
                    })));
                }
                else {
                    domStyle.set(this.appClose, "display", "none");
                }
                aspect.after(this.appUtils, "openWidget", lang.hitch(this, function () {
                    var className = "widget" + this.appUtils.widgetToOpen + "Icon",
                        widgetIcon,
                        widgetInitialized;
                    widgetIcon = query("." + className);
                    if (widgetIcon) {
                      
                        if (widgetIcon[0] && widgetIcon[0].config) {							//TODO: james - is a new widget obj created each time, on click?
                            this._initializeWidget(widgetIcon[0]);
                        } else {
                            widgetInitialized = registry.byId("app/widgets/" + this.appUtils.widgetToOpen + "/" + this.appUtils.widgetToOpen);
                            if (widgetInitialized) { 
                                this._toggleWidget(widgetInitialized);
                            }
                        }
                    }
                }));
            },


            /**
             * Call '_resize()' to append widget icons in header panel
             * @param {object} mapInstance - Map instance
             */
          loadHeaderWidgets: function (mapInstance) {           
                this._mapInstance = mapInstance;
                this._resize();
                if (this.appUtils.configGeneralSettings.onWidget) {
                    this.appUtils.openWidget(this.appUtils.configGeneralSettings.onWidget);
                }
            },

            /**
             * Calculates the header panel size and based on that selects which widgets to be shown in header panel
             * rest of the widgets will be shown in 'WidgetGallery' widget.
             */
          _resize: function () {             
              if (window.location.href.indexOf("/map") !== -1 || window.location.href.indexOf("/") !== -1) {
                    var appHeaderDimmentionDetail,
                        appHeaderWidthDetail,
                        widgetCount = this._getWidgetCount(),
                        widgetIndex;
                    html.empty(this.applicationHeaderWidgetsContainer);
                    for (widgetIndex = 0; widgetIndex < this.config.AppHeaderWidgets.length; widgetIndex++) {
                        this.config.AppHeaderWidgets[widgetIndex].isVisible = false;
                    }
                    appHeaderDimmentionDetail = html.getContentBox(this.domNode);
                    this._iconWidth = appHeaderDimmentionDetail.h;
                    appHeaderWidthDetail = this._calcContainerAndEmptyWidth(appHeaderDimmentionDetail);
                    this._maxIconCount = Math.floor(appHeaderWidthDetail.containerWidth / this._iconWidth) > this._appHeaderWidgetCount ? this._appHeaderWidgetCount : Math.floor(appHeaderWidthDetail.containerWidth / this._iconWidth);
                    if (this._maxIconCount >= widgetCount) {
                        this._headerIconCount = widgetCount;
                        this._createMoreIcon = false;
                    } else {
                        this._headerIconCount = this._maxIconCount - 1;
                        this._createMoreIcon = true;
                    }
                    html.setStyle(this.applicationHeaderWidgetsContainer, {
                        marginLeft: 5 + "px" //(appHeaderWidthDetail.emptyWidth - (0 + this._headerIconCount)) + "px" //add some margin to avoid layout mess
                    });
                    if (this._createMoreIcon) {
                        this._showWidgetGalleryIcon();
                    }
                    this._selectWidgetIcon();
                }
            },

            /**
             * If 'Widget Gallery' in initialized place it in app header,
             * or call '_createWidgetIcon()' to place its icon in application header.
             */
            _showWidgetGalleryIcon: function () {
                var widgetGallery,
                    widgetGalleryLabel,
                    widgetIndex;
                //Use '_' for below block of code, to simplify.
                for (widgetIndex = 0; widgetIndex < this.config.AppHeaderWidgets.length; widgetIndex++) {
                    widgetGalleryLabel = this.config.AppHeaderWidgets[widgetIndex].label;
                    if (widgetGalleryLabel === "More") {
                        this.config.AppHeaderWidgets[widgetIndex].isVisible = true;
                        widgetGallery = registry.byId(this.config.AppHeaderWidgets[widgetIndex].WidgetPath);
                        if (widgetGallery) {
                            domClass.add(widgetGallery.widgetIcon, "appHeaderWidgetIcon");
                            html.place(widgetGallery.widgetIcon, this.applicationHeaderWidgetsContainer);
                        } else {
                            this._createWidgetIcon(widgetIndex, widgetGalleryLabel);
                        }
                        break;
                    }
                }
            },

            /**
             * Place widget icons in application header.
             */
            _selectWidgetIcon: function () {
                var counter = 0,
                    k,
                    widget,
                    widgetIndex,
                    widgetLabel;
                for (widgetIndex = 0; widgetIndex < this.config.AppHeaderWidgets.length; widgetIndex++) {
                    widgetLabel = this.config.AppHeaderWidgets[widgetIndex].label;
                    if (widgetLabel !== "More" && !this.config.AppHeaderWidgets[widgetIndex].isVisible) {
                        counter++;
                        widget = registry.byId(this.config.AppHeaderWidgets[widgetIndex].WidgetPath);
                        if (widget) {
                            domClass.add(widget.widgetIcon, "appHeaderWidgetIcon");
                            html.place(widget.widgetIcon, this.applicationHeaderWidgetsContainer);
                        } else {
                            this._createWidgetIcon(widgetIndex, widgetLabel);
                        }
                        //Use '_' for below block of code.
                        //TODO - James - why is this needed?
                        for (k = 0; k < this.config.AppHeaderWidgets.length; k++) {
                            if (this.config.AppHeaderWidgets[k].label === widgetLabel) {
                                this.config.AppHeaderWidgets[k].isVisible = true;
                                break;
                            }
                        }
                        if (counter >= this._headerIconCount) {
                            break;
                        }
                    }
                }
            },

            /**
             * Creates widget icon.
             * @param {integer} j - Index of the widget in config file.
             * @param {string} widgetLabel - Title of the widget.
             */
            _createWidgetIcon: function (j, widgetLabel) {
                var widgetIcon, widgetName;
                widgetName = this.config.AppHeaderWidgets[j].WidgetPath.split("/")[this.config.AppHeaderWidgets[j].WidgetPath.split("/").length - 1];
                widgetIcon = html.create("div", {
                    "title": widgetLabel,
                    "class": "widget" + widgetName + "Icon"
                }, null);
                domClass.add(widgetIcon, "appHeaderWidgetIcon");
                html.place(widgetIcon, this.applicationHeaderWidgetsContainer);
                widgetIcon.config = this.config.AppHeaderWidgets[j];
                on.once(widgetIcon, "click", lang.hitch(this, function () {
                    this._initializeWidget(widgetIcon);
                }));
            },

            /**
             * Initializes the widget.
             * @param {object} widgetIcon - Details of the widget to be initialized.
             */
            _initializeWidget: function (widgetIcon) {
                require([widgetIcon.config.WidgetPath], lang.hitch(this, function (Widget) {			//james - initializing widgets in app header, this is how they're created
                    var divWidgetContainer = query(".appHeaderWidgetConainer")[0],
                        widgetInitialized;
                    widgetInitialized = new Widget({
                        map: this._mapInstance,
                        id: widgetIcon.config.WidgetPath,
                        config: widgetIcon.config,
                        appUtils: this.appUtils,
                        appConfig: widgetIcon.config.label === "More" ? this.config : null
                    });
                    domClass.add(widgetInitialized.widgetIcon, "appHeaderWidgetIcon");
                    divWidgetContainer.replaceChild(widgetInitialized.widgetIcon, widgetIcon);
                    this._toggleWidget(widgetInitialized);
                    on(widgetInitialized.widgetIcon, "click", lang.hitch(this, function () {
                        this._toggleWidget(widgetInitialized);
                    }));
                }));
            },

            /**
             * Returns array of widgets ID.
             * @returns {array} arrWidgetIDs - List of widgets ID.
             */
            _getWidgetsId: function () {
                var arrWidgetIDs = [],
                    widgetID,
                    widgetIndex;
                for (widgetIndex = 0; widgetIndex < this.config.AppHeaderWidgets.length; widgetIndex++) {
                    widgetID = this.config.AppHeaderWidgets[widgetIndex].WidgetPath;
                    arrWidgetIDs.push(widgetID);
                }
                return arrWidgetIDs;
            },

            /**
             * Toggles the widget panel, shows the panel of widget whose icon is clicked.
             * @param {object} widgetInitialized - Widget which is clicked.
             */
            _toggleWidget: function (widgetInitialized) {
                var arrWidgetIDs = this._getWidgetsId(),
                    widget,
                    widgetIndex;
                for (widgetIndex = 0; widgetIndex < arrWidgetIDs.length; widgetIndex++) {
                    widget = registry.byId(arrWidgetIDs[widgetIndex]);
                    if (widget) {
                        if (widget.isOpen && widget.config.label !== widgetInitialized.config.label) {
                            widget.hide();
                        }
                    }
                }
                widgetInitialized.show();
                currentWidget = widgetInitialized;
            },

            /**
             * Returns count of widgets (excludes 'WidgetGallery').
             * @returns {integer} widgetCount - Total number of widgets associated with the application header panel.
             */
            _getWidgetCount: function () {
                var widgetCount = this.config.AppHeaderWidgets.length - 1;
                return widgetCount;
            },

            /**
             * Returns width of the close icon node present in application header.
             * @returns {integer} width - Width of the of the close icon node.
             */
            _getCloseIconWidth: function () {
                var width = html.getMarginBox(this.appClose).w;
                return width + 5;
            },

            /**
             * Returns width of the application header node which contains application icon and name.
             * @returns {integer} width - Width of the application header node which contains application icon and name.
             */
            _getHeaderSectionWidth: function () {
                var width = html.getMarginBox(this.divApplicationHeader).w;
                return width;
            },

            /**
             * Returns width of the node which contains widget icons.
             * @param {object} box - Object that encodes the width, height, left and top positions of the node's content box.
             * @returns {integer} containerWidth - Width of the node which contains widget icons.
             */
            _getContainerWidth: function (box) {
                var containerWidth,
                    headSectionWidth;
                headSectionWidth = this._getHeaderSectionWidth();
                //the container width
                containerWidth = box.w - headSectionWidth - this._getMarginWidth(box) - this._getCloseIconWidth();
                return containerWidth;
            },

            /**
             * Returns width of the node which contains widget icons.
             * @param {object} box - Object that encodes the width, height, left and top positions of the node's content box.
             * @returns {object} widthDetail - Object containing the width detail of header container node.
             */
            _calcContainerAndEmptyWidth: function (box) {
                var containerWidth,
                    emptyWidth,
                    widthDetail;
                containerWidth = this._getContainerWidth(box);
                emptyWidth = this._getMarginWidth(box);
                //we need put at least two icons
                if (containerWidth < this._iconWidth * 2) {
                    html.setStyle(this.applicationHeaderName, {
                        display: "none"
                    });
                    containerWidth = this._getContainerWidth(box);
                    emptyWidth = this._getMarginWidth(box);
                }
                widthDetail = {
                    containerWidth: containerWidth,
                    emptyWidth: emptyWidth
                };
                return widthDetail;
            },

            /**
             * Returns 1/10th width of the application header container node.
             * @param {object} box - Object that encodes the width, height, left and top positions of the node's content box.
             * @returns {integer} marginWdith - 1/10th width of the application header container node.
             */
            _getMarginWidth: function (box) {
                var marginWdith = 1 / 10 * box.w;
                return marginWdith;
            }
        });
    });
