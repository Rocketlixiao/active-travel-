define([
    "dojo/_base/declare",
    "dojo/_base/html",
    "dojo/on",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/dom-attr",
    "dojo/dom",
    "dojo/aspect",
    "dojo/text!./StatusBarTemplate.html",
    "dojo/i18n!../../nls/LocalizedStrings",
    "esri/SpatialReference",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin"
], function(
    declare,
    html,
    on,
    array,
    lang,
    domAttr,
    dom,
    aspect,
    template,
    sharedNls,
    SpatialReference,
    _WidgetBase,
    _TemplatedMixin
) {
    return declare([_WidgetBase, _TemplatedMixin], {
        name: "StatusBar",
        baseClass: "widget-StatusBar",
        sharedNls: sharedNls,
        _spatilReferenceList: null,
        templateString: template,

        postCreate: function() {
        	var headerNode = dom.byId("headerNC4Maps");
        	var mapNode = dom.byId("mapContainerNode");
        	require(["dojo/dom-style"], function(domStyle){
        		if(domStyle.get(headerNode, "display") == "none" || domStyle.get(headerNode, "visibility") == "hidden")
        			html.addClass(mapNode, "statusBarAdded");
        		else
        			html.addClass(mapNode, "statusBarAddedWithHeader");
        	});
        	
            
            var statusBar = html.create("div", {
                "class": "statusBar"
            }, "mainContainer");
            html.place(this.domNode, statusBar);
            this._nc4Notify = this.appUtils.nc4Notify;

            this._spatilReferenceList = [3819, 3821, 3824, 3889, 3906, 4001, 4002, 4003, 4004, 4005, 4006, 4007, 4008, 4009, 4010, 4011, 4012, 4013, 4014, 4015, 4016, 4018, 4019, 4020, 4021, 4022, 4023, 4024, 4025, 4027, 4028, 4029, 4031, 4032, 4033, 4034, 4035, 4036, 4042, 4044, 4045, 4046, 4047, 4052, 4053, 4054, 4055, 4075, 4081, 4120, 4121, 4122, 4123, 4124, 4125, 4126, 4127, 4128, 4129, 4130, 4131, 4132, 4133, 4134, 4135, 4136, 4137, 4138, 4139, 4140, 4141, 4142, 4143, 4144, 4145, 4146, 4147, 4148, 4149, 4150, 4151, 4152, 4153, 4154, 4155, 4156, 4157, 4158, 4159, 4160, 4161, 4162, 4163, 4164, 4165, 4166, 4167, 4168, 4169, 4170, 4171, 4172, 4173, 4174, 4175, 4176, 4178, 4179, 4180, 4181, 4182, 4183, 4184, 4185, 4188, 4189, 4190, 4191, 4192, 4193, 4194, 4195, 4196, 4197, 4198, 4199, 4200, 4201, 4202, 4203, 4204, 4205, 4206, 4207, 4208, 4209, 4210, 4211, 4212, 4213, 4214, 4215, 4216, 4218, 4219, 4220, 4221, 4222, 4223, 4224, 4225, 4226, 4227, 4228, 4229, 4230, 4231, 4232, 4233, 4234, 4235, 4236, 4237, 4238, 4239, 4240, 4241, 4242, 4243, 4244, 4245, 4246, 4247, 4248, 4249, 4250, 4251, 4252, 4253, 4254, 4255, 4256, 4257, 4258, 4259, 4260, 4261, 4262, 4263, 4264, 4265, 4266, 4267, 4268, 4269, 4270, 4271, 4272, 4273, 4274, 4275, 4276, 4277, 4278, 4279, 4280, 4281, 4282, 4283, 4284, 4285, 4286, 4287, 4288, 4289, 4291, 4292, 4293, 4294, 4295, 4296, 4297, 4298, 4299, 4300, 4301, 4302, 4303, 4304, 4305, 4306, 4307, 4308, 4309, 4310, 4311, 4312, 4313, 4314, 4315, 4316, 4317, 4318, 4319, 4322, 4324, 4326, 4463, 4466, 4469, 4470, 4475, 4483, 4490, 4555, 4558, 4600, 4601, 4602, 4603, 4604, 4605, 4606, 4607, 4608, 4609, 4610, 4611, 4612, 4613, 4614, 4615, 4616, 4617, 4618, 4619, 4620, 4621, 4622, 4623, 4624, 4625, 4626, 4627, 4628, 4629, 4630, 4631, 4632, 4633, 4636, 4637, 4638, 4639, 4641, 4642, 4643, 4644, 4645, 4646, 4657, 4658, 4659, 4660, 4661, 4662, 4663, 4664, 4665, 4666, 4667, 4668, 4669, 4670, 4671, 4672, 4673, 4674, 4675, 4676, 4677, 4678, 4679, 4680, 4682, 4683, 4684, 4686, 4687, 4688, 4689, 4690, 4691, 4692, 4693, 4694, 4695, 4696, 4697, 4698, 4699, 4700, 4701, 4702, 4703, 4704, 4705, 4706, 4707, 4708, 4709, 4710, 4711, 4712, 4713, 4714, 4715, 4716, 4717, 4718, 4719, 4720, 4721, 4722, 4723, 4724, 4725, 4726, 4727, 4728, 4729, 4730, 4731, 4732, 4733, 4734, 4735, 4736, 4737, 4738, 4739, 4740, 4741, 4742, 4743, 4744, 4745, 4746, 4747, 4748, 4749, 4750, 4751, 4752, 4753, 4754, 4755, 4756, 4757, 4758, 4759, 4760, 4761, 4762, 4763, 4764, 4765, 4801, 4802, 4803, 4804, 4805, 4806, 4807, 4808, 4809, 4810, 4811, 4812, 4813, 4814, 4815, 4816, 4817, 4818, 4819, 4820, 4821, 4823, 4824, 4901, 4902, 4903, 4904, 5013, 5228, 5229, 5233, 5246, 5252, 5264, 5324, 5340, 5354, 5360, 5365, 5371, 5373, 5381, 5393, 5451, 5464, 5467, 5489, 5524, 5527, 5546, 5561, 5593, 5681, 5886, 6135, 6207, 6318, 6322, 6325, 6365, 6668, 6706, 6783, 6881, 6882, 6883, 6892, 6894, 6980, 6983, 6987, 6990, 37001, 37002, 37003, 37004, 37005, 37006, 37007, 37008, 37201, 37202, 37203, 37204, 37205, 37206, 37207, 37208, 37211, 37212, 37213, 37214, 37215, 37216, 37217, 37218, 37219, 37220, 37221, 37222, 37223, 37224, 37225, 37226, 37227, 37228, 37229, 37230, 37231, 37232, 37233, 37234, 37235, 37237, 37238, 37239, 37240, 37241, 37242, 37243, 37245, 37246, 37247, 37249, 37250, 37251, 37252, 37253, 37254, 37255, 37257, 37259, 37260, 104000, 104009, 104020, 104023, 104100, 104101, 104102, 104103, 104104, 104105, 104106, 104107, 104108, 104109, 104110, 104111, 104112, 104113, 104114, 104115, 104116, 104117, 104118, 104119, 104120, 104121, 104122, 104123, 104124, 104125, 104126, 104127, 104128, 104129, 104130, 104131, 104132, 104133, 104134, 104135, 104136, 104137, 104138, 104139, 104140, 104141, 104142, 104143, 104144, 104145, 104199, 104223, 104248, 104256, 104257, 104258, 104259, 104260, 104261, 104286, 104287, 104304, 104305, 104700, 104701, 104702, 104703, 104704, 104705, 104706, 104707, 104708, 104709, 104710, 104711, 104712, 104713, 104714, 104715, 104716, 104717, 104718, 104719, 104720, 104721, 104722, 104723, 104724, 104725, 104726, 104727, 104728, 104729, 104730, 104731, 104732, 104733, 104734, 104735, 104736, 104737, 104738, 104739, 104740, 104741, 104742, 104743, 104744, 104745, 104746, 104747, 104748, 104749, 104750, 104751, 104752, 104753, 104754, 104755, 104756, 104757, 104758, 104759, 104760, 104761, 104762, 104763, 104764, 104765, 104766, 104767, 104768, 104769, 104770, 104771, 104772, 104773, 104774, 104775, 104776, 104777, 104778, 104779, 104780, 104781, 104782, 104783, 104784, 104785, 104786, 104800, 104801, 104802, 104803, 104804, 104805, 104806, 104807, 104808, 104809, 104810, 104811, 104812, 104813, 104814, 104815, 104816, 104817, 104818, 104819, 104820, 104821, 104822, 104823, 104824, 104825, 104826, 104827, 104828, 104829, 104830, 104831, 104832, 104833, 104834, 104835, 104836, 104837, 104838, 104839, 104840, 104841, 104842, 104843, 104844, 104845, 104846, 104847, 104848, 104849, 104850, 104851, 104852, 104853, 104854, 104855, 104856, 104857, 104858, 104859, 104860, 104861, 104862, 104863, 104864, 104865, 104866, 104867, 104868, 104869, 104870, 104871, 104896, 104900, 104901, 104902, 104903, 104904, 104905, 104906, 104907, 104908, 104909, 104910, 104911, 104912, 104913, 104914, 104915, 104916, 104917, 104918, 104919, 104920, 104921, 104922, 104923, 104924, 104925, 104926, 104927, 104928, 104929, 104930, 104931, 104932, 104933, 104934, 104935, 104936, 104937, 104938, 104939, 104940, 104941, 104942, 104943, 104944, 104945, 104946, 104947, 104948, 104949, 104950, 104951, 104952, 104953, 104954, 104955, 104956, 104957, 104958, 104959, 104960, 104961, 104962, 104963, 104964, 104965, 104966, 104967, 104968, 104969, 104970, 104990, 104991, 104992];
            this._initializeStatusBarWidget();
            /*Below code for add custom base map and then pass map instance to all widgets*/
            /*This function will call after main function execution completes*/
            aspect.after(this.appUtils, "updateMapInstance", lang.hitch(this, function() {
                this.map = null;
                this.map = this.appUtils.mapInstance;
                this._initializeStatusBarWidget();
                this._getMercator();
            }));
        },

        /*
         * Function to initialize status bar widget.
         */
        _initializeStatusBarWidget: function() {
            var currentWebMercator,
                defaultScale,
                defaultZoom,
                defaultCenterPoint,
                defaultCenterX,
                defaultCenterY,
                defaultSplitCenterX,
                defaultSplitCenterY,
                webMercator;
            defaultScale = this.map.getScale();
            defaultZoom = this.map.getZoom();
            webMercator = new SpatialReference(this.map.spatialReference.wkid);
            currentWebMercator = webMercator.isWebMercator();
            defaultCenterPoint = this.map.extent.getCenter();
            defaultCenterX = defaultCenterPoint.x.toString();
            defaultCenterY = defaultCenterPoint.y.toString();
            defaultSplitCenterX = defaultCenterX.substring(0, 15);
            defaultSplitCenterY = defaultCenterY.substring(0, 15);
            domAttr.set(this.divScale, "textContent", "Scale: " + defaultScale + "M");
            domAttr.set(this.divZoomLevel, "textContent", "Zoom: " + defaultZoom);
            if (currentWebMercator) {
                domAttr.set(this.divWebMercator, "textContent", "EPSG:" + this.map.spatialReference.wkid);
            }
            domAttr.set(this.divMapCenterPoint, "textContent", "Center: " + defaultSplitCenterX + " , " + defaultSplitCenterY);
            // Mouse event to get latitude and longitude values based on mover over on map.
            on(this.map, "mouse-move", lang.hitch(this, this._projectToLatLong), function(err) {
                this._nc4Notify.error(sharedNls.StatusBar.error + err);
            });
            // This event to handle in ipad issue for lat and long values.
            on(this.map, "click", lang.hitch(this, this._projectToLatLong), function(err) {
            	this._nc4Notify.error(sharedNls.StatusBar.error + err);
            });

            // Event to get current zoom level.
            on(this.map, "zoom-end", lang.hitch(this, function(evt) {
                var centerPoint,
                    centerX,
                    centerY,
                    splitCenterX,
                    splitCenterY,
                    mapScale,
                    zoomLevel;
                zoomLevel = evt.level;
                if (!zoomLevel) {
                    zoomLevel = this.map.getZoom();
                }
                mapScale = this.map.getScale();
                centerPoint = this.map.extent.getCenter();
                centerX = centerPoint.x.toString();
                centerY = centerPoint.y.toString();
                splitCenterX = centerX.substring(0, 15);
                splitCenterY = centerY.substring(0, 15);
                domAttr.set(this.divZoomLevel, "textContent", "Zoom: " + zoomLevel);
                domAttr.set(this.divScale, "textContent", "Scale: " + mapScale + "M");
                domAttr.set(this.divMapCenterPoint, "textContent", "Center: " + splitCenterX + " , " + splitCenterY);
            }));
            // Event to get current center points.
            on(this.map, "extent-change", lang.hitch(this, function(evt) {
                var centerPoint,
                    centerY,
                    splitCenterX,
                    splitCenterY,
                    centerX;
                centerPoint = this.map.extent.getCenter();
                centerX = centerPoint.x.toString();
                centerY = centerPoint.y.toString();
                splitCenterX = centerX.substring(0, 15);
                splitCenterY = centerY.substring(0, 15);
                domAttr.set(this.divMapCenterPoint, "textContent", "Center: " + splitCenterX + " , " + splitCenterY);
            }));
            this.map.resize();
        },

        /*
         * Function to get current spatial reference of the base map.
         */
        _getMercator: function() {
            domAttr.set(this.divWebMercator, "textContent", "EPSG:" + this.map.spatialReference.wkid);
        },

        /*
         * Function to get latitude and longitude values based on move over.
         */
        _projectToLatLong: function(evt) {
            var showLatLong = null,
                degX,
                degY,
                longs,
                lat,
                latY,
                longX,
                minX1,
                minX2,
                minY1,
                minY2,
                secX1,
                secX2,
                secY1,
                secY2,
                splitLongX,
                splitLatY,
                xLongs,
                yLat;
            longs = evt.mapPoint.getLongitude();
            //if (!longs) {
            xLongs = evt.mapPoint.x;
            //}
            degX = parseInt(longs, 10);
            minX1 = longs - degX;
            minX2 = parseInt(minX1 * 60, 10);
            secX1 = (longs - degX - minX2 / 60) * 3600;
            secX2 = parseInt(secX1, 10);
            lat = evt.mapPoint.getLatitude();
            //if (!lat) {
            yLat = evt.mapPoint.y;
            //}
            degY = parseInt(lat, 10);
            minY1 = lat - degY;
            minY2 = parseInt(minY1 * 60, 10);
            secY1 = (lat - degY - minY2 / 60) * 3600;
            secY2 = parseInt(secY1, 10);
            longX = degX + "." + Math.sqrt(minX2 * minX2) + "'" + Math.sqrt(secX2 * secX2);
            latY = degY + "." + Math.sqrt(minY2 * minY2) + "'" + Math.sqrt(secY2 * secY2);
            splitLongX = longX.split(/'/, 1);
            splitLatY = latY.split(/'/, 1);
            for (var i = 0; i < this._spatilReferenceList.length; i++) {
                if (this.map.spatialReference.wkid === this._spatilReferenceList[i]) {
                    showLatLong = true;
                    break;
                } else {
                    showLatLong = false;
                }
            }
            if (showLatLong) {
                if (longs && lat) {
                    var strLong = longs.toString();
                    var strLat = lat.toString();
                    var longitude = strLong.substring(0, 9);
                    var latitude = strLat.substring(0, 9);
                    domAttr.set(this.divLatLong, "textContent", "Long: " + longitude + " | " + "Lat: " + latitude);
                }
            } else {
                if (xLongs && yLat) {
                    domAttr.set(this.divLatLong, "textContent", "X: " + xLongs + " | " + "Y: " + yLat);
                }
            }
        }
    });
});
