define([
    "dojo/Stateful",
    "dojo/_base/declare"
], function(Stateful, declare) {
    return declare([Stateful], {
        configGeneralSettings: null, // access to configuration's general setting at widget level - this was probably done b/c the widgets has their own 'this.config' object, so needed a separate way to refer to the prop configs
        customBasemapCollection: [],
        customLayerCollection: [],
        customLayerName: [],
        customLayerServiceName: [],
        customBaseMapsFromAddLayer: false,
        mapServerLayers: [],
        arrLayerExtent: null,
        isSidePanelOpen: false,
        bottomPanelGrid: null,
        mapNode: null,
        mapInstance: null,
        boolBasemapChanged: null,
        isLegendRefresh: null,
        treeNode: null,
        customLayerCount: 0,
        iscreateOverlayMode: false,
        overlayLayers: [],
        editOverlayLayerId: null,
        widgetToOpen: null,
        clustering: null,
        arrIntervalForClusters: [],
        log: null,
        nc4Notify: null,
        
        setNc4Notify: function(p_nc4NotifyObject)
        {
        	this.nc4Notify = p_nc4NotifyObject;
        },
        
        setLog: function(p_logLevelObj)
        {
        	this.log = p_logLevelObj;
        },
        /**
         * Store widget name which some other widget want to open.
         * @param {string} widgetName - Id of overlay layer
         */
        openWidget: function(widgetName) {
            this.widgetToOpen = widgetName;
        },

        /**
         * set Clustering object.  This object is used in DataLayers, but is also needed in BasemapGallery (on basemap switch)
         * @params {Clustering}
         */
        setClustering: function(p_clusteringObj)
        {
        	this.clustering = p_clusteringObj;
        },
        
        /**
         * Store id of overlay layer which is being edited.
         * @param {string} layerId - Id of overlay layer
         */
        setEditOverlayId: function(layerId) {
            this.editOverlayLayerId = layerId;
        },


        /**
         * maintain the custom layer array
         * @param {array} layer - array of object
         */
        overlayLayersAdded: function(layer) {
            this.overlayLayers.push(layer);
        },

        //function for draw to signify that it just finished updating an overlay.
        doneOverlayEditing: function() {
        	//do nothing
        },
        
        /**
         * maintain the createOverlayMode
         * @param {array} layer - array of object
         */
        createOverlayMode: function(isOn) {
            this.iscreateOverlayMode = isOn;
        },

        /**
         * maintain the custom layer array
         * @param {array} layer - array of object
         */
        customLayerAdded: function(layer) {
            this.customLayerCollection.push(layer);
        },

        /**
         * maintain the custom layer array
         * @param {array} servicelayerName - array of object
         */
        customLayerServiceNames: function(servicelayerName) {
            this.customLayerServiceName.push(servicelayerName);
        },

        /**
         * maintain the custom layer array
         * @param {array} layerName - array of object
         */
        customLayerNameAdded: function(layerName) {
            this.customLayerName.push(layerName);
        },

        layerAddedOnBasemap: function(bool) {
            this.boolBasemapChanged = bool;
        },

        getTreeNodeForBasemap: function(node) {
            this.treeNode = node;
        },

        updateMapInstance: function(map) {
            this.mapInstance = map;
        },

        refreshLegend: function(legendBool) {
            this.isLegendRefresh = legendBool;
        },

        addCustomBaseMapFromAddLayer: function(bool) {
            this.customBaseMapsFromAddLayer = bool;
        },

        layerExtent: function(extent) {
            this.arrLayerExtent = extent;
        },

        mapServerLayer: function(layer) {
            this.mapServerLayers.push(layer);
        },

        /**maintain the custom layer array
         * @param {array} layer - array of object
         */
        sidePanelOpen: function(isOpen) {
            this.isSidePanelOpen = isOpen;
        },

        /**sort the array of object using key name
         * @param {array} collectionData - array of object
         * @param {string} fieldname - field of the object
         */
        sortCollection: function(collectionData, fieldname) {
            var self = this;
            collectionData.sort(function(a, b) {
                //if both a and b are numbers sort as per number
                if (self._isNumber(a[fieldname]) && self._isNumber(b[fieldname])) {
                    return a[fieldname] - b[fieldname];
                }
                //if a is string and b is number put b before a (number before string)
                if (typeof a[fieldname] == "string" && self._isNumber(b[fieldname])) {
                    return 1;
                }
                //if a is number and b is string put a before b (number before string)
                if (self._isNumber(a[fieldname]) && typeof b[fieldname] == "string") {
                    return -1;
                }
                //if both a and b are strings sort as per string
                if (typeof a[fieldname] == "string" && typeof b[fieldname] == "string") {
                    var x = (a[fieldname]).toLowerCase(),
                        y = (b[fieldname]).toLowerCase();
                    return x < y ? -1 : x > y ? 1 : 0;
                }
            });
            return collectionData;
        },

        /**to validate numeric value*/
        _isNumber: function(n) {
            return !isNaN(parseFloat(n)) && isFinite(n);
        }
    });
});
