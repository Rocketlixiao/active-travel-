
/*extention*/
(function () {
  //array.find
  if (![].find) {
    Array.prototype.find = function (callback, thisArg) {
      var arr = thisArg || this;
      if (Array.isArray(arr)) {
        for (var i = 0; i < arr.length; i++) {
          if (typeof callback === 'function' && callback(arr[i], i, arr)) {
            return arr[i];
          }
        }
      }
    };
  }

  isNaN = Number.isNaN || function (value) { return value !== value };
})();

window.requestAnimFrame = (function () {
  return window.requestAnimationFrame ||
    window.webkitRequestAnimationFrame ||
    window.mozRequestAnimationFrame ||
    function (callback) {
      window.setTimeout(callback, 1000 / 60);
    };
})();

//var app = {};//this is global map app
/********global config********/
globalConfig = {
  CDN: CDN,
  isDebugMode: isDebugMode,//if it is debug mode 
  allIncidentItems: [],//all of incident items
  allFilteredIncidentItems: [],//all of filtered incident items
  allAssetItems: [],//all of Asset items
  allFilteredAssetItems: [],//all of filtered Asset items
  settingsData: {},
  allProximities: {},//all of proximities items
  allLegacyProximities: {},//all of legacy proximities items
  allResources: {},//all of resources
  userInfo: {},
  isIncidentsLoadComplete: false,//if loading incidents completely
  isAssetsLoadComplete: false,//if loading assets completely
  isClusterComplete: false,//if loading cluster completely

  //mutiple filter
  filterObject: null,
  filtedItemIndex: 0,
  isFilterApplied: false,
  multipleFilters: [],

  //auto refresh
  AutoRef_updatedIncidents: [],
  AutoRef_timestamp: '',
  AutoRef_locationRequestTimestamp: '',
  AutoRef_updatedAssets: [],
  AutoRef_impactAssetIncidentsIds: [],//collect all incidents id which needs to recalculate impacted assets

  //all valid categories
  allAvailableCategories: 'structural,intelligence,advisory,aviation,fire,geophysical,hazmat,health,infrastructure,labor,meteorological,security,structural,terrorism,transportation,analysis,other',
  /***** end global constants *****/

  /*****loader*****/
  showLoader: function () {
    var loader = document.getElementById('loader');
    loader.style.display = 'block';
  },

  hideLoader: function () {
    var loader = document.getElementById('loader');
    loader.style.display = 'none';
  },

  timerIdForLoader: null,
  timerJobHideLoader: function () {
    globalConfig.timerIdForLoader = window.setInterval(function () {
      if (globalConfig.isIncidentsLoadComplete && globalConfig.isClusterComplete) {

        //hide loader div
        globalConfig.hideLoader();
        globalConfig.clearIntervalByTimerId(globalConfig.timerIdForLoader);
      }
    }, 200);
  },
  /*****end loader*****/

  /***** logout *****/
  timeOutSession: function () {   
    var isActivity = false;
    var lastTime = Date.now();
    //define the parameters for sign out function
    var option = {
      timeout: 1 * 60 * 1000, //1 min
      tick: 1000
    };

    //define function to update lastTime with current time.
    function update() {
   
      isActivity = true;
    }

    //define function to update lastTime with current time.
    function checkActivity() {
    
      if (isActivity) {
        jQuery.ajax({
          method: "GET"
          , url: '/nc4maps/timeout/'//this url is not exempt from the timeout list, so when it fires it refreshes the session
          , success: function (response) {
          
            if (response && response.data != "") {
              window.open("/auth/sessionended.do?action=action&redir=true", '_top', false);
            }
            else {
              tick();
            }
          }
          , error: function (error) {
          
            if (error && error.status == 302) {
              window.open("/auth/sessionended.do?action=action&redir=true", '_top', false);
            }
            else {
              tick();
            }
          }
        });

        lastTime = Date.now();
        isActivity = false;
      }
      else {
        lastTime = Date.now();

        jQuery.ajax({
          method: "GET"
          , url: '/nc4maps/rest/services/timeout'//this url is exempt from the timeout list so it does not affect the session and allows us to check if the session is still allive
          , success: function (response) {
           
            if (response && response.data != "") {
              window.open("/auth/sessionended.do?action=action&redir=true", '_top', false);
            }
            else {
              tick();
            }
          }
          , error: function (error) {
           
            if (error && error.status == 302) {
              window.open("/auth/sessionended.do?action=action&redir=true", '_top', false);
            }
            else {
              tick();
            }
          }
        });

      }
    }

    //register events(mousemove|mousedown|touchstart|scroll|keydown) to document to monitor the user抯 behavior.
    //When user trigger the above events, update the lastTime with current time.
    $ui(document).on('mousemove mousedown touchstart scroll keydown', update);
    tick();

    //Define timer interval to detect if current time- last time > 20 minutes. If so, redirect to logout page.
    function tick() {      
      var timeoutId = setTimeout(function () {
        timeoutId = undefined;

        var now = Date.now();
        if (lastTime && now - lastTime >= option.timeout) {
          checkActivity();
        }
        else tick();
      }, option.tick);
    }
  },
  /***** end logout *****/

  /***** docck popup *****/
  needDockPopup: function () {
    return !!window.matchMedia("(max-width:480px) and (orientation: portrait), (max-height:480px) and (orientation: landscape)").matches;
  },
  isDockPopupMode: (!!window.matchMedia("(max-width:480px) and (orientation: portrait), (max-height:480px) and (orientation: landscape)").matches),
  //used in callback, such as extent-change or zoom-end.
  dockPopup: function () {
    if (globalConfig.isDockPopupMode) {
      var wrapper = $ui('.esriPopupWrapper .sizer.content');
      var contentPane = $ui('.esriPopupWrapper .contentPane');
      if (wrapper.length && contentPane.length) {
        wrapper.css('width', '96%');
        contentPane.css('max-height', 'none');
      }
    }
  },
  /***** end docck popup *****/

  /*header*/
  callPanelNav: function () {
    panelNav('.helper-nav', true);
    panelNav('#rightNav');
    panelNav('#headerNav', false, true);
    panelNav('#sideNavMenu');
    panelNav('#sideNavMenu', false, true);
  },

  /*end header*/

  /***** common methods in controller *****/
  filter_toLowerCase: function (str) {
    if (str != null && typeof (str) != 'undefined') {
      return str.toLowerCase();
    }
    else {
      return '';
    }
  },

  filter_capitalize: function (s) {
    if (s && typeof (s) != 'undefined' && s.length > 0) {
      return s.toLowerCase().replace(/\b./g, function (a) { return a.toUpperCase(); });
    }
    else {
      return '';
    }
  },

  hasClass: function (obj, cls) {

    var obj_class = obj.className,
      obj_class_lst = obj_class.split(/\s+/);
    x = 0;
    for (x in obj_class_lst) {
      if (obj_class_lst[x] == cls) {
        return true;
      }
    }
    return false;
  },

  removeClass: function (obj, cls) {
    var obj_class = ' ' + obj.className + ' ';
    obj_class = obj_class.replace(/(\s+)/gi, ' '),
      removed = obj_class.replace(' ' + cls + ' ', ' ');
    removed = removed.replace(/(^\s+)|(\s+$)/g, '');
    obj.className = removed;
  },

  expandCollapseHistoryDetail: function (event) {
    var item = jQuery(event.target).parents('.intel-item');
    item.toggleClass('expanded');
  },

  collapseHistory: function (classname, cls) {
    jQuery(classname).removeClass(cls);
  },

  getClientDate: function (date) {
    var clientDate = new Date(date).toString();
    //remove second
    var newClientDate = clientDate.replace(/(\d{2}:\d{2}):(\d{2})/g, '$1');
    return newClientDate;
  },

  trimRight: function (s) {
    return s.replace(/\s+$/, "");
  },
  carousel: function (selector, option) {
    $ui(selector).carousel(option);
  },

  showModal: function (selector) {
    $ui(selector).modal('show');
  },

  showOrHiddenModal: function (selectorId, cls) {
    $ui(selectorId).modal(cls);
  },

  scrollToY: function (scrollTargetY, speed, easing) {
    // scrollTargetY: the target scrollY property of the window
    // speed: time in pixels per second
    // easing: easing equation to use

    var scrollY = window.pageYOffset,
      scrollTargetY = scrollTargetY || 0,
      speed = speed || 2000,
      easing = easing || 'easeOutSine',
      currentTime = 0;

    // min time .1, max time .8 seconds
    var time = Math.max(.1, Math.min(Math.abs(scrollY - scrollTargetY) / speed, .8));

    var PI_D2 = Math.PI / 2,
      easingEquations = {
        easeOutSine: function (pos) {
          return Math.sin(pos * (Math.PI / 2));
        },
        easeInOutSine: function (pos) {
          return (-0.5 * (Math.cos(Math.PI * pos) - 1));
        },
        easeInOutQuint: function (pos) {
          if ((pos /= 0.5) < 1) {
            return 0.5 * Math.pow(pos, 5);
          }
          return 0.5 * (Math.pow((pos - 2), 5) + 2);
        }
      };

    // add animation loop
    function tick() {
      currentTime += 1 / 60;

      var p = currentTime / time;
      var t = easingEquations[easing](p);

      if (p < 1) {
        requestAnimFrame(tick);

        window.scrollTo(0, scrollY + ((scrollTargetY - scrollY) * t));
      } else {
        console.log('scroll done');
        window.scrollTo(0, scrollTargetY);
      }
    }

    // call it once to get started
    tick();
  },

  scrollToTop: function () {
    document.body.scrollTop = 0;
  },

  scrollPage: function (selector) {
    var scrollHeight = 0;
    if (selector) {
      scrollHeight = document.querySelector(selector).offsetTop;
    }
    else {
      //article page.
      //either one will show up on the screen
      var scrollHeight = document.querySelector(".drawer-container1").offsetTop
        || document.querySelector(".drawer-container2").offsetTop;
    }
    globalConfig.scrollToY(scrollHeight, 1, 'easeInOutQuint');
  },

  isMapPage: function (url) {
    if (url.indexOf("/map") >= 0) {
      return true;
    }
    else {
      return false;
    }
  },

  isContentPage: function (url) {
    if (url.indexOf("/content/list") >= 0 || url.indexOf("/content/grid") >= 0) {
      return true;
    }
    else {
      return false;
    }
  },

  isArticleDetailPage: function (url) {
    if (url.indexOf("/content") >= 0 && url.indexOf("/content/list") == -1 && url.indexOf("/content/grid") == -1) {
      return true;
    }
    else {
      return false;
    }
  },

  isAssetPage: function (url) {
    if (url.indexOf("/assets/list") >= 0 || url.indexOf("/assets/grid") >= 0) {
      return true;
    }
    else {
      return false;
    }
  },

  isAssetDetailPage: function (url) {
    if (url.indexOf("/assets") >= 0 && url.indexOf("/assets/list") == -1 && url.indexOf("/assets/grid") == -1) {
      return true;
    }
    else {
      return false;
    }
  },

  setBodyOverflow: function (val) {
    document.body.style.overflow = val;
  },

  //formatTimeago: function (date) {
  //  return timeago().format(date)
  //},

  formatDate: function (date) {
    var _date = new Date(date);
    var month = _date.getUTCMonth();
    var day = _date.getUTCDate();
    var year = _date.getUTCFullYear();
    var hours = _date.getUTCHours();
    var minutes = _date.getUTCMinutes();

    return (month < 9 ? "0" + (1 + month) : (1 + month)) + "/"
      + (day < 10 ? "0" + day : day) + "/"
      + year + " "
      + (hours > 12 ? (hours - 12 < 10 ? "0" + (hours - 12) : hours - 12) : (hours < 10 ? "0" + hours : hours)) + ":"
      + (minutes < 10 ? "0" + minutes : minutes) + " "
      + (hours > 12 ? "pm" : "am")
      + " UTC";
  },

  convertResourcesObjectToArray: function (o) {
    var arr = [];
    for (var key in o) {
      var tempObj = {};
      tempObj.id = key;
      tempObj.count = o[key];
      arr.push(tempObj);
    }

    return arr;
  },

  /***** map *****/
  Base64: { _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", encode: function (e) { var t = ""; var n, r, i, s, o, u, a; var f = 0; e = globalConfig.Base64._utf8_encode(e); while (f < e.length) { n = e.charCodeAt(f++); r = e.charCodeAt(f++); i = e.charCodeAt(f++); s = n >> 2; o = (n & 3) << 4 | r >> 4; u = (r & 15) << 2 | i >> 6; a = i & 63; if (isNaN(r)) { u = a = 64 } else if (isNaN(i)) { a = 64 } t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a) } return t }, decode: function (e) { var t = ""; var n, r, i; var s, o, u, a; var f = 0; e = e.replace(/[^A-Za-z0-9+/=]/g, ""); while (f < e.length) { s = this._keyStr.indexOf(e.charAt(f++)); o = this._keyStr.indexOf(e.charAt(f++)); u = this._keyStr.indexOf(e.charAt(f++)); a = this._keyStr.indexOf(e.charAt(f++)); n = s << 2 | o >> 4; r = (o & 15) << 4 | u >> 2; i = (u & 3) << 6 | a; t = t + String.fromCharCode(n); if (u != 64) { t = t + String.fromCharCode(r) } if (a != 64) { t = t + String.fromCharCode(i) } } t = Base64._utf8_decode(t); return t }, _utf8_encode: function (e) { e = e.replace(/rn/g, "n"); var t = ""; for (var n = 0; n < e.length; n++) { var r = e.charCodeAt(n); if (r < 128) { t += String.fromCharCode(r) } else if (r > 127 && r < 2048) { t += String.fromCharCode(r >> 6 | 192); t += String.fromCharCode(r & 63 | 128) } else { t += String.fromCharCode(r >> 12 | 224); t += String.fromCharCode(r >> 6 & 63 | 128); t += String.fromCharCode(r & 63 | 128) } } return t }, _utf8_decode: function (e) { var t = ""; var n = 0; var r = c1 = c2 = 0; while (n < e.length) { r = e.charCodeAt(n); if (r < 128) { t += String.fromCharCode(r); n++ } else if (r > 191 && r < 224) { c2 = e.charCodeAt(n + 1); t += String.fromCharCode((r & 31) << 6 | c2 & 63); n += 2 } else { c2 = e.charCodeAt(n + 1); c3 = e.charCodeAt(n + 2); t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63); n += 3 } } return t } },
  startLoadingMap: function () {
    // reference: http://stackoverflow.com/questions/28909090/arcgis-api-for-javascript-map-is-always-400px-by-400px
    var maxTries = 25;
    var counter = 0;
    var mapIntl = setInterval(function () {
      // map container doesn't exist, skip map initialization
      var container = document.getElementById('mapContainerNode');    
      if (!container) {
        return;
      }

      // dojo is loaded completely
      if (typeof (dojo) == "undefined") {
        return;
      }

      if (document.getElementById('mapContainerNode').scrollHeight != document.body.scrollHeight) {
        if (++counter < maxTries) {
          console.log("DOM isn't ready, pause for another 100 milliseconds.")
          return;
        }
        else {
          console.log("Exceed max tries, stop trying, start to load the map.")
        }
      }
      else {
        console.log("DOM is ready, start to load the map.")
      }

      clearInterval(mapIntl);
      mapIntl = null;
      //Todo
      require(['nc4maps/app/main.js']);

    }, 100);
  },

  clearIntervalByTimerId: function (timerId) {
    if (timerId) {
      window.clearInterval(timerId);
      timerId = null;
    }
  },

  esriPoint: null,
  esriSpatialReference: null,
  esriExtent: null,
  isValidCoordinate: function (c) {
    if (c != null && typeof (c) != 'undefined' && c != '' && !isNaN(c) && c * 1 != 0) {
      return true;
    }
    else {
      return false;
    }
  },

  getExtent: function (cX1, cY1, cX2, cY2) {
    var extent = new globalConfig.esriExtent(
      cX1,
      cY1,
      cX2,
      cY2,
      globalConfig.esriSpatialReference
    );

    return extent;
  },

  getPoint: function (cX, cY) {
    var point = new globalConfig.esriPoint(cX, cY, globalConfig.esriSpatialReference);
    return point;
  },

  //scroll in popup for iphone/android devices
  isTouchDevice: function () {
    try {
      document.createEvent("TouchEvent");
      return true;
    } catch (e) {
      return false;
    }
  },

  touchScroll: function (selector) {
    if (globalConfig.isTouchDevice()) {
      var scrollStartPosY = 0;
      selector.addEventListener("touchstart", function (event) {
        scrollStartPosY = globalConfig.scrollTop + event.touches[0].pageY;
      }, false);

      selector.addEventListener("touchmove", function (event) {
        globalConfig.scrollTop = scrollStartPosY - event.touches[0].pageY;

      }, false);
    }
  },

  allMapLayers: 0,
  timerIdForCluster: null,
  refreshClusters: function () {

    globalConfig.timerIdForCluster = window.setInterval(function () {

      if (app != null && app.map != null && app.map.map != undefined && app.map.map.extent != undefined && app.clusterMgr.map.graphicsLayerIds.length > 1) {

        //remove popup window
        app.map.map.infoWindow.hide();
        app.map.map.infoWindow.clearFeatures();
        if (globalConfig.paperAirplane.launch) {

          globalConfig.hideSlideList();
          if (globalConfig.paperAirplane.extent != null) {
            app.map.map.setExtent(globalConfig.getExtent(globalConfig.paperAirplane.extent.cX1, globalConfig.paperAirplane.extent.cY1, globalConfig.paperAirplane.extent.cX2, globalConfig.paperAirplane.extent.cY2));
          }
          else if (globalConfig.paperAirplane.centerPoint != null) {
            app.map.map.centerAndZoom(globalConfig.getPoint(globalConfig.paperAirplane.centerPoint.cX, globalConfig.paperAirplane.centerPoint.cY), globalConfig.paperAirplane.zoomlevel);
          }

          globalConfig.initPaperAirplane();
        }

        var gIds = app.clusterMgr.map.graphicsLayerIds;
        //clear up the clusters on the cluster layer at first.
        app.clusterMgr.map.getLayer("nc4CL").clear();
        for (var i = 0; i < gIds.length; i++) {
          if (gIds[i].indexOf("_nimc_") >= 0 || gIds[i].indexOf("_fac_") >= 0 || gIds[i].indexOf("_isa_") >= 0) {
            var lyr = app.clusterMgr.map.getLayer(gIds[i]);
            if (lyr != null) {      //jt: Todo: does it delete the old layer?
              if (lyr._refreshGraphics) {
                lyr._refreshGraphics();
              }
            }
          }
        }

        globalConfig.clearIntervalByTimerId(globalConfig.timerIdForCluster);
      }
    }, 200);
  },

  //refresh locations on the map
  refreshLocationsOnMap: function () {
    if (app != null && app.map != null && app.map.map != undefined && app.map.map.extent != undefined && app.clusterMgr.map.graphicsLayerIds.length > 1) {

      var gIds = app.clusterMgr.map.graphicsLayerIds;
      for (var i = 0; i < gIds.length; i++) {
        if (gIds[i].indexOf("_fac_") >= 0) {
          var lyr = app.clusterMgr.map.getLayer(gIds[i]);
          if (lyr != null) {      //jt: Todo: does it delete the old layer?
            if (lyr._refreshGraphics) {
              lyr._refreshGraphics();
            }
          }
        }
      }
    }
  },

  //update pin icon
  updatePinIconAndAttribute: function (locationid) {
    var currentLayer = app.map.map.getLayer("_fac_location_cluster");
    var graphics = currentLayer.graphics;
    var graphic;
    for (var i = 0; i < graphics.length; i++) {
      graphic = graphics[i];
      if (graphic.id == locationid) {
        graphic.attributes.objtype = 'null';
        var tempSysmbol = graphic.symbol;
        if (tempSysmbol != null) {
          var noAnimatedIconUrl = tempSysmbol.url.replace('animated-', '').replace('.gif', '.png');

          tempSysmbol.url = noAnimatedIconUrl;
          tempSysmbol.width = 32;
          tempSysmbol.height = 50;
          tempSysmbol.xoffset = 0;
          tempSysmbol.yoffset = 25;
          graphic.setSymbol(tempSysmbol);
        }
        break;
      }
    }
  },

  checkIfExistOnMap: function (source, category) {

    var exist = false;
    if (app != null && app.map != null && app.map.map != undefined && app.map.map.extent != undefined && app.clusterMgr.map.graphicsLayerIds.length > 0) {

      var gIds = app.clusterMgr.map.graphicsLayerIds;
      for (var i = 0; i < gIds.length; i++) {
        var layerId = gIds[i];
        if ((layerId == '_nimc_adv_cluster' && source == 'NIMC' && category == 'advisory')
          || (layerId == '_nimc__cluster' && source == 'NIMC' && category != 'advisory')
          || (layerId == '_nimc_gfp_cluster' && source == 'GFP')
          || (layerId == '_nimc_ab_cluster' && source == 'AB')
          || (layerId == '_nimc_seb_cluster' && source == 'SEB')
          || (layerId == '_nimc_sr_cluster' && source == 'SR')
          || (layerId.toLowerCase() == '_isa_cybertech_india_cluster' && source == 'Cybertech India')
          || (layerId.toLowerCase() == '_fac_location_cluster' && source == 'location')) {
          exist = true;
        }
      }
    }
    else {
      exist = true;
    }

    return exist;
  },
  //get current layer ids which are showing up
  getAllShowingLayerIds: function () {
    var gIds = [];
    if (app != null && app.map != null && app.map.map != undefined && app.map.map.extent != undefined && app.clusterMgr.map.graphicsLayerIds.length > 1) {
      gIds = app.clusterMgr.map.graphicsLayerIds;
    }

    return gIds;
  },
  //Acknowledge/Cancel request rest api
  removeLegacyProximitiesById: function (locationid) {

    if (globalConfig.allLegacyProximities != undefined && globalConfig.allLegacyProximities.features != null && globalConfig.allLegacyProximities.features.length > 0) {
      for (var j = 0; j < globalConfig.allLegacyProximities.features.length; j++) {
        if (globalConfig.allLegacyProximities.features[j].id == locationid) {
          globalConfig.allLegacyProximities.features.splice(j, 1);
          break;
        }
      }
    }
  },

  _requestAcknowledgeRestApi: function (locationid) {

    globalConfig.updatePinIconAndAttribute(locationid);
    globalConfig.removeLegacyProximitiesById(locationid);

    var url = "/nc4maps/rest/proximitymanager/clearone?facid=" + locationid;
    globalConfig.requestRestApi(url);

    app.map.map.infoWindow.hide();
    app.map.map.infoWindow.clearFeatures();

  },

  _requestCancelRestApi: function (locationid) {

    globalConfig.updatePinIconAndAttribute(locationid);
    globalConfig.removeLegacyProximitiesById(locationid);

    var url = "/nc4maps/rest/proximitymanager/muteone?facid=" + locationid;
    globalConfig.requestRestApi(url);

    app.map.map.infoWindow.hide();
    app.map.map.infoWindow.clearFeatures();
  },
  //request nc4 rest api 
  requestRestApi: function (url) {
    jQuery.ajax({
      method: "POST",
      url: url,
      contentType: 'application/json;charset=utf-8',
      data: '{"rand": ' + Math.random() * 10000 + '}',
    });
  },
  /*end map*/

  /*aire plane*/
  paperAirplane: {
    launch: false,
    extent: null,
    centerPoint: null,
    zoomlevel: 16,

    inforWindow: null,
    nc4bboxCount: 0,
    initInforWindowData: function (datatype, id) {
      //open the popup window when navigate to map
      this.inforWindow = {};
      this.inforWindow.datatype = datatype;
      this.inforWindow.id = id;
    },
    showInforWindow: function () {
      if (this.inforWindow == null) {
        return;
      }
      var clusterLayer = app.clusterMgr.map.getLayer("nc4CL");
      if (clusterLayer != null) {

        var targetGraphic = null;
        for (var i = 0; i < clusterLayer.graphics.length; i++) {
          var currCluster = clusterLayer.graphics[i];
          for (var j = 0; j < currCluster.cluster.length; j++) {
            var cluster = currCluster.cluster[j];

            if ((cluster.attributes.datatype == 'incident' && this.inforWindow.datatype == 'incident' && cluster.attributes.incidentid == this.inforWindow.id)
              || (cluster.attributes.datatype == 'location' && this.inforWindow.datatype == 'location' && cluster.attributes.clusteredIds && cluster.attributes.clusteredIds.indexOf(this.inforWindow.id) >= 0)
              || (cluster.attributes.datatype == 'location' && this.inforWindow.datatype == 'location' && cluster.attributes.facilityid == this.inforWindow.id)) {
              targetGraphic = currCluster;
              app.map.map.infoWindow.setFeatures([targetGraphic]);
              app.map.map.infoWindow.show(targetGraphic.geometry);
              break;
            }
          }
        }

        if (targetGraphic == null) {
          var gIds = app.map.map.graphicsLayerIds;
          // forloop to gather all the data
          for (var iOverLayers = gIds.length - 1; iOverLayers >= 0; iOverLayers--) {
            var layer = app.map.map.getLayer(gIds[iOverLayers]);

            if (layer == null || (layer.id && layer.id == "nc4CL") || (layer.id.indexOf('_fac_') == -1) && layer.id.indexOf('_nimc_') == -1 && layer.id.indexOf('_isa_') == -1)
              continue;
            var currFeatures = layer.graphics;
            for (var k = 0; k < currFeatures.length; k++) {
              var curFeature = currFeatures[k];
              if ((curFeature.attributes.datatype == 'incident' && this.inforWindow.datatype == 'incident' && curFeature.attributes.incidentid == this.inforWindow.id)
                || (curFeature.attributes.datatype == 'location' && this.inforWindow.datatype == 'location' && curFeature.attributes.clusteredIds && curFeature.attributes.clusteredIds.indexOf(this.inforWindow.id) >= 0)
                || (curFeature.attributes.datatype == 'location' && this.inforWindow.datatype == 'location' && curFeature.attributes.facilityid == this.inforWindow.id)) {
                targetGraphic = curFeature;
                var contentinfo = layer.mappingLayerData.createSingleTemplate(gIds[iOverLayers], curFeature.attributes);
                targetGraphic.setInfoTemplate(contentinfo);
                app.map.map.infoWindow.setFeatures([targetGraphic]);
                app.map.map.infoWindow.show(targetGraphic.geometry);
                var popups = document.getElementsByClassName('esriPopupVisible');

                if (popups.length > 0) {
                  popups[0].style.top = (popups[0].offsetTop - 25) + 'px';
                }

                break;
              }
            }
          }
        }

        if (targetGraphic != null) {
          this.inforWindow = null;
        }
      }
    },

    //check if point is on the map 
    checkIsOnMap: function (layerIds, source, category) {
      var isOnMap = false;
      if (layerIds && layerIds.length > 0) {
        for (var i = 0; i < layerIds.length; i++) {
          var layerId = layerIds[i];
          if ((layerId == '_nimc_adv_cluster' && source == 'NIMC' && category == 'advisory')
            || (layerId == '_nimc__cluster' && source == 'NIMC' && category != 'advisory')
            || (layerId == '_nimc_gfp_cluster' && source == 'GFP')
            || (layerId == '_nimc_ab_cluster' && source == 'AB')
            || (layerId == '_nimc_seb_cluster' && source == 'SEB')
            || (layerId == '_nimc_sr_cluster' && source == 'SR')
            || (layerId.toLowerCase() == '_isa_cybertech_india_cluster' && source == 'Cybertech India')
            || (layerId == '_fac_location_cluster' && source == 'location')) {
            isOnMap = true;
            break;
          }
        }
      }

      return isOnMap;
    }
  },

  createHTMLNotOnMapMessage: function (divId, incidentId, risk, source, category) {

    var divMessage = document.getElementById(divId);

    if (divMessage) {
      var navigationMessage = '<div class="icons" >';
      navigationMessage += '<a class="icon color-$risk"><i class="nc4-icon-$category"></i></a>';
      navigationMessage += '</div >';
      navigationMessage += '<div class="content-wrap">';
      navigationMessage += '<div class="title"><div class="first-line">$message</div><div>Please toggle it back on if you wish to see incidents on the map.</div></div>';
      navigationMessage += '</div>';

      if (globalConfig.filterObject != null && !globalConfig.getFilteredIncidentsById(incidentId)) {
        navigationMessage = navigationMessage.replace('$risk', risk).replace('$category', category).replace('$message', 'Incident display has been toggled off in the Filters.');
      }
      else if (!globalConfig.checkIfExistOnMap(source, category)) {
        navigationMessage = navigationMessage.replace('$risk', risk).replace('$category', category).replace('$message', 'Incident display has been toggled off in the Data Layers.');
      }
      else {
        navigationMessage = '';
      }

      divMessage.innerHTML = navigationMessage;
    }


  },

  initPaperAirplane: function () {
    globalConfig.paperAirplane.launch = false;
    globalConfig.paperAirplane.extent = null;
    globalConfig.paperAirplane.centerPoint = null;
  },

  enablePaperAirplaneBySource: function (source) {
    var enabled = true;
    if (source != null && (source == 'CR') || (source == 'CRR')) {
      enabled = false;
    }

    return enabled;
  },

  hideSlideList: function () {
    var slideListWrap = document.getElementById('sideListWrap');
    if (typeof (slideListWrap) != 'undefined') {

      var triggerIntl = setInterval(function () {
        var $trigger = jQuery('#sideList > button.sideList-trigger');
        if ($trigger.length) {
          jQuery('#sideListWrap').removeClass('active');
          jQuery('#sideList > button.sideList-trigger').removeClass('active');
          jQuery('#sideList > button.sideList-trigger i.fa').removeClass('fa-chevron-left').addClass('fa-chevron-right');
          clearInterval(triggerIntl);
          triggerIntl = null;
        }
      }, 200);
    }
  },

  //navigate to map and popup
  isIncidentsLayer: function (id) {
    if (id.indexOf('_nimc_') >= 0 || id.indexOf('_isa_') >= 0) {
      return true;
    }
    else {
      return false;
    }

  },

  enableDisableNavigation: function (checkboxid, enable) {
    if (globalConfig.allIncidentItems.length > 0) {
      for (var i = 0; i < globalConfig.allIncidentItems.length; i++) {
        var inc = globalConfig.allIncidentItems[i];
        if ((checkboxid == '_nimc_adv' && inc.source == 'NIMC' && inc.category == 'advisory')
          || (checkboxid == '_nimc_' && inc.source == 'NIMC' && inc.category != 'advisory')
          || (checkboxid == '_nimc_gfp' && inc.source == 'GFP')
          || (checkboxid == '_nimc_ab' && inc.source == 'AB')
          || (checkboxid == '_nimc_seb' && inc.source == 'SEB')
          || (checkboxid == '_nimc_sr' && inc.source == 'SR')
          || (checkboxid.toLowerCase() == '_isa_cybertech_india' && inc.source == 'Cybertech India')) {
          inc.enableNavigation = enable ? 'enable' : 'disable';
        }

      }
    }

    if (globalConfig.allFilteredIncidentItems.length > 0) {
      for (var i = 0; i < globalConfig.allFilteredIncidentItems.length; i++) {
        var inc = globalConfig.allFilteredIncidentItems[i];
        if ((checkboxid == '_nimc_adv' && inc.source == 'NIMC' && inc.category == 'advisory')
          || (checkboxid == '_nimc_' && inc.source == 'NIMC' && inc.category != 'advisory')
          || (checkboxid == '_nimc_gfp' && inc.source == 'GFP')
          || (checkboxid == '_nimc_ab' && inc.source == 'AB')
          || (checkboxid == '_nimc_seb' && inc.source == 'SEB')
          || (checkboxid == '_nimc_sr' && inc.source == 'SR')
          || (checkboxid.toLowerCase() == '_isa_cybertech_india' && inc.source == 'Cybertech India')) {
          inc.enableNavigation = enable ? 'enable' : 'disable';
        }
      }
    }
  },

  launchIncident: function (articleObject) {
    if (app.map != null && app.map.map != undefined && app.map.map.extent != undefined) {
      if (articleObject.enableNavigation == 'disable') {
        var divNavigation = document.getElementById('navigation-' + articleObject.id);
        //hide all other navigation message popup
        var divOpenMessages = document.getElementsByClassName("navigation-icon");
        if (divOpenMessages.length > 0) {
          for (var i = 0; i < divOpenMessages.length; i++) {
            if (divOpenMessages[i].id != ('navigation-' + articleObject.id) && divOpenMessages[i].style.display == 'block') {
              divOpenMessages[i].style.display = 'none';
            }
          }
        }
        //create message html
        globalConfig.createHTMLNotOnMapMessage('navigation-' + articleObject.id, articleObject.id, articleObject.risk, articleObject.source, articleObject.category.toLowerCase());
        if (divNavigation.style.display != 'block') {
          divNavigation.style.display = 'block';

          var messageOffSetTop = divNavigation.offsetTop;
          var divItem = divNavigation.parentNode.getAttribute('index');
          if (divItem * 1 == 0 && Math.abs(messageOffSetTop) > 0) {

            divNavigation.style.bottom = "auto";
          }
        }
      }

      var layerIds = globalConfig.getAllShowingLayerIds();
      if (!globalConfig.paperAirplane.checkIsOnMap(layerIds, articleObject.source, articleObject.category)) {
        return;
      }
      var point = new globalConfig.esriPoint(articleObject.longitude, articleObject.latitude, globalConfig.esriSpatialReference);
      globalConfig.hideSlideList();

      var centerX = 0;
      var centerY = 0;
      var distanceMaxX = 0;
      var distanceMaxY = 0;
      // the original purpose is to use incident icon height in pixel divide by map height in pixel (which is 50 / 320),
      // however, it appears the map might rendr it in a smaller or larger extend, so use this hardcoded value for now.
      var offsetRatio = 1 / 4;

      if (globalConfig.isValidCoordinate(articleObject.longitude) && globalConfig.isValidCoordinate(articleObject.latitude)) {

        centerX = articleObject.longitude * 1;
        centerY = articleObject.latitude * 1;
      }

      var arrAssets = [];
      var arrImpactedAssetsList = articleObject.ImpactedAssetsList;
      if (arrImpactedAssetsList.length > 0) {

        for (var j = 0; j < arrImpactedAssetsList.length; j++) {
          var tempAsset = globalConfig.getAssetById(arrImpactedAssetsList[j].id);
          if (globalConfig.paperAirplane.checkIsOnMap(layerIds, 'location', '') && typeof (tempAsset) != 'undefined')
            arrAssets.push(tempAsset);
        }

        if (arrAssets.length > 0) {
          var inciX, inciY;

          for (var i = 0; i < arrAssets.length; i++) {
            if (globalConfig.isValidCoordinate(arrAssets[i].longitude) && globalConfig.isValidCoordinate(arrAssets[i].latitude)) {
              inciX = arrAssets[i].longitude * 1;
              inciY = arrAssets[i].latitude * 1

              var temp = Math.abs(inciX - centerX)
              if (temp > distanceMaxX) {
                distanceMaxX = temp;
              }

              temp = Math.abs(inciY - centerY)
              if (temp > distanceMaxY) {
                distanceMaxY = temp;
              }
            }
          }
        }
      }

      var refinedDistanceMaxX = Math.max(distanceMaxX, distanceMaxY) * 2 * offsetRatio + distanceMaxX;
      var refinedDistanceMaxY = Math.max(distanceMaxX, distanceMaxY) * 2 * offsetRatio + distanceMaxY;
      if (distanceMaxX > 0 || distanceMaxY > 0) {
        var extent = new globalConfig.esriExtent(
          centerX - refinedDistanceMaxX,
          centerY - refinedDistanceMaxY,
          centerX + refinedDistanceMaxX,
          centerY + refinedDistanceMaxY,
          globalConfig.esriSpatialReference
        );
        app.map.map.setExtent(extent);
      }
      else {
        app.map.map.centerAndZoom(point, globalConfig.paperAirplane.zoomlevel)
          .then(function () {
            //if bing base map, check for 'no tile'
            let currBaseMap = app.map.map.getLayer(app.map.map.layerIds[0]);
            if (currBaseMap.bingMapsKey) {

              //let isViz = currBaseMap.visible - built in visible & visibleAtMapScale doesn't work

              let tiles = currBaseMap._tiles;
              //corner tiles on the map in the current view
              let corner_tiles = [tiles["esri.Map_0_layer0_tile_17_0_0"], tiles["esri.Map_0_layer0_tile_17_0_6"], tiles["esri.Map_0_layer0_tile_17_3_0"], tiles["esri.Map_0_layer0_tile_17_3_6"]]
              for (let tile in corner_tiles) {
                let tile_obj = corner_tiles[tile];
                if (tile_obj) {
                  let tile_url = "/nc4maps/proxy.jsp?" + tile_obj.src; //must go through proxy to get access headers.
                  jQuery.ajax({
                    method: "GET"
                    , url: tile_url
                    , success: function (data, textStatus, jqXHR) {
                      var allHeaders = jqXHR.getAllResponseHeaders();
                      var noTileVal = jqXHR.getResponseHeader("X-VE-Tile-Info");
                      if (noTileVal === "no-tile") {
                        //if it's in this for loop and not the default zoom level, it has already zoomed out
                        if (app.map.map.getZoom() == globalConfig.paperAirplane.zoomlevel) {
                          app.map.map.setZoom(app.map.map.getZoom() - 5);
                          return;
                        }
                      }
                    }
                  });
                }
                //return;
              }
            }

          });
      }

      //open the popup window when navigate to map
      globalConfig.paperAirplane.initInforWindowData('incident', articleObject.id);

    }
  },
  launchIncidentLocationFromPopup: function (datatype, id, latitude, longitude) {
    //check if the point is on the map before navigating
    var layerIds = globalConfig.getAllShowingLayerIds();
    if (datatype == 'incident') {
      var tempInc = globalConfig.getIncidentsById(id);
      if (!globalConfig.paperAirplane.checkIsOnMap(layerIds, tempInc.source, tempInc.category)) {
        return;
      }
    }
    else {
      if (!globalConfig.paperAirplane.checkIsOnMap(layerIds, 'location', '')) {
        return;
      }
    }

    var point = new globalConfig.esriPoint(longitude, latitude, globalConfig.esriSpatialReference);
    globalConfig.hideSlideList();

    var centerX = 0;
    var centerY = 0;
    var distanceMaxX = 0;
    var distanceMaxY = 0;
    // the original purpose is to use incident icon height in pixel divide by map height in pixel (which is 50 / 320),
    // however, it appears the map might rendr it in a smaller or larger extend, so use this hardcoded value for now.
    var offsetRatio = 1 / 4;

    if (globalConfig.isValidCoordinate(longitude) && globalConfig.isValidCoordinate(latitude)) {

      centerX = longitude * 1;
      centerY = latitude * 1;
    }

    var otherPoints = [];
    //make sure all of locations are on the map
    if (datatype == 'incident' && globalConfig.paperAirplane.checkIsOnMap(layerIds, 'location', '')) {
      var impactedAssets = globalConfig.getImpactedAssets(id);
      for (var i = 0; i < impactedAssets.length; i++) {
        otherPoints.push(globalConfig.getAssetById(impactedAssets[i].id));
      }
    }
    else {
      var assetProximity = {};
      for (var i = 0; i < globalConfig.allProximities.assets.length; i++) {
        if (globalConfig.allProximities.assets[i].id == id) {
          assetProximity = globalConfig.allProximities.assets[i];
          break;
        }
      }

      if (typeof (assetProximity.n) != 'undefined') {
        for (var j = 0; j < assetProximity.n.length; j++) {
          var tempIncident = globalConfig.getIncidentsById(assetProximity.n[j].id);
          if (globalConfig.paperAirplane.checkIsOnMap(layerIds, tempIncident.source, tempIncident.category)) {
            otherPoints.push(tempIncident);
          }
        }
      }
    }

    if (otherPoints.length > 0) {

      var inciX, inciY;

      for (var i = 0; i < otherPoints.length; i++) {
        if (globalConfig.isValidCoordinate(otherPoints[i].longitude * 1) && globalConfig.isValidCoordinate(otherPoints[i].latitude * 1)) {
          inciX = otherPoints[i].longitude * 1;
          inciY = otherPoints[i].latitude * 1

          var temp = Math.abs(inciX - centerX)
          if (temp > distanceMaxX) {
            distanceMaxX = temp;
          }

          temp = Math.abs(inciY - centerY)
          if (temp > distanceMaxY) {
            distanceMaxY = temp;
          }
        }
      }

    }

    var refinedDistanceMaxX = Math.max(distanceMaxX, distanceMaxY) * 2 * offsetRatio + distanceMaxX;
    var refinedDistanceMaxY = Math.max(distanceMaxX, distanceMaxY) * 2 * offsetRatio + distanceMaxY;
    if (distanceMaxX > 0 || distanceMaxY > 0) {
      var extent = new globalConfig.esriExtent(
        centerX - refinedDistanceMaxX,
        centerY - refinedDistanceMaxY,
        centerX + refinedDistanceMaxX,
        centerY + refinedDistanceMaxY,
        globalConfig.esriSpatialReference
      );
      app.map.map.setExtent(extent);
    }
    else {
      app.map.map.centerAndZoom(point, globalConfig.paperAirplane.zoomlevel);
    }

    //open the popup window when navigate to map
    globalConfig.paperAirplane.initInforWindowData(datatype, id);
  },
  /*end aire plane*/


  /*controllers*/
  /*severity*/
  SEVERITY_VALUE_EXTREME: 'extreme',
  SEVERITY_VALUE_SEVERE: 'severe',
  SEVERITY_VALUE_MODERATE: 'moderate',
  SEVERITY_VALUE_MINOR: 'minor',
  SEVERITY_VALUE_NORMAL: 'normal',

  //severity color
  SEVERITY_COLOR_EXTREME: '#DA0000',
  SEVERITY_COLOR_SEVERE: '#ED7B00',
  SEVERITY_COLOR_MODERATE: '#E9BA00',
  SEVERITY_COLOR_MINOR: '#242AFB',
  SEVERITY_COLOR_NORMAL: 'green',
  SEVERITY_COLOR_RING_LOCATION: '#4a3e3e',

  severity: [
    { key: 4, value: 'extreme', color: '#DA0000' },
    { key: 3, value: 'severe', color: '#ED7B00' },
    { key: 2, value: 'moderate', color: '#E9BA00' },
    { key: 1, value: 'minor', color: '#242AFB' },
    { key: 0, value: '', color: 'green' }
  ],

  severityFactory: {
    getSeverityByKey: function (key) {
      return globalConfig.severity.find(function (s) {
        return s.key === key;
      });
    },
    getSeverityByValue: function (value) {
      return globalConfig.severity.find(function (s) {
        return s.value === value.toLowerCase();
      });
    },

    getKeyByValue: function (value) {
      var severity = this.getSeverityByValue(value);
      if (severity) return severity.key;
    },

    getColorByValue: function (value) {
      var severity = this.getSeverityByValue(value);
      if (severity) return severity.color;
    },

    getValueByKey: function (key) {
      var severity = this.getSeverityByKey(key);
      if (severity) return severity.value;
    }
  },
  /*end severity*/

  convertSeverityToNum: function (severity) {
    var num = 0;
    switch (severity) {
      case 'extreme':
        num = 4;
        break;
      case 'severe':
        num = 3;
        break;
      case 'moderate':
        num = 2;
        break;
      case 'minor':
        num = 1;
        break;
      default:
        num = 0;
        break;
    }

    return num;
  },
  getIncidentIconsBySeverityCategory: function (severity, category) {
    var color = "";
    switch (severity) {
      case 'minor':
        color = 'blue';
        break;
      case 'moderate':
        color = 'yellow';
        break;
      case 'severe':
        color = 'orange';
        break;
      case 'extreme':
        color = 'red';
        break;
      case 'unknown':
        color = 'gray';
        break;
      default:
        color = 'green';
        break;
    }
    var iconName = '';
    var ca = '';

    if (category) {
      ca = category.toLowerCase();
    }

    if (ca == 'logo' || ca == '') {
      iconName = 'NC4-' + color + '.png';
    }
    else {
      iconName = ca + '-' + color + '.png';
    }

    return CDN.root + '/nc4mapMainStyle/nc4-icons/map-markers/' + iconName;
  },

  getAssetIconPathBySeverity: function (s, objtype) {

    if (s != null && typeof (s) != 'undefined') {
      s = s.toLowerCase();
    }
    else {
      s = '';
    }

    var color = '';
    switch (s) {
      case 'minor':
        color = 'blue';
        break;
      case 'moderate':
        color = 'yellow';
        break;
      case 'severe':
        color = 'orange';
        break;
      case 'extreme':
        color = 'red';
        break;
      case 'unknown':
        color = 'gray';
        break;
      default:
        color = 'green';
        break;
    }

    var assetIconPath = '';
    if (objtype == 'impacted') {
      assetIconPath = CDN.root + '/nc4mapMainStyle/nc4-icons/map-markers/animated-building-' + color + '.gif';
    }
    else {
      assetIconPath = CDN.root + '/nc4mapMainStyle/nc4-icons/map-markers/building-' + color + '.png';
    }
    return assetIconPath;
  },

  getPinWidthHeight: function (iconPath) {
    var wh = {};
    wh.width = 32;
    wh.height = 50;
    if (iconPath.indexOf('animated-building') >= 0) {
      wh.width = 46;
      wh.height = 58;
    }

    return wh;
  },

  getIncidentCategory: function (item) {

    var category = '';
    if ((item.source == 'NIMC') && (',' + globalConfig.allAvailableCategories + ',').indexOf(item.info_eventCode_NC4_NIMC.toLowerCase()) >= 0) {
      category = item.info_eventCode_NC4_NIMC.toLowerCase();
    }
    else if ((item.source == 'Cybertech India') && (',' + globalConfig.allAvailableCategories + ',').indexOf(item.info_eventCode_NC4_CyberTechIndia.toLowerCase()) >= 0) {
      category = item.info_eventCode_NC4_CyberTechIndia.toLowerCase();
    }
    else {
      category = 'logo';
    }

    return category;
  },


  getIncidentTitle: function (item) {
    var title = '';
    if (item.source == 'NIMC') {

      title = item.info_eventCode_NC4_NIMC + ' > ' + item.info_event;
    }
    else if (item.source == 'Cybertech India') {
      title = item.info_eventCode_NC4_CyberTechIndia + ' > ' + item.info_event;
    }
    else if ((item.source == 'CR') || (item.source == 'CRR')) {

      title = item.info_event;
    }
    else {
      if (item.parameter_TSCategory != null && typeof (item.parameter_TSCategory) != 'undefined' && item.parameter_TSCategory.length > 0) {
        title = item.parameter_TSCategory.split('>')[0].replace('/', ' /');
      }
    }

    return title;
  },

  getIncidentAddress: function (item) {
    var address = '';
    if ((item.source == 'CR') || (item.source == 'CRR')) {
      address = item.country;
    }
    else {
      if (item.country == 'United States') {
        address = (item.city ? item.city + ", " : "") + (item.state ? item.state + ", " : "") + item.country;
      }
      else {
        address = (item.city ? item.city + ", " : "") + item.country;
      }
    }

    return address;
  },
  getImpactedAssets: function (incidentid) {
    var impactedAssets = [];
    if (globalConfig.allProximities.incidents != undefined && globalConfig.allProximities.incidents.length > 0) {
      for (var i = 0; i < globalConfig.allProximities.incidents.length; i++) {

        if (incidentid == globalConfig.allProximities.incidents[i].id) {
          impactedAssets = globalConfig.allProximities.incidents[i].n;
          break;
        }
      }
    }
    return impactedAssets;
  },
  setupImpactedAssetsForIncidentItem: function (item) {
    var impactedAssets = globalConfig.getImpactedAssets(item.id);
    item.ImpactedAssetsList = impactedAssets;
    item.ImpactedAssets = impactedAssets.length;
    item.ImpactedAssetsId = "";
    item.HasImpactedAssets = impactedAssets.length > 0 ? 1 : 0;//this properties is for sort. 1 means has impactedAssets;0 means has no impactedAssets.

    if (impactedAssets == 1) {
      item.ImpactedAssetsId = impactedAssets[0].id;
    }
  },
  //get resources count by incidentId
  getResourcesCountById: function (id, source) {
    var count = 0;
    if (globalConfig.allResources.length > 0 && !(source == 'CR') && !(source == 'CRR')) {
      for (var i = 0; i < globalConfig.allResources.length; i++) {
        if (globalConfig.allResources[i].id == id) {
          count = globalConfig.allResources[i].count;
        }
      }
    }

    return count;
  },
  convertIncident: function (item) {

    var newItem = new Object();
    newItem.identifier = item.identifier;
    newItem.incidents = item.incidents;
    newItem.risk = item.info_severity.toLowerCase();

    newItem.id = item.incidents;
    newItem.city = item.city;
    newItem.category = globalConfig.getIncidentCategory(item);
    newItem.name = globalConfig.getIncidentTitle(item);
    newItem.address = globalConfig.getIncidentAddress(item);

    var reg = /,$/gi;
    newItem.address = globalConfig.trimRight(newItem.address.replace(reg, ""));
    newItem.address = newItem.address.replace(reg, "");

    newItem.country = item.country;
    //newItem.date = globalConfig.formatTimeago(new Date(item.sent));
    newItem.date = new Date(item.sent);
    //Todd..
    //newItem.realDate = globalConfig.filter_date(item.sent, "yyyy-MM-dd HH:mm:ss Z"); toISOString
    //newItem.realDate = new Date(item.sent).toISOString();
    newItem.clientDate = globalConfig.getClientDate(item.sent);
    newItem.location = item.source;
    newItem.source = item.source;
    newItem.enableAirPlane = globalConfig.enablePaperAirplaneBySource(item.source);
    newItem.text = item.info_headline;
    newItem.latitude = item.latitude;
    newItem.longitude = item.longitude;
    newItem.related = {
      assets: [
        {
          "type": "traveler"
        },
        {
          "type": "location"
        }
      ]
    };

    newItem.description = item.info_description;
    newItem.revision = item.revision;

    newItem.timestamp = (new Date(item.SentDateTime)).getTime();//get number of date
    newItem.IsOpened = item.IsOpened;
    //enable or disable navigation icon. Make enable as default
    newItem.enableNavigation = 'enable';

    newItem.severity = globalConfig.convertSeverityToNum(item.info_severity.toLowerCase());
    newItem.region = item.region;
    newItem.info_event = item.info_event;
    //if source is CR/CRR, make resourceCount is 0 because the link of attachment is invalid.
    newItem.resourceCount = globalConfig.getResourcesCountById(item.incidents, item.source);
    //install impacted assets for incident
    globalConfig.setupImpactedAssetsForIncidentItem(newItem);

    return newItem;
  },

  //assets
  reOderIndicentsForAssets: function (assets) {

    if (assets.assetsProximityWarningsIncidents.length <= 1) {
      return assets;
    }
    var incidents = assets.assetsProximityWarningsIncidents;
    assets.assetsProximityWarningsIncidents = [];

    var s = firstBy(function (v1, v2) { return v2.severityNumber - v1.severityNumber; })
      .thenBy(function (v1, v2) { return v1.distanceNumber - v2.distanceNumber; });
    incidents.sort(s);

    assets.assetsProximityWarningsIncidents.push(incidents[0]);
    //other incidents will be sort by distinct.
    var otherIncidents = incidents.slice(1);
    s = firstBy(function (v1, v2) { return v1.distanceNumber - v2.distanceNumber; });
    otherIncidents.sort(s);
    assets.assetsProximityWarningsIncidents = assets.assetsProximityWarningsIncidents.concat(otherIncidents);

    //take only four items to render
    assets.assetsProximityWarningsIncidentsToRender = [];
    assets.assetsProximityWarningsIncidents.forEach(function (a) {
      if (a.icon && assets.assetsProximityWarningsIncidentsToRender.length < 4) {
        assets.assetsProximityWarningsIncidentsToRender.push(a);
      }
    });
    return assets;
  },
  //remove invalid incidents from asset proximities and recalculate the severity of asset
  filterIncidentsFromAssetProximities: function (allIncidentItems, autoRef_updatedIncidents, newIncidentUpdates) {

    if (globalConfig.allProximities.assets != null && globalConfig.allProximities.assets.length > 0) {
      var asset;
      var calculateSeverity;
      var existed;
      for (var i = 0; i < globalConfig.allProximities.assets.length; i++) {
        asset = globalConfig.allProximities.assets[i];
        if (asset.n.length > 0) {
          calculateSeverity = false;
          for (var j = asset.n.length - 1; j >= 0; j--) {
            existed = false;
            //if existed in global incidents list
            if (allIncidentItems && allIncidentItems.length > 0) {
              for (var k = 0; k < allIncidentItems.length; k++) {
                if (asset.n[j].id == allIncidentItems[k].incidents) {
                  existed = true;
                  break;
                }
              }
            }

            //if existed in global updated incidents list
            if (!existed && autoRef_updatedIncidents && autoRef_updatedIncidents.length > 0) {
              for (var k = 0; k < autoRef_updatedIncidents.length; k++) {
                if (asset.n[j].id == autoRef_updatedIncidents[k].incidents) {
                  existed = true;
                  break;
                }
              }
            }

            //if existed in new updated incidents list
            if (!existed && newIncidentUpdates && newIncidentUpdates.length > 0) {
              for (var k = 0; k < newIncidentUpdates.length; k++) {
                if (asset.n[j].id == newIncidentUpdates[k].incidents) {
                  existed = true;
                  break;
                }
              }
            }

            if (!existed) {
              calculateSeverity = true;
              asset.n.splice(j, 1);
            }
          }
          //recalculate asset severity
          if (calculateSeverity) {
            var severity = 'normal';
            var severityNumber = 0;
            if (asset.n != null && asset.n.length > 0) {
              for (var m = 0; m < asset.n.length; m++) {
                if (globalConfig.convertSeverityToNum(asset.n[m].s) > severityNumber) {
                  severity = asset.n[m].s;
                  severityNumber = globalConfig.convertSeverityToNum(severity);
                }
              }
            }

            asset.s = severity;
          }
        }
      }
    }
  },
  //get incidents around for each asset
  getAssetsProximityWarningsIncidents: function (asset) {

    asset.assetsProximityWarningsIncidents = [];
    var assetProximity = {};
    if (globalConfig.allProximities.assets != undefined && globalConfig.allProximities.assets.length > 0) {
      for (var i = 0; i < globalConfig.allProximities.assets.length; i++) {
        if (globalConfig.allProximities.assets[i].id == asset.id) {
          assetProximity = globalConfig.allProximities.assets[i];
          break;
        }
      }
    }

    if (typeof (assetProximity.n) != 'undefined') {
      for (var j = 0; j < assetProximity.n.length; j++) {
        var inc = assetProximity.n[j];
        var incidentWarning = {
          //incident: inc,
          id: inc.id,
          title: inc.it,
          distance: inc.d.toFixed(2) + " " + globalConfig.settingsData.DistanceUnit,
          unit: globalConfig.settingsData.DistanceUnit,
          severity: inc.s,
          severityNumber: globalConfig.convertSeverityToNum(inc.s),
          icon: globalConfig.getIncidentIconsBySeverityCategory(inc.s, inc.ic),
          distanceNumber: inc.d
        };
        asset.assetsProximityWarningsIncidents.push(incidentWarning);
      }

      //sort
      if (assetProximity.n.length >= 1) {
        asset = globalConfig.reOderIndicentsForAssets(asset);
      }
    }

    //take only four items to render
    asset.assetsProximityWarningsIncidentsToRender = [];
    asset.assetsProximityWarningsIncidents.forEach(function (a) {
      if (a.icon && asset.assetsProximityWarningsIncidentsToRender.length < 4) {
        asset.assetsProximityWarningsIncidentsToRender.push(a);
      }
    });
    return asset;
  },

  //update impactedAssets for incidents
  updateImpactedAssetsForIncidents: function () {
    if (globalConfig.allIncidentItems.length > 0) {
      for (var i = 0; i < globalConfig.allIncidentItems.length; i++) {
        var item = globalConfig.allIncidentItems[i];
        globalConfig.setupImpactedAssetsForIncidentItem(item);
      }
    }

    if (globalConfig.allFilteredIncidentItems.length > 0) {
      for (var i = 0; i < globalConfig.allFilteredIncidentItems.length; i++) {
        var item = globalConfig.allFilteredIncidentItems[i];
        globalConfig.setupImpactedAssetsForIncidentItem(item);
      }
    }
  },
  //update resources count for incidents
  updateResourcesForIncidents: function () {
    if (globalConfig.allIncidentItems.length > 0) {
      for (var i = 0; i < globalConfig.allIncidentItems.length; i++) {
        var item = globalConfig.allIncidentItems[i];
        item.resourceCount = globalConfig.getResourcesCountById(item.id, item.source);
      }
    }

    if (globalConfig.allFilteredIncidentItems.length > 0) {
      for (var i = 0; i < globalConfig.allFilteredIncidentItems.length; i++) {
        var item = globalConfig.allFilteredIncidentItems[i];
        item.resourceCount = globalConfig.getResourcesCountById(item.id, item.source);
      }
    }
  },

  //update proximities for assets
  updateProximitiesForAssets: function () {

    if (globalConfig.allAssetItems.length > 0) {
      for (var i = 0; i < globalConfig.allAssetItems.length; i++) {
        var item = globalConfig.allAssetItems[i];
        globalConfig.setupProximitiesForAssetItem(item);
      }
    }

    if (globalConfig.allFilteredAssetItems.length > 0) {
      for (var i = 0; i < globalConfig.allFilteredAssetItems.length; i++) {
        var item = globalConfig.allFilteredAssetItems[i];
        globalConfig.setupProximitiesForAssetItem(item);
      }
    }
  },

  getAssetProximityStatus: function (id) {
    var status = 'normal';
    if (globalConfig.allProximities.assets != undefined && globalConfig.allProximities.assets.length > 0) {
      for (var i = 0; i < globalConfig.allProximities.assets.length; i++) {
        if (id == globalConfig.allProximities.assets[i].id) {
          status = globalConfig.allProximities.assets[i].s;
          break;
        }
      }
    }

    return status;
  },

  setupProximitiesForAssetItem: function (newAssetsItem) {

    var proximityStatus = globalConfig.getAssetProximityStatus(newAssetsItem.id);
    newAssetsItem.risk = proximityStatus;
    newAssetsItem.ProximityStatus = proximityStatus;
    if (newAssetsItem.ProximityStatus == "extreme") {
      newAssetsItem.sortProximityStatus = "4";
    } else if (newAssetsItem.ProximityStatus == "severe") {
      newAssetsItem.sortProximityStatus = "3";
    } else if (newAssetsItem.ProximityStatus == "moderate") {
      newAssetsItem.sortProximityStatus = "2";
    } else if (newAssetsItem.ProximityStatus == "minor") {
      newAssetsItem.sortProximityStatus = "1";
    }
    else {
      newAssetsItem.sortProximityStatus = "0";
    }
    if (!proximityStatus || proximityStatus == "") {
      newAssetsItem.ProximityStatus = "normal";
    }

    newAssetsItem.icon = "risk-" + proximityStatus;

    //newAssetsItem.ProximityWarnings = item.ProximityWarnings;
    newAssetsItem = globalConfig.getAssetsProximityWarningsIncidents(newAssetsItem);
  },

  convertAssets: function (item) {

    var newAssetsItem = new Object();
    newAssetsItem.id = item.facilityid;

    newAssetsItem.locationName = item.facilityname;
    newAssetsItem.streetAddress = item.street;
    newAssetsItem.city = item.city;
    newAssetsItem.state = item.stateprovince;
    newAssetsItem.zip = item.zip;
    newAssetsItem.country = item.country;
    newAssetsItem.region = item.region;
    newAssetsItem.latitude = item.latitude;
    newAssetsItem.longitude = item.longitude;
    newAssetsItem.showonmap = ~~item.showonmap;
    newAssetsItem.type = item.facilitytype;
    newAssetsItem.description = item.description;
    if (newAssetsItem.description) {
      newAssetsItem.description = newAssetsItem.description.replace(/&#10;/g, '<br/>').replace(/\r\n/g, "<br/>").replace(/\n/g, "<br/>");
    }
    //install proximities for asset
    globalConfig.setupProximitiesForAssetItem(newAssetsItem);

    return newAssetsItem;
  },
  //get legacy proximities by id
  getLegacyProximitiesById: function (facilityid) {
    var objtype = 'null';
    if (globalConfig.allLegacyProximities != undefined && globalConfig.allLegacyProximities.features != null && globalConfig.allLegacyProximities.features.length > 0) {
      for (var j = 0; j < globalConfig.allLegacyProximities.features.length; j++) {
        if (globalConfig.allLegacyProximities.features[j].id == facilityid) {
          objtype = 'impacted';
          break;
        }
      }
    }
    return objtype;

  },
  //get incidents by id
  getIncidentsById: function (id) {
    var inc;
    if (globalConfig.allIncidentItems.length > 0) {
      for (var k = 0; k < globalConfig.allIncidentItems.length; k++) {
        if (id == globalConfig.allIncidentItems[k].id) {
          inc = globalConfig.allIncidentItems[k];
          break;
        }
      }
    }

    return inc;
  },
  //get incidents by id
  getFilteredIncidentsById: function (id) {
    var inc;
    if (globalConfig.allFilteredIncidentItems.length > 0) {
      for (var k = 0; k < globalConfig.allFilteredIncidentItems.length; k++) {
        if (id == globalConfig.allFilteredIncidentItems[k].id) {
          inc = globalConfig.allFilteredIncidentItems[k];
          break;
        }
      }
    }

    return inc;
  },
  //get assets by id
  getAssetById: function (id) {
    var asset;
    for (var j = 0; j < globalConfig.allAssetItems.length; j++) {
      if (id == globalConfig.allAssetItems[j].id) {
        asset = globalConfig.allAssetItems[j];
        break;
      }
    }

    return asset;
  },


  /*end controllers*/

  /*directive*/
  callFormsUI: function () {
    formsUI();
  },

  callPiechart: function (id, data) {
    $ui(document).ready(function () {
      /*create pie chart*/
      $('.dash-' + id + '-piechart').empty();
      $('.dash-' + id + '-piechart').removeClass('processed');
      pieChart(data, '.dash-' + id + '-piechart');
    });
  },
  /*end directive*/


}
