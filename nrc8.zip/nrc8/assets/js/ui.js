/*
 * jQuery Autolink
 * jQuery Automail
 *
 * @author Riccardo Mastellone
 * @description Two simple jQuery plugins to detect links (autolink) and email (automail) and make them clickable
 * @usage $(".contaier").automail().autolink();
 */
//(function($){
//       $.fn.automail = function() {
//               return this.each(function() {
//                       var re = /(([A-Za-z0-9*._+]){1,}\@(([A-Za-z0-9]+[-]?){1,}[a-z0-9]+\.){1,}([A-Za-z]{2,4}|museum)(?![\w\s?&.\/;#~%"=-]*>))/g;
//                   if( $(this).parents('a[href]').length == 0 )
//                       $(this).html($(this).html().replace(re, '<a href="mailto:$1">$1</a>'));
//               });
//       };
//
//
//   $(window).load(function(){
//      $(".article").automail(); 
//   });
//})($ui);

// Image caption creator from image title
var imageCaptions = function (selector) {
    (function ($) {
        $(selector).each(function () {
            $(this).wrap('<div class="image-wrap"></div>')
                .after('<div class="image-caption">' + $(this).attr('title') + '</div>');
        });
    })($ui);
};


(function ($) {
    $(window).load(function () {
        $(document).on('click', '#view .modal-header .close', function () {
            window.history.back();
        })
    });
})($ui);

(function ($) {
    $(window).load(function () {
        // $('#dashSlider').carousel({'interval':false});

    });
})($ui);

//Hide slider list in Phone when click logo
var hideSlideListInPhone = function () {
    if (window.matchMedia("(max-width: 480px)").matches) {
        //var triggerIntl = setInterval(function () {
        //    var trigger = $ui('#sideList > button.sideList-trigger');
        //    if (trigger != undefined && trigger.length) {
        //        $ui('#sideListWrap').removeClass('active');
        //        $ui('#sideList > button.sideList-trigger').removeClass('active');
        //        clearInterval(triggerIntl);
        //        triggerIntl = null;
        //    }
        //}, 200);

        globalConfig.hideSlideList();
    }
}

//stayopen is not in use any more but I keep it here. Maybe we can remove it when do code optimization.
var panelNav = function (selector, stayopen, isMobile) {
    (function ($) {
        $(document.body).on('click touch', selector + ' .nav-item .link, .nav-trigger  .link', function () {
            var resolution = 12300000;
            if (isMobile) {
                resolution = 768;
            }
            //make sure all of links are visible under side nav menu
            if ($(selector).attr("id") == 'headerNav') {
                $('#sideNavMenu').find(".nav-item .link").show();
            }

            if ($(window).width() <= resolution) {
                $link = $(this);
                $nav = $(selector);
                if ($link.is('[href]') == true)
                    $item = $link.parents('.nav-item');
                else
                    $item = $link.closest('.nav-item');
                $item.siblings().each(function () {
                    $(this).removeClass('active');
                    $(this).find('.nav-item').removeClass('active');
                })
                var timeoutID = window.setTimeout(function () {
                    if ($link.is('[href]')) {
                        $item.removeClass('active');
                    }
                    else {
                        $item.toggleClass('active');
                        currentLinks();
                    }
                }, 200);


            }

            //hide all of nav menus when dashboard displays in mobile mode
            if ($(window).width() <= 768 && $(selector).attr("id") == 'sideNavMenu') {
                $(selector).find(".nav-item .link").hide();
            }

        });

        $(document.body).on('mouseover', selector + ' .nav-item.dropdown', function () {
            if ($(window).width() > 992) {

                $item = $(this);
                $nav = $(selector);
                $item.on('mouseleave', function () {
                    $item.removeClass('active');
                })
                if ($item.hasClass('active') == false)
                    var timeoutID = window.setTimeout(function () {
                        $item.delay(1000).addClass('active');
                    }, 200);
            }
        })
    })($ui);
}

panelNav('.helper-nav', true);
panelNav('#rightNav');
panelNav('#headerNav', false, true);
panelNav('#sideNavMenu');
panelNav('#sideNavMenu', false, true); //This is used to fix on moble people and trave icon do not clickable bug.

var toggleActive = function (options) {
    if (typeof options != 'undefined') {
        (function ($) {
            options.trigger = typeof options.trigger == 'undefined' ? options.target + '-trigger' : options.trigger;

            $(document).on('click', options.trigger, function (e) {
                e.preventDefault();
                options.target = typeof options.target == 'undefined' ? $(this).attr('data-target') : options.target;
                $(options.target).toggleClass('active');
                $(this).toggleClass('active');

                if (options.target != '#sideListWrap') {
                    $(options.target).find('input').focus();
                }

                delete options.target;

                // for map side list only
                var mapSideListToggle = $(this).find('> i.fa');
                if (mapSideListToggle.length) {
                    if (mapSideListToggle.hasClass('fa-chevron-left')) {
                        mapSideListToggle.removeClass('fa-chevron-left').addClass('fa-chevron-right');
                    }
                    else {
                        mapSideListToggle.removeClass('fa-chevron-right').addClass('fa-chevron-left');
                    }
                }
            });

            if (window.matchMedia("(max-width: 480px)").matches) {
                var triggerIntl = setInterval(function () {
                    var $trigger = $('#sideList > button.sideList-trigger');
                    if ($trigger.length) {
                        $('#sideListWrap').removeClass('active');
                        $('#sideList > button.sideList-trigger').removeClass('active');
                        $('#sideList > button.sideList-trigger i.fa').removeClass('fa-chevron-left').addClass('fa-chevron-right');

                        clearInterval(triggerIntl);
                        triggerIntl = null;
                    }
                }, 200);
            }
        })($ui);
    }
}

$ui(window).load(function () {
    toggleActive({ 'trigger': '.toggleActive' });
    toggleActive({ 'trigger': '.sideList-trigger' });
});

// filters accordian
(function ($) {
    $(document).on('click', '.collapse-bar.toggleCollapse', function (e) {
        e.preventDefault();

        $target = $($(this).attr('data-target'));
        $elem = $(this);

        $target.toggleClass('active');
        $elem.toggleClass('active');
        if ($elem.hasClass('on')) {

            $target.removeClass('on');
            $elem.removeClass('on');
        }
        $ontimer = setTimeout(
            function () {
                if ($elem.hasClass('active')) {
                    $target.addClass('on');
                    $elem.addClass('on');
                }
            }, 1000);
    })
    //Aireplane:hide navigation message popup when click outside.
    $(document).on('mousedown touch', function (e) {
        //e.preventDefault();
        var target = $(e.target);
        //alert(target.closest(".paper-airplane").length);
        if (target.closest(".navigation-icon").length == 0 && target.closest(".navigation-icon-marker").length == 0) {
            //alert('1123');
            $(".navigation-icon").hide();
        }        
    })


})($ui);

//forms
var dateCache = {
    start: moment().subtract(30, 'days'),
    end: moment()
};
var formsUI = function () {
    (function ($) {
        //#region  date range slider and calendars
        //init
        $("#date-range-from").val(Date.parse(dateCache.start));
        $("#date-range-to").val(Date.parse(dateCache.end));
        //daterangeslider
        $("#daterangeslider").slider({
            range: true,
            min: dateCache.start,
            max: dateCache.end,
            values: [dateCache.start, dateCache.end],
            slide: function (event, ui) {
                var from = moment(ui.values[0]), to = moment(ui.values[1]);

                $("#date-range-from").val(ui.values[0]);
                $("#date-range-to").val(ui.values[1]);
                setDateRangePickerValues(from, to);
                setDateRangeSliderLabels(from, to);
                setDateCache(from, to);
            }
        });
        setDateRangeSliderLabels(dateCache.start, dateCache.end);
        //daterangepicker
        $('#daterangepicker').daterangepicker({
            startDate: dateCache.start,
            endDate: dateCache.end,
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb);
        //remove hover event on daterangepicker
        $('.calendar').off('mouseenter', 'td.available', $.proxy(this.hoverDate, this));
        $('.calendar').off('mouseleave', 'td.available', $.proxy(this.updateFormInputs, this));

        function cb(start, end) {
            setDateRangeSliderRange(start, end);

            $("#date-range-from").val(Date.parse(start));
            $("#date-range-to").val(Date.parse(end));
            setDateRangeSliderLabels(start, end);
            setDateRangeSliderValues(start, end);
            setDateCache(start, end);
        }
        var picker = $('#daterangepicker').data('daterangepicker');
        function setDateRangePickerValues(start, end) {
            if (start) picker.setStartDate(start);
            if (end) picker.setEndDate(end);
        }
        function setDateRangeSliderRange(min, max) {
            $("#daterangeslider").slider('option', 'min', min);
            $("#daterangeslider").slider('option', 'max', max);
        }
        function setDateRangeSliderValues(start, end) {
            $("#daterangeslider").slider('values', [start, end]);
        }
        function setDateRangeSliderLabels(start, end) {
            $("#daterangeslider .ui-slider-handle").first().text(start.format('M.D.YYYY'));
            $("#daterangeslider .ui-slider-handle").last().text(end.format('M.D.YYYY'));
        }
        function setDateCache(start, end) {
            dateCache.start = start;
            dateCache.end = end;
        }
        //#endregion

        //checkbox and radios
        $('.checkbox').each(function () {
            if ($(this).find('input').prop('checked') == true)
                $(this).addClass('checked')
        })

        function checkboxChange() {
            $('[name="' + $(this).attr('name') + '"]').closest('.checkbox').toggleClass('checked');
        }

        $(document).off('change', '.checkbox input');
        $(document).on('change', '.checkbox input', checkboxChange);

        //risk slider

        $("#riskrangeslider").slider({
            range: true,
            min: 0,
            max: 100,
            values: [25, 75],
            slide: function (event, ui) {
                //$( "#amount" ).val( ui.value );
            }
        });

        // select2 inpouts

        $('select.select2').select2();

        //bootstrap-select inputs

        $('.bootstrap-select').selectpicker({
            style: 'btn-info',
            size: 4
        });
    })($ui);
}


/// Charts
var pieChart = function (data, selector) {
    if ($ui(selector).hasClass('processed') == false) {
        $range = Array.isArray(data) && data.map(function (item) { return item.color; }) || ["#4f6677", "#7e878f", '#697e92', '#646e75', '#727272'];
        var width = 300,
            height = 320,
            radius = Math.min(width, height) / 2,
            outerRadius = radius - 50,
            innerRadius = radius - 110,
            labelRadius = radius - 50;

        var color = d3.scale.ordinal()
            .range($range);

        var arc = d3.svg.arc()
            .outerRadius(outerRadius)
            .innerRadius(innerRadius);

        var pie = d3.layout.pie()
            .sort(null)
            .value(function (d) { return d.value; });

        var svg = d3.select(selector).append("svg")
            .attr("width", width + 70)
            .attr("height", height + 50)
            .append("g")
            .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

        var g = svg.selectAll(".arc")
            .data(pie(data))
            .enter().append("g")
            .attr("class", "arc");

        g.append("path")
            .attr("d", arc)
            .style("fill", function (d) { return color(d.data.label); });

        var base = 10,
            length = data.length - 1;
        function offset(d, i) {
            var os = length - i;
            return (os > 1 ? os : 1) * base;
        }

        g.append('polyline')
            .attr({
                points: function (d, i) {
                    if (!d.value) return '0,0 0,0';

                    var pts = '',
                        centroid = arc.centroid(d),
                        angle = (d.startAngle + d.endAngle) / 2;

                    var x1 = centroid[0];
                    var x2 = Math.cos(Math.atan2(centroid[1], centroid[0])) * (labelRadius + offset(d, i));
                    var x3 = x2 + (angle > Math.PI ? -1 : 1) * offset(d, i);

                    var y1 = centroid[1];
                    var y2 = Math.sin(Math.atan2(centroid[1], centroid[0])) * (labelRadius + offset(d, i));

                    pts += x1 + ',' + y1 + ',' + x2 + ',' + y2 + ',' + x3 + ',' + y2;
                    return pts;
                }
            })
            .attr("stroke-width", "1")
            .attr('fill', 'none')
            .attr("stroke", function (d) { return color(d.data.label); });

        g.append("text")
            .attr("x", function (d, i) {
                var centroid = arc.centroid(d),
                    angle = (d.startAngle + d.endAngle) / 2,
                    midAngle = Math.atan2(centroid[1], centroid[0]);
                x = Math.cos(midAngle) * (labelRadius + offset(d, i)) + (angle > Math.PI ? -1 : 1) * offset(d, i) * 0.5;
                return x;
            })
            .attr("y", function (d, i) {
                centroid = arc.centroid(d);
                midAngle = Math.atan2(centroid[1], centroid[0]);
                y = Math.sin(midAngle) * (labelRadius + offset(d, i));
                return y;
            })
            .attr('text-anchor', function (d, i) {
                centroid = arc.centroid(d);
                midAngle = Math.atan2(centroid[1], centroid[0]);
                x = Math.cos(midAngle) * (labelRadius + offset(d, i));
                return (x > 0) ? "start" : "end";
            })
            .attr("class", "label")
            .attr('stroke', function (d) { return color(d.data.label); })
            .text(function (d) {
                if (!d.value) return '';
                return d.data.lineLabel || '';
            });

        if (data[0].label) {
            $output = '';
            $ui.each(data, function (i, v) {

                $output += '<li class="label' + v.label.replace(' ', '-').toLowerCase() + '" ><span style="background-color:' + $range[i] + '" class="marker"></span>' + v.label + '</li>';
            });

            $ui(selector).closest('.chart-wrap').find('.legend .list').html($output);
        }
        $ui(selector).addClass('processed');
    }
}

var lineChart = function (data, selector) {

    if ($ui(selector).hasClass('processed') == false) {
        var margin = { top: 20, right: 20, bottom: 30, left: 50 },
            width = $ui(selector).outerWidth() - margin.left - margin.right,
            height = $ui(selector).outerHeight() - margin.top - margin.bottom;

        var formatDate = d3.time.format("%d-%b-%y");

        var x = d3.time.scale()
            .range([0, width]);

        var y = d3.scale.linear()
            .range([height, 0]);

        var xAxis = d3.svg.axis()
            .scale(x)
            .orient("bottom")
            .innerTickSize(-height)
            .outerTickSize(-height)
            .tickPadding(10);

        var yAxis = d3.svg.axis()
            .scale(y)
            .orient("left")
            .innerTickSize(-width)
            .outerTickSize(-width)
            .tickPadding(10);

        var line = d3.svg.line()
            .x(function (d) { return x(formatDate.parse(d.date)); })
            .y(function (d) { return y(+d.value); });

        var area = d3.svg.area()
            .x(function (d) { return x(formatDate.parse(d.date)); })
            .y0(height)
            .y1(function (d) { return y(+d.value); });

        var svg = d3.select(selector).append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        x.domain(d3.extent(data, function (d) { return formatDate.parse(d.date); }));
        y.domain(d3.extent(data, function (d) { return +d.value; }));

        svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis);

        svg.append("g")
            .attr("class", "y axis")
            .call(yAxis)
            .append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", 6)
            .attr("dy", ".71em")
            .style("text-anchor", "end")
            .text("");

        svg.append("path")
            .datum(data)
            .attr("class", "line")
            .attr("d", line);

        svg.append("path")
            .datum(data)
            .attr("class", "area")
            .attr("d", area);

        // Add the scatterplot
        svg.selectAll("dot")
            .data(data)
            .enter().append("circle")
            .attr("r", 5)
            .attr("cx", function (d) { return x(formatDate.parse(d.date)); })
            .attr("cy", function (d) { return y(d.value); });

        function type(d) {
            d.date = formatDate.parse(d.date);
            d.close = +d.close;
            return d;
        }
        $ui(selector).addClass('processed');
    }
}

var barChart = function (data, selector) {

    var margin = { top: 20, right: 20, bottom: 30, left: 40 },
        width = $ui(selector).width() - margin.left - margin.right,
        height = $ui(selector).width() - margin.top - margin.bottom;

    var x = d3.scale.ordinal()
        .rangeRoundBands([0, width], .1);

    var y = d3.scale.linear()
        .range([height, 0]);

    var xAxis = d3.svg.axis()
        .scale(x)
        .orient("bottom");

    var yAxis = d3.svg.axis()
        .scale(y)
        .orient("left")
        .ticks(10, "%");

    var svg = d3.select(selector).append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    x.domain(data.map(function (d) { return d.label; }));
    y.domain([0, d3.max(data, function (d) { return +d.value; })]);

    svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis);

    svg.append("g")
        .attr("class", "y axis")
        .call(yAxis)
        .append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 6)
        .attr("dy", ".71em")
        .style("text-anchor", "end")
        .text("Value");

    svg.selectAll(".bar")
        .data(data)
        .enter().append("rect")
        .attr("class", "bar")
        .attr("x", function (d) { return x(d.label); })
        .attr("width", x.rangeBand())
        .attr("y", function (d) { return y(+d.value); })
        .attr("height", function (d) { return height - y(+d.value); });

    function type(d) {
        d.frequency = +d.frequency;
        return d;
    }
}

var scatterChart = function (data, selector) {
    //var data = [[5,3], [10,17], [15,4], [2,8]];
    console.log({ 'selecter': selector, 'data': data });

    var margin = { top: 20, right: 15, bottom: 60, left: 60 }
        , width = $ui(selector).outerWidth() - margin.left - margin.right
        , height = $ui(selector).outerWidth() - margin.top - margin.bottom;
    console.log(width);
    console.log(height);
    var x = d3.scale.linear()
        .domain([0, d3.max(data, function (d) { return d.value[0]; })])
        .range([0, width]);

    var y = d3.scale.linear()
        .domain([0, d3.max(data, function (d) { return d.value[1]; })])
        .range([height, 0]);

    var chart = d3.select(selector)
        .append('svg')
        .attr('width', width + margin.right + margin.left)
        .attr('height', height + margin.top + margin.bottom)
        .attr('class', 'chart')

    var main = chart.append('g')
        .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
        .attr('width', width)
        .attr('height', height)
        .attr('class', 'main')

    // draw the x axis
    var xAxis = d3.svg.axis()
        .scale(x)
        .orient('bottom');

    main.append('g')
        .attr('transform', 'translate(0,' + height + ')')
        .attr('class', 'main axis date')
        .call(xAxis);

    // draw the y axis
    var yAxis = d3.svg.axis()
        .scale(y)
        .orient('left');

    main.append('g')
        .attr('transform', 'translate(0,0)')
        .attr('class', 'main axis date')
        .call(yAxis);

    var g = main.append("svg:g");

    g.selectAll("scatter-dots")
        .data(data)
        .enter().append("svg:circle")
        .attr("cx", function (d, i) { return x(d.value[0]); })
        .attr("cy", function (d) { return y(d.value[1]); })
        .attr("r", 8);
}

var drawchart = function (data, selector) {
    console.log(selector);
    (function ($) {
        $(selector).each(function () {
            if ($(this).hasClass('piechart'))
                pieChart(data, selector + '.piechart');
            if ($(selector).hasClass('linechart'))
                lineChart(data, selector + '.linechart');
            if ($(selector).hasClass('barchart'))
                barChart(data, selector + '.barchart');
            if ($(selector).hasClass('scatterchart'))
                scatterChart(data, selector + '.scatterchart');
        })

    })($ui);
}

var draggableModal = function () {
    (function ($) {
        $(document).ready(function () {
            $(".modal-content").resizable();
            $(".modal-dialog").draggable({ axis: "y" });  //handle: ".modal-header",

            $('.modal-body').bind('mousedown', function () {
                $(this).parents('.modal-dialog').draggable("option", "axis", "");
                $(this).bind('mousemove', function () {
                    //$(this).parents('.modal-content').removeClass('snap'); 
                    $(this).unbind('mousemove, mousedown, mouseup');
                    $(this).bind('mouseup', function () {
                        $(this).parents('.modal-dialog').draggable("option", "axis", "y");
                        $(this).unbind('mousemove, mousedown, mouseup');
                    });
                })
                $(this).bind('mouseup', function () {
                    $(this).parents('.modal-dialog').draggable("option", "axis", "y");
                    $(this).bind('mouseup', function () {
                        $(this).parents('.modal-dialog').toggleClass('snap');
                        $(".modal-content").resizable();
                        $(".snap .modal-content").resizable("destroy").removeAttr('style');

                        $(this).unbind('mouseup, mouseup, mousemove');
                    });
                });
            });
        });

        $(document).ready(function () {

            scrollable('.modal-content');
        });

    })($ui);
}

// function to create custom scrolling object
// element with absolute position inside of an object with a set height
var scrollable = function (selector) {
    (function ($) {
        $(selector).each(function () {
            inittop = $(this).position().top;
            addWheelListener($(this)[0], function (e) {
                // DO NOT USE this keyword in this context, as the it will be changed to window context in Safari.
                var $scrollableElem = $(e.target).parents('.scrollable');

                e.preventDefault();
                min = $scrollableElem.parent().innerHeight() - $scrollableElem.outerHeight();
                //no need to scroll since no overflow
                if (min >= 0) return;

                scroll = e.deltaY > 0 ?
                    $scrollableElem.position().top - e.deltaY :
                    $scrollableElem.position().top + (Math.abs(e.deltaY));

                if (scroll <= inittop && scroll >= min) {
                    $scrollableElem.css({ 'top': scroll + "px" });
                } else {
                    if (scroll > inittop)
                        $scrollableElem.css({ 'top': inittop + "px" });
                    if (scroll < min)
                        $scrollableElem.css({ 'top': min + "px" });
                }
            });
        });
    })($ui);
}
$ui(window).load(function () {
    scrollable('.scrollable');
});

var closeButton = function (selector) {
    (function ($) {
        $(document).on('click', selector, function () {
            $(this).parents('.active').removeClass('active');
        })
    })($ui);
}
closeButton('.close-button');

var currentLinks = function () {
    (function ($) {
        url = String(window.location);
        url = url.split("#");
        current = url[1];
        $('a').each(function () {
            link = String($(this).attr('href'));
            link = link.replace('#', '/');
            if (current == link || (current == '/map' && link == '/')) {
                // console.log( current + '?' + link );
                $(this).addClass('current')
            } else {
                $(this).removeClass('current');
            }

        });
    })($ui);
}

//just for test
$ui(window).load(function () {
    currentLinks();
});

window.addEventListener("orientationchange", function () {
    globalConfig.isDockPopupMode = globalConfig.needDockPopup();
});